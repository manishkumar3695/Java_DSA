package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.List;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.*;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementClick;
import static com.croma.automationqa.util.CommonUtil.numericValuesExtractionMethod;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;

//import static com.croma.automationqa.util.CommonUtil.productComparisonNumberExtractValidation;
//import static com.croma.automationqa.util.CommonUtil.productComparisonValidation;


/*
    All the wishlist related function defined in CromaWishListPageStepDef class
*/
public class CromaWishListPageStepDef {


    /*
         User removes all the products from the wishlist
    */
    @Then("^user removes all the wishlist products$")
    public void userRemovesAllTheWishlistProducts() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));

        Thread.sleep(6000);
        int wishListIndexValueOne = 1, wishListIndexValueZero = 0;
        List<WebElement> productListAvailableInWishList = getDriver().findElements(By.xpath(getLocator("productListOnWishListPage")));
        logger.info("Wishlist size is: " + productListAvailableInWishList.size());
        // actionMoveToElementClick(getElement("mywishlist"));
        //  getElement("mywishlist").click();
        getDriver().navigate().refresh();
        if (productListAvailableInWishList.size() > wishListIndexValueZero) {
            for (int i = wishListIndexValueOne; i <= productListAvailableInWishList.size(); i++) {
                // conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cleanUpWishListDeleteButton", String.valueOf(1))), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
                logger.info("Product button to be deleted: " + getElement("cleanUpWishListDeleteButton", String.valueOf(1)));
                getElement("cleanUpWishListDeleteButton", String.valueOf(1)).click();
                getElement("clickOnProceedButton").click();
                Thread.sleep(5000);
            }
        }
        processScreenshot();
        assertStepExecution(true, getOptionalElement("emptyWishlist").isDisplayed(),
                "Oops! Your wishlist looks empty");
    }


    /*
         User validates as number of products and as products names in wishlist page
    */
    @And("^user validates \"([^\"]*)\" as number of products, \"([^\"]*)\" as products names, \"([^\"]*)\" as products ids, \"([^\"]*)\" as products mrps, \"([^\"]*)\" as products discounts, \"([^\"]*)\" as product rating, \"([^\"]*)\" as product review in wishlist page$")
    public void userValidatesAsNumberOfProductsAndAsProductsNamesInWishlistPage(String wishListProductsCounts, String wishListProductsNames, String wishListProductsIds, String wishListProductsIndividualMRP, String wishListProductsIndividualDiscount, String wishListProductsIndividualRating, String wishListProductsIndividualReview) {
        String splitOption = ";", comparisonOrder = "ReverseOrder";
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));

        List<WebElement> productAvailable = getElements("productCountListWishListPage");
        logger.info("No of products are: " + productAvailable.size() + " and " + "Counts from DB:" + wishListProductsCounts);

        List<String> itemListWishListProductName = generatingProductDetailsListThroughCount(wishListProductsCounts, wishListProductsNames, splitOption);
        logger.info("itemListWishListProductName is: " + itemListWishListProductName);

        List<String> itemListWishListProductIds = generatingProductDetailsListThroughCount(wishListProductsCounts, wishListProductsIds, splitOption);
        logger.info("itemListWishListProductIDs is: " + itemListWishListProductIds);

        List<String> itemListWishListProductIndividualMRP = generatingProductDetailsListThroughCount(wishListProductsCounts, wishListProductsIndividualMRP, splitOption);
        logger.info("itemListWishListProductIndividualMRP is: " + itemListWishListProductIndividualMRP);

        List<String> itemListWishListProductIndividualDiscount = generatingProductDetailsListThroughCount(wishListProductsCounts, wishListProductsIndividualDiscount, splitOption);
        logger.info("itemListWishListProductIndividualDiscount is: " + itemListWishListProductIndividualDiscount);

        List<String> itemListWishListProductIndividualRating = generatingProductDetailsListThroughCount(wishListProductsCounts, wishListProductsIndividualRating, splitOption);
        logger.info("itemListWishListProductIndividualRating is: " + itemListWishListProductIndividualRating);

        List<String> itemListWishListProductIndividualReview = generatingProductDetailsListThroughCount(wishListProductsCounts, wishListProductsIndividualReview, splitOption);
        logger.info("itemListWishListProductIndividualReview is: " + itemListWishListProductIndividualReview);

        List<WebElement> productIdsAvailable = getElements("productIDListWishList");
        List<WebElement> productReviewAvailable = getElements("productReviewWishList");

        // For MRP
        ArrayList<String> productMRPList = new ArrayList<String>();
        for (int i = 1; i <= Integer.parseInt(wishListProductsCounts); i++) {
            List<WebElement> productMRPListWebElements = getDriver().findElements(By.xpath(getLocator("productIndividualMRPListWishList", String.valueOf(i))));
            if (productMRPListWebElements.size() > 0) {
                productMRPList.add(productMRPListWebElements.get(0).getText());
            } else
                productMRPList.add("NA");
        }

        // For capturing discount of a product
        ArrayList<String> productDiscountList = new ArrayList<String>();
        for (int i = 1; i <= Integer.parseInt(wishListProductsCounts); i++) {
            List<WebElement> productDiscountListWebElements = getDriver().findElements(By.xpath(getLocator("productIndividualDiscountListWishList", String.valueOf(i))));
            if (productDiscountListWebElements.size() > 0) {
                productDiscountList.add(productDiscountListWebElements.get(0).getText());
            } else
                productDiscountList.add("NA");
        }

        // For capturing rating of a product
        ArrayList<String> productRating = new ArrayList<String>();
        for (int i = 1; i <= Integer.parseInt(wishListProductsCounts); i++) {
            List<WebElement> productRatingWebElements = getDriver().findElements(By.xpath(getLocator("productRatingWishList", String.valueOf(i))));
            if (productRatingWebElements.size() > 0) {
                productRating.add(productRatingWebElements.get(i - 1).getAttribute("aria-label"));
            } else
                productRating.add("NA");
        }

        assertStepExecution(wishListProductsCounts, String.valueOf(productAvailable.size()),
                "Total product name count is matching in wishList page");
        productComparisonValidation(productAvailable, itemListWishListProductName, comparisonOrder);
        productComparisonNumberExtractValidation(productIdsAvailable, itemListWishListProductIds, comparisonOrder);
        productComparisonValidation(productMRPList, itemListWishListProductIndividualMRP, comparisonOrder);
        productComparisonValidation(productDiscountList, itemListWishListProductIndividualDiscount, comparisonOrder);
        productComparisonNumberExtractValidation(productReviewAvailable, itemListWishListProductIndividualReview, comparisonOrder);
        productComparisonValidation(productRating, itemListWishListProductIndividualRating, comparisonOrder);
    }


    @And("^user validates \"([^\"]*)\" as number of products and \"([^\"]*)\" as products names in wishlist page$")
    public void userValidatesAsNumberOfProductsAndAsProductsNamesInWishlistPage(String wishListProductsCounts, String wishListProductsNames) throws InterruptedException {
        String splitOption = ";", comparisonOrder = "ForwardOrder";
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
        List<String> itemListWishListProductName = generatingProductDetailsListThroughCount(wishListProductsCounts, wishListProductsNames, splitOption);
        logger.info("itemListWishListProductName is: " + itemListWishListProductName);
        List<WebElement> productAvailable = getElements("productCountListCartWishListPage");
        logger.info("No of products are: " + productAvailable.size() + "and " + "Counts from DB:" + wishListProductsCounts);

        logger.info("No of products are: " + productAvailable.size() + " and " + "Counts from DB:" + wishListProductsCounts);


        logger.info("itemListWishListProductName is: " + itemListWishListProductName);

        assertStepExecution(wishListProductsCounts, String.valueOf(productAvailable.size()),
                "Total product name count is not matching in order confirmation page");
        productComparisonValidation(productAvailable, itemListWishListProductName, comparisonOrder);
    }

    /*
             User validates as number of products and as products names in wishlist page
     */
    @And("^user clicks move to cart \"([^\"]*)\" from wishlist page and validates the pop up message$")
    public void userClicksMoveToCartFromWishlistPageAndValidatesThePopUpMessage(String itemIndex) {
        String popUpMessage = "Product added to cart successfully!";
        //  processScreenshot();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("moveToCartFromWishList", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("wishlistPageTitle").click();
        getElement("moveToCartFromWishList", itemIndex).click();
//        conditionalWait(ExpectedConditions.visibilityOf(getElement("popUpAddToCartMessage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
//        logger.info("Add to cart popup message on wish list page is: " + getElement("popUpAddToCartMessage").getText());
//        assertStepExecution(popUpMessage, getElement("popUpAddToCartMessage").getText(), "Popup message is not matched");
    }


    /*
         User clicks on product name from wish list page and lands on product definition page
    */
    @And("^user clicks on product name \"([^\"]*)\" and lands on product definition page$")
    public void userClicksOnProductNameAndLandsOnProductDefinitionPage(String itemIndex) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
        logger.info("Index " + itemIndex);
        processScreenshot();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("wistListProductName", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("wistListProductName", itemIndex).click();
    }

    @And("^user validates \"([^\"]*)\" as number of products, \"([^\"]*)\" as products names, \"([^\"]*)\" as products id, \"([^\"]*)\" as products prices, \"([^\"]*)\" as products mrp, \"([^\"]*)\" as products reviews, \"([^\"]*)\" as products ratings in wishlist page$")
    public void userValidatesAsNumberOfProductsAsProductsNamesAsProductsIdAsProductsPricesAsProductsMrpAsProductsReviewsAsProductsRatingsInWishlistPage(String wishlistTotalProductCount, String wishListProductNames, String wishListProductIds, String wishListProductPrices, String wishListProductMrpPrices, String wishListProductReviews, String wishListProductStars) {
        String splitOption = ";", comparisonOrder = "ForwardOrder";
        logger.info("The selected products on Wishlist : " + wishlistTotalProductCount + "name " + wishListProductNames + " " + "id" + wishListProductIds + " " + "price" + wishListProductPrices + " " + "discounted price" + wishListProductMrpPrices + "Review " + wishListProductReviews + "Star" + wishListProductStars);
        // name
        List<String> itemListWishListProductName = generatingProductDetailsListThroughCount(wishlistTotalProductCount, wishListProductNames, splitOption);
        logger.info("itemListWishListProductName is: " + itemListWishListProductName);
        List<WebElement> productAvailable = getElements("productCountListWishListPage");
        logger.info("No of products are: " + productAvailable.size() + "and " + "Counts from DB:" + wishlistTotalProductCount);
        assertStepExecution(wishlistTotalProductCount.toLowerCase(), String.valueOf(productAvailable.size()).toLowerCase(), "Total product name count is not matching in order confirmation page");
        productComparisonValidation(productAvailable, itemListWishListProductName, comparisonOrder);

        if ((!(wishListProductIds.equalsIgnoreCase("NA"))) && (!(wishListProductPrices.equalsIgnoreCase("NA"))) && (!(wishListProductReviews.equalsIgnoreCase("NA"))) && (!(wishListProductStars.equalsIgnoreCase("NA")))) {
            List<String> itemListWishListProductIds = generatingProductDetailsListThroughCount(wishlistTotalProductCount, wishListProductIds, splitOption);
            logger.info("itemListWishListProductIds is: " + itemListWishListProductIds);
            List<String> itemListWishListProductPrices = generatingProductDetailsListThroughCount(wishlistTotalProductCount, wishListProductPrices, splitOption);
            logger.info("itemListWishListProductPrices is: " + itemListWishListProductPrices);
            List<String> itemListWishListProductMrp = generatingProductDetailsListThroughCount(wishlistTotalProductCount, wishListProductMrpPrices, splitOption);
            logger.info("itemListWishListProductMrp is: " + itemListWishListProductMrp);
            List<String> itemListWishListProductReview = generatingProductDetailsListThroughCount(wishlistTotalProductCount, wishListProductReviews, splitOption);
            logger.info("itemListWishListProductReview is: " + itemListWishListProductReview);
            List<String> itemListWishListProductStar = generatingProductDetailsListThroughCount(wishlistTotalProductCount, wishListProductStars, splitOption);
            logger.info("itemListWishListProductStar is: " + itemListWishListProductStar);

            List<WebElement> productIdsAvailable = getElements("productIDListWishListPage");
            List<WebElement> productPricesAvailable = getElements("productPriceListWishListPage");


            // For Ratings
            ArrayList<String> productRatingsAvailable = new ArrayList<String>();
            // For Reviews
            ArrayList<String> productReviewsAvailable = new ArrayList<String>();
            // For MRP
            ArrayList<String> productMRPList = new ArrayList<String>();


            for (int i = 1; i <= Integer.parseInt(wishlistTotalProductCount); i++) {
                logger.info("Wishlist counter :" + i);
                // For Ratings
                productRatingsAvailable.add(String.valueOf(numericValuesExtractionMethod((getElement("productRatingsListWishListPage", String.valueOf(i))).getAttribute("aria-label"))));
                logger.info("Ratings :" + (String.valueOf(numericValuesExtractionMethod((getElement("productRatingsListWishListPage", String.valueOf(i))).getAttribute("aria-label")))));

                // For Reviews
                productReviewsAvailable.add(String.valueOf(numericValuesExtractionMethod((getElement("productReviewsListWishListPage", String.valueOf(i))).getText())));
                logger.info("Ratings :" + (String.valueOf(numericValuesExtractionMethod((getElement("productReviewsListWishListPage", String.valueOf(i))).getAttribute("aria-label")))));

                // For MRP
                List<WebElement> productMRPListWebElements = getDriver().findElements(By.xpath(getLocator("productIndividualMRPListWishListPage", String.valueOf(i))));
                if (productMRPListWebElements.size() > 0) {
                    logger.info("productMRPList :" + i);
                    productMRPList.add(productMRPListWebElements.get(0).getText());
                } else
                    productMRPList.add("NA");
            }

            productComparisonNumberExtractValidation(productIdsAvailable, itemListWishListProductIds, comparisonOrder);
            productComparisonValidation(productPricesAvailable, itemListWishListProductPrices, comparisonOrder);
            productComparisonValidation(productMRPList, itemListWishListProductMrp, comparisonOrder);
            productComparisonValidation(productReviewsAvailable, itemListWishListProductReview, comparisonOrder);
            productComparisonValidation(productRatingsAvailable, itemListWishListProductStar, comparisonOrder);
        }
    }

    @And("^user delete the product \"([^\"]*)\" from the wishlist page$")
    public void userDeleteTheProductFromTheWishlistPage(String wishListProduct) throws InterruptedException {
        userClicksOnMenuIconAndCloseIt();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("wishListDeleteProduct", wishListProduct)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("wishListDeleteProduct", wishListProduct) != null, "user delete the product");
        getElement("wishListDeleteProduct", wishListProduct).click();
        Thread.sleep(4000);
        getElement("wishListDeleteYesButton").click();
        Thread.sleep(4000);
    }

    @And("^user validates empty wishlist page$")
    public void userValidatesEmptyWishlistPage() {
        String emptyWighlistTextUI = "Oops! Your wishlist looks empty";
        assertStepExecution(emptyWighlistTextUI.toLowerCase(), getElement("emptyWishlistText").getText().toLowerCase(), "Empty Wishlist Text is not matching");
    }

    @And("user verifies {string} is present in my wishlist page")
    public void userVerifiesIsPresentInMyWishlistPage(String productId) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getElement("productIdsFromWishistPage").getText().contains(productId),
                "user verifies " + productId + " is present in my wishlist page");
    }
}