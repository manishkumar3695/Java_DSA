package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.List;

import static com.croma.automationqa.stepDefinitions.CromaHomePageStepDef.categoriesFromHome;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementBuild;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.windowScrollIntoTopToBottom;
import static com.croma.automationqa.util.JavaScriptUtil.windowScrollIntoViewAdjustment;
import static org.assertj.core.api.Assertions.assertThat;

public class CromaSearchResultPageStepDef {

    @And("user lands on search result page having no result {string}")
    public void userLandsOnSearchResultPageHavingNoResult(String searchedResultStatement) {

        String searchedResultTextFromWEb = getElement("searchedResultText").getText();
        assertStepExecution(searchedResultStatement, searchedResultTextFromWEb, "User validates the searched result text");
    }

    @And("user verifies no result found image on search result page")
    public void userVerifiesNoResultFoundImageOnSearchResultPage() {
        WebElement ele = getElement("image");
        String src = ele.getAttribute("src");
        logger.info("Src attribute is: " + src);
        assertStepExecution(true, src.contains(".png"), "User validates the No result found image");

    }

    @And("user verifies the text messages {string}, {string} in search result page")
    public void userVerifiesTheTextMessagesInSearchResultPage(String textMessage1, String textMessage2) {
        assertThat(getElement("noResultText1").getText()).describedAs("User validates the text1").isEqualToIgnoringCase(textMessage1);
        assertThat(getElement("noResultText2").getText()).describedAs("User validates the text1").isEqualToIgnoringCase(textMessage2);
        passStepExecution("Both the text is present in search result page.");


    }

    @And("user verifies the {string} on search result page")
    public void userVerifiesTheOnSearchResultPage(String shopSafelyWithCromaMessage) {
        assertStepExecution(shopSafelyWithCromaMessage, getElement("shopSafelyWithCromaText").getText(), "User validates shop safely with croma message on search result page");
    }

    @And("user Verifies all shop by categories widget on search result page as per home page")
    public void userVerifiesAllShopByCategoriesWidgetOnSearchResultPageAsPerHomePage() {
        List<WebElement> element = getElements("searchResultPageShopByCategoriesWidget");
        ArrayList<String> categoriesFromSearchPage = new ArrayList<>();
        logger.info("Total size of elements are:" + element.size());
        for (int i = 0; i < element.size(); i++) {
            categoriesFromSearchPage.add(element.get(i).getText());
        }
        logger.info("The categories from search page is " + categoriesFromSearchPage);
            for (int j = 0; j < categoriesFromHome.size(); j++) {
                assertThat(categoriesFromSearchPage).describedAs("Categories on home and search result page is same").contains(categoriesFromHome.get(j));
            }
            passStepExecution("user Verifies all shop by categories widget on search result page as per home page");


        }

    @And("user clicks on {string} on search result page")
    public void userClicksOnOnSearchResultPage(String shopByCategoryOption) throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true,getOptionalElement("shopByCategoryOption",shopByCategoryOption)!=null,"User verifies shop by category option");
        Thread.sleep(5000);
        getElement("shopByCategoryOption",shopByCategoryOption).click();


    }

    @Then("^user verifies \"([^\"]*)\" section is present in the search result page$")
    public void userVerifiesSectionIsPresentInTheSearchResultPage(String sectionName) {
        int homePageScrollUpFirstIndex = 150;
        int homePageScrollDownFirstIndex = 0;
        windowScrollIntoTopToBottom();
        windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpFirstIndex);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("carouselLinks", sectionName)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        actionMoveToElementBuild(getElement("carouselLinks", sectionName));
        assertStepExecution(true, getOptionalElement("anyHeaderSectionInSearchResultPage", sectionName) != null,
                "user verify " + sectionName + " section is present in the search result page");
    }
}

