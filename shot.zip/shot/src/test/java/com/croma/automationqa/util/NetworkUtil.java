package com.croma.automationqa.util;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.croma.automationqa.util.CromaLoggerUtil.logger;

public class NetworkUtil {

    static WebDriver driver = null;

    public static void parseLog(String url) {

        try {
            String logContent = FileUtils.readFileToString(DriverUtil.tempFile);


            // this is how the log looks like when the request starts
            // I have to get the id of the request using a regular expression
            // and use that id later to get the response
            //
            //    2017-11-02 14:14:01.170000 UTC - [Main Thread]: D/nsHttp nsHttpChannel::BeginConnect [this=000000BFF27A5000]
            //    2017-11-02 14:14:01.170000 UTC - [Main Thread]: D/nsHttp host=api.ipify.org port=-1
            //    2017-11-02 14:14:01.170000 UTC - [Main Thread]: D/nsHttp uri=https://api.ipify.org/?format=text
            String pattern = "BeginConnect \\[this=(.*?)\\](?:.*?)uri=(.*?)\\s";

            Pattern p = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            Matcher m = p.matcher(logContent);
            String urlID = null;
            while (m.find()) {
                String id = m.group(1);
                String uri = m.group(2);

                if (uri.contains(url)) {
                    urlID = id;
                    //break;   // Not keeping break as we want to note the last occurance
                }
            }

            logger.info("request id = " + urlID);

            // this is how the response looks like in the log file
            // ProcessResponse [this=000000CED8094000 httpStatus=200]
            // I will use another regular espression to get the httpStatus
            //
            //    2017-11-02 14:45:39.296000 UTC - [Main Thread]: D/nsHttp nsHttpChannel::OnStartRequest [this=000000CED8094000 request=000000CED8014BB0 status=0]
            //    2017-11-02 14:45:39.296000 UTC - [Main Thread]: D/nsHttp nsHttpChannel::ProcessResponse [this=000000CED8094000 httpStatus=200]

            pattern = "ProcessResponse \\[this=" + urlID + " httpStatus=(.*?)\\]";

            p = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
            m = p.matcher(logContent);

            if (m.find()) {
                String responseCode = m.group(1);
                logger.info("response code found " + responseCode);
            } else {
                logger.info("response code not found");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
