package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.croma.automationqa.util.AssertUtil.*;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementClick;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.ElementUtil.getElements;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;

public class CromaBrandPageStepDef {

    public static ArrayList<String> categoriesFromBrand = new ArrayList<>();

    private final int brandPageConditionFirstValue = 1;

    JavascriptExecutor js = (JavascriptExecutor) getDriver();

    @Then("^user lands on \"([^\"]*)\" brand page having \"([^\"]*)\" in current URL$")
    public void userLandsOnBrandPageHavingInCurrentURL(String brandName, String brandCode) {

        String stepDescription = "user lands on " + brandName + " brand page having " + brandCode + " in current URL";
        String brandNameOnThePage = getElement("brandTitle").getText();

        assertThat(brandNameOnThePage).isEqualTo(brandName)
                .describedAs("Brand name should be present in the header");

        String currentPageURL = getDriver().getCurrentUrl();
        assertThat(currentPageURL).containsIgnoringCase(brandCode)
                .describedAs("Current URL should contain Brand Code");
//        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
//        String brandLogoSrc = getElement("brandLogoImg").getAttribute("src");
//
//        assertThat(brandLogoSrc).startsWith("https://media.croma.com/").
//                describedAs("Brand Image SRC should starts with https://media.croma.com/");

        passStepExecution(stepDescription + " :: Passed \n");

    }


    @And("user validates {string} product is present in brand page")
    public void userValidatesProductIsPresentInBrandPage(String brandProductName) {
        windowScrollIntoViewByWebElement(getElement("brandPageProductName"));
        String productOnBrandPage = getElement("brandPageProductName").getText().trim();
        logger.info("The product on pdp is" + productOnBrandPage + "The product from db:" + brandProductName);
        assertStepExecution(true, productOnBrandPage.equalsIgnoreCase(brandProductName), "Product name are matching in Brand page");

    }

    @And("user validates {string} product id is present in brand page")
    public void userValidatesProductIdIsPresentInBrandPage(String productId) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String productIdFromWeb = getElement("brandPageProductId").getText().trim().replace("PRODUCT ID: ", "");
        logger.info(productIdFromWeb);
        assertStepExecution(true, productIdFromWeb.equals(productId), "user validate product id is present in brand page");

    }

    @And("user validates {string} review and rating is present in brand page")
    public void userValidatesReviewAndRatingIsPresentInBrandPage(String brandProductName) {
        assertThat(getElement("brandPageReviewAnaRating", brandProductName).isDisplayed());
        logger.info("Rating and review count is: " + getElement("brandPageReviewAnaRating", brandProductName).getText() + getElement("brandPageReview", brandProductName).getText());
        assertThat(getElement("brandPageReviewAnaRating", brandProductName).getText().contains("Ratings"));
        assertThat(getElement("brandPageReviewAnaRating", brandProductName).getText().contains("Reviews)"));
        passStepExecution("User validates review and rating is present in brand page");
    }

    @And("user validates {string} product price is present in brand page")
    public void userValidatesProductPriceIsPresentInBrandPage(String brandProductPrice) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("The product price on pdp is" + getElement("brandPageMrp").getText());
        assertStepExecution(true, getElement("brandPageMrp").getText().equalsIgnoreCase(brandProductPrice),
                "user validates product price is present in brand page");
    }

    @And("user validates {string} product strike price is present in brand page")
    public void userValidatesProductStrikePriceIsPresentInBrandPage(String brandPageStrikeMrp) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("The product price on pdp is" + getElement("brandStrikeOfMrp").getText());
        assertStepExecution(true, getElement("brandStrikeOfMrp").getText().equalsIgnoreCase(brandPageStrikeMrp),
                "user validates product strike price is present in brand page");
    }

    @And("user validates key features is present in brand page")
    public void userValidatesKeyFeaturesIsPresentInBrandPage() {
        assertStepExecution(true, getElement("brandPageKeyFeature") != null, "brandPageKeyFeatures");
        logger.info("key feature description on the brand page" + getElement("brandPageKeyFeatureDescription").getText());


    }

    @And("user hovers all images in brand page")
    public void userHoversAllImagesInBrandPage() throws InterruptedException {
        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME")) {
            Thread.sleep(3000);
            int brandPageConditionSecondValue = 2, brandPageConditionThirdValue = 3;
     //      actionMoveToElementClick(getElement("brandProductImage"));
            List<WebElement> pdpImagesList = getElements("brandImagesListXPath");
            logger.info("No of Images are: " + pdpImagesList.size());
            if (pdpImagesList.size() > brandPageConditionFirstValue) {
                for (int i = 1; i <= pdpImagesList.size(); i++) {
                    processScreenshot();
                    actionMoveToElementClick(getElement("brandImagesXPath", String.valueOf(i)));
                    if (i >= 3 && i <= (pdpImagesList.size() - 1)) {
                        windowScrollIntoViewAdjustment_scroll(0, 500);
                    jsClick(getElement("clickOnNextButton"));
                    }
                }
            }
            processScreenshot();
        } else if (getConfig("Browser").trim().equalsIgnoreCase("EMULATED_CHROME")) {
            List<WebElement> paginationBullet = getElements("swiperPaginationBullet");
            logger.info("No of Images are: " + paginationBullet.size());
            for (WebElement webElement : paginationBullet) {
                webElement.click();
            }
            processScreenshot();

        }
    }

    @And("user clicks on the particular product in brand page")
    public void userClicksOnThePerticulerProductInBrandPage() {
        windowScrollIntoViewByWebElement(getElement("brandPageProduct"));
        assertStepExecution(true, getElement("brandPageProduct")!=null,
                "user validates user clicks on the item from brand page it should land on PDP page");
        getElement("brandPageProduct").click();
    }
}
