package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementClick;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;


/*
   All the compare page related function defined in CromaProductComparePageStepDef class
*/
public class CromaProductComparePageStepDef {

    private final int comparePageScrollDownFirstIndex = 0,comparePageScrollDownLastIndex = 400;
    JavascriptExecutor js = (JavascriptExecutor) getDriver();

    /*
        user lands on compare page with product comparison details and clicks on product information tab in product comparison page
    */
    @And("^user lands on compare page with product comparison details and clicks on product information tab in product comparison page$")
    public void userLandsOnComparePageWithProductComparisonDetailsAndClicksOnProductInformationTabInProductComparisonPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        windowScrollIntoViewByWebElement(getElement("getProductDetails"));
        windowScrollIntoViewAdjustment(comparePageScrollDownFirstIndex, comparePageScrollDownLastIndex);
        processScreenshot();
        logger.info("Title of the product details in compare page is: " + getElement("getProductDetails").getText());
        List<WebElement> compareProductDetailsList = getElements("compareProductDetailsListXPath");
        logger.info("No of Product details are: " + compareProductDetailsList.size());
        windowScrollIntoViewAdjustment(comparePageScrollDownFirstIndex, comparePageScrollDownLastIndex);
        for (int i = 1; i <= compareProductDetailsList.size(); i++) {
            processScreenshot();
            logger.info("Product details name is: " + getElement("compareProductDetailsName", String.valueOf(i)).getText());
            actionMoveToElementClick(getElement("compareProductDetailsXPath", String.valueOf(i)));
            windowScrollIntoViewAdjustment(comparePageScrollDownFirstIndex, comparePageScrollDownLastIndex);
        }
        processScreenshot();
    }


    /*
        user closes the products comparison in product comparison page
    */
    @Then("^user closes the products comparison in product comparison page$")
    public void userClosesTheProductsComparisonInProductComparisonPage() throws InterruptedException {
        Thread.sleep(5000);
        getDriver().navigate().refresh();
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        List<WebElement> productList = getDriver().findElements(By.xpath(getLocator("compareProductCrossBtn")));
        logger.info("No of products are: " + productList.size());
        int counter = 1;
        while (productList.size() > 0 && counter!=10) {
           // waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
            js.executeScript("window.scrollBy(0,5000)");
            getElement("compareProductCrossBtn").click();
            waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
            productList = getDriver().findElements(By.xpath(getLocator("compareProductCrossBtn")));
            logger.info("After deleting 1st product in compare page, no of products are: " + productList.size());
            counter++;
        }
        assertStepExecution(0, productList.size(), "user removes all the products from compare page");
    }

    @And("^user validate the \"([^\"]*)\" fifth product by clicking on right arrow$")
    public void userValidateTheFifthProductByClicksOnRightArrow(String CompareProdName) {
        String stepDescription = "user validate the fifth product by clicks on right arrow";


        while (getDriver().findElements(By.xpath(getLocator("rightArrow"))).size() !=0){
            getElement("rightArrow").click();
        }

        assertThat(getElement("compareProductName", CompareProdName).isDisplayed()
        ).describedAs("Fifth product successfully displayed").isEqualTo(true);

        logger.info("product name:"+getElement("compareProductName", CompareProdName).getText()+ " product price: +"+getElement("compareProductPrice",CompareProdName).getText()+ "product id:+ "+getElement("compareProductId",CompareProdName).getText());
        passStepExecution(stepDescription + " :: Passed \n");


    }

    @And("^user validate the \"([^\"]*)\" second product by clicking on left arrow$")
    public void userValidateTheSecondProductByClicksOnLeftArrow(String CompareProdName2) {
        String stepDescription = "user validate the second product by clicks on left arrow";

        while (getDriver().findElements(By.xpath(getLocator("leftArrow"))).size() !=0){
            getElement("leftArrow").click();
        }

        assertThat(getElement("compareProductName", CompareProdName2).isDisplayed()
        ).describedAs("Second product successfully displayed").isEqualTo(true);
        passStepExecution(stepDescription + " :: Passed \n");
        logger.info("Pass 1");

    }

    @And("^user not able to add product from comparison page as there is no such option to add product$")
    public void userNotAbleToProductFromAsThereAreNotGettingAnyOptionToAddProduct() {
        assertStepExecution(false, getOptionalElement("compareBox") != null,
                "Compare check box not present");

    }


    @And("user checks compare tray should open")
    public void userChecksCompareTrayShouldOpen() {
        assertStepExecution(true, getOptionalElement("compareTray") != null,
                "Compare tray not present");
    }


    @And("user validates alert window should open with the error message {string} when more than five items are being added for compare")
    public void userValidatesAlertWindowShouldOpenWithTheErrorMessageWhenMoreThanFiveItemsAreBeingAddedForCompare(String errorMsg) throws InterruptedException {
        Alert alert=getDriver().switchTo().alert();
        String alertMessage= alert.getText().trim();
        logger.info("Error msg is"+alertMessage);
        alert.accept();
        assertStepExecution(errorMsg,alertMessage,"Error message is not matching");
    }

    @And("user validates the error massage {string} should display when tries to add item from different category")
    public void userValidatesTheErrorMassageShouldDisplayWhenTriesToAddItemFromDifferentCategory(String compareErrorMsg) {
     String compareErrorMsgDifferentCategory=getElement("compareErrorMsgDifferentCategory").getText().trim();
     logger.info("Compare error msg for different categoty is "+ compareErrorMsgDifferentCategory);
     assertStepExecution(compareErrorMsg,compareErrorMsgDifferentCategory,"Error message is not matching");
     if((getConfig("Browser").equalsIgnoreCase("CHROME")))
     getElement("buyOnCallPopUpClose").click();
    }

    @And("user validates the {string} is present in product comparison page")
    public void userValidatesTheIsPresentInProductComparisonPage(String compareProduct) {
        List<WebElement> compareProductDetailsList = getElements("compareProductAddedListXPath");
        logger.info("No of Product details are: " + compareProductDetailsList.size());
        for (int i = 1; i <= compareProductDetailsList.size(); i++) {
            processScreenshot();
            logger.info("Product details name is: " + getElement("compareProductNameInComparisonPage", String.valueOf(i)).getText()+"Product Price:"+getElement("compareProductPriceInComparisonPage",String.valueOf(i)).getText()+"Product Id:"+getElement("compareProductIdInComparisonPage",String.valueOf(i)).getText());
            if(getElement("compareProductNameInComparisonPage", String.valueOf(i)).getText().equals(compareProduct))
            {
                assertStepExecution(compareProduct,getElement("compareProductNameInComparisonPage", String.valueOf(i)).getText(),"Product is present");
                break;
            }
        }
        processScreenshot();

    }

    @And("user clicks on compare checkbox in product defination page")
    public void userClicksOnCompareCheckboxInProductDefinationPage() {

        if (getConfig("Browser").equalsIgnoreCase("EMULATED_CHROME")) {
            windowScrollIntoViewByWebElement(getElement("clickOnCompareCheckBoxInPDPMobile"));
            windowScrollIntoViewAdjustment_scroll(comparePageScrollDownFirstIndex, comparePageScrollDownLastIndex);

            assertStepExecution(true, getElement("clickOnCompareCheckBoxInPDPMobile")!=null,"Compare checkbox is present");
           jsClick(getElement("clickOnCompareCheckBoxInPDPMobile"));
        }
        else if (getConfig("Browser").equalsIgnoreCase("CHROME")) {
            assertStepExecution(true, getElement("clickOnCompareCheckBoxInPDP")!=null,"Compare checkbox is present");
            getElement("clickOnCompareCheckBoxInPDP").click();

        }
    }

    @And("user clicks on clear all button in compare tray")
    public void userClicksOnClearAllButtonInCompareTray() {
        assertStepExecution(true, getElement("clickOnClearAllButtonInPDP")!=null,"Compare checkbox is present");
        getElement("clickOnClearAllButtonInPDP").click();

        }

}