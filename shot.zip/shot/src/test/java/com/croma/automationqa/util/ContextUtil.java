package com.croma.automationqa.util;

import java.util.HashMap;

import static com.croma.automationqa.util.FrameworkUtil.logger;

/**
 * <h3> Purpose:  <p> <h4> &#10687;  This class includes all the methods to handle contextual strings that need to be carried forward from one StepDefinition Method to another.
 * <br> &#10687; This class uses a hash-map to store scenario execution specific contextual values.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 28/05/2020
 */
public class ContextUtil {

    private static ContextUtil instance;
    private HashMap<String, HashMap<String, String>> contextMap;

    /**
     * This constructor is kept <b>private</b> to prevent users from creating instance of this class by invoking '<b>new</b>' keyword from outside of this class.
     */
    private ContextUtil() {
    }

    /**
     * This method implements <b>Thread-safe Singleton design pattern</b> by allowing users to create only one instance of this class.
     *
     * @return <b>ContextUtil</b> object.
     */
    public static synchronized ContextUtil getContextInstance() {

        if (instance == null) {

            instance = new ContextUtil();
            instance.contextMap = new HashMap<String, HashMap<String, String>>();
            instance.contextMap.put("ScenarioExecMap", new HashMap<String, String>());
            logger.info("ContextUtil instantiated...");
        }

        return instance;
    }

    /**
     * This method <b>Add</b> context strings into context HashMap.
     *
     * @param <b>contextKey</b> Key to add Context String.
     * @param <b>contextVal</b> Context String.
     */
    public static synchronized void setContext(String contextKey, String contextVal) {

        getContextInstance();
        String t = String.valueOf(Thread.currentThread().getId());

        if (!instance.contextMap.containsKey(t)) {
            instance.contextMap.put(t, new HashMap<>());
        }
        instance.contextMap.get(t).put(contextKey, contextVal);
        ScenarioUtil.getScenario().log(contextKey + "::" + contextVal);
    }


    /**
     * This method <b>Return</b> already added context strings from context HashMap.
     *
     * @param <b>contextKey</b> Key used while adding the context string.
     * @return context string corresponding to provided ContextKey from context HashMap.
     */
    public static synchronized String getContext(String contextKey) {

        getContextInstance();
        String t = String.valueOf(Thread.currentThread().getId());
        String val = "";
        if (instance.contextMap.containsKey(t) && instance.contextMap.get(t).containsKey(contextKey)) {
            val = instance.contextMap.get(t).get(contextKey);
        }
        return val;
    }

    /**
     * This method <b>Add</b> 'scenarioName' strings for each 'testCaseExecutionId' into 'ScenarioExecMap' HashMap.
     *
     * @param <b>testCaseExecutionId</b> testCaseExecutionId provided by QMetry Open API.
     * @param <b>scenarioName</b>        Name of currently executing Scenario as mentioned in Feature file.
     */
    public static synchronized void setScenarioExecution(String testCaseExecutionId, String scenarioName) {

        getContextInstance();

        instance.contextMap.get("ScenarioExecMap").put(testCaseExecutionId, scenarioName);
        logger.info("//**// testCaseExecutionId:: " + testCaseExecutionId + ", scenarioName:: " + scenarioName);

    }

    /**
     * This method returns 'ScenarioExecMap' as a HashMap&lt;String, String&gt;.
     *
     * @return <b>HashMap&lt;String, String&gt;</b>
     */
    public static synchronized HashMap<String, String> getScenarioExecution() {

        return instance.contextMap.get("ScenarioExecMap");
    }

    /**
     * This method <b>Remove</b> already added context strings from context HashMap.
     */
    public static synchronized void removeContext() {
        String t = String.valueOf(Thread.currentThread().getId());

        if (instance.contextMap.containsKey(t)) {
            instance.contextMap.remove(t);
        }
    }

}
