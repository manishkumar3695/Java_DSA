package com.croma.automationqa.stepDefinitions;

import com.croma.automationqa.util.JavaScriptUtil;
import io.cucumber.java.en.And;

import java.io.File;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.CommonUtil.selectFromDown;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.getConfig;
import static com.croma.automationqa.util.FrameworkUtil.logger;

public class CromaOmsAppStepDef {

    @And("^store user waits for loading circle to be invisible$")
    public static void storeUserWaitsForLoadingCircleToBeInvisible() throws InterruptedException {
        int timer = 0;
        while (getOptionalElement("storeLoadingCircle") != null && timer != 12) {
            logger.info("Loading Circle is present, waiting for timer " + timer);
            Thread.sleep(10000);
            timer++;
        }
            /*conditionalWait(ExpectedConditions.invisibilityOf(getDriver().findElement(By.xpath(getLocator("storeLoadingCircle"))))
                , Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));*/

    }


    @And("user launches the oms site {string}")
    public void userLaunchesTheOmsSite(String omsAppURL) {
        getDriver().get(getConfig(omsAppURL));
        assertStepExecution(true, getDriver().getTitle().length() > 0, "Validation of application launch");
    }

    @And("user provides {string} and {string} then click on Login button")
    public void userProvidesAndThenClickOnLoginButton(String userName, String password) throws InterruptedException {
        Thread.sleep(3000);
        getElement("userID").sendKeys(userName);
        getElement("password").sendKeys(password);
        getElement("loginButton").click();
        assertStepExecution(true, getOptionalElement("loginButton") == null, "Validation of absence of Login Button");
    }

    @And("user provides previously stored order no in pick order text box")
    public void userProvidesPreviouslyStoredOrderNoInPickOrderTextBox() {
        String orderNo = getContext("orderId");
        getElement("pickOrderInputBox").clear();
        getElement("pickOrderInputBox").sendKeys(orderNo);
        assertStepExecution(getElement("pickOrderInputBox").getAttribute("value"), orderNo,
                "user provides previously stored order no in pick order text box");
    }

    @And("user clicks on search button in pick order section")
    public void userClicksOnSearchButtonInPickOrderSection() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("pickOrderSearchBtn") != null,
                "user clicks on search button in pick order section");
        JavaScriptUtil.jsClick(getElement("pickOrderSearchBtn"));
        storeUserWaitsForLoadingCircleToBeInvisible();
    }

    @And("user lands on pick order page")
    public void userLandsOnPickOrderPage() {
        assertStepExecution(getElement("pickOrderPageHeading").getText(), "Pick Order", "user lands on pick order page");
    }

    @And("user clicks on pick all button")
    public void userClicksOnPickAllButton() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("pickAllBtn") != null, "user clicks on pick all button");
        getElement("pickAllBtn").click();
        storeUserWaitsForLoadingCircleToBeInvisible();
    }

    @And("user verifies notification modal header title as {string}")
    public void userVerifiesNotificationModalHeaderTitleAs(String headerTitle) throws InterruptedException {
        Thread.sleep(3000);
        String stepDesc = "user verifies notification modal header title as " + headerTitle;
        assertStepExecution(getElement("modalNotificationTitle").getText(), headerTitle, stepDesc);
    }

    @And("user verifies notification message as {string} and clicks on {string} button")
    public void userVerifiesNotificationMessageAsAndClicksOnButton(String notifyMsg, String button) {
        String stepDesc = "user verifies notification message as " + notifyMsg + " and clicks on " + button + "button";
        String message = getElement("modalNotificationMsg").getText();
        logger.info("Notification Message : " + message);
        assertStepExecution(message, notifyMsg, stepDesc);
        getElement("modalNotificationOKBtn", button).click();
    }

    @And("user clicks on finish pick button")
    public void userClicksOnFinishPickButton() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("finishPickBtn") != null, "user clicks on finish pick button");
        getElement("finishPickBtn").click();
        storeUserWaitsForLoadingCircleToBeInvisible();
    }

    @And("user clicks on Yes button if any warning appears")
    public void userClicksOnYesButtonIfAnyWarningAppears() throws InterruptedException {
        Thread.sleep(10000);
        if (getOptionalElement("modalNotificationOKBtn", "Yes") != null) {
            logger.info("Warning Message Present");
            getElement("modalNotificationOKBtn", "Yes").click();
            storeUserWaitsForLoadingCircleToBeInvisible();
        }
    }

    @And("user lands on shipment summary page")
    public void userLandsOnShipmentSummaryPage() {
        assertStepExecution(getElement("shipmentSummaryPageTitle").getText(), "Shipment Summary", "user lands on shipment summary page");
    }

    @And("user validates status of the shipment in shipment summary page is {string}")
    public void userValidatesStatusOfTheShipmentInShipmentSummaryPageIs(String status) {
        String stepDesc = "user validates status of the shipment in shipment summary page is " + status;
        String shipmentStatus = getElement("shipmentSummaryPageStatus").getText();
        logger.info("Shipment Status in Shipment Summary Page : " + shipmentStatus);
        assertStepExecution(shipmentStatus, status, stepDesc);
    }

    @And("user clicks on start customer pick up in shipment summary page")
    public void userClicksOnStartCustomerPickUpInShipmentSummaryPage() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("startCustomerPickUp") != null,
                "user clicks on start customer pick up in shipment summary page");
        getElement("startCustomerPickUp").click();
        storeUserWaitsForLoadingCircleToBeInvisible();
    }

    @And("user selects verification method as {string}")
    public void userSelectsVerificationMethodAs(String button) {
        selectFromDown(getElement("verifyOptionDropdown"), button);
        assertStepExecution(true,true,"user selects verification method as " + button);
    }

    @And("user uploads customer ID proof for customer pick up")
    public void userUploadsCustomerIDProofForCustomerPickUp() throws InterruptedException {
        String filePath = "";
        File fileObj = new File(getConfig("imagePath"));
        filePath = fileObj.getAbsolutePath();
        assertStepExecution(true,filePath.length()>0,"user uploads customer ID proof for customer pick up");
        getElement("chooseFile").sendKeys(filePath);
        getElement("uploadBtn").click();
        storeUserWaitsForLoadingCircleToBeInvisible();
    }

    @And("user clicks on pickup all button")
    public void userClicksOnPickupAllButton() {
        assertStepExecution(true,getOptionalElement("pickUpAllBtn")!=null,"user clicks on pickup all button");
        getElement("pickUpAllBtn").click();
    }

    @And("user logs out of store")
    public void userLogsOutOfStore() throws InterruptedException {
        Thread.sleep(2000);
        getElement("userMenuButton").click();
        Thread.sleep(1000);
        getElement("logoutButton").click();
        getDriver().switchTo().alert().accept();
        assertStepExecution(true, getOptionalElement("logoutButton") == null, "Validation of user log out");

    }

    @And("user clicks pick order button")
    public void userClicksPickOrderButton() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("pickOrderBtn") != null, "user clicks pick order button");
        getElement("pickOrderBtn").click();
        storeUserWaitsForLoadingCircleToBeInvisible();
    }

    @And("user clicks on shipment link of the {string} shipment")
    public void userClicksOnShipmentLinkOfTheShipment(String shipment_line) throws InterruptedException {
        String stepDesc = "user clicks on shipment link of the " + shipment_line + " shipment";
        Thread.sleep(10000);
        assertStepExecution(true, getOptionalElement("shipmentLine", shipment_line) != null, stepDesc);
        JavaScriptUtil.jsClick(getElement("shipmentLine", shipment_line));
    }

    @And("user clicks on done button")
    public void userClicksOnDoneButton() {
        assertStepExecution(true, getOptionalElement("doneBtn") != null, "user clicks on done button");
        getElement("doneBtn").click();
    }
}
