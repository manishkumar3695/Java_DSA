package com.croma.automationqa.stepDefinitions;

import com.croma.automationqa.util.DriverUtil;
import com.croma.automationqa.util.ElementUtil;
import io.cucumber.core.backend.TestCaseState;
import io.cucumber.java.*;
import io.cucumber.plugin.event.PickleStepTestStep;
import io.cucumber.plugin.event.TestCase;
import org.openqa.selenium.By;

import java.lang.reflect.Field;
import java.net.URL;
import java.util.List;
import java.util.stream.Collectors;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.*;
import static com.croma.automationqa.util.CommonUtil.pageRefresh;
import static com.croma.automationqa.util.ContextUtil.*;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.DriverUtil.removeDriver;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.QMetryUtil.initiateQMetry;
import static com.croma.automationqa.util.QMetryUtil.updateTestStepExecution;
import static com.croma.automationqa.util.ScenarioUtil.removeScenario;
import static com.croma.automationqa.util.ScenarioUtil.setScenario;



public class Hooks {

    private ThreadLocal<Integer> currentStepDefIndex = new ThreadLocal<>();
    private List<PickleStepTestStep> stepDefs;


    @BeforeStep
    public void setUpStep(Scenario sc) throws NoSuchFieldException, IllegalAccessException, InterruptedException {

        System.out.println("Test BeforeStep : " + sc.getName());

       // userHandlesTheUnexpectedPopup();

        /*Get Scenario Steps*/
        Field f = sc.getClass().getDeclaredField("delegate");
        f.setAccessible(true);
        TestCaseState tcs = (TestCaseState) f.get(sc);

        Field f2 = tcs.getClass().getDeclaredField("testCase");
        f2.setAccessible(true);
        TestCase r = (TestCase) f2.get(tcs);

        // Need to filter out before/after hooks
        stepDefs = r.getTestSteps()
                .stream()
                .filter(x -> x instanceof PickleStepTestStep)
                .map(x -> (PickleStepTestStep) x)
                .collect(Collectors.toList());


        // This object now holds the information about the current step definition
        PickleStepTestStep currentStepDef = stepDefs.get(currentStepDefIndex.get());
        String currentStepDescr = currentStepDef.getStep().getText();

        setContext("currentStep", currentStepDescr);


    }

    @AfterStep
    public void tearDownStep(Scenario sc) {
        System.out.println("Test AfterStep : " + sc.getName());
        try {

            //Handling of Abruptly encountered failures
            if (sc.isFailed() && (!getContext("testStatus").equalsIgnoreCase("Failed"))) {

                setContext("testStatus", "Failed");
                processScreenshot("Abrupt Failure Screenshot");
                sc.log("This is a failure log  -- Screenshot name: " + getContext("screenshotName"));
                updateTestStepExecution(getContext("currentStep") + " -- failed.", "Test Step Assertion failed. Please check TestCase attachment for detailed failure report.", "fail");

            }
            currentStepDefIndex.set(currentStepDefIndex.get() + 1);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Before
    public synchronized void setUp(Scenario sc) throws InterruptedException {

        logger.setScenario(sc.getName());
        logger.info(sc.getId());
        setScenario(sc);
        initiateQMetry();
        setScenarioExecution(getContext("testCaseExecutionId"), sc.getName());
        getContextInstance();
        DriverUtil.getInstance();  // Instantiate DriverUtil & initialize driverMap (ONLY FIRST TIME)
        getDriver().get(getConfig(("URL"))); // Instantiate  Website URL
        logger.info("The URL is : "+ getConfig("URL"));
        userHandlesTheUnexpectedPincodePopup();
        Thread.sleep(5000);
//        if(getDriver().getTitle()==null) {
//            getDriver().navigate().refresh();
//        }
        userRefreshTheLandingPageToBeLoadProperly();
        /*Set Scenario for Capture Screenshot*/
        String featureName = "Feature :: ";
        String rawFeatureName = sc.getId().split(";")[0].replace("-", " ");
        featureName = featureName + rawFeatureName.substring(0, 1).toUpperCase() + rawFeatureName.substring(1);
        logger.info(featureName);
        System.setProperty(String.valueOf(Thread.currentThread().getId()), sc.getName());

        currentStepDefIndex.set(0);
    }

    @After
    public synchronized void wrapUp(Scenario sc) {
        try {

            logger.info("Status::" + sc.getStatus());
            logger.info(sc.getId());

           getDriver().quit();
           removeDriver();
            removeScenario();
            removeContext();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
