package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.CommonUtil.numericValuesExtractionMethod;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;


//import static com.croma.automationqa.util.CommonUtil.windowScrollIntoViewByWebElement;


/*
   All the payment method page related function defined in public class CromaPaymentMethodPageStepDef class
*/
public class CromaPaymentMethodPageStepDef {

    static final String splitOption = "\\.", splitOptionOne = "- ", splitOptionTwo = ",", splitOptionThree = " ";
    private final int paymentPageScrollDownFirstIndex = 0, paymentPageScrollDownLastIndex = 100, paymentSearchResultFirstIndex = 1;
    JavascriptExecutor js = (JavascriptExecutor) getDriver();

    /*
        User choose payment method as tata pay and fill card details and click pay
    */
    @And("^user chooses payment method as tata pay and fills card details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and clicks pay$")
    public void userChoosesPaymentMethodAsTataPayAndFillsCardDetailsAndClicksPay(String orderCreditCardName, String orderCreditCardNumber, String orderCreditCardMonth, String orderCreditCardYear, String orderCreditCardCvv) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));

        logger.info("User provided credit cards details " + " " + orderCreditCardNumber + " " + orderCreditCardName + " " + orderCreditCardMonth + " " + orderCreditCardYear + " " + orderCreditCardCvv);
        //   userSwitchedToPaymentPageFrame();
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        actionMoveToElementClick(getElement("tataCardPaymentTab"));
        //    actionMoveToElementClick(getElement("paymentMethodCardOption"));
        actionMoveToElementClick(getElement("paymentMethodAddNewCardOption"));
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getElement("paymentMethodCardNumberInput").sendKeys(orderCreditCardNumber);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardMonth);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardYear);
        getElement("paymentMethodCardCVVInput").sendKeys(orderCreditCardCvv);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentSaveCardOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        actionMoveToElementClick(getElement("paymentSaveCardOption"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentMethodProceedButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("paymentMethodProceedButton").isDisplayed(), "Proceed button enabled");
        // actionMoveToElementClick(getElement("paymentMethodProceedButton"));
        getElement("paymentMethodProceedButton").click();
    }


    /*
        User chooses payment method as Voucher and fills card details and click pay
    */
    @And("^user chooses payment method as voucher card and fills card details \"([^\"]*)\" compares the Voucher message \"([^\"]*)\"$")
    public void userChoosesPaymentMethodAsVoucherCardAndFillsCardDetailsComparesTheVoucherMessage(String orderVoucherCardNumber, String validationMsg) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        int paymentMethodPageFirstIndex = 0, paymentMethodPageSecondIndex = 1;
        String amountZero = "0", toValidateGiftCardPayableMessageOnPaymentPage;

        userSelectsGCVouchergramOption("Voucher");

        getElement("paymentVoucherNumberInputText").sendKeys(orderVoucherCardNumber);
        actionMoveToElementClick(getElement("paymentVoucherApplyButton"));

        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));


        logger.info("Validation of voucher success message: " + (getElement("paymentVoucherValidationMessage").getText()) +
                " Validation of voucher number: " + (getElement("paymentVoucherNumberDisplayValidation").getText()));

        String balanceAmount = (getElement("balanceAmount").getText());
        logger.info("balanceAmount is: " + balanceAmount);

        if (numericValuesExtractionMethod(splitTextWithIndexing(balanceAmount, splitOption, paymentMethodPageSecondIndex)) > paymentMethodPageFirstIndex)
            toValidateGiftCardPayableMessageOnPaymentPage = ("Balance amount payable ").concat(balanceAmount);
        else
            toValidateGiftCardPayableMessageOnPaymentPage = ("Balance amount payable Rs. ").concat(amountZero);
        logger.info("ToValidateGiftCardPayableMessageOnPaymentPage is: " + toValidateGiftCardPayableMessageOnPaymentPage);
        String giftCardPayableMessageOnPaymentPage = getElement("balanceAmountPayableMsg").getText();
        logger.info("Gift card payable message is: " + giftCardPayableMessageOnPaymentPage);

        // Asserting the validation messages
        conditionalWait(ExpectedConditions.visibilityOf(getElement("paymentVoucherValidationMessage")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(validationMsg).describedAs("Validation message is not matching").isEqualTo(getElement("paymentVoucherValidationMessage").getText());
        // Amount validation
        assertThat(giftCardPayableMessageOnPaymentPage).describedAs("Validation of balance amount payable text").isEqualTo(toValidateGiftCardPayableMessageOnPaymentPage);
        actionSendKeyPageDownBuild();
        windowScrollIntoViewByWebElement(getElement("paymentVoucherOtherPaymentOptionButton"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentVoucherOtherPaymentOptionButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));

        /* if method only for POD payment mode*/
        if (getOptionalElement(getContext("podProducts")) != null) {
            assertThat(getElement("podEligibleAlert").getText()).isEqualTo("Please note that payment on delivery is not applicable for the outstanding amount.").describedAs("POD alert massage should match");
        }

        actionMoveToElementClick(getElement("paymentVoucherOtherPaymentOptionButton"));
        passStepExecution("User chooses payment method as Voucher and fills card details and click pay");
    }


    /*
        User chooses payment method as gift card and fills card details and click pay
    */
    @And("^user chooses payment method as gift card and fills card details \"([^\"]*)\", \"([^\"]*)\" and clicks pay$")
    public void userChoosesPaymentMethodAsGiftCardAndFillsCardDetailsAndClicksPay(String orderGiftCardNumber, String orderGiftCardPin) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        int paymentMethodPageFirstIndex = 0, paymentMethodPageSecondIndex = 1;
        String finalMessage, amountZero = "0", toValidateGiftCardPayableMessageOnPaymentPage;
        logger.info("User provided gift cards details " + " " + orderGiftCardNumber + " " + orderGiftCardPin);
       /* getElement("clickOnGiftCardVoucherDropdown").click();
        getElement("clickOnDropdownOption").click();
        getElement("selectGiftCardOptionFromDropdown").click();*/
        userSelectsGCVouchergramOption("Gift card");

        getElement("orderGiftCardNumberInput").sendKeys(orderGiftCardNumber);
        getElement("orderGiftCardPinInput").sendKeys(orderGiftCardPin);
        getElement("clickOnGcVApplyButton").click();
        String giftCardAmount = splitTextWithIndexing(getElement("giftCardAmount").getText(), splitOptionOne, paymentMethodPageSecondIndex);
        logger.info(" Gift card amount is: " + giftCardAmount);
        if (giftCardAmount.contains("."))
            finalMessage = "Your applied card is " + orderGiftCardNumber + ". Amount deducted from your card :" + giftCardAmount;
        else
            finalMessage = ("Your applied card is " + orderGiftCardNumber + ". Amount deducted from your card :" + giftCardAmount).concat(".").concat(amountZero);
        logger.info("Gift card applied and amount deducted message is: " + finalMessage);
        String giftCardMessageOnPaymentPage = getElement("giftCardMessageOnPaymentPage").getText();
        logger.info("Gift card message is: " + giftCardMessageOnPaymentPage);
        assertThat(giftCardMessageOnPaymentPage).describedAs("Validation of gift card applied and amount deducted text").isEqualTo(finalMessage);
        String balanceAmount = (getElement("balanceAmount").getText());
        logger.info("Balance amount is: " + balanceAmount + "Split " + numericValuesExtractionMethod(splitTextWithIndexing(balanceAmount, splitOption, paymentMethodPageFirstIndex)));
        if (numericValuesExtractionMethod(splitTextWithIndexing(balanceAmount, splitOption, paymentMethodPageFirstIndex)) > paymentMethodPageFirstIndex)
            toValidateGiftCardPayableMessageOnPaymentPage = ("Balance amount payable Rs. ").concat(balanceAmount);
        else
            toValidateGiftCardPayableMessageOnPaymentPage = ("Balance amount payable Rs. ").concat(amountZero);
        String giftCardPayableMessageOnPaymentPage = getElement("balanceAmountPayableMsg").getText();
        logger.info("Gift card payable message is: " + giftCardPayableMessageOnPaymentPage);
        assertThat(giftCardPayableMessageOnPaymentPage).describedAs("Validation of balance amount payable text").isEqualTo(toValidateGiftCardPayableMessageOnPaymentPage);
        getElement("clickOnPayNowButton").click();
        passStepExecution("User chooses payment method as gift card and fills card details and click pay");
    }


    /*
          User chooses payment method as wallet option and chooses payment option and clicks proceed to pay and provide details
    */
    @And("^user chooses payment method as wallet option and chooses \"([^\"]*)\" and clicks proceed to pay and provide details \"([^\"]*)\" as mobile no, \"([^\"]*)\" as OTP and clicks pay$")
    public void userChoosesPaymentMethodAsWalletOptionAndChoosesAndClicksProceedToPayAndProvideDetailsAsMobileNoAsOTPAndClicksPay(String walletPaymentOption, String walletPaymentMobileNo, String walletPaymentOtp) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        logger.info("User provided wallet details " + " " + walletPaymentOption + " " + walletPaymentMobileNo + " " + walletPaymentOtp);
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        actionMoveToElementClick(getElement("paymentMethodWalletOption"));
        // getElement("paymentMethodWalletOption").click();
        switch (walletPaymentOption) {
            case "Paytm":
                actionMoveToElementClick(getElement("paymentMethodSelectOption", walletPaymentOption));
                actionMoveToElementClick(getElement("paymentMethodPayTmProceedToPay", walletPaymentOption));
                clearTextBox(getElement("payTmMobileNo"));
                getElement("payTmMobileNo").sendKeys(walletPaymentMobileNo);
                actionMoveToElementClick(getElement("payTmProceedButton"));
                getElement("otpPayTmPagefield").sendKeys(walletPaymentOtp);

                /*getElement("oTP1PayTm").sendKeys(walletPaymentOtp.substring(0, 1));
                getElement("oTP2PayTm").sendKeys(walletPaymentOtp.substring(1, 2));
                getElement("oTP3PayTm").sendKeys(walletPaymentOtp.substring(2, 3));
                getElement("oTP4PayTm").sendKeys(walletPaymentOtp.substring(3, 4));
                getElement("oTP5PayTm").sendKeys(walletPaymentOtp.substring(4, 5));
                getElement("oTP6PayTm").sendKeys(walletPaymentOtp.substring(5, 6));*/
                actionMoveToElementClick(getElement("paymentMethodPayTmVerify"));
                //  assertThat(getElement("paymentMethodPayTmVerify").isDisplayed()).describedAs("Pay button enabled");
                actionMoveToElementClick(getElement("paymentMethodPayTmPayButton"));
                break;
            case "Amazon Pay":
                actionMoveToElementClick(getElement("paymentMethodSelectOption", walletPaymentOption));
                actionMoveToElementClick(getElement("paymentMethodPayTmProceedToPay", walletPaymentOption));
                assertThat(getElement("amazonWalletPageValidationText").isDisplayed()).describedAs("Amazon wallet page validation text displayed");
                getDriver().navigate().back();
               /* clearTextBox(getElement("amazonPayEmailOrMobileNo"));
                getElement("amazonPayEmailOrMobileNo").sendKeys(walletPaymentMobileNo);
                getElement("amazonPayPassword").sendKeys(walletPaymentOtp);
                actionMoveToElementClick(getElement("amazonPayLoginSubmit"));
                assertStepExecution(true, getElement("amazonPayOrderPayNowButton").isDisplayed(), "Pay button enabled");
                actionMoveToElementClick(getElement("amazonPayOrderPayNowButton"));*/
                break;
            case "Mobikwik":
                //todo
                break;
        }
        passStepExecution("User chooses payment method as wallet option and chooses payment option and clicks proceed to pay and provide details");
    }


    /*
        User chooses payment method as netbanking option and chooses option and provide account details
    */
    @And("^user chooses payment method as netbanking option and chooses \"([^\"]*)\" and provide account details$")
    public void userChoosesPaymentMethodAsNetbankingOptionAndChoosesAndProvideAccountDetails(String netbankingBank) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        if (getOptionalElement("offerPopupSkipOnPayment") != null) {
            getElement("offerPopupSkipOnPayment").click();
        }
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        Thread.sleep(10000);
        assertStepExecution(true, getOptionalElement("netBankingTab") != null, "Net banking tab displayed");
        jsClick(getDriver().findElement(By.xpath("//article[text()='Netbanking']")));
        actionMoveToElementClick(getElement("netBankingAxisBankIcon", netbankingBank));
    }


    /*
        User chooses payment method as pay on delivery option
    */
    @And("^user chooses payment method as pay on delivery option$")
    public void userChoosesPaymentMethodAsPayOnDeliveryOption() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        actionMoveToElementClick(getElement("payOnDeliveryTab"));
        getElement("payOnDeliveryOptionRadioButton").click();
        assertStepExecution(true, getElement("paymentMethodPayOnDeliveryProceedButton").isDisplayed(), "POD Proceed button displayed");
        actionMoveToElementClick(getElement("paymentMethodPayOnDeliveryProceedButton"));
    }


    /*
        user removes gift card / voucher and checks amount
    */
    @And("^user removes the card and checks$")
    public void userRemovesTheCardAndChecks() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("gcDeleteIcon")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertThat(getElement("giftCardMessageOnPaymentPage").isDisplayed());
        getElement("gcDeleteIcon").click();
        assertThat(getElement("messagePostCardRemove").isDisplayed());
        passStepExecution(" user removes card and checks amount");
    }


    /*
        user clicks on failure button in bank page while payment
    */
    @And("^user clicks on failure button in bank page while payment$")
    public void userClicksOnFailureButtonInBankPageWhilePayment() {
        logger.info("User clicks on failure button");
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("bankFailureSubmitButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("bankFailureSubmitButton").isDisplayed(), "Failure button displayed");
        getElement("bankFailureSubmitButton").click();
    }


    /*
         User validates the offer applied message
     */

    @And("^user validates the offer applied \"([^\"]*)\"$")
    public void userValidatesTheOfferApplied(String offerAppliedMessage) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("offerApplied", offerAppliedMessage)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("The offer applied message is : " + getElement("offerApplied", offerAppliedMessage).getText());
        assertStepExecution(offerAppliedMessage.toUpperCase(), getElement("offerApplied", offerAppliedMessage).getText().toUpperCase(), "Offer is applied");
    }

    /*
       user selects Gift card or vouchagram from payment dropdown
   */
    public void userSelectsGCVouchergramOption(String cardOption) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnGiftCardVoucherDropdown")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("clickOnGiftCardVoucherDropdown").click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnDropdownOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("clickOnDropdownOption").click();
        assertStepExecution(true, getElement("selectGCVoucherFromDropdown", cardOption).isDisplayed(), "Failure button displayed");
        getElement("selectGCVoucherFromDropdown", cardOption).click();
    }


    /*
        user switched to payment page frame
    */
    public void userSwitchedToPaymentPageFrame() {
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
    }


    /*
        user performs payment validation for the selected method
    */
    @And("^user provides \"([^\"]*)\" as payment option, \"([^\"]*)\" as value on payment page for the field \"([^\"]*)\" and validates error message as \"([^\"]*)\"$")
    public void userProvidesAsPaymentOptionAsValueOnPaymentPageForTheFieldAndValidatesErrorMessageAs(String paymentOption, String fieldValue, String fieldName, String errorMessage) {
        String giftCardNo, giftCardPin, month, year;
        switch (paymentOption) {
            case "CreditDebitCard":
                logger.info("field name to chk: " + fieldName);
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                if (fieldName.equalsIgnoreCase("creditDebitCardTextBox")) {
                    //      userSwitchedToPaymentPageFrame();
                    //////      getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
                    //     actionMoveToElementClick(getElement("paymentMethodCardOption"));
                    //     actionMoveToElementClick(getElement("tataCardPaymentTab"));
                    actionMoveToElementClick(getElement("paymentMethodAddNewCardOption"));
                    if (fieldValue.equalsIgnoreCase("controlV"))
                        getElement("paymentMethodCardNumberInput").sendKeys(Keys.CONTROL + "v");
                    else
                        getElement("paymentMethodCardNumberInput").sendKeys(fieldValue);
                    logger.info("Displayed message is :" + getElement("credicCardNoValidationMsg").getText());
                    logger.info("Argument message is :" + errorMessage);
                    assertThat(errorMessage).describedAs("CC no validation message").isEqualTo(getElement("credicCardNoValidationMsg").getText());
                    logger.info("cc no assert done");
                } else if (fieldName.equalsIgnoreCase("creditDebitExpiry")) {
                    logger.info("inside expiry code");
                    waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                    month = splitTextWithIndexing(fieldValue, splitOptionOne, paymentPageScrollDownFirstIndex);
                    year = splitTextWithIndexing(fieldValue, splitOptionOne, paymentSearchResultFirstIndex);
                    logger.info("month and year value is: " + month + " " + year);
                    getElement("paymentMethodCardMonthYearInput").sendKeys(month);
                    getElement("paymentMethodCardMonthYearInput").sendKeys(year);
                    logger.info("Displayed message is :" + getElement("credicCardCVVValidationMsg").getText());
                    logger.info("Argument message is :" + errorMessage);
                    assertThat(errorMessage).describedAs("CC expiry validation message").isEqualTo(getElement("credicCardCVVValidationMsg").getText());
                }
                break;

            case "Gift card":
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                userSelectsGCVouchergramOption(paymentOption);

                if (fieldValue.equalsIgnoreCase("giftCardFile")) {

                    logger.info("gc details in get context: " + getContext("gcDetails"));


                    giftCardNo =
                            splitTextWithIndexing(splitTextWithIndexing(getContext("gcDetails"), splitOptionThree,
                                            paymentSearchResultFirstIndex), splitOptionTwo,
                                    paymentPageScrollDownFirstIndex);
                    giftCardPin = splitTextWithIndexing(getContext("gcDetails"), splitOptionTwo,
                            paymentSearchResultFirstIndex);
                    logger.info("card no.: " + giftCardNo + " pin is: " + giftCardPin);

                } else {
                    giftCardNo = splitTextWithIndexing(fieldValue, splitOptionOne,
                            paymentPageScrollDownFirstIndex);
                    giftCardPin = splitTextWithIndexing(fieldValue, splitOptionOne,
                            paymentSearchResultFirstIndex);
                }
                logger.info("giftCardNo is :" + giftCardNo);
                logger.info("giftCardPin is :" + giftCardPin);
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("orderGiftCardNumberInput")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                if (!(giftCardNo.equals("NA"))) {
                    getElement("orderGiftCardNumberInput").clear();
                    getElement("orderGiftCardNumberInput").sendKeys(giftCardNo);
                }
                if (!(giftCardPin.equals("NA"))) {
                    getElement("orderGiftCardPinInput").clear();
                    getElement("orderGiftCardPinInput").sendKeys(giftCardPin);
                }
                getElement("paymentVoucherApplyButton").click();
                if (fieldName.equalsIgnoreCase("GCCardTextBox")) {
                    logger.info("Displayed message is :" + getElement("gcNoValidationMsg").getText());
                    logger.info("Argument message is :" + errorMessage);
                    assertThat(errorMessage).describedAs("GC No validation message").isEqualTo(getElement("gcNoValidationMsg").getText());
                } else if (fieldName.equalsIgnoreCase("GCPinTextBox")) {
                    logger.info("Displayed message is :" + getElement("gcPinValidationMsg").getText());
                    logger.info("Argument message is :" + errorMessage);
                    assertThat(errorMessage).describedAs("GC Pin validation message").isEqualTo(getElement("gcPinValidationMsg").getText());
                } else if (fieldName.equalsIgnoreCase("GCCardPinApply")) {
                    if (!(errorMessage.equalsIgnoreCase("NA"))) {
                        logger.info("Displayed message is :" + getElement("giftCardMessageOnPaymentPage").getText());
                        logger.info("Argument message is :" + errorMessage);
                        assertThat(errorMessage).describedAs("GC Apply validation message").isEqualTo(getElement("giftCardMessageOnPaymentPage").getText());
                    }
                }
                break;

            case "Voucher":
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                userSelectsGCVouchergramOption(paymentOption);
                if (!(fieldValue.equals("NA")))
                    getElement("paymentVoucherNumberInputText").sendKeys(fieldValue);
                getElement("paymentVoucherApplyButton").click();
                if (fieldName.equalsIgnoreCase("voucherOnly")) {
                    logger.info("Displayed message is :" + getElement("gcNoValidationMsg").getText());
                    logger.info("Argument message is :" + errorMessage);
                    assertThat(errorMessage).describedAs("Voucher No validation message").isEqualTo(getElement("gcNoValidationMsg").getText());
                } else if (fieldName.equalsIgnoreCase("VoucherApply")) {
                    if (!(errorMessage.equalsIgnoreCase("NA"))) {
                        logger.info("Displayed message is :" + getElement("giftCardMessageOnPaymentPage").getText());
                        logger.info("Argument message is :" + errorMessage);
                        assertThat(errorMessage).describedAs("GC Apply validation message").isEqualTo(getElement("giftCardMessageOnPaymentPage").getText());
                    }
                }
                break;
        }
        passStepExecution("Payment validations");
    }


    /*
   User checks on Terms and conditions
*/
    @And("^user clicks on terms and condition link in payment page$")
    public void userClicksOnTermsAndConditionLinkInPaymentPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clicksOnTermsAndCondition")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clicksOnTermsAndCondition").click();
        userMovesToNewWindow();
        logger.info("Terms and condition title is:- " + getElement("termsAndConditionTitle").getText());
        userClosesTheCurrentWindowAndMovesToOldWindow();
    }


    /*
     User proceeds for TATA pay and enter Card details
 */
    @And("^user chooses payment method as tata pay and add new card and fills card details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and clicks pay$")
    public void userChoosesPaymentMethodAsTataPayAndAddNewCardAndFillsCardDetailsAndClicksPay(String orderCreditCardNumber, String orderCreditCardMonth, String orderCreditCardYear, String orderCreditCardCvv) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        logger.info("User provided credit cards details " + " " + orderCreditCardNumber + " " + orderCreditCardMonth + " " + orderCreditCardYear + " " + orderCreditCardCvv);
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        getOptionalElement("tataCardPaymentTab").click();
//        actionMoveToElementClick(getElement("tataCardPaymentTab"));
        if (getOptionalElement("paymentMethodAddNewCardOption") != null)
        {
            windowScrollIntoViewByWebElement(getElement("paymentMethodAddNewCardOption"));
            actionMoveToElementClick(getElement("paymentMethodAddNewCardOption"));
        }
        conditionalWait(ExpectedConditions.visibilityOf(getElement("paymentMethodCardNumberInput")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getElement("paymentMethodCardNumberInput").sendKeys(orderCreditCardNumber);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardMonth);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardYear);
        getElement("paymentMethodCardCVVInput").sendKeys(orderCreditCardCvv);
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentSaveCardOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentMethodProceedButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("paymentMethodProceedButton").isDisplayed(), "Proceed button enabled");
        // actionMoveToElementClick(getElement("paymentMethodProceedButton"));
        getElement("paymentMethodProceedButton").click();
    }


    /*
       User validates saved card details appears on payment page
   */
    @And("^user validates card details \"([^\"]*)\", \"([^\"]*)\" added in payment page$")
    public void userValidatesCardDetailsAddedInPaymentPage(String cardName, String CardNumber) {
        int cardNumberSubStringValue = 15;
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        //     getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        // actionMoveToElementClick(getElement("tataCardPaymentTab"));
        logger.info("CardName and number details are: " + getElement("savedCardName", cardName).getText() + "  " +
                getElement("savedCardNumber", cardName).getText().substring(cardNumberSubStringValue));
        assertThat(cardName).describedAs("user validates card name").
                isEqualTo(getElement("savedCardName", cardName).getText());
        assertThat(CardNumber).describedAs("user validates card number").
                isEqualTo(getElement("savedCardNumber", cardName).getText().substring(cardNumberSubStringValue));
        getDriver().switchTo().defaultContent();
        passStepExecution("User validates saved card details appears on payment page");
    }


    /*
       user clicks on proceed with other payment option
   */
    @And("^user clicks on proceed with another payment button$")
    public void userClicksOnProceedWithAnotherPaymentButton() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));

        //   windowScrollIntoViewByWebElement(getElement("paymentVoucherOtherPaymentOptionButton"));
        //  conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentVoucherOtherPaymentOptionButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        //  windowScrollIntoViewByWebElement(getElement("paymentVoucherOtherPaymentOptionButton"));
        assertStepExecution(true, getElement("paymentVoucherOtherPaymentOptionButton").isDisplayed(), "Proceed with other payment button displayed");
        //   actionMoveToElementClick(getElement("paymentVoucherOtherPaymentOptionButton"));
        windowScrollIntoViewByWebElement(getElement("paymentVoucherOtherPaymentOptionButton"));
        getElement("paymentVoucherOtherPaymentOptionButton").click();
    }


    /*
       user performs offer validation on payment page
   */
    @And("^user validates offer operation \"([^\"]*)\" on payment page for offer \"([^\"]*)\"$")
    public void userValidatesOfferOperationOnPaymentPageForOffer(String offerOperation, String offerName) {
        String requiredPaymentOption, notRequiredPaymentOption;
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
        switch (offerOperation) {
            case "offerApply":
                getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
                List<WebElement> paymentOptions = getElements("paymentOptionsDisplayed");
                setContext("payment_option_count", String.valueOf(paymentOptions.size()));
                getDriver().navigate().refresh();
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
                getElement("viewAllOffersPaymentPage").click();
                assertThat(getElement("selectOffer", offerName).isDisplayed());
                getElement("selectOffer", offerName).click();
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
                logger.info("selected offer is: " + getElement("selectedOffer").getText());
                assertThat(offerName).describedAs("Provided offer is not selected").
                        isEqualToIgnoringCase(getElement("selectedOffer").getText());
                break;

            case "offerRemove":
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
                assertThat(getElement("removeOffer").isDisplayed());
                getElement("removeOffer").click();
                getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
                List<WebElement> paymentOptions1 = getElements("paymentOptionsDisplayed");
                assertThat(Integer.parseInt(getContext("payment_option_count"))).describedAs
                                ("Payment options not decreased").
                        isEqualTo(paymentOptions1.size());
                break;
            case "offerValidate":
                boolean requiredPaymentOptionPresent = false;
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
                getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
                List<WebElement> paymentOptions2 = getElements("paymentOptionsDisplayed");
                assertThat(Integer.parseInt(getContext("payment_option_count"))).describedAs
                                ("Payment options not decreased. Payment locking not happening").
                        isGreaterThanOrEqualTo(paymentOptions2.size());

                requiredPaymentOption = splitTextWithIndexing(offerName, splitOptionOne, paymentPageScrollDownFirstIndex);
                notRequiredPaymentOption = splitTextWithIndexing(offerName, splitOptionOne, paymentSearchResultFirstIndex);

                String[] requiredPaymentOptions = requiredPaymentOption.split(splitOption);
                String[] notrequiredPaymentOptions = notRequiredPaymentOption.split(splitOption);

                for (String requiredPayment : requiredPaymentOptions) {
                    logger.info("requiredPayment is: " + requiredPayment);
                    for (WebElement displayedPaymentOption : paymentOptions2) {
                        if (requiredPayment.equalsIgnoreCase(displayedPaymentOption.getText())) {
                            requiredPaymentOptionPresent = true;
                            break;
                        } else {
                            requiredPaymentOptionPresent = false;
                        }
                    }
                    assertThat(requiredPaymentOptionPresent).describedAs
                            ("Required payment option is present");
                }

                for (String unwantedPaymentOption : notrequiredPaymentOptions) {
                    logger.info("unwantedPaymentOption is: " + unwantedPaymentOption);
                    for (WebElement displayedPaymentOption : paymentOptions2) {

                        assertThat(unwantedPaymentOption)
                                .describedAs("Unwanted payment method displayed on payment page ")
                                .isNotEqualTo(displayedPaymentOption.getText());

                    }
                }
                break;

            case "offerDisplayCheck":
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
                getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));

                break;
        }
        passStepExecution("user performs offer validation on payment page");
    }


    /*
          User performs testing with saved card
       */
 /*   @And("^user chooses payment method as saved card for saved card of \"([^\"]*)\"$")
    public void userChoosesPaymentMethodAsSavedCardForSavedCardOf(String savedCardName) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        assertStepExecution(true, getElement("paymentMethodSavedCard", savedCardName).isDisplayed(), "Saved card payment mode visibility");
        actionMoveToElementClick(getElement("paymentMethodSavedCard", savedCardName));
        actionMoveToElementClick(getElement("savedCardProceed", savedCardName));
    }*/
  /*  @And("^user validates offer operation \"([^\"]*)\" on payment page for offer \"([^\"]*)\"$")
    public void userValidatesOfferOperationOnPaymentPageForOffer(String offerOperation, String offerName) {
        String requiredPaymentOption, notRequiredPaymentOption;
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        List<WebElement> paymentOptions = getElements("paymentOptionsDisplayed");
        switch (offerOperation) {
            case "offerApply":
                setContext("payment_option_count", String.valueOf(paymentOptions.size()));
                getDriver().navigate().refresh();
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                getElement("viewAllOffersPaymentPage").click();
                getElement("selectOffer", offerName).click();
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                assertThat(offerName).describedAs("Provided offer is not selected").
                        isEqualToIgnoringCase(getElement("selectedOffer").getText());
                break;

            case "offerRemove":
                getDriver().navigate().refresh();
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                getElement("removeOffer").click();
                getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
                List<WebElement> paymentOptions1 = getElements("paymentOptionsDisplayed");
                assertThat(Integer.parseInt(getContext("payment_option_count"))).describedAs
                        ("Payment options not decreased").
                        isEqualTo(paymentOptions1.size());
                break;
            case "offerValidate":
                boolean requiredPaymentOptionPresent = false;
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                assertThat(Integer.parseInt(getContext("payment_option_count"))).describedAs
                        ("Payment options not decreased").
                        isGreaterThan(paymentOptions.size());

                requiredPaymentOption = splitTextWithIndexing(offerName, splitOptionOne, paymentPageScrollDownFirstIndex);
                notRequiredPaymentOption = splitTextWithIndexing(offerName, splitOptionOne, paymentSearchResultFirstIndex);

                String[] requiredPaymentOptions = requiredPaymentOption.split(splitOption);
                String[] notrequiredPaymentOptions = notRequiredPaymentOption.split(splitOption);

                for (String requiredPayment : requiredPaymentOptions) {
                    logger.info("requiredPayment is: " + requiredPayment);
                    for (WebElement displayedPaymentOption : paymentOptions) {
                        if (requiredPayment.equalsIgnoreCase(displayedPaymentOption.getText())) {
                            requiredPaymentOptionPresent = true;
                            break;
                        } else {
                            requiredPaymentOptionPresent = false;
                        }
                    }
                    assertThat(requiredPaymentOptionPresent).describedAs
                            ("Required payment option is present");
                }

                outerPaymentMethodNotRequired:
                for (String unwantedPaymentOption : notrequiredPaymentOptions) {
                    logger.info("unwantedPaymentOption is: " + unwantedPaymentOption);
                    for (WebElement displayedPaymentOption : paymentOptions) {
                        if (unwantedPaymentOption.equalsIgnoreCase(displayedPaymentOption.getText())) {
                            Assert.fail("Unwanted payment method displayed on payment page");
                            break outerPaymentMethodNotRequired;
                        }
                    }
                }
                break;
        }
        passStepExecution("user performs offer validation on payment page");
    }*/

    /*
        User choose payment method as tata pay and fill card details and click pay
    */
    @And("^user chooses payment method as tata pay and fills card details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and clicks pay$")
    public void userChoosesPaymentMethodAsTataPayAndFillsCardDetailsAndClicksPay(String orderCreditCardNumber, String orderCreditCardMonth, String orderCreditCardYear, String orderCreditCardCvv) {
        logger.info("User provided credit cards details " + " " + orderCreditCardNumber + " " + orderCreditCardMonth + " " + orderCreditCardYear + " " + orderCreditCardCvv);
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));

        // getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        //actionMoveToElementClick(getElement("paymentMethodCardOptionCredit"));
        windowScrollIntoViewByWebElement(getElement("paymentMethodAddNewCardOption"));
        actionMoveToElementClick(getElement("paymentMethodAddNewCardOption"));
        conditionalWait(ExpectedConditions.visibilityOf(getElement("paymentMethodCardNumberInput")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("paymentMethodCardNumberInput").sendKeys(orderCreditCardNumber);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardMonth);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardYear);
        getElement("paymentMethodCardCVVInput").sendKeys(orderCreditCardCvv);
        actionMoveToElementClick(getElement("paymentSaveCardOption"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentMethodProceedButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("paymentMethodProceedButton") != null,
                "User choose payment method as tata pay and fill card details and click pay");
        actionMoveToElementClick(getElement("paymentMethodProceedButton"));
    }


    @And("^user chooses payment method as credit debit cards with details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and clicks pay$")
    public void userChoosesPaymentMethodAsCreditDebitCardsWithDetailsAndClicksPay(String orderCreditCardName, String orderCreditCardNumber, String orderCreditCardMonth, String orderCreditCardYear, String orderCreditCardCvv) {
        if (getOptionalElement("offerPopupSkipOnPayment") != null) {
            getElement("offerPopupSkipOnPayment").click();
        }
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        actionMoveToElementClick(getElement("tataPayPaymentTab"));
        windowScrollIntoViewByWebElement(getElement("tataCardPaymentTab"));
        getOptionalElement("tataCardPaymentTab").click();
//        actionMoveToElementClick(getElement("paymentMethodCardOptionCredit"));
        windowScrollIntoViewByWebElement(getElement("paymentMethodAddNewCardOption"));

        if (getOptionalElement("paymentMethodAddNewCardOption") != null) {
            actionMoveToElementClick(getElement("paymentMethodAddNewCardOption"));
        }
        conditionalWait(ExpectedConditions.visibilityOf(getElement("paymentMethodCardNumberInput")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("paymentMethodCardNumberInput").sendKeys(orderCreditCardNumber);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardMonth);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardYear);
        getElement("paymentMethodCardCVVInput").sendKeys(orderCreditCardCvv);
//        actionMoveToElementClick(getElement("paymentSaveCardOption"));
        windowScrollIntoViewByWebElement(getElement("paymentMethodProceedButton"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentMethodProceedButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("paymentMethodProceedButton") != null,
                "User choose payment method as tata pay and fill card details and click pay");
        actionMoveToElementClick(getElement("paymentMethodProceedButton"));
    }

    @And("^user clicks on credit debit card method of payment$")
    public void userClicksOnCreditDebitCardMethodOfPayment() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        actionMoveToElementClick(getElement("paymentMethodCardOptionCredit"));
    }


    @And("^user validates if net payment amount less than twenty five thousand then POD should display and if net payment amount more than twenty five thousand then POD option should not display$")
    public void userValidatesIfNetPaymentAmountLessThanTwentyFiveThousandThenPODShouldDisplayAndIfNetPaymentAmountMoreThanTwentyFiveThousandThenPODOptionShouldNotDisplay() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String netAmount = getElement("netAmount").getText().trim().replace("₹", "").replace(",", "");
        int netAmountValue = Integer.parseInt(netAmount.split("\\.")[0]);
        logger.info("net amount balance :- " + netAmountValue);
        if (netAmountValue <= 25000) {
            getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
            assertThat(getElement("payOnDeliveryTab").isDisplayed()).
                    describedAs("Pay on delivery option should display");
            logger.info("Pay on delivery option should display");
        } else
            getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        logger.info("Pay on delivery option should not display");
        assertThat(getOptionalElement("payOnDeliveryTab") == null).
                describedAs("Pay on delivery option should not display");

        getDriver().switchTo().defaultContent();
    }


 /*   @Given("^user handles gc file$")
    public void userHandlesGcFile()  throws IOException {

        Date objDate = new Date();
        long timeMilli = objDate.getTime();
       *//* logger.info("Date to be used: " + objDate.toString().replaceAll("\\s", "") + " file name: " +
                getConfig("Search_Text_File_Path") + "_" + splitTextWithIndexing(keywordToCheck, splitOptionSynonym, pLPPageScrollDownFirstIndex).
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");

        File file = new File(getConfig("Search_Text_File_Path") + "_" + "gcfile".
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");
        FileWriter fW = new FileWriter(file.getAbsoluteFile(), true);
        BufferedWriter bW = new BufferedWriter(fW);
        if (file.createNewFile()) {
            logger.info("File created: " + file.getName());
        } else {
            logger.info("File already exists " + file.getName());
        }
      //  BufferedReader in = new BufferedReader(Reader in, int size);
   //     bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" + searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");

        bW.close();
*//*





        try {
            File myObj = new File(getConfig("gcFileToBeUsed"));
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println("GC file entry: "+data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }*/

    @And("^user validates if net amount less than twenty five thousand then also pay on delivery payment mode should not display$")
    public void userValidatesIfNetAmountLessThanTwentyFiveThousandThenAlsoPayOnDeliveryPaymentModeShouldNotDisplay() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String netAmount = getElement("netAmount").getText().trim().replace("₹", "").replace(",", "");
        int netAmountValue = Integer.parseInt(netAmount.split("\\.")[0]);
        logger.info("net amount balance :- " + netAmountValue);
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        assertStepExecution(true, getOptionalElement("payOnDeliveryTab") == null, "pay on delivery mode should not display");
        getDriver().switchTo().defaultContent();
    }

    @Given("^user handles gc file$")
    public void userHandlesGcFile() {
        try {
       /*     List<String> allGCCode = new ArrayList<String>();
            File myObj = new File(getConfig("gcFileToBeUsed"));

            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                allGCCode.add(data);

                logger.info("GC file entry: "+data);

            }
            myReader.close();
            for (int i=1; i<allGCCode.size();i++){
                String[] gcArray = allGCCode.get(i).split(",");
                if (gcArray[2].equalsIgnoreCase("NA")){
                    logger.info("not used gc is: "+gcArray[0]+" pin: "+gcArray[1]);
                    setContext("gcCardNoToUse",gcArray[0]);
                    setContext("gcCardPinToUse",gcArray[1]);

                    break;
                }
                else if (gcArray[2].equalsIgnoreCase("fully")){
                    logger.info("fully used gc is: "+gcArray[0]+" pin: "+gcArray[1]);
                }

                else if (gcArray[2].equalsIgnoreCase("partially")){
                    logger.info("partially used gc is: "+gcArray[0]+" pin: "+gcArray[1]);
                }
            }

            logger.info("get context gc is: "+getContext("gcCardNoToUse")+" pin: "+getContext("gcCardPinToUse"));
*/
         /*   File file = new File(getConfig("gcFileToBeUsed"));
            FileWriter fW = new FileWriter(file.getAbsoluteFile(), true);
            BufferedWriter bW = new BufferedWriter(fW);
            Scanner myReader = new Scanner(file);

            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();

                logger.info("GC file entry: " + data);
                logger.info("GC file entry to write: " + data + "test");
                bW.write(data + "test");
                System.out.println("" + myReader.nextLine());
                //remove the row
                myReader.remove();
                bW.close();
                break;
            }
            myReader.close();
      //      https://www.geeksforgeeks.org/java-program-delete-certain-text-file/

           if (file.createNewFile()) {
                logger.info("File created: " + file.getName());
            } else {
                logger.info("File already exists " + file.getName());
            }*/

/*
            PrintWriter pw = new PrintWriter(getConfig("gcFileToBeUsed"));
            BufferedReader br1 = new BufferedReader(new FileReader(getConfig("gcFileToBeUsed")));
            String line1 = br1.readLine();
            pw.println("pw.println: "+line1);

         //   pw.flush();
            br1.close();
            pw.close();*/

    /*    } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } catch (IOException ie) {
            System.out.println("An error occurred.");
            ie.printStackTrace();
        }*/


            // next approach
/*

        PrintWriter pw = new PrintWriter("output.txt");
        BufferedReader br1 = new BufferedReader(new FileReader("input.txt"));

        String line1 = br1.readLine();
        pw.flush();
*/
            List<String> allGCCode = new ArrayList<String>();
            File myObj = new File(getConfig("gcFileToBeUsed"));
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                allGCCode.add(data);

                logger.info("GC file entry: " + data);

            }
            myReader.close();
            BufferedReader br1 = new BufferedReader(new FileReader(getConfig("gcFileToBeUsed")));
            PrintWriter pw = new PrintWriter(getConfig("gcFileToBeUsed"));

            logger.info("list size: " + allGCCode.size());
            for (int i = 0; i < allGCCode.size(); i++) {
                if (i == 1) {
                    setContext("gcDetails", allGCCode.get(i));
                } else {
                    pw.println(allGCCode.get(i));
                }







              /*  String[] gcArray = allGCCode.get(i).split(",");
                if (gcArray[2].equalsIgnoreCase("NA")) {
                    logger.info("not used gc is: " + gcArray[0] + " pin: " + gcArray[1]);
                    setContext("gcCardNoToUse", gcArray[0]);
                    setContext("gcCardPinToUse", gcArray[1]);
                    String line1 = br1.readLine();
                //    pw.println(line1);
                //    break;
                } else if (gcArray[2].equalsIgnoreCase("fully")) {
                    logger.info("fully used gc is: " + gcArray[0] + " pin: " + gcArray[1]);
                } else if (gcArray[2].equalsIgnoreCase("partially")) {
                    logger.info("partially used gc is: " + gcArray[0] + " pin: " + gcArray[1]);
                }*/
            }
            logger.info("GC details to use: " + getContext("gcDetails"));

            //   pw.flush();

            // closing resources
            br1.close();
            pw.close();

        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } catch (IOException ie) {
            System.out.println("An error occurred.");
            ie.printStackTrace();
        }


    }

    @And("^user gets gift card$")
    public void userGetsGiftCard() {
        try {

            List<String> allGCCode = new ArrayList<String>();
            File myObj = new File(getConfig("gcFileToBeUsed"));
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                allGCCode.add(data);

                logger.info("GC file entry: " + data);

            }
            myReader.close();
            BufferedReader br1 = new BufferedReader(new FileReader(getConfig("gcFileToBeUsed")));
            PrintWriter pw = new PrintWriter(getConfig("gcFileToBeUsed"));

            logger.info("list size: " + allGCCode.size());
            for (int i = 0; i < allGCCode.size(); i++) {
                if (i == 1) {
                    setContext("gcDetails", allGCCode.get(i));
                } else {
                    pw.println(allGCCode.get(i));
                }
            }
            logger.info("GC details to use: " + getContext("gcDetails"));
            //   pw.flush();
            br1.close();
            pw.close();

        } catch (IOException ie) {
            System.out.println("An error occurred.");
            ie.printStackTrace();
        }

    }

    @And("^user chooses payment method as gift card and fills card details \"([^\"]*)\", \"([^\"]*)\" and clicks on apply button$")
    public void userChoosesPaymentMethodAsGiftCardAndFillsCardDetailsAndClicksOnApplyButton(String orderGiftCardNumber, String orderGiftCardPin) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        int paymentMethodPageFirstIndex = 0, paymentMethodPageSecondIndex = 1;
        String finalMessage, amountZero = "0", toValidateGiftCardPayableMessageOnPaymentPage;
        logger.info("User provided gift cards details " + " " + orderGiftCardNumber + " " + orderGiftCardPin);

        userSelectsGCVouchergramOption("Gift card");

        getElement("orderGiftCardNumberInput").sendKeys(orderGiftCardNumber);
        getElement("orderGiftCardPinInput").sendKeys(orderGiftCardPin);
        getElement("clickOnGcVApplyButton").click();
        String giftCardAmount = splitTextWithIndexing(getElement("giftCardAmount").getText(), splitOptionOne, paymentMethodPageSecondIndex);
        logger.info(" Gift card amount is: " + giftCardAmount);
        if (giftCardAmount.contains("."))
            finalMessage = "Your applied card is " + orderGiftCardNumber + ". Amount deducted from your card :" + giftCardAmount;
        else
            finalMessage = ("Your applied card is " + orderGiftCardNumber + ". Amount deducted from your card :" + giftCardAmount).concat(".").concat(amountZero);
        logger.info("Gift card applied and amount deducted message is: " + finalMessage);
        String giftCardMessageOnPaymentPage = getElement("giftCardMessageOnPaymentPage").getText();
        logger.info("Gift card message is: " + giftCardMessageOnPaymentPage);
        assertThat(giftCardMessageOnPaymentPage).describedAs("Validation of gift card applied and amount deducted text").isEqualTo(finalMessage);
        String balanceAmount = (getElement("balanceAmount").getText());
        logger.info("Balance amount is: " + balanceAmount + "Split " + numericValuesExtractionMethod(splitTextWithIndexing(balanceAmount, splitOption, paymentMethodPageFirstIndex)));
        if (numericValuesExtractionMethod(splitTextWithIndexing(balanceAmount, splitOption, paymentMethodPageFirstIndex)) > paymentMethodPageFirstIndex)
            toValidateGiftCardPayableMessageOnPaymentPage = ("Balance amount payable Rs. ").concat(balanceAmount);
        else
            toValidateGiftCardPayableMessageOnPaymentPage = ("Balance amount payable Rs. ").concat(amountZero);
        String giftCardPayableMessageOnPaymentPage = getElement("balanceAmountPayableMsg").getText();
        logger.info("Gift card payable message is: " + giftCardPayableMessageOnPaymentPage);
        assertThat(giftCardPayableMessageOnPaymentPage).describedAs("Validation of balance amount payable text").isEqualTo(toValidateGiftCardPayableMessageOnPaymentPage);
        //getElement("gcApplyBtn").click();
        passStepExecution("User chooses payment method as gift card and fills card details and click on apply button");
    }

    @And("^user validates warning massage payment on delivery is not applicable for the outstanding amount and clicks on Proceed with other payment option$")
    public void userValidatesWarningMassagePaymentOnDeliveryIsNotApplicableForTheOutstandingAmountAndClicksOnProceedWithOtherPaymentOption() {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("otherPaymentOptions")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        if (getContext("podProducts") != null) {
            assertThat(getElement("podEligibleAlert").getText()).isEqualTo("Please note that payment on delivery is not applicable for the outstanding amount.").describedAs("POD alert massage should match");
        }
        getElement("otherPaymentOptions").click();
    }

    @And("^user validates applied offers \"([^\"]*)\" in payment page$")
    public void userValidatesAppliedOffersFromPaymentPage(String offerName) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("offerStatus")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("offerStatus").isDisplayed()).isEqualTo(true).describedAs("OFFER APPLIED text should display");
        String appliedOffer = getElement("offersName").getText().trim();
        logger.info("Offer Name :- " + appliedOffer);
        assertThat(getElement("offersName").getText().trim()).isEqualTo(offerName).describedAs("Offer name should match");
    }

    @And("^user clicks on view all offers button and clicks radio button of \"([^\"]*)\" offer in payment page$")
    public void userClicksOnViewAllOffersButtonAndClicksRadioButtonOfOfferInPaymentPage(String offerName) throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("viewAllOffersBtn")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("viewAllOffersBtn").isDisplayed()).isEqualTo(true).describedAs("view offer button should display");
        getElement("viewAllOffersBtn").click();
        assertThat(getElement("paymentOffer", offerName).isDisplayed()).isEqualTo(true).describedAs("Offer name should display");
        getElement("paymentOffer", offerName).click();
        Thread.sleep(5000);
    }


    /*
        User pays with saved card
     */
    @And("user chooses payment method as saved card for saved card of {string} and otp {string}")
    public void userChoosesPaymentMethodAsSavedCardForSavedCardOfAndOtp(String savedCardName, String savedCardOtp) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        actionMoveToElementClick(getElement("paymentMethodCardOptionCredit"));
        windowScrollIntoViewByWebElement(getElement("paymentMethodSavedCard", savedCardName));

        assertStepExecution(true, getElement("paymentMethodSavedCard", savedCardName).isDisplayed(), "Saved card payment mode visibility");
        actionMoveToElementClick(getElement("paymentMethodSavedCard", savedCardName));
        getElement("savedCardCVV").sendKeys(savedCardOtp);
        actionMoveToElementClick(getElement("savedCardProceed", savedCardName));
    }


    /*
       User validates offer section title
    */
    @And("user validates offers section title for offers {string}")
    public void userValidatesOffersSectionTitleForOffers(String offerCount) {
        logger.info("offer title displayed: " + getElement("offerSectionTitle").getText());
        assertStepExecution((offerCount + " Offers Applied").toLowerCase(), getElement("offerSectionTitle").getText().toLowerCase(),
                "Offer section title text");
    }

    /*
     User clicks on View all offers link
  */
    @And("user clicks on view all offers on payment page")
    public void userClicksOnViewAllOffersOnPaymentPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getElement("viewAllOffersLinkPaymentPage").isDisplayed(), "View All offers link is not displayed on payment page");
        getElement("viewAllOffersLinkPaymentPage").click();
    }

    /*
   User clicks on the offer
*/
    @And("user selects additional offer as {string} from offer pop up")
    public void userSelectsAdditionalOfferAsFromOfferPopUp(String offerToSelect) {
        assertStepExecution(true, getElement("offerToSelectPaymentPage", offerToSelect).isDisplayed(),
                "Offer to select displayed");
        getElement("offerToSelectPaymentPage", offerToSelect).click();
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
    }

    @And("user waits until payment methods are loading")
    public void userWaitsUntilPaymentMethodsAreLoading() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(8000);
        for (int i = 0; i < 6; i++) {
            String pageSource = getDriver().getPageSource();
            if (!(pageSource.contains("id=\"juspay_iframe\"") | (pageSource.contains("name=\"HyperServices\"")))) {
                getDriver().navigate().refresh();
                if (getOptionalElement("offerPopupSkipOnPayment") != null) {
                    getElement("offerPopupSkipOnPayment").click();
                }
                Thread.sleep(8000);

            }


        }
    }


    /*
    User removes the offer
     */
    @And("user validates remove offer button is displayed for the offer selected")
    public void userValidatesRemoveOfferButtonIsDisplayedForTheOfferSelected() {
        assertStepExecution(true, getElement("removeOfferLink").isDisplayed(), "user validates remove offer link not displayed");
        getElement("removeOfferLink").click();
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
    }

   /*
   Skip In Additional Offer popup
   */

    @And("user handles additional offer popup in payment page")
    public void userHandlePopupInPaymentPage() {
        assertStepExecution(true, getElement("skipInAdditionalOfferPopupButton").isDisplayed(), "user handles additional offer popup in payment page");
        getElement("skipInAdditionalOfferPopupButton").click();
    }

    /*
    User Lands on Payment Page
     */
    @Then("user lands on payment page")
    public void userLandsOnPaymentPage() {
        String paymentPageName = "Payment";
        String pageTitle = getElement("paymentPageTitle").getText();
        logger.info(pageTitle);
        assertStepExecution(pageTitle, paymentPageName, "user lands on payment page");
    }

    /*
    User Clicks on View all offers link
     */
    @Then("user validates view all offers link is present in payment page")
    public void userValidatesViewAllOffersLinkIsPresentInPaymentPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getElement("viewAllOffersLinkPaymentPage").isDisplayed(), "user validates view all offers link is not present in payment page");
        logger.info("Link is displayed with the name :" + getElement("viewAllOffersLinkPaymentPage").getText());
    }

    /*
    User Clicks on Apply offers link in additional offers pop up
     */
    @And("user clicks on additional offers as {string} , {string} from offer pop up")
    public void userClicksOnAdditionalOffersAsFromOfferPopUp(String applyOffer1, String applyOffer2) {

        if (getOptionalElement("AdditionalOffer", applyOffer1).isDisplayed()) {
            if (getOptionalElement("AdditionalOffer", applyOffer2).isDisplayed()) {
                getElement("ClickOnApplyOfferLink").click();
                logger.info("One Additional Offer applied ");
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
            }
        }
    }

    /*
    User validates Exchange product details in Payment Page
     */
    @Then("user validates exchange product details in Payment Page")
    public void userValidatesExchangeProductDetailsInPaymentPage() {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("exchangeProductName")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("exchangeProductName").getText().trim()).containsIgnoringCase(getContext("exchangeProName")).describedAs("Exchange Product Name should match");
        assertThat(getElement("exchangePrice").getText().trim()).containsIgnoringCase(getContext("fixedExValue")).describedAs("Exchange Product price should match");
        assertThat(getElement("exchangeText").getText().trim()).containsIgnoringCase("Your old mobile will be examined before confirming exchange during delivery.").describedAs("Message should display");
    }

    /*
    User validates Exchange value details in Payment Page
     */
    @Then("user validates exchange values {string} , {string} , {string} in Order Summary Of Payment Page")
    public void userValidatesExchangeValuesInOrderSummaryOfPaymentPage(String exchangeValue, String paybleValue, String productDetail) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("exchangeValue")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        String fixedValue = getElement("exchangeValue").getText().replace("- ₹", "");
        String payblValue = getElement("paybleValue").getText().replace("₹", "");
        String produtName = (getElement("exchangProDetails").getText().substring(18));

        logger.info("Fixed Value :- " + fixedValue);
        logger.info("Payble Value :- " + payblValue);
        logger.info("Product Name :- " + produtName);

        setContext("fixedExValue", fixedValue);
        setContext("exchangeProName", produtName);

        assertThat(fixedValue).isEqualTo(exchangeValue).describedAs("Exchange value should match");
        assertThat(payblValue).isEqualTo(paybleValue).describedAs("Payble value should match");
        assertThat(produtName).isEqualTo(productDetail).describedAs("Payble value should match");
    }

    /*
    User Lands on retry-Payment Page
     */
    @Then("user should lands on retry payment page")
    public void userShouldLandsOnRetryPaymentPage() {
        if (getOptionalElement("offerPopupSkipOnPayment") != null) {
            getElement("offerPopupSkipOnPayment").click();
        }
        String CurrentUrl = getDriver().getCurrentUrl();
        assertThat(CurrentUrl.contains("retry-payment")).describedAs("user navigate back to retry-payment page");
    }

    /*
     User validates total available NeuCoins in Payment Page
     */
    @And("user should choose to pay using NeuCoins by selecting the check box in Payments page")
    public void userShouldChooseToPayUsingNeuCoinsBySelectingTheCheckBoxInPaymentsPage() throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("NeuCoinsCheckbox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("NeuCoinsCheckbox").isDisplayed(), "User validates NeuCoins Checkbox is not Present");
        logger.info("Total Available NeuCoins message is: " + getElement("totalNeuCoins").getText());
        String availableNeuCoins = String.valueOf(numericValuesExtractionMethod(getElement("totalNeuCoins").getText()));
        logger.info("Total Available NeuCoins is: " + availableNeuCoins);
        setContext("availableNeuCoins", availableNeuCoins);

        /*User clicks on NeuCoins checkbox in Payment Page*/
        if (getOptionalElement("offerPopupSkipOnPayment") != null) {
            getElement("offerPopupSkipOnPayment").click();
        }
        getDriver().findElement(By.xpath(getLocator("NeuCoinsCheckbox"))).click();
    }

    /*
    user validates entire applied neuCoins balance should used by default in order summary of payment page
     */
    @And("user validates entire applied neuCoins balance should used by default in order summary of payment page")
    public void userValidatesEntireAppliedNeuCoinsBalanceShouldUsedByDefaultInOrderSummaryOfPaymentPage() {
        String availableNeuCoins = String.valueOf(numericValuesExtractionMethod(getElement("totalNeuCoins").getText()));
        setContext("availableNeuCoins", availableNeuCoins);
        logger.info("Total NeuCoins value is : " + availableNeuCoins);

        String availableNeuCoins1 = String.valueOf(numericValuesExtractionMethod(getElement("appliedNeuCoins").getText()));
        //availableNeuCoins1= availableNeuCoins1.replace("00","");
        //String appliedCoins = getElement("appliedNeuCoins").getText().replace("- ₹", "");
        //appliedCoins = appliedCoins.replace(".00", "").trim();
        logger.info("Applied NeuCoins value is : " + availableNeuCoins1);

        assertThat(availableNeuCoins).isEqualTo(availableNeuCoins1).describedAs("Available neuCoins matched with Applied neuCoins");
        assertThat(availableNeuCoins).containsIgnoringCase(availableNeuCoins1).describedAs("Available neuCoins matched with Applied neuCoins");
        passStepExecution("User select NeuCoins as a payment option and it applied entire available balance by default");

    }

    /*
     User validates Edit Link is Displayed and Click on Edit Link
     */
    @And("user validates edit link is displayed and click on Edit link")
    public void userValidatesEditLinkIsDisplayedAndClickOnEditLink() throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("editLinkInPaymentPage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("editLinkInPaymentPage") != null, "Edit Link is displayed");
        getElement("editLinkInPaymentPage").click();
        Thread.sleep(3000);


    }

    /*
     User validates Popup heading as NEUCOINS
     */
    @And("user validates Popup heading as {string}")
    public void userValidatesPopupHeadingAs(String Heading) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String HeadingNeucoins = getElement("HeadingNeuCoins", Heading).getText().trim();
        assertStepExecution(true, HeadingNeucoins.contains(Heading), "NeuCoins Heading Matched");
    }

    /*
      User validates Popup subtext message
      */
    @And("user validates Popup subtext message as {string}")
    public void userValidatesPopupSubtextMessageAs(String SubtextMsgInNeuCoins) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String SubtextMesssageInNeuCoin = getElement("SubtextMsgInNeuCoins", SubtextMsgInNeuCoins).getText().trim();
        //assertStepExecution(true, SubtextMesssageInNeuCoin.contains(SubtextMsgInNeuCoins), "Sub text message in NeuCoins Matched");
        assertStepExecution(true, SubtextMsgInNeuCoins.equalsIgnoreCase(SubtextMesssageInNeuCoin), "Sub text message in NeuCoins Matched");
    }

    @And("user validates available NeuCoins balance should displayed inside Popup as {string}")
    public void userValidatesAvailableNeuCoinsBalanceShouldDisplayedInsidePopupAs(String NeuCoinsAvailableText) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String NeuCoinsAvailableTextMsg = getElement("NeuCoinsAvailableText", NeuCoinsAvailableText).getText().trim();
        assertStepExecution(true, NeuCoinsAvailableTextMsg.contains(NeuCoinsAvailableText), "NeuCoins Available text Matched");
    }

    /*
      User can edit textBox to redeem neuCoins
      */
    @And("user can edit textBox {string} to redeem neuCoins")
    public void userCanEditTextBoxToRedeemNeuCoins(String textBoxValue) {
        getElement("textBoxXpath").clear();
        getElement("textBoxXpath").sendKeys(textBoxValue);
        logger.info("user can edit the NeuCoins to redeem value as : " + getElement("textBoxXpath").getAttribute("Value"));

    }

    /*
     User click on confirm button of NeuCoins pop-up
     */
    @Then("user validates confirm button is displayed and click on confirm button")
    public void userValidatesConfirmButtonIsDisplayedAndClickOnConfirmButton() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getElement("NeuCoinsConfirmButton").isEnabled(), "NeuCoins confirm button is not enabled");
        Thread.sleep(2000);
        getElement("NeuCoinsConfirmButton").click();
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
    }

    /*
     User validates neuCoins applied text messages
     */
    @Then("user validates neuCoins applied text messages {string}, {string}, {string}")
    public void userValidatesNeuCoinsAppliedTextMessages(String textMessage1, String textMessage2, String textMessage3) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String NeuCoinsTextMessage1 = getElement("totalNeuCoins").getText().trim();
        assertStepExecution(true, NeuCoinsTextMessage1.contains(textMessage1), "NeuCoins text Message1 not matched");

        String NeuCoinsTextMessage2 = getElement("neuCoinsBalance").getText().trim();
        assertStepExecution(true, NeuCoinsTextMessage2.contains(textMessage2), "NeuCoins text Message2 not matched");
        assertStepExecution(true, NeuCoinsTextMessage2.contains(textMessage2), "NeuCoins text Message3 not matched");
    }

    /*
    User should Check and then UnCheck NeuCoins CheckBox and Validate full balance is available
    */
    @Then("user should check and then uncheck neuCoins checkbox and validate full balance is available")
    public void userShouldCheckAndThenUnCheckNeuCoinsCheckBoxAndValidateFullBalanceIsAvailable() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        getDriver().findElement(By.xpath(getLocator("NeuCoinsCheckbox"))).click();
        Thread.sleep(2000);

        String availableNeuCoins1 = String.valueOf(numericValuesExtractionMethod(getElement("totalNeuCoins").getText()));
        setContext("availableNeuCoins1", availableNeuCoins1);

        getDriver().findElement(By.xpath(getLocator("NeuCoinsCheckbox"))).click();
        Thread.sleep(2000);

        String availableNeuCoins2 = String.valueOf(numericValuesExtractionMethod(getElement("totalNeuCoins").getText()));
        setContext("availableNeuCoins2", availableNeuCoins2);

        assertThat(availableNeuCoins1).isEqualTo(availableNeuCoins2).describedAs("User validates full NeuCoins balance is available after check and uncheck the NeuCoins Checkbox");
    }

    /*
   User can edit textBox to redeem neuCoins and verify the remaining neuCoins
   */
    @Then("user can edit textBox {string} to redeem neuCoins and verify the remaining neuCoins")
    public void userCanEditTextBoxToRedeemNeuCoinsAndVerifyTheRemainingNeuCoins(String textBoxValue) throws InterruptedException {

        String totalNeuCoinsAvailable = String.valueOf(numericValuesExtractionMethod(getElement("totalNeuCoins").getText()));
        int totalNeuCoinsAvailableBalance = Integer.parseInt(totalNeuCoinsAvailable);
        logger.info("Total NeuCoins available balance before Pop-up checked value is : " + totalNeuCoinsAvailableBalance);

        getDriver().findElement(By.xpath(getLocator("NeuCoinsCheckbox"))).click();
        getElement("editLinkInPaymentPage").click();
        getElement("textBoxXpath").clear();
        getElement("textBoxXpath").sendKeys(textBoxValue);
        getElement("NeuCoinsConfirmButton").click();
        Thread.sleep(2000);

        String usingNeuCoins = String.valueOf(numericValuesExtractionMethod(getElement("totalNeuCoins").getText()));
        int usingNeuCoinsValue = Integer.parseInt(usingNeuCoins);
        logger.info("Total NeuCoins used : " + usingNeuCoinsValue);

        int RemainingNeuCoins = totalNeuCoinsAvailableBalance - usingNeuCoinsValue;
        logger.info("Remaining neuCoins is : " + RemainingNeuCoins);

        String RemainingNeuCoinsBal = String.valueOf(numericValuesExtractionMethod(getElement("neuCoinsBalance").getText()));
        int RemainingNeuCoinsBalance = Integer.parseInt(RemainingNeuCoinsBal);
        logger.info("Remaining neuCoins balance is : " + RemainingNeuCoins);

        assertThat(RemainingNeuCoins).isEqualTo(RemainingNeuCoinsBalance).describedAs("Remaining NeuCoins Balance should Match");
    }

    /*
       User clicks on tata pay option as payment method
       */
    @And("user clicks on tata pay option as payment method")
    public void userClicksOnTataPayOptionAsPaymentMethod() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        getElement("tataPayPaymentTab").click();
        getElement("tataPayRadioButton").click();
        getElement("proceedToPayButton").click();
        //waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(8000);
    }

    @And("user waits until tata pay page is loading")
    public void userWaitsUntilTataPayPageIsLoading() throws InterruptedException {
        Thread.sleep(8000);
        for (int i = 0; i < 6; i++) {
            String pageSource = getDriver().getPageSource();
            if (!(pageSource.contains("id=\"juspay_iframe\"") | (pageSource.contains("name=\"HyperServices\"")))) {
                getDriver().navigate().refresh();
                Thread.sleep(5000);
            }
        }
    }

    @Then("user validates neuCoins should displayed as an instrument inside Tata pay")
    public void userValidatesNeuCoinsShouldDisplayedAsAnInstrumentInsideTataPay() throws InterruptedException {
        assertStepExecution(true, getElement("neuCoinsInstrumentInsideTataPay") != null, "user validates neuCoins should displayed as an instrument inside Tata pay");
        Thread.sleep(3000);
    }

    @And("user checked the neuCoins checkbox and clicks on pay now button inside Tata pay")
    public void userCheckedTheNeuCoinsCheckboxAndClicksOnPayNowButtonInsideTataPay() throws InterruptedException {
        getDriver().findElement(By.xpath(getLocator("TataPayNeuCoinsCheckbox"))).click();
        getElement("TataPayButton").click();
        Thread.sleep(3000);
    }

    @And("user checked the neuCoins checkbox and clicks on pay now button")
    public void userCheckedTheNeuCoinsCheckboxAndClicksOnPayNowButton() throws InterruptedException {
        getDriver().findElement(By.xpath(getLocator("NeuCoinsCheckbox"))).click();
        getElement("payNowButton").click();
        Thread.sleep(3000);
    }

    @Then("user validates neuCoins should not displayed as an instrument inside Tata pay")
    public void userValidatesNeuCoinsShouldNotDisplayedAsAnInstrumentInsideTataPay() {
        assertStepExecution(true, getOptionalElement("neuCoinsInstrumentInsideTataPay") == null, "user validates neuCoins should not displayed as an instrument inside Tata pay");
    }

    @Then("user should validate neuCoins instrument name and logo on payment page")
    public void userShouldValidateNeuCoinsInstrumentNameAndLogoOnPaymentPage() {
        assertThat(getElement("neuCoinsInstrumentName")).describedAs("neuCoins instrument name validation").isNotNull();
        assertThat(getElement("neuCoinsLogo")).describedAs("neuCoins Logo Img validation").isNotNull();
        passStepExecution("user should validated neuCoins instrument name and logo on payment page : passed");
    }

    @Then("user should validate neuCoins point conversion {string} is displayed on payment page")
    public void userShouldValidateNeuCoinsPointConversionIsDisplayedOnPaymentPage(String message) {
        logger.info(getElement("neuCoinsPointConversionMessage").getText() + " and data from example : " + message);
        String neuCoinsPointConversionMessage = subStringTextWithIndexing(getElement("neuCoinsPointConversionMessage").getText(), 9, 28);
        logger.info("neuCoins Point Conversion Message is "+neuCoinsPointConversionMessage);
        assertStepExecution(true, neuCoinsPointConversionMessage.equals(message), "User should validate neuCoins point conversion message is displayed");
    }

    /*
      User validates NeuCoins available balance
      */
    @And("user validates neuCoins available text should displayed as {string}")
    public void userValidatesAvailableNeuCoinsBalanceShouldDisplayedAs(String NeuCoinsAvailableText) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String totalNeuCoinsCount = String.valueOf(numericValuesExtractionMethod(getElement("totalNeuCoins").getText()));
        logger.info("NeuCoins available count is : " + totalNeuCoinsCount);
        assertStepExecution(true, getElement("totalNeuCoins").getText().contains(NeuCoinsAvailableText), "NeuCoins available text is matched");
        //String NeuCoinsAvailableTextMessage = subStringTextWithIndexing(getElement("totalNeuCoins").getText(), 4,22);
    }

    /*
    user validates neuCoins is displayed as first instrument on the payments page
     */
    @And("user validates neuCoins is displayed as {string} on the payments page")
    public void userValidatesNeuCoinsIsDisplayedAsInstrumentOnThePaymentsPage(String firstInstrumentIsNeucoins) {
        String position1 = getElements("NeuCoinsInstrument").get(0).getText();
        logger.info("First position is " + position1);
        assertStepExecution(true, firstInstrumentIsNeucoins.equalsIgnoreCase(position1), "user verify " + position1 + " is present in First Index in Recently Viewed section");

    }

    /*
   user chooses payment method as voucher card and fills card details
    */
    @And("user chooses payment method as voucher card and fills card details {string}")
    public void userChoosesPaymentMethodAsVoucherCardAndFillsCardDetailsAndClickPay(String orderVoucherCardNumber) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        userSelectsGCVouchergramOption("Voucher");

        getElement("paymentVoucherNumberInputText").sendKeys(orderVoucherCardNumber);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("paymentVoucherApplyButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        actionMoveToElementClick(getElement("paymentVoucherApplyButton"));
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
    }

    /*
   user validates neuCoins is displayed out side tata pay on the payments page
    */
    @And("user validates neuCoins is displayed out side tata pay on the payments page")
    public void userValidatesNeuCoinsIsDisplayedOutSideTataPayOnThePaymentsPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getOptionalElement("neuCoinOption") != null, "Neu coin Option displayed");
    }

    /*
user validates neuCoins is not displayed in side tata pay on the payments page
*/
    @And("user validates neuCoins is not displayed in side tata pay on the payments page")
    public void userValidatesNeuCoinsIsNotDisplayedInSideTataPayOnThePaymentsPage() {
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getOptionalElement("neuCoinOption") == null, "Neu coin Option displayed");
        getDriver().switchTo().defaultContent();
    }

    /*
   user validates neuCoins applied line should displayed with negative sign
    */
    @And("user validates neuCoins applied line should displayed with negative sign")
    public void userValidatesNeuCoinsAppliedLineShouldDisplayedWithNegativeSign() {
        assertStepExecution(true, getElement("appliedNeuCoins").getText().contains("-"), "user validates neuCoins applied line should displayed with negative sign");
    }

    /*
  user validates opel instrument is present on the payments page
   */
    @And("user validates {string} is present on the payments page")
    public void userValidatesIsPresentOnThePaymentsPage(String opelInstrument) {
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        windowScrollIntoViewByWebElement(getElement("opelInstrumentOption", opelInstrument));
        windowScrollIntoViewAdjustment(0, 200);
        assertStepExecution(true, getOptionalElement("opelInstrumentOption", opelInstrument) != null, "Opel instrument option displayed");
        getDriver().switchTo().defaultContent();
    }

    /*
   user validates payable amount is present with pay now button
    */
    @And("user validates payable amount is present with pay now button")
    public void userValidatesPayableAmountIsPresentWithPayNowButton() {
        assertThat(getElement("payableAmount").isDisplayed()).describedAs("user validates payable amount is present");
        logger.info("Payable amount text is : " + getElement("payableAmount").getText() + " and the amount is: " + numericValuesExtractionMethod(getElement("payableAmount").getText()));
        int netAmount = numericValuesExtractionMethod(getElement("payableAmount").getText());
        assertThat(netAmount).isGreaterThan(0).describedAs("user validates payable amount is greater than Zero");
        assertThat(getElement("clickOnPayNowButton").isDisplayed()).describedAs("user validates payable amount is present with pay now button");
    }

    /*
     user clicks on pay now button in payment page
     */
    @And("user clicks on pay now button in payment page")
    public void userClicksOnPayNowButtonInPaymentPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("payNowButton").isEnabled(), "user validates payable amount is not present");
        windowScrollIntoViewByWebElement(getElement("payNowButton"));
        jsClick(getElement("payNowButton"));
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
    }

    /*
     user validates payable amount is not present and pay now button is present
     */
    @And("user validates payable amount is not present and pay now button is present")
    public void userValidatesPayableAmountIsNotPresentWithPayNowButton() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getOptionalElement("payableAmount") == null, "user validates payable amount is not present");
        windowScrollIntoViewAdjustment(0, 200);
        assertThat(getElement("clickOnPayNowButton").isDisplayed()).describedAs("user validates Pay now button is present");

    }

    /*
   user validates neucoin error messsage in neucoin edit popup
   */
    @And("user validates neucoin {string} in neucoin edit popup")
    public void userValidatesNeucoinInNeucoinEditPopup(String errorMessage) {
        logger.info("Neucoin increase error message is : " + getElement("neuCoinsPopupErrorMessage").getText());
        assertStepExecution(true, getElement("neuCoinsPopupErrorMessage").getText().contains(errorMessage), "user validates neucoin error message in neucoin edit popup");
    }

    /*
    user clicks on cross icon on neucoin edit popup
    */
    @And("user clicks on cross icon on neucoin edit popup")
    public void userClicksOnCrossIconOnNeucoinEditPopup() throws InterruptedException {
        getElement("neuCoinsEditPopupCrossIcon").click();
        Thread.sleep(3000);

    }

    /*
    user validates neuCoins error message
    */
    @Then("user should validates the error message {string}")
    public void userShouldValidatesTheErrorMessage(String errorMessageText) {
        assertStepExecution(true, getElement("neuCoinsErrorMessage").getText().contains(errorMessageText), "user validates neuCoins error message should display");
    }

    /*
    user validates checkbox selection is not allowed with message
    */
    @Then("user validates checkbox selection is not allowed with message {string}")
    public void userValidatesCheckboxSelectionIsNotAllowedWithMessage(String neuCoinsPayableOrderMessage) {
        assertStepExecution(false, getOptionalElement(("NeuCoinsCheckbox")).isSelected(), "NeuCoins checkbox is not selected");
        assertStepExecution(true, getElement("neuCoinsPayableOrderMessage").getText().equalsIgnoreCase(neuCoinsPayableOrderMessage), "Payable order message matched");

    }

    /*
    user validates pay now button is present outside voucher section
    */
    @And("user validates pay now button is present outside voucher section")
    public void userValidatesPayNowButtonIsPresentOutsideVoucherSection() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        windowScrollIntoViewAdjustment_scroll(0, 300);
        if (getOptionalElement("VoucherIframe") != null) {
            assertStepExecution(false, getOptionalElement("payNowButton") == null, "Pay now button is present Outside Voucher section");
        }
    }

    /*
  User Clicks on Apply offers link in additional offers pop up
   */
    @And("user clicks on additional offers as {string} from offer pop up")
    public void userClicksOnAdditionalOffersAsFromOfferPopUp(String applyOffer1) {
        List<WebElement> additionalOffers = getElements("additionalOffersList");
        logger.info("Total additional offers present for the product = " + additionalOffers.size());
        for (int i = 1; i <= additionalOffers.size(); i++) {
            String offerName = getElement("additionalOfferName", String.valueOf(i)).getText();
            logger.info("Offer is: " + offerName + "and option from DB is: " + applyOffer1);
            if (offerName.equalsIgnoreCase(applyOffer1)) {
                assertStepExecution(true, getOptionalElement("applyOfferPresentForTheParticularOffer", applyOffer1).isDisplayed(), "Apply offer is present");
                getElement("applyOfferPresentForTheParticularOffer", applyOffer1).click();
                logger.info("One Additional Offer applied ");
                break;
            }
        }
    }

    @And("user validates additional offers as {string} is applied")
    public void userValidatesAdditionalOffersAsIsApplied(String applyOffer1) {
        assertStepExecution(true, getElement("appliedAdditionalOffer", applyOffer1).isDisplayed(), "user validates additional offer is applied");
    }

    @And("user removed the applied offer as {string} from offer pop up")
    public void userRemovedTheAppliedOfferAsFromOfferPopUp(String applyOffer1) {
        assertStepExecution(true, getElement("removeAdditionalOffer", applyOffer1).isDisplayed(), "user validates remove offer is applied");
        getElement("removeAdditionalOffer", applyOffer1).click();
    }

    @And("user clicks on the cross button in offer popup")
    public void userClicksOnTheCrossButtonInOfferPopup() {
        getElement("clickOnCrossOfferButton").click();
    }

    @And("user validates additional offers as {string} is not applied")
    public void userValidatesAdditionalOffersAsIsNotApplied(String applyOffer1) {
        assertStepExecution(true, getOptionalElement("appliedAdditionalOffer", applyOffer1) == null, "user validates additional offers is not applied");
    }

    @And("user validates payment section should load by default")
    public void userValidatesPaymentSectionShouldLoadByDefault() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getElement("paymentMethodPageIframe") != null, "Payment opel section loaded by default");
    }

    @And("^user chooses payment method as credit debit cards without tatapay with details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and clicks pay$")
    public void userChoosesPaymentMethodAsCreditDebitCardsWithoutTatapayWithDetailsAndClicksPay(String orderCreditCardName, String orderCreditCardNumber, String orderCreditCardMonth, String orderCreditCardYear, String orderCreditCardCvv) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        //actionMoveToElementClick(getElement("preferredPayment"));
        if (getOptionalElement("tataCardPaymentTab") != null) {
            getOptionalElement("tataCardPaymentTab").click();
        }
        if (getOptionalElement("paymentMethodAddNewCardOption") != null) {
            actionMoveToElementClick(getElement("paymentMethodAddNewCardOption"));
        }
        conditionalWait(ExpectedConditions.visibilityOf(getElement("paymentMethodCardNumberInput")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("paymentMethodCardNumberInput").sendKeys(orderCreditCardNumber);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardMonth);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardYear);
        getElement("paymentMethodCardCVVInput").sendKeys(orderCreditCardCvv);
        actionMoveToElementClick(getElement("paymentSaveCardOption"));
        windowScrollIntoViewByWebElement(getElement("paymentMethodProceedButton"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentMethodProceedButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("paymentMethodProceedButton") != null,
                "User choose payment method as as credit debit cards without tatapay with details and fill card details and click pay");
        actionMoveToElementClick(getElement("paymentMethodProceedButton"));
    }

    @And("user clicks on continue button in payment page")
    public void userClicksOnContinueButtonInPaymentPage() throws InterruptedException {
        if (getOptionalElement("ContinueButtonInPayment") != null) {
            getElement("ContinueButtonInPayment").click();
            Thread.sleep(3000);
        }
    }

    @And("user provide minimum amount less than one {string} to use neuCoins and validate error {string}")
    public void userProvideMinimumAmountLessThanOneToUseNeuCoinsAndValidateError(String value1, String message1) throws InterruptedException {
        getElement("textBoxXpath").clear();
        getElement("textBoxXpath").sendKeys(value1);
        Thread.sleep(1000);
        assertThat(getElement("neuCoinsErrorMsg1", message1).getText()).isEqualTo(message1).describedAs("Error msg1 should display below NeuCoins textBox field");
        logger.info("Hey, you need at least 1 NeuCoin to pay using NeuCoins");
        getElement("neuCoinsEditPopupCrossIcon").click();

    }

    @And("user can edit neuCoins {string} more than available neuCoins and validate error {string}")
    public void userCanEditNeuCoinsMoreThanAvailableNeuCoinsnAndValidateError(String textBoxValue, String neuCoinsErrorMsg2) throws InterruptedException {
        getDriver().findElement(By.xpath(getLocator("NeuCoinsCheckbox"))).click();
        getDriver().findElement(By.xpath(getLocator("NeuCoinsCheckbox"))).click();
        getElement("editLinkInPaymentPage").click();
        getElement("textBoxXpath").clear();
        getElement("textBoxXpath").sendKeys(textBoxValue);
        getElement("NeuCoinsConfirmButton").click();
        Thread.sleep(5000);
        String neucoinserrormsg2 = getElement("neuCoinsErrorMsg2").getText();
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(neuCoinsErrorMsg2, neucoinserrormsg2, "Error msg2 should display below NeuCoins Enter field");
        logger.info("Oops! You've crossed your NeuCoins limit");

    }

    @And("user should validate NeuCoins balance is displayed in decimals at NeuCoins section of Payment page")
    public void userShouldValidateNeuCoinsBalanceIsDisplayedInDecimalsAtNeuCoinsSectionOfPaymentPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat((getElement("totalNeuCoins").getText())).describedAs("NeuCoins balance is displayed in decimal format").contains(".");
    }

    @And("user should validate NeuCoins balance in decimals at NeuCoins on edit popup window")
    public void userShouldValidateNeuCoinsBalanceInDecimalsAtNeuCoinsOnEditPopupWindow() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(3000);
        logger.info("Value: " + (getElement("textBoxXpath").getAttribute("value")));
        //assertThat((getElement("textBoxXpath").getText())).describedAs("NeuCoins value is displayed in decimal format").contains(".");
    }

    @And("user should validate NeuCoins applied is displayed in decimals at Order Summary section of Payment page")
    public void userShouldValidateNeuCoinsAppliedIsDisplayedInDecimalsAtOrderSummarySectionOfPaymentPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat((getElement("neuCoinsAppliedInOrderSummary").getText())).describedAs("NeuCoins applied is displayed in decimal format").contains(".");
    }

    @And("user should validate NeuCoins decimal redemption in order confirmation page")
    public void userShouldValidateNeuCoinsDecimalRedemptionInOrderConfirmationPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat((getElement("neuCoinsInOrderConfirmation").getText())).describedAs("NeuCoins in Order Confirmation is displayed in decimal format").contains(".");
    }

    @And("user validate Croma logo and three step navigation process should present in payment page")
    public void userValidateCromaLogoAndThreeStepNavigationProcessShouldPresentInPaymentPage() throws InterruptedException {
        String stepDescription = "user verify Croma logo, three buttons in header are present in payment page";
        Thread.sleep(5000);
        assertThat(getOptionalElement("paymentPageCromaLogo")).describedAs("Croma logo is present in payment page").isNotNull();
        assertThat(getOptionalElement("paymentPageMainShipCart")).describedAs("Croma three buttons in header are present in payment page").isNotNull();

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("user validate sign in button, mini cart icon, global search box, hamburger menu and pin code field are not present in header section of payment page")
    public void userValidateSignInButtonMiniCartIconGlobalSearchBoxHamburgerMenuMyAccountIconAndPinCodeFieldAreNotPresentInHeaderSectionOfPaymentPage() throws InterruptedException {
        String stepDescription = "user verify sign in button, mini cart icon , global search box, pin code field are not present in header section";
        Thread.sleep(5000);

        assertThat(getOptionalElement("menuButtonHomePage"))
                .describedAs("Products dropdown should not display in header").isNull();

        assertThat(getOptionalElement("signinLink"))
                .describedAs("SIGN IN Button should not display in header").isNull();

        assertThat(getOptionalElement("cartIcon"))
                .describedAs("Mini cart icon should not display in header").isNull();

        assertThat(getOptionalElement("searchProductInGlobalSearchBox"))
                .describedAs("Global Search Box should not display in header").isNull();

        assertThat(getOptionalElement("shopByCategoryTextInHamburgerMenu"))
                .describedAs("Hamburger menu should not display in header").isNull();

        assertThat(getOptionalElement("enterPincodeField"))
                .describedAs("Pin code field should not display in header").isNull();

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("user validate on hover to {string} steps from payment page it should clickable and the user can navigate to Shipping from Payment pages")
    public void userValidateOnHoverToStepsFromPaymentPageItShouldClickableAndTheUserCanNavigateToShippingFromPaymentPages(String Shipping) {

        assertThat(getElement("shippingTabInPaymentPage", Shipping).isDisplayed()).describedAs("user validate on hover to Shipping steps from payment page it should clickable");
        getElement("shippingTabInPaymentPage", Shipping).click();

        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String CurrentUrl = getDriver().getCurrentUrl();
        assertThat(CurrentUrl.contains("checkout")).describedAs("user is on checkout page");
    }

    @And("user validate Payment CTA should be disabled in Checkout page")
    public void userValidatePaymentCTAShouldBeDisabledInCheckoutPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat(getElement("paymentTab").isEnabled()).describedAs("Payment tab in header section of checkout page is enable");
    }

    @And("user validate on hover to {string} steps from payment page it should clickable and the user can navigate to Cart from Payment pages")
    public void userValidateOnHoverToStepsFromPaymentPageItShouldClickableAndTheUserCanNavigateToCartFromPaymentPages(String Cart) {
        assertThat(getElement("cartTabInCheckoutPage", Cart).isDisplayed()).describedAs("user validate on hover to Shipping steps from payment page it should clickable");
        getElement("cartTabInCheckoutPage", Cart).click();

        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String CurrentUrl = getDriver().getCurrentUrl();
        assertThat(CurrentUrl.contains("cart")).describedAs("user is on cart page");
    }

    @And("user validate global header should contain only croma logo on retry payment page")
    public void userValidateGlobalHeaderShouldContainOnlyCromaLogoOnRetryPaymentPage() {
        assertThat(getOptionalElement("paymentPageCromaLogo")).describedAs("Croma logo is present in payment page").isNotNull();
    }

    @And("user validate {string} highlight on payment step in payment page")
    public void userValidateHighlightOnPaymentStepInPaymentPage(String paymentBorderColor) throws InterruptedException {
        String colorOfCircle = getElement("paymentTab").getCssValue("border");
        logger.info("The color of Payment border in header section is :" + colorOfCircle);
        String color = Color.fromString(paymentBorderColor).asRgb();
        logger.info("The color of Payment border :" + color);
        //assertStepExecution(colorOfCircle, color, "Color of payment border circle is verified");
        Thread.sleep(1000);
    }

    @And("user validate aphabets N & C should be in Upper case in NeuCoins text")
    public void userValidateAphabetsNCShouldBeInUpperCaseInNeuCoinsText() {
        if (getOptionalElement("offerPopupSkipOnPayment") != null) {
            getElement("offerPopupSkipOnPayment").click();
        }
        String NeuCoinsName = getElement("NeuCoinsNameInPaymentPage").getText();
        logger.info(NeuCoinsName);
        for (int i = 0; i < NeuCoinsName.length(); i++) {
            Character Letter = NeuCoinsName.charAt(i);
            if (Character.isUpperCase(Letter)) {
                if (Letter == 'N') {
                    logger.info("The N Character is present in Upper case : " + Letter);
                    assertThat(Letter).isUpperCase().describedAs("N is not in capital");
                }
                if (Letter == 'C') {
                    logger.info("The C Character is present in Upper case : " + Letter);
                    assertThat(NeuCoinsName.charAt(i)).isUpperCase().describedAs("C is not in capital");
                }
            } else {
                logger.info("Rest of Character are in Lower case : " + Letter);
                assertThat(Letter).isLowerCase().describedAs("Rest are not in lower");
            }
        }

    }

    @Then("user should verify rupee symbol against each {string}")
    public void userShouldVerifyRupeeSymbolAgainstEachWith(String paymentMethod) throws InterruptedException {
        Thread.sleep(3000);
        String symbol = getElement("tenderPaymentMethodValue", paymentMethod).getText();
        logger.info("Tender Payment method value is " + symbol);
        assertThat(symbol.contains("₹")).isTrue().describedAs("user should verify rupee symbol against each payment methods in order confirmation page");
    }

    @And("user validate aphabets N & C should be in Upper case in NeuCoins text in Order Confirmation page")
    public void userValidateAphabetsNCShouldBeInUpperCaseInNeuCoinsTextInOrderConfirmationPage() {
        String NeuCoinsName = getElement("NeuCoinsNameInOrderConfirmationPage").getText();
        logger.info(NeuCoinsName);
        for (int i = 0; i < NeuCoinsName.length(); i++) {
            Character Letter = NeuCoinsName.charAt(i);
            if (Character.isUpperCase(Letter)) {
                if (Letter == 'N') {
                    logger.info("The N Character is present in Upper case : " + Letter);
                    assertThat(Letter).isUpperCase().describedAs("N is not in capital");
                }
                if (Letter == 'C') {
                    logger.info("The C Character is present in Upper case : " + Letter);
                    assertThat(NeuCoinsName.charAt(i)).isUpperCase().describedAs("C is not in capital");
                }
            } else {
                logger.info("Rest of Character are in Lower case : " + Letter);
                assertThat(Letter).isLowerCase().describedAs("Rest are not in lower");
            }
        }
    }

    /*
    User Lands on Payment Page
     */
    @Then("user should lands on payment page {string}")
    public void userShouldLandsOnPaymentPage(String paymentPageValidation) {
        assertStepExecution(paymentPageValidation, getElement("paymentPageValidation", paymentPageValidation).getText(), "user is on Payment page");
        String CurrentUrl = getDriver().getCurrentUrl();
        assertThat(CurrentUrl.contains("payment")).describedAs("user should lands on payment page");
    }

    @And("user clicks on additional no Cost EMI offer {string} from offer pop up")
    public void userClicksOnAdditionalNoCostEMIOfferFromOfferPopUp(String noCostEMIOffer) {
        assertThat(getElement("noCostEMIOffer", noCostEMIOffer).isDisplayed()).describedAs("No cot EMI offer applied");
        getElement("noCostEMIOffer", noCostEMIOffer).click();
    }

     /* validation of order summary details in Payment page */
    @And("user validates the order summary {string} section in payment page")
    public void userValidatesTheOrderSummarySectionInPaymentPage(String section) throws InterruptedException {
        Thread.sleep(3000);
        logger.info("user validates the order summary " + section + " section is present in payment page");
        assertStepExecution(true, getOptionalElement("orderSummaryDetails", section) != null, "user validates the order summary " + section + " section is not present in payment page");
    }

    @And("user clicks on plus sign beside the savings text in payment page")
    public void userClicksOnPlusSignBesideTheSavingsTextInPaymentPage() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("savingsPlusIcon") != null, "user clicks on plus sign beside the savings text in cart and checkout page");
        getElement("savingsPlusIcon").click();
        Thread.sleep(3000);
    }

    @And("user clicks on secure and pay")
    public void userClicksOnSecureAndPay() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("secureAndPayButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("secureAndPayButton").isDisplayed(), "Secure and Pay button displayed");
        getElement("secureAndPayButton").click();
    }

    @And("user chooses payment method as EMI option and chooses {string} and provide account details {string}, {string}, {string}, {string} and clicks pay")
    public void userChoosesPaymentMethodAsEMIOptionAndChoosesAndProvideAccountDetailsAndClicksPay(String index, String orderCreditCardNumber, String orderCreditCardMonth, String orderCreditCardYear, String orderCreditCardCvv) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        js.executeScript("window.scrollBy(0,200)");
        getDriver().switchTo().frame(getElement("paymentMethodPageIframe"));
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        String emiText = getElement("emiTab").getText();
        logger.info("EMI text in payment page is : " + emiText);
        setContext("emiText", emiText);
        assertStepExecution(true, getOptionalElement("emiTab") != null, "EMI tab is not displayed");
        getElement("emiTab").click();
        getElement("creditCardEMI").click();
        getElement("emiWithInterestHDFCBank").click();
        ArrayList<WebElement> element = new ArrayList<>(getElements("emiWithInterestRadioButton", index));
        logger.info("Number of radio buttons are : " + element.size());
        assertStepExecution(true, getElement("emiWithInterestRadioButton", index) != null, "user clicks on the first radio button " + index + " in my order page");
        getElement("emiWithInterestRadioButton", index).click();
        actionMoveToElementClick(getElement("emiTabProceedButton"));

        windowScrollIntoViewByWebElement(getElement("paymentMethodCardNumberInput"));
        conditionalWait(ExpectedConditions.visibilityOf(getElement("paymentMethodCardNumberInput")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("paymentMethodCardNumberInput").sendKeys(orderCreditCardNumber);
        getElement("paymentMethodCardNumberInput").click();
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardMonth);
        getElement("paymentMethodCardMonthYearInput").sendKeys(orderCreditCardYear);
        getElement("paymentMethodCardCVVInput").sendKeys(orderCreditCardCvv);
        windowScrollIntoViewByWebElement(getElement("paymentMethodProceedButton"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentMethodProceedButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("paymentMethodProceedButton") != null, "User choose payment method as tata pay and fill card details and click pay");
        actionMoveToElementClick(getElement("paymentMethodProceedButton"));
    }
}