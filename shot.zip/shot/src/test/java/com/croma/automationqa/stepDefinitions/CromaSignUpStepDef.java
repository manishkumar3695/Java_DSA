package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.jsClick;
import static com.croma.automationqa.util.JavaScriptUtil.jsExecuteCode;
import static org.assertj.core.api.Assertions.assertThat;


/*
     All the SSO related function defined in CromaSignUpStepDef class
*/
public class CromaSignUpStepDef {
    public static String defaultOTP = getConfig("defaultOTP");

    /**
     * This method validates phone number country code and enters Phone Number on Sign in/Sign Up page.
     * For the purpose of repeated Sign up, to produce unique phone no every time, if the phone number received from feature file contain '000000' (Six zeros) then it replaces those digits with random 6 digit number.
     * <p>
     * // * @param <b>phnNo</b> Phone number
     */
    @And("^user enters \"([^\"]*)\" in phone number field$")
    public void userEntersInPhoneNumberField(String phnNo) throws Throwable {
        // Validate Country Code
        // Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        phnNo = phnNo.replace("000000", String.valueOf(randomNumber(6)));

        //assertThat(getElement("countryCode").getText())
        //    .describedAs("Phone Number Country code validation")
        //     .isEqualTo("+91");

        WebElement phnElem1 = getOptionalElement("userPhnNumberTextBox");


        // Enter phone number based on current phoneNumber Element
        if (phnElem1 != null) {
            phnElem1.clear();
            phnElem1.sendKeys(phnNo);
        } else {
            WebElement phnElem2 = getOptionalElement("welcomeUserPhoneNo");
            if (phnElem2 != null) {
                phnElem2.clear();
                phnElem2.sendKeys(phnNo);
            }
        }
        //   Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
    }

    /**
     * This method clicks on Continue buttons of various types.
     */
    @And("^user clicks on continue button$")
    public void userClicksOnContinueButton() throws InterruptedException {
        // Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("continueSignInButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        WebElement continueElem1 = getOptionalElement("continueSignInButton");
        WebElement continueElem2 = getOptionalElement("continueOTPButton");
        WebElement continueElem3 = getOptionalElement("continueWelcomeButton");

        // Click currently available continue button
        if (continueElem2 != null) {
            continueElem2.click();
        } else if (continueElem3 != null) {
            continueElem3.click();
        } else if (continueElem1 != null) {
            continueElem1.click();
        }
        Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED")) * 100);
    }

    /**
     * This method uses JavaScript to enter OTP.
     * <p>
     * //* @param <b>OTP</b> OTP as provided by feature file. Default OTP is 123456
     */
    @When("^user enters \"([^\"]*)\" in OTP field$")
    public void userEntersInOTPField(String otp) throws InterruptedException {
        // Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
        //jsExecuteCode("callbacks.otpEntered(\"" + otp + "\")");
        //   Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
        logger.info("Entering OTP : " + otp);
        //Thread.sleep(25000);
        getDriver().findElement(By.xpath("//input[@name='otp']")).sendKeys(otp);
        String jsString = "document.getElementById(\"partitioned\").value = \"" + otp + "\"";
        logger.info(jsString);
        ((JavascriptExecutor) getDriver()).executeScript(jsString);
    }

    /**
     * This method clicks on Email Login option
     */
    @And("^user clicks Email Login Option$")
    public void userClicksEmailLoginOption() throws InterruptedException {
        System.out.println("Replaced tag");
        //    Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
        getElement("useEmailLoginOption").click();
        //    conditionalWait(ExpectedConditions.invisibilityOf( getElement("useEmailLoginOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        //    Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
    }

    /**
     * This method enters Email id.
     * For the purpose of repeated Sign up, to produce unique email every time, if the Email id received from feature file contain 'xxxx' (Four lowercase 'x') then it replaces them with random text of length 8.
     * <p>
     * // * @param <b>email</b> Email id
     */
    @And("^user enters \"([^\"]*)\" in Email field$")
    public void userEntersInEmailField(String email) throws InterruptedException {
        //  Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
        getElement("userPhnNumberTextBox").clear();
        email = email.replace("xxxx", randomAlphabeticString(8));

        //   getElement("emailIdTextbox").sendKeys(email);

        getElement("userPhnNumberTextBox").sendKeys(email);
        // conditionalWait(ExpectedConditions.invisibilityOf( getElement("emailIdTextbox")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        //  Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED"))*1000);
    }

    /**
     * This method clicks on Skip Phone Number button
     */
    @And("^user clicks on Skip Phone Number button$")
    public void userClicksOnSkipPhoneNumberButton() throws InterruptedException {

        getElement("skipPhnNo").click();
        Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED")) * 1000);
    }


    /**
     * This method clicks on SignUp Different Option link
     */
    @And("^user clicks on SignUp Different Option$")
    public void userClicksOnSignUpDifferentOption() throws InterruptedException {

        getElement("signUpDiffOption").click();
        Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED")) * 1000);
    }

    @And("user clicks on send otp button")
    public void userClicksOnSendOtpButton() throws InterruptedException {
        processScreenshot();
        //getElement("sendOtp").click();
        assertStepExecution(true, getOptionalElement("sendOtp") != null,
                "user clicks on send otp button");
        jsClick(getElement("sendOtp"));
        Thread.sleep(5000);
    }

    @And("User clicks on create now button")
    public void userClicksOnCreateNowButton() {
        processScreenshot();
        getElement("signupbutton").click();


        assertStepExecution("Sign up for Croma.com", getElement("signuppage").getText(), "Create Now Button clicked");
        assertStepExecution(true, getElement("signuppage").isDisplayed(), "SignUp Page displayed");
        processScreenshot();
    }

    @When("user clicks on verify phone number button")
    public void userClicksOnVerifyPhoneNumberButton() throws InterruptedException {
        Thread.sleep(6000);
        processScreenshot();
        getElement("clicksOnVerifyMobileNoButton").click();
    }

    @Then("user enters otp in otp field")
    public void userEntersOtpInOtpField() throws InterruptedException {
        if (!defaultOTP.equals("NA")) {
            logger.info("Entering Default OTP : " + defaultOTP);
            Thread.sleep(5000);
            getDriver().findElement(By.xpath("//input[@name='otp']")).sendKeys(defaultOTP);
            String jsString = "document.getElementById(\"partitioned\").value = \"" + defaultOTP + "\"";
            logger.info(jsString);
            ((JavascriptExecutor) getDriver()).executeScript(jsString);
        }
        getElement("submitOtpButton").click();
        Thread.sleep(8000);
    }

    @Then("user successfully login validating my account option present in croma homepage")
    public void userSuccessfullyLoginValidatingMyAccountOptionPresentInCromaHomepage() throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("myAccountLinkPresent") != null,
                "user selects appointment at store option");
    }

    /*
    Sign up scenario
     */
    @When("user validates sign up")
    public void userValidatesSignUp() throws Throwable {

      /*  int randomNo, min = 000000000, max = 999999999;
        String randomMobNo;

        randomNo = (int) Math.floor(Math.random() * (max - min + 1) + min);
        randomMobNo = "6" + randomNo;
        logger.info("Random mob no to use: " + randomMobNo);

        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("userPhoneNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        logger.info("Croma UserPhoneNo is:" + randomMobNo + "The Default OTP is: " + defaultOTP);
        setContext("saved_user_mobile_number", randomMobNo);

        getElement("userPhoneNumberTextBox").sendKeys(randomMobNo);

        getElement("continueSignInButton").click();
        Thread.sleep(2000);
        getElement("verifyMobileNo").click();
        logger.info("Entering Default OTP : " + defaultOTP);
        Thread.sleep(25000);
        getDriver().findElement(By.xpath("//input[@name='otp']")).sendKeys(defaultOTP);
        String jsString = "document.getElementById(\"partitioned\").value = \"" + defaultOTP + "\"";
        logger.info(jsString);
        ((JavascriptExecutor) getDriver()).executeScript(jsString);

        getElement("validateOtpButton").click();
        Thread.sleep(10000);

        assertThat(getElement("signInUserDetails").isDisplayed());

        actionMoveToElementBuild(getElement("signInUserDetails"));
        actionMoveToElementClick(getElement("userAccountLinkMenu", "My Profile"));

        assertThat(getElement("mobileNoOnProfPage").getAttribute("value")).describedAs("Profile mobile number").
                isEqualTo(randomMobNo);
        passStepExecution("Sign up verification done");*/
    }

    @And("user validates login popup is launched")
    public void userValidatesLoginPopupIsLaunched() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("userPhnNumberTextBox").isDisplayed(), "Login popup is launched");
    }

    @And("user verifies the {string} and {string} section is visible in sign in popup")
    public void userVerifiesTheAndSectionIsVisibleInSignInPopup(String loginText, String createAccountText) {
        String stepDescp = "user verifies the " + loginText + " and " + createAccountText + " section is visible in sign in popup";
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("userPhnNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getElement("loginSectionInSignInPopup").getText().trim().equalsIgnoreCase(loginText),
                stepDescp);
        assertStepExecution(true, getElement("createAccountSectionInSignInPopup").getText().trim().equalsIgnoreCase(createAccountText),
                stepDescp);
    }

    @And("user verifies phone number {string} text box is editable in sign in popup")
    public void userVerifiesPhoneNumberTextBoxIsEditableInSignInPopup(String mobileNumber) {
        String stepDescp = "user verifies phone number " + mobileNumber + " text box is editable in sign in popup";
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("userPhnNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        getElement("userPhnNumberTextBox").sendKeys(mobileNumber);
        assertStepExecution(true, getElement("userPhnNumberTextBox").getText().trim().equals(mobileNumber),
                stepDescp);
    }

    @And("user validates continue {string} button is present in sign in popup")
    public void userValidatesContinueButtonIsPresentInSignInPopup(String continueButton) {
        String stepDescp = "user validates continue " + continueButton + " button is present in sign in popup";
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("userPhnNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getElement("sendOtp") != null, stepDescp);
    }

    @And("user validates the text as {string} is present in sign in popup")
    public void userValidatesTheTextAsIsPresentInSignInPopup(String text) {
        String stepDescp = "user validates continue " + text + " button is present in sign in popup";
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("userPhnNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String webText = getElement("termConditionsTextOnSignupPopup").getText().trim();
        assertStepExecution(true, webText.equalsIgnoreCase(text), stepDescp);
    }


    @And("user clicks on cross icon is present on right corner in sign in popup")
    public void userClicksOnCrossIconIsPresentOnRightCornerInSignInPopup() {
        String stepDescp = "user clicks on cross icon is present on right corner in sign in popup";
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("userPhnNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getElement("crossIconSymbolOnSignupPopup") != null,
                stepDescp);
        getElement("crossIconSymbolOnSignupPopup").click();
    }

    @And("user validates the keep me signed in text as {string} is present in sign in popup")
    public void userValidatesTheKeepMeSignedInTextAsIsPresentInSignInPopup(String text) {
        String stepDescp = "user validates the keep me signed in text as " + text + " is present in sign in popup";
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("userPhnNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String webText = getElement("keepMeSignedInTextOnSignupPopup").getText().trim();
        assertStepExecution(true, webText.equalsIgnoreCase(text), stepDescp);
        assertStepExecution(true, getElement("keepMeSignedInCheckbox") != null,
                stepDescp);
    }
    @And("user enters otp and validates the toaster message {string}")
    public void userEntersOtpAndValidatesTheToasterMessage(String msg) throws InterruptedException {
        if (!defaultOTP.equals("NA")) {
            logger.info("Entering Default OTP : " + defaultOTP);
            Thread.sleep(5000);
            getDriver().findElement(By.xpath("//input[@name='otp']")).sendKeys(defaultOTP);
            String jsString = "document.getElementById(\"partitioned\").value = \"" + defaultOTP + "\"";
            logger.info(jsString);
            ((JavascriptExecutor) getDriver()).executeScript(jsString);
        }
        getElement("submitOtpButton").click();
        Thread.sleep(4000);
        WebElement el = getOptionalElement("successfulUserLoginToaster");
        if (el != null)
            assertStepExecution(true, el.getText().equals(msg), "user verifies the successful user login toaster message ");
        else
            assertThat(true).describedAs("user verifies the toaster message" + "Logged In Successfully").isFalse();
        Thread.sleep(8000);
    }
}