package com.croma.automationqa.util;

import io.cucumber.java.Scenario;

import java.util.HashMap;

import static com.croma.automationqa.util.FrameworkUtil.logger;

/**
 * <h3> Purpose:  <p> <h4> &#10687; This class includes all the methods to create, return and remove Thread-specific Cucumber Scenario Objects. These Scenario objects are utilized in captureScreen() method.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 5/05/2020
 */
public class ScenarioUtil {

    private static ScenarioUtil instance;
    private HashMap<String, Scenario> scenarioMap;

    /**
     * This constructor is kept <b>private</b> to prevent users from creating instance of this class by invoking '<b>new</b>' keyword from outside of this class.
     */
    private ScenarioUtil() {
    }

    /**
     * This method implements <b>Thread-safe Singleton design pattern</b> by allowing users to create only one instance of this class.
     *
     * @return <b>ScenarioUtil</b> object.
     */
    private static synchronized ScenarioUtil getInstance() {

        if (instance == null) {
            instance = new ScenarioUtil();
            instance.scenarioMap = new HashMap<String, Scenario>();
            logger.info("ScenarioUtil instantiated...");
        }

        return instance;
    }

    /**
     * This method returns the current Cucumber Scenario object from a HashMap by using the Thread-id as key.
     *
     * @return <b>Scenario</b> Current Cucumber Scenario object
     */
    public static Scenario getScenario() {

        getInstance();
        String t = String.valueOf(Thread.currentThread().getId());
        logger.info("Inside getScenario >> Thread Id: " + t);
        return instance.scenarioMap.get(t);
    }

    /**
     * This method saves the current Cucumber Scenario object into a HashMap by keeping the Thread-id as key.
     *
     * @param <b>Scenario</b> Current Cucumber Scenario object
     */
    public static synchronized void setScenario(Scenario scn) {

        getInstance();
        String t = String.valueOf(Thread.currentThread().getId());
        logger.info("Inside setScenario >> Thread Id: " + t);
        if (!instance.scenarioMap.containsKey(t)) {
            instance.scenarioMap.put(t, scn);
        }

    }

    /**
     * This method removes the current Cucumber Scenario object from the HashMap by using the Thread-id as key.
     *
     * @return <b>Boolean</b> Based on Success or Failure of object removal from HashMap.
     */
    public static synchronized Boolean removeScenario() {

        Boolean flag = false;
        String t = String.valueOf(Thread.currentThread().getId());
        if (instance.scenarioMap.containsKey(t)) {
            flag = true;
            instance.scenarioMap.remove(t);
            logger.info("Scenario instance removed for Thread id: " + t);
        }
        return flag;
    }

}
