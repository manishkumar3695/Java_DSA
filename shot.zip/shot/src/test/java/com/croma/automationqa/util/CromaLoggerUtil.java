package com.croma.automationqa.util;

import org.slf4j.LoggerFactory;
import org.slf4j.MDC;


/**
 * <h3> Purpose:  <p> <h4> &#10687;  This class includes all the methods to handle logging for various levels.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 28/05/2020
 */
public class CromaLoggerUtil {

    static org.slf4j.Logger logger = LoggerFactory.getLogger(CromaLoggerUtil.class);


    public void setScenario(String scenarioName) {
        MDC.put("scenario", scenarioName);
    }

    public void CromaLoggerUtil() {
    }

    public void startTestCase(String scenarioName) {

        logger.info("****************************************************************************************");

        logger.info("****************************************************************************************");

        logger.info("$$$$$$$$$$$$$$$$$$$$$                 " + scenarioName + "       $$$$$$$$$$$$$$$$$$$$$$$$$");

        logger.info("****************************************************************************************");

        logger.info("****************************************************************************************");

    }

    //This is to print log for the ending of the test case

    public void endTestCase() {

        logger.info("XXXXXXXXXXXXXXXXXXXXXXX             " + "-E---N---D-" + "             XXXXXXXXXXXXXXXXXXXXXX");

        logger.info("X");

        logger.info("X");

        logger.info("X");

        logger.info("X");

    }

    public void info(String message) {

        logger.info(message);

    }

    public void warn(String message) {

        logger.warn(message);

    }

    public void error(String message) {

        logger.error(message);

    }


    public void debug(String message) {

        logger.debug(message);

    }

    public void trace(String message) {

        logger.trace(message);

    }


}
