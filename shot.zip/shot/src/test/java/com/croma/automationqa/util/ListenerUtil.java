package com.croma.automationqa.util;

import org.testng.IInvokedMethodListener;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ListenerUtil implements ITestListener, IInvokedMethodListener {


    public void onTestStart(ITestResult result) {
        System.out.println("New Test Started : - " + result.getName());

    }


    public void onTestSuccess(ITestResult result) {
    }

    public synchronized void onTestFailure(ITestResult result) {
    }

    public void onTestSkipped(ITestResult result) {
        System.out.println("Test Skipped :- " + result.getName());

    }


}
