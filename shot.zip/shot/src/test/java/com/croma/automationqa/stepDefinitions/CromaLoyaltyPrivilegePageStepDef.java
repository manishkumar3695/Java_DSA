package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.Then;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

public class CromaLoyaltyPrivilegePageStepDef {

    @Then("user validates neuCoins balance should displayed in my privileges page")
    public void userValidatesNeuCoinsBalanceShouldDisplayedInMyPrivilegesPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("My reward page is displayed");
        assertStepExecution(true, getOptionalElement("NeuCoinsBalance") != null, "user validates neuCoins balance should displayed in my privileges page");
    }

    @Then("user validate neuCoins balance should displayed in decimal points upto two in my privilege page")
    public void userValidateNeuCoinsBalanceShouldDisplayedInDecimalPointsUptoTwoInMyPrivilegePage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat((getElement("NeuCoinsBalance").getText())).describedAs("NeuCoins balance is displayed in decimal format").contains(".");
        }
    }