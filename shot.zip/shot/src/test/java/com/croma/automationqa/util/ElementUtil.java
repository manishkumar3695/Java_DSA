package com.croma.automationqa.util;


import com.google.common.base.Charsets;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.opentest4j.AssertionFailedError;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.croma.automationqa.util.ConfigUtil.configIterator;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.FrameworkUtil.*;


/**
 * <h3> Purpose:  <p> <h4> &#10687; This class includes all the generic methods which perform various diverse activities related to Selenium WebElement.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 29/03/2020
 */
public class ElementUtil {

    // INPUT::  StepDef Class Name, Element Name (Same as in Property file)
    // PROCESS:: Get ThreadId & Get Driver Instance from DriverUtil
    // OUTPUT:: getElement returns WebElement ; getElements returns List of WebElements

    private static ElementUtil instance;
    private static HashMap<String, HashMap<String, String>> locatorMap;

    private static int LongWait, MidWait, ShortWait;

    /**
     * This constructor is kept <b>private</b> to prevent users from creating instance of this class by invoking '<b>new</b>' keyword from outside of this class.
     */
    private ElementUtil() {
    }

    /**
     * This method implements <b>Thread-safe Singleton design pattern</b> by allowing users to create only one instance of this class.
     *
     * @return <b>ElementUtil</b> object reference.
     */
    public static synchronized ElementUtil getInstance() throws IOException {

        if (instance == null) {

            instance = new ElementUtil();

            /* Locator Map Construction */

//            String[] str = getFilesInPackage(stepDefPath);
            InputStream is = ElementUtil.class.getClassLoader().getResourceAsStream(locatorPath);
            List<String> fileArr = IOUtils.readLines(is, Charsets.UTF_8);
            locatorMap = new HashMap<String, HashMap<String, String>>();
            for (String file : fileArr) {
                locatorMap.put(file, configIterator(locatorPath + file));
            }

            LongWait = Integer.parseInt(getConfig("LongWait"));
            MidWait = Integer.parseInt(getConfig("MidWait"));
            ShortWait = Integer.parseInt(getConfig("ShortWait"));

            logger.info("ElementUtil instantiated...");
        } else {
            logger.info("ElementUtil not instantiated...");

        }
        return instance;
    }


    /**
     * This method returns <b>Selenium WebElement</b> object after taking the element name & dynamic part of the element locator as input.
     * Passing the first param is mandatory while the second param is optional & applicable only for dynamic locators.
     *
     * @param <b>elemInfo[]</b> Variable  Argument where first param is Name of element as mentioned in .properties locator file &
     *                          second param is the dynamic part of the locators
     * @return <b>Selenium WebElement</b> object reference
     */
    public static WebElement getElement(String... elemInfo) {
        String locator = "";
        WebElement elem = null;
        try {
            getInstance();
            locator = getLocator(elemInfo);
            int waitCounter = 0;
            while (getDriver().findElements(By.xpath(locator)).size() == 0) {
                if (waitCounter < LongWait) {
                    Thread.sleep(2000);
                    waitCounter = waitCounter + 2;
                } else
                    break;
            }
            elem = masterWait(getDriver(), locator, LongWait);
        } catch (TimeoutException ex) {
            throw ex;
        } catch (IOException e) {
            e.printStackTrace();
            throw new AssertionFailedError(e.getMessage());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return elem;
    }

    /**
     * This method waits for specified time for an optional element after taking the element name
     * & dynamic part of the element locator as input and returns the <b>Selenium WebElement</b> object.
     * Passing the first param is mandatory while the second param is optional & applicable only for dynamic locators.
     *
     * @param <b>elemInfo[]</b> Variable  Argument where first param is Name of element as mentioned in .properties locator file &
     *                          second param is the dynamic part of the locators
     * @return <b>Selenium WebElement</b> object reference
     */
    public static WebElement getOptionalElement(String... elemInfo) {
        String locator = "";
        WebElement elem = null;
        try {
            getInstance();

            locator = getLocator(elemInfo);

            if ((getDriver().findElements(By.xpath(locator)).size() > 0) && (getDriver().findElements(By.xpath(locator)).get(0).isEnabled())) {

                System.out.println(elemInfo[0] + " isEnabled : " + getDriver().findElements(By.xpath(locator)).get(0).isEnabled());
                System.out.println(elemInfo[0] + " isDisplayed : " + getDriver().findElements(By.xpath(locator)).get(0).isDisplayed());
                System.out.println(elemInfo[0] + " isSelected : " + getDriver().findElements(By.xpath(locator)).get(0).isSelected());
                elem = fluentWaitUtil(getDriver(), locator, ShortWait);
//                System.out.println(elemInfo[0] + " CSS : " + elem.getCssValue());
            }
        } catch (Exception ex) {
            logger.info(elemInfo[0] + " is absent in current page.");
        }
        return elem;


    }


    /**
     * This method returns <b>Selenium WebElement</b> object after taking the element name as input.
     *
     * @param <b>elementName</b> Name of element as mentioned in .properties file storing the xpath value.
     * @return <b>Selenium WebElement</b> object reference
     */
 /*   public static MobileElement getElement(CharSequence elementName) {
        String xpath = "";
        MobileElement elem;
        try {
            getInstance();
            xpath = getLocator(elementName.toString());
            elem = masterMobileWait(getDriver(), xpath, LongWait);
        } catch (TimeoutException ex) {
            throw ex;
        } catch (IOException e) {
            e.printStackTrace();
            throw new AssertionFailedError(e.getMessage());
        }
        return elem;


    }
*/

    /**
     * This method returns <b>Selenium WebElement</b> object whose xpath is dynamic
     *
     * @param <b>elementName</b>   Name of element as mentioned in .properties file storing the xpath value.
     * @param <b>dynamicString</b> Current value of the dynamic part of the element's xpath
     * @return <b>Selenium WebElement</b> object reference
     */
/*
    public static WebElement getDynamicElement(String elementName, String dynamicString) {
        String xpath = "";
        WebElement elem = null;
        try {
            getInstance();
            xpath = getLocator(elementName);
            xpath = xpath.replaceAll("(?i)XXXX", dynamicString);
            elem = masterWait(getDriver(), xpath, LongWait);
        } catch (TimeoutException ex) {
            ex.printStackTrace();
            throw ex;
        } catch (IOException e) {
            e.printStackTrace();
            throw new AssertionFailedError(e.getMessage());
        }
        return elem;


    }

*/

    /**
     * This method returns <b>List&lt;WebElement&gt;</b> whose xpath is dynamic
     *
     * @param <b>elementName</b>   Name of element as mentioned in .properties file storing the xpath value.
     * @param <b>dynamicString</b> Current value of the dynamic part of the element's xpath
     * @return <b>List&lt;WebElement&gt;</b>
     */
 /*   public static List<WebElement> getDynamicElements(String elementName, String dynamicString) {
        String xpath = "";
        List<WebElement> elemList = null;
        try {
            getInstance();
            xpath = getLocator(elementName);
            xpath = xpath.replaceAll("(?i)XXXX", dynamicString);
            masterWait(getDriver(), "(" + xpath + ")[1]", LongWait);
            elemList = getDriver().findElements(By.xpath(xpath));
        } catch (TimeoutException ex) {
            ex.printStackTrace();
            throw ex;
        } catch (IOException e) {
            e.printStackTrace();
            throw new AssertionFailedError(e.getMessage());
        }
        return elemList;

    }

*/

    /**
     * This method returns a <b>List&lt;WebElement&gt;</b> of an element which is expected to appear multiple times on a page.
     * taking the element name & dynamic part of the element locator as input.
     * Passing the first param is mandatory while the second param is optional & applicable only for dynamic locators.
     *
     * @param <b>elemInfo[]</b> Variable  Argument where first param is Name of element as mentioned in .properties locator file &
     *                          second param is the dynamic part of the locators.
     * @return <b>List&lt;WebElement&gt;</b>
     */
    public static List<WebElement> getElements(String... elemInfo) {
        String locator = "";
        List<WebElement> elemList;
        try {
            getInstance();
            locator = getLocator(elemInfo);
            masterWait(getDriver(), "(" + locator + ")[1]", LongWait);
            elemList = getDriver().findElements(By.xpath(locator));
        } catch (IOException e) {
            e.printStackTrace();
            throw new AssertionFailedError(e.getMessage());
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        }
        return elemList;

    }


    /**
     * This method returns <b>locator</b> of an element by parsing the <b>.properties</b> files inside <b>locators</b> folder.
     * Passing the first param i.e. Name of element is mandatory while the second param is optional & applicable only for dynamic locators.
     *
     * @param <b>elemInfo[]</b> Variable  Argument where first param is Name of element as mentioned in .properties locator file &
     *                          second param is the dynamic part of the locators
     * @return Locator of the provided element as <b>String</b>.
     */
    public static String getLocator(String... elemInfo) {
        String locator = "";
        String callerClass = getCallerClassName();
        String propFile = callerClass.replace("stepDefinitions.", "");
        propFile = propFile.replace("StepDef", "").replace("com.croma.automationqa.", "");
        propFile = propFile + ".properties";


        if (locatorMap.containsKey(propFile) && locatorMap.get(propFile).containsKey(elemInfo[0])) {
            locator = locatorMap.get(propFile).get(elemInfo[0]);
        }

        if (locator.equals("")) {

            for (Map.Entry<String, HashMap<String, String>> fileMap : locatorMap.entrySet()) {

                if (fileMap.getValue().containsKey(elemInfo[0])) {
                    locator = fileMap.getValue().get(elemInfo[0]);
                    propFile = fileMap.getKey();
                    break;
                }
            }

        }

        // Case when locator needs to be replaced at one place only
        if (elemInfo.length == 2) {

            locator = locator.replaceAll("(?i)XXXX", elemInfo[1]);
        }
        // Case when locator needs to be replaced at multiple places
        else if ((elemInfo.length > 2) && (locator.contains("1111"))) {

            for (int i = 1; i < elemInfo.length; i++) {

                String placeHolder = String.valueOf(i) + String.valueOf(i) + String.valueOf(i) + String.valueOf(i);
                locator = locator.replaceAll(placeHolder, elemInfo[i]);

            }
        }

        logger.info("locator: " + locator + " ;; Property File: " + propFile + "  ;; class: " + callerClass);

        return locator;


    }

    /**
     * This method analyzes the Java stacktrace, finds the <b>StepDefinition</b> class which is calling <b>getElement()</b> method.
     *
     * @return Name of the calling <b>StepDefinition class</b> as String
     */
    public static synchronized String getCallerClassName() {
        StackTraceElement[] stElements = Thread.currentThread().getStackTrace();
        for (int i = 1; i < stElements.length; i++) {
            StackTraceElement ste = stElements[i];
            if (!ste.getClassName().equals(ElementUtil.class.getName()) && ste.getClassName().indexOf("java.lang.Thread") != 0) {
                return ste.getClassName();
            }
        }
        return null;
    }

}
