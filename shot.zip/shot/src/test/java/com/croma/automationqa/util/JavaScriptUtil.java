package com.croma.automationqa.util;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;

import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;

/**
 * <h3> Purpose:
 * <p> <h4> &#10687; This class includes all the methods which are created to automate actions on webelements using JavaScript specially where corresponding Selenium actions are unsuccessful.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 20/11/2020
 */

public class JavaScriptUtil {

    public static void jsExecuteCode(String code) {
        ((JavascriptExecutor) getDriver()).executeScript(code);
    }


    public static void jsClick(WebElement element) {
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", element);
    }

    public static void jsClear(WebElement element) {
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].value = '';", element);
    }

    public static void jsSendKeys(WebElement element, String value) {
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].value='" + value + "';", element);
    }

    public static void windowScrollIntoViewByWebElement(WebElement webElement) {
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(false);", webElement);
    }

    public static void scrollToWebelement(WebElement webElement) {
        Point location = webElement.getLocation();
        int x = location.getX();
        int y = location.getY();
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollTo("+x+","+(y-300)+")");
    }
    public static void windowScrollIntoViewByWebElementTrue(WebElement webElement) {
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", webElement);
    }

    public static void windowScrollIntoViewAdjustment(int arg1, int arg2) {
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(" + arg1 + ",-" + arg2 + ")");
    }
    public static void windowScrollIntoViewAdjustment_scroll(int arg1, int arg2) {
        ((JavascriptExecutor) getDriver()).executeScript("window.scroll(" + arg1 + "," + arg2 + ")");
    }
    public static void windowScrollIntoViewLazyLoad(String... elemInfo) {
        int xAxis = 0, yAxis = 50;

        for (int j = 0; j < 10; j++) {

            ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(" + xAxis + ",-" + yAxis + ")");

            if (getOptionalElement(elemInfo) != null) {
                break;
            }
        }
    }

    public static void windowScrollIntoBottom() {
    try {
        long lastHeight = (long) ((JavascriptExecutor) getDriver()).executeScript("return document.body.scrollHeight");

        while (true) {
            ((JavascriptExecutor) getDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight);");
            Thread.sleep(2000);

            long newHeight = (long) ((JavascriptExecutor) getDriver()).executeScript("return document.body.scrollHeight");
            if (newHeight == lastHeight) {
                break;
            }
            lastHeight = newHeight;
        }
    } catch (InterruptedException e) {
        e.printStackTrace();
    }}

    public static void windowScrollIntoTopToBottom() {
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
    }


    public static void windowScrollToTop() {
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollTo(0, 0)");
    }


}
