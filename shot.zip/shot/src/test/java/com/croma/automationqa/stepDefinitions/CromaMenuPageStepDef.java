package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementBuild;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementClick;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.*;

public class CromaMenuPageStepDef {

//    /*
//        user clicks on user icon and clicks on the my profile link and lands on corresponding page
//    */
//    @Given("^user clicks on user icon and clicks on the \"([^\"]*)\" link and lands on corresponding page$")
//    public void userClicksOnUserIconAndClicksOnTheLinkAndLandsOnCorrespondingPage(String userAccountLink) {
//        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("userIcon")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
//        logger.info("Clicking user icon ");
//        getElement("userIcon").click();
//        logger.info("Clicking link ");
//        assertStepExecution(true,getOptionalElement("userAccountLinkMenu")!=null," User account link menu found");
//        getElement("userAccountLinkMenu", userAccountLink).click();
//    }


    /*
        user clicks on plus icon to go to product categories
    */
    @And("^user clicks on plus icon on menu bar$")
    public void userClicksOnPlusIconOnMenuBar() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("productCategoryPlusIcon") != null, "Plus icon in product category found.");
        getElement("productCategoryPlusIcon").click();
        Thread.sleep(5000);
    }


    /*
        user clicks on different product categories according to the category option
    */
    @And("^user clicks on \"([^\"]*)\" category$")
    public void userClicksOnCategory(String categoryOption1) {
        logger.info("User selects catagory option: " + categoryOption1);
        List<WebElement> elementPresent = getDriver().findElements(By.xpath("(//*[@class='text' and (text()='" + categoryOption1 + "')])[1]//parent::a//span[1]"));
        logger.info("No of element are: " + elementPresent.size());
        if (elementPresent.size() != 0) {
            assertStepExecution(true, getOptionalElement("categoryOptionPresent", categoryOption1) != null, "Category option found.");
            getElement("categoryOptionPresent", categoryOption1).click();
        } else {
            assertStepExecution(true, getOptionalElement("categoryOptionPresent", categoryOption1) != null, "Category option found.");
            actionMoveToElementClick(getElement("categoryOption", categoryOption1));
        }
    }


    @And("^user selects \"([^\"]*)\" as menu option$")
    public void userSelectsAsMenuOption(String menuOption) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("menuLink")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getOptionalElement("menuLink") != null, "user selects menu option");
        getElement("menuLink", menuOption).click();
    }

    @And("user validates {string} link is present with {string} under my account menu")
    public void userValidatesLinkIsPresentWithUnderMyAccountMenu(String userAccountLink, String linkDetails) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME")) {
            actionMoveToElementBuild(getElement("signInUserDetails"));
        } else if (getConfig("Browser").trim().equalsIgnoreCase("ANDROID") || getConfig("Browser").trim().equalsIgnoreCase("EMULATED_CHROME") || getConfig("Browser").trim().equalsIgnoreCase("IOS")) {
            actionMoveToElementClick(getElement("signInUserDetails"));
        }
        List<WebElement> userAccountLinkCountList = getDriver().findElements(By.xpath("//div[@class='dropdown-list dropdown-list-container']//ul/li/a"));
        logger.info("user Account Link Count List size : " + userAccountLinkCountList.size());
        if (userAccountLinkCountList.size() < 8) {
            for (int i = 1; i < userAccountLinkCountList.size(); i++) {
                logger.info("User Account link is: " + getElement("userAccountLinkName", String.valueOf(i)).getText());
                String accountLinkKeyword = getElement("userAccountLinkName", String.valueOf(i)).getText();
                if (accountLinkKeyword.equalsIgnoreCase(userAccountLink)) {
                    logger.info("Account link present" + accountLinkKeyword+"Account link details"+linkDetails);
                    String accountLinkDetailsKeyword = getElement("accountLinkDetails", String.valueOf(i)).getText();
                    assertStepExecution(true, accountLinkDetailsKeyword.equalsIgnoreCase(linkDetails),
                            "User validates link is present with details under my account menu");
                    break;
                }
            }
        }
    }
}
