package com.croma.automationqa.stepDefinitions;


import com.croma.automationqa.util.JavaScriptUtil;
import com.google.errorprone.annotations.Var;
import com.jayway.jsonpath.JsonPath;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.verifyProductAvailability;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.CommonUtil.numericValuesExtractionMethod;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.extractProperty;


/*
     All the product definition page related function defined in CromaProductDefinitionPageStepDef class
*/
public class CromaProductDefinitionPageStepDef {

    public static ArrayList<String> categoriesFromPDP = new ArrayList<>();
    private final int pDPPageScrollDownFirstIndex = 0, pDPPageScrollDownLastIndex = 1000, pDPPageConditionFirstValue = 1;
    JavascriptExecutor js = (JavascriptExecutor) getDriver();


    /*
        User lands on product definition page of the selected product
    */
    @Then("^user lands on product definition page of the \"([^\"]*)\" product$")
    public void userLandsOnProductDefinitionPageOfTheProduct(String pdpProduct1) throws InterruptedException {
        //conditionalWait(ExpectedConditions.visibilityOf(getElement("pdp_Product", pdpProduct1)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        //logger.info("Current window title is: " + getDriver().getTitle() + "The product name on PDP Data Base is: " + pdpProduct1 + " And the PDP Product is: " + getElement("pdp_Product", pdpProduct1).getText());
        //logger.info("Current window title is: " + getDriver().getTitle() + "The product name on PDP Data Base is: " + pdpProduct1 + " And the PDP Product is: " + getElement("pdp_Product", pdpProduct1).getText());
        if (getOptionalElement("pdpPodTag") != null) {
            String productName = getElement("pdpProductName").getText().trim();
            setContext("podProductName", productName);
            logger.info("Pay on delivery eligible product name :-" + productName);
        }
        logger.info("Landed on PDP");
        String productOnPdp = getElement("pdpProductTitle").getText().trim();
        logger.info("The product on pdp is" + productOnPdp + "The product from db:" + pdpProduct1);
        assertStepExecution(true, productOnPdp.equalsIgnoreCase(pdpProduct1), "Product name are matching in PDP");
        Thread.sleep(5000);

    }


    /*
        User lands on product definition page of the product id
    */
    @And("^user lands on product definition page of the \"([^\"]*)\" product id$")
    public void userLandsOnProductDefinitionPageOfTheProductId(String pdpProductId1) throws IOException, InterruptedException {
        String productIdDetails, deliveryOption1, deliveryOption2, deliveryOption3, noProductAvailable = "Product not found in";
        Date objDate = new Date();
        BufferedWriter bW = fileWrite(getConfig("Text_File_Path"));
        logger.info(objDate.toString());
        if (getContext("product_available").equalsIgnoreCase("true")) {
            Thread.sleep(3000);
            if (getOptionalElement("OutOfStockPopUp") != null) {
                logger.info("Product is not available message:- " + getElement("UnavailabilityOfProduct").getText());
                getElement("sharePopUpClose").click();
            }
            conditionalWait(ExpectedConditions.visibilityOf(getElement("pdpProductTitle")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
            logger.info("The PDP Product is: " + getElement("pdpProductTitle").getText());
            productIdDetails = getElement("getProductIdDetails").getText();
            logger.info(" Pdp product id is: " + numericValuesExtractionMethod(productIdDetails));
            setContext("pdp_Product_Id_1", getElement("getProductIdDetails").getText());
            processScreenshot();
            assertStepExecution(pdpProductId1.toLowerCase(), String.valueOf(numericValuesExtractionMethod(productIdDetails)).toLowerCase(),
                    "Product name is not matching in PDP");
            waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
            if (getOptionalElement("OutOfStockPopUp") != null) {
                logger.info("Product is not available message:- " + getElement("UnavailabilityOfProduct").getText());
                getElement("sharePopUpClose").click();
            }
            if (getOptionalElement("storePickupAvailable") != null) {
                deliveryOption1 = getElement("storePickupAvailable").getText();

            } else {
                deliveryOption1 = getElement("getTextDeliveryOption1Name").getText();
            }
            logger.info("Product availability message: " + productIdDetails + "\n" + deliveryOption1 + "\n" + "Date and Time: " + objDate.toString() + " In " + getConfig("URL") + "\n\n");
            bW.write(productIdDetails + "\n" + deliveryOption1 + "\n" + "Date and Time: " + objDate.toString() + " In " + getConfig("URL") + "\n\n");
        } else {
            logger.info("PRODUCT ID:" + pdpProductId1 + "\n" + noProductAvailable + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
            bW.write("PRODUCT ID:" + pdpProductId1 + "\n" + noProductAvailable + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
        }
        bW.close();
    }

    /*
        User clicks add to wishlist from product definition page
    */
    @And("^user clicks add to wishlist from product definition page$")
    public void userClicksAddToWishlistFromProductDefinitionPage() throws InterruptedException {
        Thread.sleep(2000);
        //   conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addToWishListButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //getElement("addToWishListButton").click();
        jsClick(getElement("addToWishListButton"));
        Thread.sleep(1000);
    }


    /*
        User click add to cart from product Listing page [PLP]
    */
    @And("^user clicks add to cart from product definition page$")
    public void userClicksAddToCartFromProductDefinitionPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            js.executeScript("window.scrollBy(0,1800)");
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addToCartButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            assertStepExecution(true, getOptionalElement("addToCartButton") != null, "user clicks add to cart from product definition page");
            Thread.sleep(3000);
            // js.executeScript("window.scrollBy(0,500)");
            //jsClick(getElement("addToCartButton"));
            getElement("addToCartButton").click();
            Thread.sleep(3000);
            //userHandlesTheUnexpectedMiniCartDialogPopup();

        }
        //  Thread.sleep(3000);
    }

    /*
         User clicks Buy Now from product definition page [PDP]
     */
    @And("^user clicks buy now from product definition page$")
    public void userClicksBuyNowFromProductDefinitionPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            js.executeScript("window.scrollBy(0,1800)");
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("BuyNowButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            assertStepExecution(true, getOptionalElement("BuyNowButton") != null, "user clicks Buy Now from product definition page");
            Thread.sleep(3000);
            // js.executeScript("window.scrollBy(0,500)");
            getElement("BuyNowButton").click();
            waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
            Thread.sleep(5000);

        }
    }

    /*
         User click buy now from product Listing page [PLP] and lands on the cart page
    */
    @And("^user clicks buy now from product definition page and lands on the cart page$")
    public void userClicksBuyNowFromProductDefinitionPageAndLandsOnTheCartPage() throws InterruptedException {
        String flag = "false";
        //    conditionalWait(ExpectedConditions.elementToBeClickable(getElement("selectBuyNowButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //  processScreenshot();
        //  windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownSecondIndex);
        js.executeScript("window.scrollBy(0,1800)");
        //windowScrollIntoViewByWebElement(getElement("selectBuyNowButton"));

        //    getElement("selectBuyNowButton").click();
        getElement("buyNowFromBottom").click();
        Thread.sleep(2000);
        windowScrollToTop();
        setContext("coupon_applied_flag_cart", flag);
        setContext("gift_item_applied_flag_cart", flag);
        setContext("donation_applied_flag_cart", flag);
    }


    /*
       User clicks on product information tab in product definition page
    */
    @And("^user clicks on \"([^\"]*)\" product information tab in product definition page$")
    public void userClicksOnProductInformationTabInProductDefinitionPage(String productInformation) {
//        logger.info("Product information from DB is:  " + productInformation);
//        js.executeScript("window.scrollBy(0,600)");
//        //windowScrollIntoViewByWebElement(getElement("productDetailsGetText", productInformation));
//        //windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownLastIndex);
//        logger.info("The item details name on PDP is: " + getElement("productDetailsGetText", productInformation).getText());
//        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("productDetailsGetText", productInformation)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
//        // if (!productInformation.equalsIgnoreCase("Review"))
//        //getElement("productDetailsGetText", productInformation).click();
//        jsClick(getElement("productDetailsGetText", productInformation));


        logger.info("Product information from DB is:  " + productInformation);
        js.executeScript("window.scrollBy(0,1000)");
        logger.info("The item details name on PDP is: " + getElement("productDetailsGetText", productInformation).getText());
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("productDetailsGetText", productInformation)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        if (!productInformation.equalsIgnoreCase("Review")) {
            assertThat(getOptionalElement("viewMoreButtonPresentForTheOption", productInformation)).isNotNull().describedAs("View more option is present for the element");
            jsClick(getOptionalElement("viewMoreButtonPresentForTheOption", productInformation));
            logger.info("View more button is present for " + productInformation);
            assertThat(getOptionalElement("viewLessButtonPresentForTheOption", productInformation)).isNotNull().describedAs("View more option is present for the element");
            jsClick(getOptionalElement("viewLessButtonPresentForTheOption", productInformation));
        }
        jsClick(getElement("productDetailsGetText", productInformation));
    }


    /*
        User clicks add to compare link from product definition page
    */
    @And("^user clicks add to compare link from product definition page$")
    public void userClicksAddToCompareLinkFromProductDefinitionPage() throws InterruptedException {

        int comparePageScrollDownLastIndex = 200, comparePageScrollDownFirstIndex = 0;
        logger.info("Clicking On PDP Compare link");

        scrollToWebelement(getElement("clickOnAddToCompareLinkOnPdP"));

        Thread.sleep(3000);
//        windowScrollToTop();
//        windowScrollIntoViewByWebElement(getElement("clickOnAddToCompareLinkOnPdP"));
//        windowScrollIntoViewAdjustment(comparePageScrollDownFirstIndex, comparePageScrollDownLastIndex);
//        windowScrollIntoViewAdjustment_scroll(0,100);
//        js.executeScript("window.scrollTo(0,700)");
        processScreenshot();
        actionMoveToElementClick(getElement("clickOnAddToCompareLinkOnPdP"));
//        .click();
    }


    /*
        User clicks on plus icon
    */
    @And("^user clicks on plus icon$")
    public void userClicksOnPlusIcon() throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnPlusIcon")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        processScreenshot();
        getElement("clickOnPlusIcon").click();
        Thread.sleep(5000);
    }


    /*
      User hovers all images in product definition page
    */
    @And("^user hovers all images in product definition page$")
    public void userHoversAllImagesInProductDefinitionPage() throws InterruptedException {
        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME")) {
            Thread.sleep(3000);
            int pDPPageConditionSecondValue = 2, pDPPageConditionThirdValue = 3;
            actionMoveToElementClick(getElement("productImage"));
            List<WebElement> pdpImagesList = getElements("pdpImagesListXPath");
            logger.info("No of Images are: " + pdpImagesList.size());
            if (pdpImagesList.size() > pDPPageConditionFirstValue) {
                for (int i = 1; i <= pdpImagesList.size(); i++) {
                    processScreenshot();
                    actionMoveToElementClick(getElement("pdpImagesXPath", String.valueOf(i)));
//                    if (i >= pDPPageConditionThirdValue && i <= (pdpImagesList.size() - pDPPageConditionFirstValue)) {
//                        windowScrollIntoViewAdjustment_scroll(0, 500);
                    getElement("clickOnNextButton").click();
//                    }
                }
            }
            processScreenshot();
        } else if (getConfig("Browser").trim().equalsIgnoreCase("EMULATED_CHROME")) {
            List<WebElement> paginationBullet = getElements("swiperPaginationBullet");
            logger.info("No of Images are: " + paginationBullet.size());
            for (WebElement webElement : paginationBullet) {
                webElement.click();
            }
            processScreenshot();

        }
    }


    /*
        User clicks on connect to store option from product definition page
    */
    @And("^user clicks on connect to store option from product definition page$")
    public void userClicksOnConnectToStoreOptionFromProductDefinitionPage() throws InterruptedException {
        if (getConfig("Browser").equalsIgnoreCase("CHROME")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clicksOnConnectToStoreButtonFromPDP")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            processScreenshot();
            logger.info("Page url is: " + getDriver().getCurrentUrl());
            String url = getDriver().getCurrentUrl();
            setContext("url_Currentpage", url);
            //getElement("clicksOnConnectToStoreButtonFromPDP").click();
            jsClick(getElement("clicksOnConnectToStoreButtonFromPDP"));
            Thread.sleep(2000);
        } else if (getConfig("Browser").equalsIgnoreCase("EMULATED_CHROME")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clicksOnConnectToStoreButtonFromPDPMobileView")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            processScreenshot();
            logger.info("Page url is: " + getDriver().getCurrentUrl());
            String url = getDriver().getCurrentUrl();
            setContext("url_Currentpage", url);
            //getElement("clicksOnConnectToStoreButtonFromPDP").click();
            jsClick(getElement("clicksOnConnectToStoreButtonFromPDPMobileView"));
            Thread.sleep(2000);

        }

    }

    @And("^user Enter pincode \"([^\"]*)\" to find your nearest store from product definition page$")
    public void userEnterPincodeToFindNearestStoreFromProductDefinitionPage(String pincode) throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clicksOnConnectToStoreButtonFromPDP")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));

        logger.info("Page url is: " + getDriver().getCurrentUrl());
        getElement("pincodeInputBoxToFindNearsetStore").sendKeys(pincode);
        assertStepExecution(true, getElement("pincodeInputBoxToFindNearsetStore").isDisplayed(),
                "Enter pincode to find your nearest store popup is visible");
        getElement("pincodeApplyByttonToFindNearsetStore").click();

        processScreenshot();
        Thread.sleep(2000);
    }

// Blocked due to functionality not available
//    /*
//       User clicks onView more store hyperlink and validates all stores based on location
//    */
//    @And("^user clicks on view more store hyperlink in product definition page and validates all the stores based on location \"([^\"]*)\" and closes the popup$")
//    public void userClicksOnViewMoreStoreHyperlinkInProductDefinitionPageAndValidatesAllTheStoresBasedOnLocationAndClosesThePopup(String storeLocation) {
//        getElement("clickOnViewMoreStore").click();
//        List<WebElement> pdpViewMoreStoreList = getDriver().findElements(By.xpath("//div[@class='cp-product typ-plp typ-cart']"));
//        logger.info("No of stores are: " + pdpViewMoreStoreList.size());
//        for (int i = pDPPageConditionFirstValue; i <= pdpViewMoreStoreList.size(); i++) {
//            logger.info("Store address is: " + getElement("pdpViewStoreAddress", String.valueOf(i)).getText() + "and store location is: " + storeLocation);
//            assertStepExecution(true, (getElement("pdpViewStoreAddress", String.valueOf(i)).getText()).contains(storeLocation)
//                    , "Store location assert");
//        }
//        getElement("clickOnPopUpCloseButton").click();
//    }


    /*
       User selects extended warranty product
    */
    @And("^user selects \"([^\"]*)\" extended warranty option from product definition page$")
    public void userSelectsExtendedWarrantyOptionFromProductDefinitionPage(String extended_warranty_pdp_option) throws InterruptedException {
        logger.info("inside extended wty method");
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);
        JavaScriptUtil.windowScrollIntoViewByWebElementTrue(getElement("lastKeyFeatureOfProduct"));
        Thread.sleep(2000);
        JavaScriptUtil.windowScrollIntoViewByWebElementTrue(getElement("extendedWarrantyPlanText"));
        //  conditionalWait(ExpectedConditions.elementToBeClickable(getElement("extendedWarrantyOptionSelect", extended_warranty_pdp_option)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("extendedWarrantyOptionSelect", extended_warranty_pdp_option) != null, "Extended warranty option present");
        //windowScrollIntoViewByWebElement(getElement("extendedWarrantyOptionSelect", extended_warranty_pdp_option));
        getElement("extendedWarrantyOptionSelect", extended_warranty_pdp_option).click();
        Thread.sleep(5000);


    }


    /*
        user saves compares the TAT message or option
    */
    @And("^user saves compares the TAT message or option \"([^\"]*)\"$")
    public void userSavesComparesTheTATMessageOrOption(String saveCompare) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("displayedTATMessage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        switch (saveCompare) {
            case "save":
                logger.info("TAT message displayed is: " + getElement("displayedTATMessage").getText());
                setContext("pincode_TAT_message", getElement("displayedTATMessage").getText());
                break;
            case "compare":
                logger.info("TAT message displayed is: " + getElement("displayedTATMessage").getText() +
                        " earlier TAT message is: " + getContext("pincode_TAT_message"));
              /*  assertThat(getElement("displayedTATMessage").getText()).describedAs("TAT message comparisons").
                        isNotEqualTo(getContext("pincode_TAT_message"));*/
                assertStepExecution(false, (getElement("displayedTATMessage").getText()).equals
                                (getContext("pincode_TAT_message")),
                        "TAT message comparisons");
                logger.info("TAT assertion done");
                break;
        }
    }


    /*
        user clicks on Share icon on product definition page and closes pop up
    */


    @And("^user clicks on Share icon on product definition page and closes pop up$")
    public void userClicksOnShareIconOnProductDefinitionPageAndClosesPopUp() {
        assertStepExecution(true, getOptionalElement("shareIcon") != null, "Share icon is not present on product definition page");
        windowScrollIntoViewByWebElement(getElement("shareIcon"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("shareIcon")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("shareIcon").click();
      /*  List<WebElement> shareMediaList = getElements("shareMediaList");
        logger.info("share media list size is: " + shareMediaList.size());
        assertStepExecution(true, (shareMediaList.size() > pDPPageConditionFirstValue),
                "user clicks on Share icon on product definition page");*/
        //   getElement("sharePopUpClose").click();
    }

    /*
      user validates the pop up message
   */


    @And("^user validates the pop up message \"([^\"]*)\" in product definition page$")
    public void userValidatesThePopUpMessageInProductDefinitionPage(String popUpMessage) {
        //  conditionalWait(ExpectedConditions.elementToBeClickable(getElement("AddToCartFailedMessagePopUp", popUpMessage)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(popUpMessage, getElement("AddToCartFailedMessagePopUp", popUpMessage).getText(), "Failed Popup Message not matched while adding product to cart");
        //  processScreenshot();
    }


    /*
        user validates the breadcrumb on pdp
     */
    @And("^user validates breadcrumb link \"([^\"]*)\" in product definition page$")
    public void userValidatesBreadcrumbLinkInProductDefinitionPage(String pdpBreadcrumb) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("pdpBreadcrumbLink", pdpBreadcrumb)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("The breadcrumb on pdp is : " + getElement("pdpBreadcrumbLink", pdpBreadcrumb).getText());
        processScreenshot();
        assertStepExecution(pdpBreadcrumb, getElement("pdpBreadcrumbLink", pdpBreadcrumb).getText(), "Breadcrumb is not matched");
    }


    /*
      user clicks on pincode textbox on pdp
  */
    @And("^user clicks on pincode text box of product definition page$")
    public void userClicksOnPincodeTextBoxOfProductDefinitionPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("noPincodeValidation")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("noPincodeValidation").click();
    }


    /*
    user validates no pincode condition and out of stock on product definition page
*/
    @And("^user validates pincode unavailability or out of stock \"([^\"]*)\" on product definition page with pincode text \"([^\"]*)\" and standard delivery text \"([^\"]*)\"$")
    public void userValidatesPincodeUnavailabilityOrOutOfStockOnProductDefinitionPageWithPincodeTextAndStandardDeliveryText(String pincode_oos_option, String pincodeMsg, String sdTATMsg) {
        switch (pincode_oos_option) {
            case "pincodeUnavailabilityCheckPDP":
                windowScrollIntoViewByWebElement(getElement("noPincodeValidation"));
                logger.info("Pincode validation text on PDP: " + getElement("noPincodeValidation").getText() +
                        " SD TAT validation text on PDP: " + getElement("displayedTatNoPincode").getText());
                assertThat(getElement("noPincodeValidation").getText()).describedAs("No pincode on pdp validation").
                        isEqualTo(pincodeMsg);

                assertThat(getElement("displayedTatNoPincode").getText()).describedAs("TAT message no pincode validation").
                        isEqualTo(sdTATMsg);
                break;
            case "oosCheckPDP":
            /*    conditionalWait(ExpectedConditions.elementToBeClickable(getElement("trendingProductHeading")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
                String trendingProductList = "You may like some of these trending products";
                assertThat(getElement("trendingProductHeading").getText()).describedAs("Trending product heading").
                        isEqualTo(trendingProductList);

                List<WebElement> pdpTrendingProductList = getDriver().findElements(By.xpath(getLocator("trendingProductList")));
                //    getElements("trendingProductList");


                assertThat(pdpTrendingProductList.size()).describedAs
                        ("Trending product should contain products").isGreaterThan
                        (pDPPageScrollDownFirstIndex);

                getElement("trendingProductClose").click();
*/
                logger.info("Pincode validation text on PDP: " + getElement("oosValidationText").getText() +
                        " SD TAT validation text on PDP: " + getElement("displayedTATMessage").getText());


                assertThat(getElement("oosValidationText").getText()).describedAs("No pincode on pdp validation").
                        contains(pincodeMsg);

                assertThat(getElement("displayedTATMessage").getText()).describedAs("TAT message no pincode validation").
                        isEqualTo(sdTATMsg);

                assertThat(getElement("displayed3HRTATMessage").getText()).describedAs("TAT message no pincode validation").
                        isEqualTo(sdTATMsg);

                assertThat(getElement("displayedStoreTATMessage").getText()).describedAs("TAT message no pincode validation").
                        isEqualTo(sdTATMsg);

                break;

        }

        passStepExecution("user validates no pincode condition and out of stock on product definition page");
    }


    /*
      User validates offer link in pdp
    */
    @And("^user validates offer link \"([^\"]*)\" in product definition page and clicks on it$")
    public void userValidatesOfferLinkInProductDefinitionPageAndClicksOnIt(String offerLink) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("offerForYouLink", offerLink)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //String offerLinkSubstr = StringUtils.substringBefore((getElement("offerForYouLink", offerLink).getText()), " (");
        // logger.info("The offer for you link is :" + offerLinkSubstr);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("offerForYouLink")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));

        String offerLinkSubstr = splitTextWithIndexing(getElement("offerForYouLink").getText(), " \\(", 0);

        int total_Offer_Count = numericValuesExtractionMethod(getElement("offerForYouLink").getText());
        //String offerLinkSubstr = StringUtils.substringBefore((getElement("offerForYouLink", offerLink).getText()), " (");
        logger.info("The offer for you link is :" + offerLinkSubstr);
        processScreenshot();
        assertStepExecution(offerLink.toUpperCase(), offerLinkSubstr.toUpperCase(), "Offer link text matched");
        setContext("Total_Offers", String.valueOf(total_Offer_Count));
        getElement("offerForYouLink").click();
        processScreenshot();
    }


    /*
       user validates the list of offers
    */
    @And("^user validates the offers and terms and condition link \"([^\"]*)\", terms of use page \"([^\"]*)\"$")
    public void userValidatesTheOffersAndTermsAndConditionLinkTermsOfUsePage(String termAndConditionLink, String termsOfUse) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("offersList")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        List<WebElement> offersListonPdp = getElements("offersList");
        logger.info("Total offers present for the product = " + offersListonPdp.size());
        assertStepExecution(true, offersListonPdp.size() > pDPPageScrollDownFirstIndex, "Offers are not present in pdp");
        logger.info("Total offers present for the product = " + offersListonPdp.size());
        assertStepExecution(true, getContext("Total_Offers").equals(String.valueOf(offersListonPdp.size())),
                "Total Offer count Matched");
        processScreenshot();
        List<WebElement> offerDropdown = getDriver().findElements(By.xpath(getLocator("offerDropDownArrow")));
        int sizeOfOfferList = offerDropdown.size();
        for (int i = 1; i <= sizeOfOfferList; i++) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("offerDropDownArrowList", String.valueOf(i))), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            getElement("offerDropDownArrow", String.valueOf(i)).click();
            assertStepExecution(termAndConditionLink, getElement("termsAndConditionHeading").getText(), "terms and condition is present");
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("termsAndConditionLink", String.valueOf(i))), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            getElement("termsAndConditionLink", String.valueOf(i)).click();
            userMovesToNewWindow();
            logger.info("New window title is: " + getDriver().getTitle());
            assertStepExecution(termsOfUse, getElement("termOfUse", String.valueOf(i)).getText(), "Term of Use is validated");
//                Set<String> ids = getDriver().getWindowHandles();
//                Iterator<String> it = ids.iterator();
//                String parentid = it.next();
//                String childid = it.next();
//                getDriver().switchTo().window(childid);
            logger.info("New window title is: " + getDriver().getTitle());
            assertStepExecution(termsOfUse, getElement("termOfUse", String.valueOf(i)).getText(), "Term of Use is validated");
//                getDriver().close();
//                getDriver().switchTo().window(parentid);
            userClosesTheCurrentWindowAndMovesToOldWindow();
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("offerDropDownArrowList", String.valueOf(i))), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            getElement("offerDropDownArrowList", String.valueOf(i)).click();
        }
        getElement("crossIconOnOffer").click();
    }


    /*
        user closes the pdp window tab and navigates back to old tab
    */
    @And("^user closes the pdp window tab and navigates back to old tab$")
    public void userClosesThePdpWindowTabAndNavigatesBackToOldTab() {
        if (getContext("product_available").equalsIgnoreCase("true")) {
            logger.info("Current window title is: " + getDriver().getTitle());
            userClosesTheCurrentWindowAndMovesToOldWindow();
        }
    }


    @And("^user hovers the product image in product definition page and verify the zoomed image$")
    public void userHoversTheProductImageInProductDefinitionPageAndVerifyTheZoomedImage() {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("productImage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        actionMoveToElementBuild(getElement("productImage"));
        assertStepExecution(true, getOptionalElement("zoomedProduct") != null, "Element matched");

    }

    @And("^user deselects \"([^\"]*)\" extended warranty option from product definition page$")
    public void userDeselectsExtendedWarrantyOptionFromProductDefinitionPage(String extended_warranty_pdp_option) throws InterruptedException {
        logger.info("inside extended wty method");
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("extendedWarrantyOptionSelect", extended_warranty_pdp_option)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("extendedWarrantyOptionSelect", extended_warranty_pdp_option) != null, "Extended warranty option present");
        getElement("extendedWarrantyOptionSelect", extended_warranty_pdp_option).click();
        Thread.sleep(5000);
        windowScrollToTop();

    }


    @And("^user clicks on write a review \"([^\"]*)\" tab$")
    public void userClicksOnWriteAReviewTab(String write_a_review_tab) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        js.executeScript("window.scrollBy(0,1400)");
        //Thread.sleep(5000);
        //getDriver().findElement(By.xpath("(//span[@class='MuiIconButton-label'])[3]")).click();
//        js.executeScript("window.scrollBy(0,50000)");
//        windowScrollIntoViewByWebElement
        // windowScrollIntoViewLazyLoad("reviewDropDown");
//        windowScrollIntoViewByWebElement(getElement("reviewTab"));
//        windowScrollIntoViewByWebElementTrue(getElement("reviewTab"));
        //windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownLastIndex);
        //Thread.sleep(5000);
        getElement("reviewDropDown").click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("writeAReviewTab", write_a_review_tab)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("writeAReviewTab") != null, "Write a a review section is present");
        getElement("writeAReviewTab").click();


    }

    @And("^user writes the review \"([^\"]*)\" and submit the review$")
    public void userWritesTheReviewAndSubmitTheReview(String review) throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("reviewTextBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("reviewTextBox").sendKeys(review);
        Thread.sleep(5000);
        processScreenshot();
        js.executeScript("window.scrollBy(0,200)");
        // windowScrollIntoViewByWebElement(getElement("submitButtonReview"));
        // windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownLastIndex);
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("submitButtonReview") != null, "sumbit button is present.");
        getElement("submitButtonReview").click();
        processScreenshot();


    }
      /*
         User validates the review submition pop up message
      */

    @Then("^user validates the review submition pop up message \"([^\"]*)\"$")
    public void userValidatesTheReviewSubmitionPopUpMessage(String review_submition_pop_up_message) {

        assertStepExecution(review_submition_pop_up_message, getElement("reviewSubmitionPopUpMessage", review_submition_pop_up_message).getText(), "Review Submition Pop Up Message Matched");
        processScreenshot();
    }

    /*
       User provides the rating for the product
     */
    @And("^user gives the rating$")
    public void userGivesTheRating() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("ratingTab") != null, "Rating tab is present");
        getElement("ratingTab").click();

    }


    /*
      user clicks on shop with video option for the plp product and close the window
   */
    @And("^user clicks on shop with video option for the \"([^\"]*)\" from product definition page and close the video window$")
    public void userClicksOnShopWithVideoOptionForTheFromProductDefinitionPageAndCloseTheVideoWindow(String productName) {
        // waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            processScreenshot();
            windowScrollIntoViewByWebElement(getElement("pdpProductShopWithVideo"));
            windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownLastIndex);
            processScreenshot();
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("pdpProductShopWithVideo")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
            assertStepExecution(true, getOptionalElement("pdpProductShopWithVideo") != null, " Pdp shop with video is present");
            getElement("pdpProductShopWithVideo").click();
        }
    }

    /*
      user provides name, contact no, email id to shop with video window
  */
    @And("^user provides \"([^\"]*)\" as name, \"([^\"]*)\" as contact no, \"([^\"]*)\" as email and submit in shop with video window$")
    public void userProvidesAsNameAsContactNoAsEmailAndSubmitInShopWithVideoWindow(String name, String contact, String email) {
        /*String videoTimingText = "Shop with video assistance is available between 10:00 AM and 11:30 PM. Do visit again or leave your contact details & we will call you back during operational hours.";
        assertStepExecution(getElement("shopWithVideoTimingText").getText(), videoTimingText, "Video Timing text did not match in shop with video window");*/
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Passed arguments: " + name + " " + contact + " " + email);
        if (!name.equalsIgnoreCase("NA")) {
            clearTextBox(getElement("customerNameTextBox"));
            getElement("customerNameTextBox").sendKeys(name);
        }
        if (!contact.equalsIgnoreCase("NA")) {
            clearTextBox(getElement("customerContactTextBox"));
            getElement("customerContactTextBox").sendKeys(contact);
        }
        if (!email.equalsIgnoreCase("NA")) {
            clearTextBox(getElement("customerEmailTextBox"));
            getElement("customerEmailTextBox").sendKeys(email);
        }
        getElement("customerCallMeButton").click();
    }

    /*
       user validates call back message in shop with video window
   */
    @And("^user validates call back message as \"([^\"]*)\" in shop with video window$")
    public void userValidatesCallBackMessageAsInShopWithVideoWindow(String message) {
        assertStepExecution(getElement("callBackSuccessfulMessage").getText(), message, "Call back successful text did not match in shop with video window");
        getElement("callBackSuccessWindowClose").click();
    }

    /*
        user provide leaving too early reason and submit in leaving too early window
    */
    @And("^user provides \"([^\"]*)\" as leaving reason in leaving too early window and submit and verifies feedback message as \"([^\"]*)\"$")
    public void userProvidesAsLeavingReasonInLeavingTooEarlyWindowAndSubmitAndVerifiesFeedbackMessageAs(String reason, String feedback) {
        getElement("leavingEarlyReasonCheckBox", reason).click();
        getElement("leavingEarlyReasonSubmitButton").click();
        assertStepExecution(getElement("leavingEarlyReasonFeedbackText").getText(), feedback, "Feedback message did not match in too early window");
    }

    @And("^user lands on product definition page of the \"([^\"]*)\" as product name, \"([^\"]*)\" as product id, \"([^\"]*)\" as product price, \"([^\"]*)\" as product mrp price, \"([^\"]*)\" as product review, \"([^\"]*)\" as product star available in page$")
    public void userLandsOnProductDefinitionPageOfTheAsProductNameAsProductIdAsProductPriceAsProductMrpPriceAsProductReviewAsProductStarAvailableInPage(String pdpProduct, String pdpProductId, String pdpProductPrice, String pdpProductMrpPrice, String pdpProductReview, String pdpProductStar) {
        logger.info("Current window title is: " + getDriver().getTitle() + "The product details on PDP Data Base is: " + pdpProduct + " " + pdpProductId + " " + pdpProductPrice + " " + pdpProductMrpPrice + "  " + pdpProductReview + " " + pdpProductStar);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("pdp_Product", pdpProduct)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Product details are:" + getElement("pdp_Product", pdpProduct).getText() + " " + numericValuesExtractionMethod(getElement("pdp_Product_Id", pdpProduct).getText()) + " " + getElement("pdp_Product_Actual_Price", pdpProduct).getText());
        assertThat(getElement("pdp_Product", pdpProduct).getText()).describedAs("Product name is not matching in plp").isEqualToIgnoringCase(pdpProduct);
        assertThat(String.valueOf(numericValuesExtractionMethod(getElement("pdp_Product_Id", pdpProduct).getText()))).describedAs("Product id is not matching in plp").isEqualTo(pdpProductId);
        assertThat(getElement("pdp_Product_Actual_Price", pdpProduct).getText()).describedAs("Product actual price is not matching in plp").isEqualTo(pdpProductPrice);
        logger.info(" MRP Percentage " + getDriver().findElements(By.xpath(getLocator("mrpPresentPdp", pdpProduct))).size());
        if ((getDriver().findElements(By.xpath(getLocator("mrpPresentPdp", pdpProduct)))).size() > pDPPageScrollDownFirstIndex) {
            logger.info("Discount details are:" + getElement("discountPricePdp", pdpProduct).getText());
            assertThat(getElement("discountPricePdp", pdpProduct).getText()).describedAs("Product discount Price  is not matching in plp ").isEqualTo(pdpProductMrpPrice);
        }
        logger.info("Review and star details are:" + getElement("discountReviewPdp", pdpProduct).getText().replaceAll("\\(", "").replaceAll("\\)", "") + " and " + getElement("discountStarPdp", pdpProduct).getAttribute("aria-label"));
        assertThat(getElement("discountReviewPdp", pdpProduct).getText().replaceAll("\\(", "").replaceAll("\\)", "")).describedAs("Product discount review  is not matching in plp").isEqualTo(pdpProductReview);
        assertThat(getElement("discountStarPdp", pdpProduct).getAttribute("aria-label")).describedAs("Product discount Star is not matching in plp").isEqualTo(pdpProductStar);
        processScreenshot();
        passStepExecution("User lands on product listing page and validates product details and click");
    }

    /*
     user clicks on play button to play the video of the product in youtube
     */
    @Then("^user clicks on play button to play the video of the \"([^\"]*)\" in youtube$")
    public void userClicksOnPlayButtonToPlayTheVideoOfTheInYoutube(String productName) throws InterruptedException {
        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME")) {
            processScreenshot();
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("pdpVideoYoutubeFrame", productName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
            getDriver().findElement(By.xpath("//iframe [@title=\"" + productName + "\"]")).click();

        } else if (getConfig("Browser").trim().equalsIgnoreCase("EMULATED_CHROME")) {
            processScreenshot();
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("pdpVideoYoutubeFrame", productName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
            getDriver().switchTo().frame(getDriver().findElement(By.xpath("//iframe[@title='Redmi MI 10T Pro (8GB+128GB) Black']")));
            Thread.sleep(5000);
            getDriver().findElement(By.className("ytp-large-play-button")).sendKeys(Keys.ENTER);
            processScreenshot();

        }

    }

    /*
      user clicks on maximize button in the youtube window and minimize it
     */
    @And("^user clicks on maximize button in the youtube window and minimize it$")
    public void userClicksOnMaximizeButtonInTheYoutubeWindow() throws InterruptedException {
        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME")) {
            processScreenshot();
            iframeVideoFullAndMiniScreen();
            Thread.sleep(2000);
            iframeVideoFullAndMiniScreen();
        } else if (getConfig("Browser").trim().equalsIgnoreCase("EMULATED_CHROME")) {
            getDriver().findElement(By.className("ytp-fullscreen-button")).sendKeys(Keys.ENTER);
            Thread.sleep(5000);
            getDriver().findElement(By.className("ytp-play-button")).sendKeys(Keys.ESCAPE);
        }
    }

    /*
      user clicks on pause button in the youtube window

     */
    @Then("^user clicks on pause button in the youtube window$")
    public void userClicksOnPauseButtonInTheYoutubeWindow() {

        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME")) {
            iframeVideoPlayAndPause();
            processScreenshot();
        } else if (getConfig("Browser").trim().equalsIgnoreCase("EMULATED_CHROME")) {
            getDriver().findElement(By.className("ytp-play-button")).sendKeys(Keys.ENTER);
            processScreenshot();
        }
    }

    @And("^validate SEE EMI OPTIONS should displayed and user clicks on it$")
    public void validateSEEEMIOPTIONSShouldDisplayedAndUserClicksOnIt() throws InterruptedException {
        String emiStartingPrice = getElement("emiStartingAt").getText().trim().replace(",", "");
        logger.info("EMI starting at :- " + emiStartingPrice);
        setContext("emiStartingAmount", emiStartingPrice);
        assertStepExecution(true, getElement("seeEMIOptions").isDisplayed(), "See EMI options should displayed");
        Thread.sleep(3000);
        if (getElement("seeEMIOptions").isDisplayed()) {
            logger.info("EMI option is present ");
            //js.executeScript("window.scrollBy(0,500)");
            //js.executeScript("arguments[0].scrollIntoView(true);", getElement("seeEMIOptions"));
            getElement("seeEMIOptions").click();
        } else {
            js.executeScript("window.scrollBy(0,500)");
            //js.executeScript("arguments[0].scrollIntoView(true);", getElement("seeEMIOptions"));
            getElement("seeEMIOptions").click();
        }
    }

    @Then("^EMI modal window opened and user verify bank EMI options$")
    public void emiModalWindowOpenedAndUserVerifyBankEMIOptions() throws InterruptedException {
        String stepDescription = "EMI modal window opened and user verify bank EMI options";
        assertThat(getElement("emiModalWindow").isDisplayed()).isEqualTo(true)
                .describedAs("EMI modal window should displayed");
        int bankOptionCount = getElements("bankName").size();
        logger.info("Bank Count :- " + bankOptionCount);

        for (int bankCount = 0; bankCount == bankOptionCount; bankCount++) {

            String emiOnwardsValue = getElements("emiOnwards").get(bankCount).getText().trim().replace(" Onwards", "");
            assertThat(emiOnwardsValue).isGreaterThanOrEqualTo(getContext("emiStartingAmount"))
                    .describedAs("EMI Onwards Value should already greater than or equal to EMI Starting Amount in PDP");

            logger.info("EMI Onwards amount :- " + emiOnwardsValue);
            Thread.sleep(5000);
            getElements("bankArrowBtn").get(bankCount).click();

            assertThat(getOptionalElement("emiTable")).isNotNull().describedAs("EMI details table should be displayed");

        }

        passStepExecution(stepDescription + " :: Passed \n");

    }


    /*
        user clicks on offer for you link and validate the offer details
    */
    @And("^user validates \"([^\"]*)\"$")
    public void userClicksOnOfferForYouLinkAndValidateAndCloseThePopUp(String offerDetails) throws InterruptedException {
        boolean verifyOffer = false;
        conditionalWait(ExpectedConditions.visibilityOf(getElement("viewAllOffersLink")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        // getElement("offerForYouButton").click();
        // Thread.sleep(5000);
        // getOptionalElement("viewAllOffersLink").click();
        //jsClick(getOptionalElement("viewAllOffersLink"));
        getElement("viewAllOffersLink").click();
        Thread.sleep(5000);
        List<WebElement> offerForYouTextList = getElements("offersList");
        logger.info("offerForYouTextList size : " + offerForYouTextList.size());
        for (WebElement element : offerForYouTextList) {
            logger.info("element value is: " + element.getText());
            String offer = element.getText().replaceAll("Learn More", "");
            verifyOffer = offer.equalsIgnoreCase(offerDetails);
            logger.info("Offer Match boolean: " + verifyOffer);
            if (verifyOffer)
                break;
        }
        if (offerDetails.equalsIgnoreCase("NA")) {
            assertStepExecution(false, verifyOffer, "Particular Offer should not be there in this product");
        } else {
            assertStepExecution(true, verifyOffer, "Offer does not exists in this product");
        }
        //getElement("offerForYouWindowClose").click();
    }


    @And("^user selects the offer from product definition page$")
    public void userSelectsTheOfferFromProductDefinitionPage() throws InterruptedException {

        windowScrollIntoViewByWebElement(getElement("WindowScrollTillOffer"));

        getElement("offerToSelect").click();
        Thread.sleep(1000);
    }


    @And("^user clicks add to cart button from offer section on product definition page$")
    public void userClicksAddToCartButtonFromOfferSectionOnProductDefinitionPage() {
        getElement("addToCartButtonOnOffer").click();
    }
    /*
        user clicks offer checkbox of  offer on product definition page
     */

    @And("^user clicks offer checkbox of \"([^\"]*)\" offer on product definition page$")
    public void userClicksOfferCheckboxOfOfferOnProductDefinitionPage(String offerText) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        windowScrollIntoBottom();
        Thread.sleep(4000);
        windowScrollToTop();
        Thread.sleep(15000);
        windowScrollIntoViewByWebElementTrue(getOptionalElement("offerCheckboxToClick", offerText));
        String stepDesc = "user clicks offer checkbox of " + offerText + " offer on product definition page";
        assertStepExecution(true, getOptionalElement("offerCheckboxToClick", offerText) != null,
                stepDesc);
        Thread.sleep(3000);
        windowScrollIntoViewByWebElement(getElement("offerCheckboxToClick", offerText));
        windowScrollIntoViewAdjustment(0, 300);
        jsClick(getElement("offerCheckboxToClick", offerText));
        //    getElement("offerCheckboxToClick",offerText).click();
        Thread.sleep(3000);
    }

    @And("^user validates the offer \"([^\"]*)\" to be display$")
    public void userValidatesTheOfferToBeDisplay(String productOfferName) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("offerName")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));

        String pdpOfferName = getElement("offerName").getText().trim();
        logger.info("Offer details are :- " + pdpOfferName);
        assertStepExecution(true, pdpOfferName.contains(productOfferName), "PDP offer details should be display");
        setContext("pdpOfferNames", pdpOfferName);
    }

    @Then("^user validates \"([^\"]*)\" section and \"([^\"]*)\" text should display$")
    public void userValidatesSectionShouldBeDisplay(String standardDeliveryAvailable, String enterPincodeForDelivery) {
        String stepDescription = "user validates standard delivery available section and enter pin code for delivery estimates text should display";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("standardDelivery")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));

        String pdpDeliveryText = getElement("standardDelivery").getText().trim();
        logger.info("Default delivery option without pincode" + pdpDeliveryText);

        String pdpEnterPincodeText = getElement("enterPincodeForDelivery").getText().trim();
        logger.info("Enter Pincode For Delivery Estimates" + pdpEnterPincodeText);


        assertThat(standardDeliveryAvailable.equals(pdpDeliveryText))
                .describedAs("Standard Delivery Available text should display").isEqualTo(true);

        assertThat(pdpEnterPincodeText.equals(enterPincodeForDelivery))
                .describedAs("Standard Delivery Available text should display").isEqualTo(true);

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user validates text box for enter pin code along with \"([^\"]*)\" text should be display$")
    public void userValidatesTextBoxForEnterPinCodeAlongWithTextShouldBeDisplay(String EnterYourPincode) {
        clearTextBox(getElement("enterYourPincodeText"));
        conditionalWait(ExpectedConditions.visibilityOf(getElement("enterYourPincodeText")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        String EnterYourPincodeText = getElement("enterYourPincodeText").getAttribute("placeholder").trim();
        logger.info("Enter Pincode text" + EnterYourPincodeText);

        assertStepExecution(EnterYourPincode, EnterYourPincodeText, "Enter your pincode should be display");
    }

    @And("^user validates apply button should be disable$")
    public void userValidatesApplyButtonShouldBeDisable() throws InterruptedException {
        boolean button = getDriver().findElement(By.xpath(getLocator("disableApplyBtn"))).isDisplayed();
        logger.info("Apply btn is :- " + button);
        assertStepExecution(true, getDriver().findElement(By.xpath(getLocator("disableApplyBtn"))).isDisplayed(), "Apply button should display as disable");
        Thread.sleep(5000);
    }


    @And("^user provides \"([^\"]*)\" and \"([^\"]*)\" massage should be display$")
    public void userProvidesAndMassageShouldBeDisplay(String invalidPincode, String errorMassage) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("enterYourPincodeText")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("enterYourPincodeText").sendKeys(invalidPincode);
        getElement("standardDelivery").click();
        String enteredPincode = getElement("enterYourPincodeText").getAttribute("value").trim();
        String errorMsg = getElement("enterValidPincode").getText().trim();
        assertStepExecution(errorMassage, errorMsg, "Please enter valid pincode should display");
        setContext("wrongPincode", enteredPincode);
        setContext("errorMsg", errorMsg);
        logger.info("Enter Pincode value :- " + getContext("ErrorMassage"));
    }


    @And("^user provides \"([^\"]*)\" and validates apply button should be enable$")
    public void userProvidesAndValidatesApplyButtonShouldBeEnable(String pincode) {
        String stepDescription = "user provides correct pincode and validates apply button should be enable";
        assertThat(getContext("wrongPincode")).describedAs("Incorrect pincode should display").isEqualTo(true);
        getElement("enterYourPincodeText").clear();
        getElement("enterYourPincodeText").sendKeys(pincode);
        assertThat(getContext("errorMsg") == null).describedAs("Please enter valid pincode should not display").isEqualTo(true);
        assertThat(getElement("activeApplyBtn").isDisplayed()).isEqualTo(true).describedAs("Active apply button should display");
        passStepExecution(stepDescription + " :: Passed \n");

    }

    @And("^user validates \"([^\"]*)\" should be display for the product$")
    public void userClicksOnApplyButtonAndShouldBeDisplayForTheProduct(String deliveryOption) throws InterruptedException {
        String stepDescription = "user Clicks On Apply Button And Should Be Display For The Product";

        Thread.sleep(10000);

        conditionalWait(ExpectedConditions.visibilityOf(getElement("zipDelivery")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String deliveryDetails = getElement("zipDelivery").getText().trim();
        logger.info("Delivery details are :- " + deliveryDetails);
        assertThat(deliveryDetails.contains(deliveryOption)).isEqualTo(true).describedAs("Details details should match");

        String deliveryBox = getElement("deliveryBox").getText().trim();
        logger.info("Delivery details are :- " + deliveryBox);

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user provides \"([^\"]*)\" pincode and clicks on apply button$")
    public void userProvidesAndClicksOnApplyButton(String outOfStockPincode) throws InterruptedException {
        String stepDescription = "user Provides And Clicks On Apply Button";
        String pincodeBoxValue = getElement("enterPincodeForDelivery").getText().trim();
        assertThat((pincodeBoxValue).equalsIgnoreCase(getContext("wrongPincode"))).describedAs("Enter pincode fields contained with value");

        Thread.sleep(5000);
        jsClear(getElement("enterYourPincodeText"));

        Thread.sleep(5000);
        getElement("enterYourPincodeText").sendKeys(outOfStockPincode);

        assertThat(getElement("enterYourPincodeText").getText().contains(outOfStockPincode)).describedAs("Out of stock pincode value should display");
        assertThat(getElement("activeApplyBtn").isDisplayed()).isEqualTo(true).describedAs("Active apply button should display");

        Thread.sleep(5000);
        windowScrollIntoViewByWebElement(getElement("activeApplyBtn"));
        windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownLastIndex);
        Thread.sleep(5000);
        jsClick(getElement("activeApplyBtn"));
        //getElement("activeApplyBtn").click();
        setContext("outOfStockPin", outOfStockPincode);
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user validates not available in your pincode massage should display$")
    public void userValidatesNot_available_in_your_pincodeMassageShouldDisplay() {

        String notAvailableMsg = getElement("notAvailableYourPincode").getText().trim();
        /*assertThat(getElement("notAvailableYourPincode").isDisplayed()).
                describedAs("Not available in your pincode massage should display").isEqualTo(true);*/
        logger.info("Not available msg :-" + notAvailableMsg);
        assertStepExecution(notAvailableMsg, "Delivery options are not available for this pincode.", "Delivery options are not available for this pincode.");

    }


    @And("^user validates \"([^\"]*)\" text and change link should display$")
    public void userValidatesDeliveryOptionsForTextAndChangeLinkShouldDisplay(String DeliveryOptionsforPincode) {
        String stepDescription = "user Validates Delivery Options For Text And Change Link Should Display";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("deliveryText")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String pinCodeText = getElement("pinCode").getText().trim();
        String deliveryText = getElement("deliveryText").getText().trim().split("\n" + pinCodeText)[0];

        String deliveryPincode = deliveryText + " " + pinCodeText;
        logger.info("Delivery details :- " + deliveryPincode);
        logger.info("Delivery1 details :- " + deliveryText);
        logger.info("Delivery2 details :- " + pinCodeText);

        assertThat(deliveryPincode.contains(DeliveryOptionsforPincode)).isEqualTo(true).describedAs("Delivery Options for Pincode should display");
        assertThat(getElement("changeLink").isDisplayed()).describedAs("Change link should display").isEqualTo(true);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("popUpCrossIcon")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        if (getOptionalElement("popUpCrossIcon") != null) {
            //getElement("OOSCloseBtn").click();
            jsClick(getElement("popUpCrossIcon"));
        }

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user clicks on change link and provides \"([^\"]*)\" correct pincode$")
    public void userClicksOnChangeLinkAndProvides(String stockAvailablePincode) throws InterruptedException {
        String stepDescription = "user Clicks On Change Link And Provides";
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("changeLink")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        jsClick(getElement("changeLink"));
        //  getElement("changeLink").click();
        assertThat(getElement("pinCodeHome").getText().
                equals(getContext("outOfStockPin"))).describedAs("Out of stock pincode should display");

        assertThat(getElement("crossBtn").isDisplayed()).isEqualTo(true).describedAs("Cross button should display");
        assertThat(getElement("pinCodeHome").getAttribute("placeholder").trim()).isEqualTo("Enter pincode").describedAs("Default text Enter pincode should display");
        assertThat(getElement("pinCodeText").getText().contains("Enter a pincode")).describedAs("Enter a pincode text should display");

        Thread.sleep(5000);
        // getElement("pinCodeHome").clear();
        jsClear(getElement("pinCodeHome"));
        getElement("pinCodeHome").sendKeys(stockAvailablePincode);
        assertThat(getElement("pinCodeSubmit").isDisplayed()).describedAs("Apply button should display").isEqualTo(true);
        getElement("pinCodeSubmit").click();
        assertThat(getElement("pinCode").getText().equals(stockAvailablePincode)).describedAs("Updated pincode should display");

        String pinCodeText = getElement("pinCode").getText().trim();
        String deliveryText = getElement("deliveryText").getText().trim().split("\n" + pinCodeText)[0];
        String deliveryPincode = deliveryText + " " + pinCodeText;
        setContext("updatedPincode", deliveryPincode);
        setContext("stockAvailablePincode", stockAvailablePincode);
        logger.info("Text msg :- " + getContext("updatedPincode"));

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @Then("^user validates \"([^\"]*)\" and View Store List link should display in PDP$")
    public void userValidatesAndViewStoreListLinkShouldDisplayInPDP(String storeName) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("storeName", storeName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        String pickUpStore = getElement("storePickUp").getText().trim();
        logger.info("Store name :- " + pickUpStore);
        assertThat(pickUpStore).isEqualTo(storeName).describedAs("Store PickUp name should match");

        assertThat(getElement("viewStoreLink").isDisplayed()).describedAs("Store pick up link should display").isEqualTo(true);
    }

    @And("^user clicks on View Store List link and validates store list should display$")
    public void userClicksOnViewStoreListLinkAndValidatesStoreListShouldDisplay() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("viewStoreLink")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        jsClick(getElement("viewStoreLink"));
        // getElement("viewStoreLink").click();
        String storeCount = getElement("storeCount").getText().trim().replace(" stores available", "");
        int intCount = Integer.parseInt(storeCount);
        logger.info("total Store count :- " + storeCount);
        logger.info("total Store count1 :- " + intCount);
        int totalStoreCount = getElements("storeInfoBox").size();
        logger.info("total Store :- " + totalStoreCount);

        assertThat(getElement("cromaStoreText").getText().equalsIgnoreCase("Croma Stores")).describedAs("Croma Stores text should display");
        assertThat(intCount).isEqualTo(totalStoreCount).describedAs("Total Store count should match");
        assertThat(getElement("changeBtn").isDisplayed()).isEqualTo(true).describedAs("Change button should display");
        assertThat(getElement("storeListPincode").getText().contains("Store List for " + getContext("stockAvailablePincode").equals(true))).describedAs("Text massage should match");

        getElement("storeCloseBtn").click();
    }


    @And("^user validates learn more link of the offers \"([^\"]*)\" clicked and terms of use page \"([^\"]*)\" displayed$")
    public void userValidatesLearnMoreLinkOfTheOffersClickedAndTermsOfUsePageDisplayed(String offerText, String termOfUsePage) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDesc = "user clicks learn more of " + offerText + " offer on product definition page";
        assertStepExecution(true, getOptionalElement("offerLearnMoreToClick", offerText) != null,
                stepDesc);
        Thread.sleep(3000);
        actionMoveToElementClick(getOptionalElement("offerLearnMoreToClick", offerText));
        //    getElement("offerCheckboxToClick",offerText).click();
        Thread.sleep(3000);
        userMovesToNewWindow();
        logger.info("New window title is: " + getDriver().getTitle());
        assertStepExecution(termOfUsePage, getElement("termOfUse").getText(), "Term of Use is validated");
        userClosesTheCurrentWindowAndMovesToOldWindow();
    }

    /*
        User click add to cart from product definition page
    */
    @And("^user clicks add to cart from product definition page with successful message \"([^\"]*)\"$")
    public void userClicksAddToCartFromProductDefinitionPageWithSuccessfulMessage(String addToCartMessage) {
        if (getContext("product_available").equalsIgnoreCase("true")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addToCartButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            // CommonUtil.windowScrollIntoViewByWebElement(getElement("addToCartButton"));
            windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownLastIndex);
            assertStepExecution(true, getOptionalElement("addToCartButton") != null, "User clicks add to cart from product definition page");
            //getElement("addToCartButton").click();
            jsClick(getElement("addToCartButton"));
        }
    }

    /*
        User clicks on plus icon
    */
    @And("^user clicks on plus icon on compare tray$")
    public void userClicksOnPlusIconOnCompareTray() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnPlusIcon")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("clickOnPlusIcon") != null, "Plus Icon is found");
        getElement("clickOnPlusIcon").click();
    }

    /*
      User clicks onView more store hyperlink and validates all stores based on location
   */
    @And("^user clicks on view more store hyperlink in product definition page and validates all the stores based on location \"([^\"]*)\" and closes the popup$")
    public void userClicksOnViewMoreStoreHyperlinkInProductDefinitionPageAndValidatesAllTheStoresBasedOnLocationAndClosesThePopup(String storeLocation) {
        getElement("clickOnViewMoreStore").click();
        List<WebElement> pdpViewMoreStoreList = getDriver().findElements(By.xpath("//div[@class='cp-product typ-plp typ-cart']"));
        logger.info("No of stores are: " + pdpViewMoreStoreList.size());
        for (int i = pDPPageConditionFirstValue; i <= pdpViewMoreStoreList.size(); i++) {
            logger.info("Store address is: " + getElement("pdpViewStoreAddress", String.valueOf(i)).getText() + "and store location is: " + storeLocation);
            assertThat(getElement("pdpViewStoreAddress", String.valueOf(i)).getText()).contains(storeLocation).describedAs("PDP View Stores Present");
        }
        getElement("clickOnPopUpCloseButton").click();
        passStepExecution("Close button is successfully clicked");
    }

    @And("^user clicks on buy with exchange link$")
    public void userClicksOnBuyWithExchangeLink() {
        assertThat(getElement("exchangeBtn").isDisplayed()).isEqualTo(true).describedAs("Buy with exchange button should display");
        getElement("exchangeBtn").click();
    }

    @And("^user provides product details \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" and clicks on check price button$")
    public void userProvidesPhoneDetailsAndClicksOnCheckPriceButton(String brandName, String brandModel, String brandVariant) throws InterruptedException {
        //conditionalWait(ExpectedConditions.visibilityOf(getElement("phoneBrand")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));

      /*  getElement("dropDwonButton").click();

        int totalProducts = getElements("listOfProducts").size();
        ArrayList<String> listOfProducts = new ArrayList<>();

        for (int pro = 0; pro < totalProducts; pro++) {
            listOfProducts.add(getElements("listOfProducts").get(pro).getText());
        }
        if (listOfProducts.contains(brandName)) {
            WebElement element = getElement("enteredProduct", brandName);
            element.click();
        } else {
            logger.info(brandName + " Brand Name is not present");
        }
        /*
        /*
       User provides phone brand details
    */

        WebElement inputWebElement = getDriver().findElement(By.xpath(getLocator("phoneBrand")));
        inputWebElement.click();
        Thread.sleep(5000);
        inputWebElement.sendKeys(brandName);
        inputWebElement.sendKeys(Keys.ARROW_DOWN);
        inputWebElement.sendKeys(Keys.ENTER);
        String brandValue = getElement("brandValue").getAttribute("value").trim();
        logger.info("Brand Value :- " + brandValue);
        assertThat(brandValue).isEqualTo(brandName).describedAs("Brand name should display");

        inputWebElement.sendKeys(Keys.TAB);

          /*
       User provides brand model details
    */

        WebElement inputWebElement1 = getDriver().findElement(By.xpath(getLocator("modelValue")));
        inputWebElement1.click();
        Thread.sleep(5000);
        inputWebElement1.sendKeys(brandModel);
        inputWebElement1.sendKeys(Keys.ARROW_DOWN);
        inputWebElement1.sendKeys(Keys.ENTER);
        String modelValue = getElement("modelValue").getAttribute("value").trim();
        logger.info("model Value :- " + modelValue);
        assertThat(modelValue).isEqualTo(brandModel).describedAs("model name should display");

        inputWebElement1.sendKeys(Keys.TAB);
    /*
   User provides brand variant details
    */

        WebElement inputWebElement2 = getDriver().findElement(By.xpath(getLocator("variantValue")));
        inputWebElement2.click();
        Thread.sleep(5000);
        inputWebElement2.sendKeys(brandVariant);
        inputWebElement2.sendKeys(Keys.ARROW_DOWN);
        inputWebElement2.sendKeys(Keys.ENTER);
        String variantValue = getElement("variantValue").getAttribute("value").trim();
        logger.info("variant Value :- " + variantValue);
        assertThat(variantValue).containsIgnoringCase(brandVariant).describedAs("variant name should display");
        inputWebElement2.sendKeys(Keys.TAB);

        assertThat(getElement("exchangeCheckPriceBtn").isDisplayed()).isEqualTo(true).describedAs("exchange Check Price Btn should display");
        jsClick(getElement("exchangeCheckPriceBtn"));
    }

    @And("^user provides IMEI number \"([^\"]*)\" , clicks on verify link and clicks on apply button$")
    public void userProvidesIMEINumberClicksOnVerifyLinkAndClicksOnApplyButton(String IMEIno) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("IMEINumber")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("IMEINumber").click();
        getElement("IMEINumber").sendKeys(IMEIno);
        getElement("imEiVerifyBtn").click();
        assertStepExecution(true, getElement("activeVerified").isDisplayed(), "IMEI number should display verified");
        getElement("applyBtn").click();
    }

    @And("^user validates exchange offer details \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" and clicks on the buy with exchange button$")
    public void userValidatesExchangeOfferDetailsAndClicksOnTheBuyWithExchangeButton(String exchangeValue, String paybleValue, String productDetail) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("exchangeValue")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        String fixedValue = getElement("exchangeValue").getText().trim().replace("₹ ", "");
        String payblValue = getElement("paybleValue").getText().trim().replace("₹ ", "");
        String produtName = getElement("exchangProDetails").getText().trim();

        logger.info("Fixed Value :- " + fixedValue);
        logger.info("Payble Value :- " + payblValue);
        logger.info("Product Name :- " + produtName);

        setContext("fixedExValue", fixedValue);
        setContext("exchangeProName", produtName);

        assertThat(fixedValue).isEqualTo(exchangeValue).describedAs("Exchange value should match");
        assertThat(payblValue).isEqualTo(paybleValue).describedAs("Payble value should match");
        assertThat(produtName).isEqualTo(productDetail).describedAs("Payble value should match");

        assertThat(getElement("buyWithExchBtn").isDisplayed()).isEqualTo(true).describedAs("Buy with exchange button should display");
        getElement("buyWithExchBtn").click();
    }


    @And("^user clicks add to cart button under freebie offer section from product definition page$")
    public void userClicksAddToCartButtonUnderFreebieOfferSectionFromProductDefinitionPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addToCartButtonOnOffer")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            assertStepExecution(true, getOptionalElement("addToCartButtonOnOffer") != null, "user clicks add to cart from product definition page");
            //Thread.sleep(5000);
            jsClick(getElement("addToCartButtonOnOffer"));
        }
        Thread.sleep(5000);
    }

    @And("user clicks add to cart button from offer {string} section on product definition page")
    public void userClicksAddToCartButtonFromOfferSectionOnProductDefinitionPage(String offer) {
        scrollToWebelement(getElement("addToCartButtonOnOffer", offer));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addToCartButtonOnOffer", offer)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getElement("addToCartButtonOnOffer", offer) != null,
                "user clicks add to cart button from offer " + offer + " section on product definition page");
        jsClick(getElement("addToCartButtonOnOffer", offer));
    }

    @And("user closes the product popup button in pdp if present")
    public void userClosesTheProductPopupButtonOnInPdpIfPresent() {

        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (getOptionalElement("popUpCrossIcon") != null) {
            assertStepExecution(true, getOptionalElement("popUpCrossIcon") != null, "Popup is present on pdp with cross icon");
            getElement("popUpCrossIcon").click();
        } else {
            assertStepExecution(true, getOptionalElement("popUpCrossIcon") == null, "Popup is not present on pdp with cross icon");
            logger.info("Pop up has not arrived on pdp");
        }
        passStepExecution("This method is passed.");


    }

    @Then("user clicks on proceed to cart button and lands on cart page")
    public void userClicksOnProceedToCartButtonAndLandsOnCartPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        getElement("proceedToCartBtn").click();
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
    }

    @And("user clicks on continue button and lands on product definition page")
    public void userClicksOnContinueButtonAndLandsOnProductDefinitionPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        getElement("goToContinueButton").click();
    }


    @And("user verifies {string} section is present in product definition page")
    public void userVerifiesSectionIsPresentInProductDefinitionPage(String sectionName) throws InterruptedException {
        int homePageScrollUpFirstIndex = 150;
        int homePageScrollDownFirstIndex = 0;
        windowScrollIntoTopToBottom();
        Thread.sleep(3000);
        windowScrollIntoTopToBottom();
        windowScrollIntoViewByWebElement(getElement("carouselLink", sectionName));
        windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpFirstIndex);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("carouselLinks", sectionName)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        actionMoveToElementBuild(getElement("carouselLinks", sectionName));
        assertStepExecution(true, getOptionalElement("anyHeaderSectionInProductDefinitionPage", sectionName) != null,
                "user verify " + sectionName + " section is present in product definition page");
    }

    @And("user verifies {string} section is present in pop up modal box")
    public void userVerifiesSectionIsPresentInPopUpModalBox(String sectionName) throws InterruptedException {
//        int homePageScrollUpFirstIndex = 150;
//        int homePageScrollDownFirstIndex = 0;
//        windowScrollIntoTopToBottom();
//        windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpFirstIndex);
        //            conditionalWait(ExpectedConditions.visibilityOf(getElement("carouselLinks", sectionName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        logger.info(getElement("anyHeaderSectionInProductDefinitionPage", sectionName).getText());
        //     actionMoveToElementBuild(getElement("anyHeaderSectionInProductDefinitionPage", sectionName));
        assertStepExecution(true, getElement("anyHeaderSectionInProductDefinitionPage", sectionName) != null,
                "user verify " + sectionName + " section is present in product definition page");

    }


    @And("user stores the first product id of the product from {string} section")
    public void userStoresTheFirstProductIdOfTheProductFromSection(String sectionName) {
        WebElement wb = getElement("productIdFromMiniCartModal", sectionName);
        String productLink = wb.getAttribute("href");
        logger.info("The product url is:" + productLink);
        String productId = productLink.substring(productLink.lastIndexOf("/") + 1).trim();
        logger.info("The product id is:" + productId);
        setContext("ProductIdFromMiniCartModalPopUp", productId);

    }


    @And("user clicks on add to cart of the first product from {string} section")
    public void userClicksOnAddToCartOfTheFirstProductFromSection(String sectionName) throws InterruptedException {
        actionMoveToElementBuild(getElement("anyHeaderSectionInProductDefinitionPage", sectionName));
        assertStepExecution(true, getElement("addToCartButtonInMiniCart", sectionName) != null, "User verifies the add to cart button in mini cart modal pop up");
        actionMoveToElementClick(getElement("addToCartButtonInMiniCart", sectionName));
    }

    @And("user verifies the {string}")
    public void userVerifiesThe(String addToCartPopUpMessage) throws InterruptedException {
        Thread.sleep(1000);
        assertStepExecution(addToCartPopUpMessage, getElement("addToCartPopUpMessage", addToCartPopUpMessage).getText(), "User verifies the add to cart success message");
    }

    @And("user validates recommended text {string} in EW tiles in mini cart dialog box")
    public void userValidatesInEWTilesInMiniCartDialogBox(String recommendedTextEWTile) {
        assertStepExecution(recommendedTextEWTile, getElement("recommendedText").getText(), "User validates the recommended text in EW tile");

    }

    @And("user validates recommended text {string} is not coming in EW tiles in mini cart dialog box")
    public void userValidatesRecommendedTextIsNotComingInEWTilesInMiniCartDialogBox(String recommendedTextEWTile) {
        assertStepExecution(false, getOptionalElement("recommendedText") != null, "User validates that No recommended text present in mini cart modal pop up");
    }

    @And("user clicks on view store list on product definition page")
    public void userClicksOnViewStoreListOnProductDefinitionPage() throws InterruptedException {
        //js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);
        assertStepExecution(true, getElement("viewStoreLinkPdp") != null, "User verified the view store link on pdp");
        getElement("viewStoreLinkPdp").click();
        Thread.sleep(6000);
    }

    @And("user verifies the stores is in sorted order as per distance or not")
    public void userVerifiesTheStoresIsInSortedOrderAsPerDistanceOrNot() {
        String baseURI = getConfig("URL").replace("pwa", "api");
        RestAssured.baseURI = baseURI;
        ArrayList<String> storeList = new ArrayList<>(Arrays.asList("A035", "A001", "A002", "A009"));
        RequestSpecification specification = RestAssured.given();

        Response resp = specification.queryParam("storeList", storeList)
                .queryParam("latitude", "19.1047153")
                .queryParam("longitude", "72.826827")
                .when()
                .log().all()
                .get("store/pwamobileapp/v2/detail")
                .then().extract().response();
        String respAsString = resp.asString();
        System.out.println("=====Response Body====\n" + respAsString);

        ArrayList<String> formatDistList = JsonPath.read(respAsString, "$..formattedDistance");
        ArrayList<String> storeDisplayNameList = JsonPath.read(respAsString, "$..displayName");
        System.out.println(formatDistList);
        System.out.println(storeDisplayNameList);
        assertThat(formatDistList.size()).describedAs("Both List Having Same Size")
                .isEqualTo(storeDisplayNameList.size());
        for (int dist = 0; dist < formatDistList.size() - 1; dist++) {
            double dist1 = Double.parseDouble(formatDistList.get(dist));
            double dist2 = Double.parseDouble(formatDistList.get(dist + 1));
            System.out.println("Comparision between " + dist1 + " and " + dist2);
            assertThat(dist1).describedAs("Store Distance is in Sorted Order")
                    .isLessThan(dist2);
        }
        List<WebElement> listOfStoreInUi = getElements("listOfStore");
        for (int store = 0; store < listOfStoreInUi.size(); store++) {
            assertThat(listOfStoreInUi.get(store).getText()).describedAs("Store from API and Web are matched")
                    .isEqualTo(storeDisplayNameList.get(store));
        }
    }

    @And("user validates pick up at store delivery option on pdp page")
    public void userValidatesPickUpAtStoreDeliveryOptionOnPdpPage() throws InterruptedException {
        assertThat(getElement("pickUpMessage").isDisplayed()).isEqualTo(true).describedAs("user validates pick up at store delivery option on pdp page");
        Thread.sleep(5000);
    }

    @And("user validates {string} offer is absent in PDP")
    public void userValidatesOfferIsAbsentInPDP(String offer) throws InterruptedException {
        //conditionalWait(ExpectedConditions.visibilityOf(getElement("viewAllOffersLink")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
//        if (getOptionalElement("viewAllOffersLink") != null) {
//            getElement("viewAllOffersLink").click();
//        }
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("offerOnPDP", offer) == null,
                "user validates " + offer + " offer is absent in PDP");
    }

    @And("user validates {string} offer is present in PDP")
    public void userValidatesOfferIsPresentInPDP(String offer) throws InterruptedException {
//        if (getOptionalElement("viewAllOffersLink") != null) {
//            getElement("viewAllOffersLink").click();
//        }
        Thread.sleep(5000);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("offerOnPDP", offer)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("offerOnPDP", offer) != null,
                "user validates " + offer + " offer is present in PDP");
    }

    @And("user verifies that add to cart and buy now button is disabled")
    public void userVerifiesThatAddToCartAndBuyNowButtonIsDisabled() throws InterruptedException {
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        assertThat(getOptionalElement("disabledAddToCartButton") != null).describedAs("User verified that add to cart button is disabled").isEqualTo(true);
        assertThat(getOptionalElement("disabledBuyNowButton") != null).describedAs("User verified that add to cart button is disabled").isEqualTo(true);
        passStepExecution("user verifies that add to cart and buy now button is disabled");
    }

    @And("user verifies product title, product image, product price, add to cart button is present in carousel {string}")
    public void userVerifiesProductTitleProductImageProductPriceAddToCartButtonIsPresentInCarousel(String productCarousel) {
        WebElement wb = getElement("imageOnCarousel", productCarousel);
        String image = wb.getAttribute("src");
        assertThat(image.contains(".png")).isEqualTo(true).describedAs("User verifies the product image is present in product carousel");
        assertThat(getElements("productTitleOnCarousel", productCarousel) != null).isEqualTo(true).describedAs("User verifies the product title is present on product carousel");
        assertThat(getElement("addToCartButtonOnProductCarousel") != null).isEqualTo(true).describedAs("User verifies the add to cart button on product carousel");
        assertThat(getElements("priceOnProductCarousel", productCarousel) != null).isEqualTo(true).describedAs("User verifies the price on product carousel");
        passStepExecution("Product details in product carousel is verified.");
    }

    @And("user verifies {string}, {string}, {string} in mini cart pop up from pdp")
    public void userVerifiesInMiniCartPopUpFromPdp(String productName, String productId, String productPrice) {
        assertThat(getElement("productNameMiniCartPopUpPDP", productName).getText()).describedAs("User verifies the product name on miniCart pop up")
                .isEqualTo(productName);
//        assertThat(getElement("productIdMiniCartPopUp", productName).getText().replaceAll("[^0-9]", "")).describedAs("User verifies the product ID on miniCart pop up")
//                .isEqualTo(productId);
        assertThat(getElement("productPriceMiniCartPopUpPDP", productName).getText()).describedAs("User verifies the product price on miniCart pop up")
                .isEqualTo(productPrice);
        setContext("productPriceInMiniCart", getElement("productPriceMiniCartPopUpPDP", productName).getText());
        passStepExecution("Product details in mini cart pdp is verified.");
    }

    @And("user verifies continue shopping button and go to cart button in mini cart")
    public void userVerifiesContinueShoppingButtonAndGoToCartButtonInMiniCart() {
        assertThat(getElement("continueShoppingButton") != null).describedAs("User verifies continue shopping button")
                .isEqualTo(true);
        assertThat(getElement("goToCartButton") != null).describedAs("User verifies go to cart button")
                .isEqualTo(true);
        passStepExecution("user verifies continue shopping button and go to cart button in mini cart pop.");
    }

    @And("user validates not available in your pincode massage should display on pdp page")
    public void userValidatesNotAvailableInYourPincodeMassageShouldDisplayOnPdpPage() {
        String notAvailableMsg = getElement("notAvailableOnYourPincode").getText().trim();
        logger.info("Not available msg :-" + notAvailableMsg);
        assertStepExecution(notAvailableMsg, "Not available for your pincode", "User validates not available in your pincode massage should display on pdp page");

    }


    @And("user verifies {string} section is present below delivery section in product defination page and display product features")
    public void userVerifiesSectionIsPresentBelowDeliverySectionInProductDefinationPageAndDisplayProductFeatures(String keyFeatureTitle) {
        String keyFeatureTitleName = getElement("keyFeatureTitle").getText();
        assertStepExecution(keyFeatureTitleName, keyFeatureTitle, "Key feature section is present below delivery section in product defination page and display product features");
        List<WebElement> KeyFeatureListDetails = getElements("KeyFeatureList");
        for (int i = pDPPageScrollDownFirstIndex; i < KeyFeatureListDetails.size(); i++) {
            logger.info("Key Feature : " + i + ". " + KeyFeatureListDetails.get(i).getText());
        }
    }

    @And("user checks {string} should also appear in the delivery option based on the Pincode")
    public void userChecksShouldAlsoAppearInTheDeliveryOptionBasedOnThePincode(String cityName) {
        scrollToWebelement(getElement("cityNamePresentOnYourPincode"));
        String cityNamePresent = getElement("cityNamePresentOnYourPincode").getText().trim();
        logger.info("City name for the pincode :-" + cityNamePresent);
        assertStepExecution(cityNamePresent, cityName, "User checks city name should also appear in the delivery option based on the Pincode");
    }

    @And("user validates the delivery estimate should appear as per the eligibility of different delivery options {string} for that product")
    public void userValidatesTheDeliveryEstimateShouldAppearAsPerTheEligibilityOfDifferentDeliveryOptionsForThatProduct(String deliveryOption) {
        switch (deliveryOption) {
            case "Home Delivery":
                String homeDeliveryEstimate = getElement("homeZipDeliveryMessage").getText().trim();
                logger.info("Home delivery estimate msg :-" + homeDeliveryEstimate);
                assertThat(homeDeliveryEstimate).describedAs("user validates the delivery estimate should appear as per the eligibility of home delivery option")
                        .contains("Will be delivered");
                break;
            case "Express Delivery":
                String zipDeliveryEstimate = getElement("homeZipDeliveryMessage").getText().trim();
                logger.info("Express delivery estimate msg :-" + zipDeliveryEstimate);
                assertThat(zipDeliveryEstimate).describedAs("user validates the delivery estimate should appear as per the eligibility of zip delivery option")
                        .contains("Express Delivery");
                break;
        }
        passStepExecution("User validates the delivery estimate should appear as per the eligibility of different delivery options");
    }

    /*
    This method is used to click on proceed to cart button after clicking on add to cart button

      */
    @And("user clicks on proceed to cart button in product definition page")
    public void userClicksOnProceedToCartButtonInProductDefinitionPage() throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getOptionalElement("proceedToCartBtn") != null,
                "user clicks on proceed to cart button in product definition page");
        getDriver().findElement(By.xpath(getLocator("proceedToCartBtn"))).click();
        Thread.sleep(2000);
    }

    /*
       This method is used to select one year extended warranty

         */
    @And("user selects one year extended warranty in product definition page")
    public void userSelectsOneYearExtendedWarrantyInProductDefinitionPage() throws InterruptedException {
        js.executeScript("window.scrollBy(0,600)");
        waitForJavascript(Integer.parseInt(getConfig("LongWait")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(25000);
        assertStepExecution(true, getDriver().findElement(By.xpath(getLocator("exWarranty"))) != null,
                "user selects extended warranty one year extended warranty in product definition page");
        getDriver().findElement(By.xpath(getLocator("exWarranty"))).click();
    }

    /*
    User validates old phone will not be accepted options section should appear correctly in exchange popup

      */
    @And("user validates old phone will not be accepted options section {string} should appear correctly in exchange popup")
    public void userValidatesOldPhoneWillNotBeAcceptedOptionsSectionShouldAppearCorrectlyInExchangePopup(String optionName) {
        assertStepExecution(true, getOptionalElement("oldPhoneSectionMsg") != null,
                "User verifies the product price on miniCart pop up");
        List<WebElement> exchangeOptionDetailsList = getElements("exchangeNotAcceptedOptionDetailsListXPath");
        logger.info("No of option details are: " + exchangeOptionDetailsList.size());
        for (int i = pDPPageConditionFirstValue; i <= exchangeOptionDetailsList.size(); i++) {
            logger.info("Value of i: " + i + " " + (getElement("exchangeNotAcceptedOptionName", String.valueOf(i)).getText()));
            if (getElement("exchangeNotAcceptedOptionName", String.valueOf(i)).getText().equals(optionName)) {
                logger.info("Option is present");
                break;
            }
        }
        processScreenshot();
    }

    /*
       user checks qik emi card option is present in product definition page
          */
    @And("user checks qik emi card option is present in product definition page")
    public void userChecksQikEmiCardOptionIsPresentInProductDefinitionPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("LongWait")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(8000);
        assertStepExecution(true, getElement("qikEmiCardOption").isDisplayed(),
                "user checks qik emi card option is present in product definition page");

    }


    /*
       user validates qik EMI card option is present as first option in EMI modal window
          */
    @Then("user validates qik EMI card option is present as first option in EMI modal window")
    public void userValidatesQikEMICardOptionIsPresentAsFirstOptionInEMIModalWindow() {
        String optionName = "Qik EMI Card";
        assertThat(getOptionalElement("emiTitle")).isNotNull().describedAs("User verifies the emi title in EMI modal window");
        List<WebElement> emieOptionDetailsList = getElements("emiOptionDetailsListXPath");
        logger.info("No of option details are: " + emieOptionDetailsList.size());
        for (int i = pDPPageConditionFirstValue; i <= emieOptionDetailsList.size(); i++) {
            logger.info("Value of i: " + i + " " + (getElement("emiOptionName", String.valueOf(i)).getText()));
            if (getElement("emiOptionName", String.valueOf(i)).getText().equals(optionName)) {
                if (i == pDPPageConditionFirstValue) {
                    logger.info("Option is present in first position");
                    getElements("bankArrowBtn").get(i).click();
                    assertThat(getOptionalElement("qikEmiTable")).isNotNull().describedAs("QIK EMI details table should be displayed");
                    break;
                }
            }
        }
        passStepExecution("user validates qik EMI card option is present as first option in EMI modal window :: Passed \n");
        getElement("closeCromaStoresPopup").click();
    }

    /*
       user validates qik EMI card option is not present in EMI modal window
          */

    @Then("user validates qik EMI card option is not present in EMI modal window")
    public void userValidatesQikEMICardOptionIsNotPresentInEMIModalWindow() {
        String optionName = "Qik EMI Card";
        assertThat(getOptionalElement("emiTitle")).isNotNull().describedAs("User verifies the emi title in EMI modal window");
        List<WebElement> emieOptionDetailsList = getElements("emiOptionDetailsListXPath");
        logger.info("No of option details are: " + emieOptionDetailsList.size());
        for (int i = pDPPageConditionFirstValue; i <= emieOptionDetailsList.size(); i++) {
            assertThat(getElement("emiOptionName", String.valueOf(i)).getText()).isNotEqualToIgnoringCase(optionName)
                    .describedAs("User validates qik EMI card option is not present in EMI modal window");
        }
        passStepExecution("user validates qik EMI card option is present as first option in EMI modal window :: Passed \n");
    }

    /**
     * This method is used to select phone brand or brand model or model variant in exchange popup
     **/

    @And("user selects {string} in {string} in the exchange popup on product listing page")
    public void userSelectsInInTheExchangePopupOnProductListingPage(String dropDownValue, String dropdown) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElement("exchangePopupDropDown", dropdown) != null,
                "user selects " + dropdown + " in the exchange popup in product listing page");
        WebElement elem = getDriver().findElement(By.xpath(getLocator("exchangePopupDropDown", dropdown)));
        elem.click();
        elem.findElement(By.xpath(getLocator("exchangePopupDropDownValue", dropDownValue))).click();
        Thread.sleep(2000);
    }

    /**
     * This method is used to click on buttons on exchange popup
     **/
    @And("user clicks on {string} button in the exchange popup on product listing page")
    public void userClicksOnButtonInTheExchangePopupOnProductListingPage(String buttonName) throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getElement("exchangePopupbutton", buttonName) != null,
                "user clicks on " + buttonName + " button in the exchange popup on product listing page");
        getElement("exchangePopupbutton", buttonName).click();
        Thread.sleep(2000);
    }

    /**
     * This method is used to provide imei number in exchange popup
     **/
    @And("user provides {string} in {string} in the exchange popup on product listing page")
    public void userProvidesInInTheExchangePopupOnProductListingPage(String imeiNumber, String imeiNumberTextBox) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getElement("exchangePopupDropDown", imeiNumberTextBox) != null,
                "user provides " + imeiNumber + " in " + imeiNumberTextBox + "in the exchange popup on product listing page");
        getElement("exchangePopupDropDown", imeiNumberTextBox).sendKeys(imeiNumber);
        Thread.sleep(2000);
    }

    /**
     * This method is used to click on buy with exchange button in PDP
     **/
    @And("user clicks on buy with exchange button on product listing page")
    public void userClicksOnBuyWithExchangeButtonOnProductListingPage() throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true, getElement("exchangeButtonPDP") != null,
                "user clicks on buy with exchange button on product listing page");
        getElement("exchangeButtonPDP").click();
        Thread.sleep(5000);
    }

    /*
      user verifies proceed to cart button present in mini cart
         */

    @Then("user verifies proceed to cart button present in mini cart")
    public void userVerifiesProceedToCartButtonPresentInMiniCart() {
        assertStepExecution(true, getElement("proceedToCartBtn").isDisplayed(),
                "user validates proceed to cart button is present in mini cart popup");
    }

    /*
      user lands on product definition page and verify product name
         */

    @And("user lands on product definition page and verify product name")
    public void userLandsOnProductDefinitionPageAndVerifyProductName() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("Landed on PDP");
        String productOnPdp = getElement("pdpProductTitle").getText().trim();
        logger.info("The product on pdp is" + productOnPdp + "Saved data" + getContext("firstProductNameOfTheSection"));
        //   assertStepExecution(true, productOnPdp.contains(getContext("firstProductNameOfTheSection")), "Product name are matching in PDP");
    }

    /*
     the method verifies cross button is present to close the mini cart dialog box
        */
    @Then("user verifies cross button is present to close the mini cart dialog box")
    public void userVerifiesCrossButtonIsPresentToCloseTheMiniCartDialogBox() {
        assertStepExecution(true, getElement("closeMiniCartDialog") != null,
                "user verifies cross button is present to close the mini cart dialog box");
        getElement("closeMiniCartDialog").click();
    }

    /*
     User validates super savings section is present in product definition page
        */
    @And("user validates super savings section is present in product definition page")
    public void userValidatesSuperSavingsSectionIsPresentInProductDefinitionPage() throws InterruptedException {
        windowScrollIntoBottom();
        Thread.sleep(4000);
        windowScrollToTop();
        Thread.sleep(4000);
        logger.info("Super saving section text is: " + getElement("superSavingsSectionText").getText() + "Offers count:" + getElement("offersCount").getText());
        assertThat(getElement("superSavingsSectionText").getText()).contains("Super Savings").describedAs("user validates super savings section is present in product definition page");
        assertThat(getElement("offersCount").getText()).contains("(").describedAs("user validates total no of offers in brackets");
        passStepExecution("User validates super savings section is present in product definition page:: Passed");
    }

    /*
     User validates buy as low as is not present in super savings section
        */
    @Then("user validates buy as low as is not present in super savings section")
    public void userValidatesBuyAsLowAsIsNotPresentInSuperSavingsSection() {
        assertStepExecution(true, !getElement("offersCount").getText().contains("as low as"),
                "User validates buy as low as is not present in super savings section");
    }

    /*
   User validates breadcrumb to freeze when PDP scrolls
      */
    @And("user validates breadcrumb to freeze when PDP scrolls")
    public void userValidatesBreadcrumbToFreezeWhenPDPScrolls() {
        windowScrollIntoViewAdjustment(pDPPageScrollDownFirstIndex, pDPPageScrollDownLastIndex);
        logger.info("Saved breadCrum name: " + getOptionalElement("breadCrumoption", getContext("breadcrumOptionCount")));
        assertStepExecution(true, getOptionalElement("breadCrumoption", getContext("breadcrumOptionCount")).isDisplayed(), "user validates breadcrumb to freeze when PDP scrolls");
    }

    /*
     User validates breadcrumb on PDP should scroll when product image scrolls
   */
    @Then("user validates breadcrumb on PDP should scroll when product image scrolls")
    public void userValidatesBreadcrumbOnPDPShouldScrollWhenProductImageScrolls() {
        windowScrollIntoTopToBottom();
        assertStepExecution(true, getOptionalElement("floatingTextStyle").isDisplayed(), "user validates breadcrumb on PDP should scroll when product image scrolls");
    }

    /*
      User validates validates add to cart failure messag
   */
    @And("user validates add to cart failure message {string}")
    public void userValidatesAddToCartFailureMessage(String failureMessage) {
        String addToCartFailureMessageFromWeb = getElement("addToCartFailureMessage", failureMessage).getText();
        assertStepExecution(true, addToCartFailureMessageFromWeb.equalsIgnoreCase(failureMessage), "Add to cart failure message matched");
    }

    /*
     User validates products added to mini cart with success message
  */
    @And("user validates {string} added to mini cart with success message {string}")
    public void userValidatesAddedToMiniCartWithSuccessMessage(String noOfproduct, String successMessage) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String addToCartSuccessMessageFromWeb = getElement("addToCartSuccessMessage", successMessage).getText();
        assertThat(addToCartSuccessMessageFromWeb).contains(successMessage).describedAs("Add to cart success message matched");
        String numberOfProducts = String.valueOf(numericValuesExtractionMethod(addToCartSuccessMessageFromWeb));
        assertThat(numberOfProducts).isEqualTo(noOfproduct).describedAs("Number of product matched matched");
        passStepExecution("user validates products added to mini cart with success message  :: pass");
    }

    /*
    User validates products names in mini cart page
 */
    @And("user validates {string} as products names in mini cart page")
    public void userValidatesAsProductsNamesInMiniCartPage(String miniCartProductNames) {
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("productCountListMiniCartPage"));
        assertThat(productDetail.size()).describedAs("Products are more than 1").isGreaterThan(0);
        if (miniCartProductNames.contains(";")) {
            String[] productNamefromExamples = miniCartProductNames.split(";");
            for (int i = 0; i < productNamefromExamples.length; i++) {
                String productNameFromWeb = productDetail.get(i).getText();
                logger.info("The product name from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("Cart product name from web and examples are matched.").isEqualTo(productNamefromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText()).describedAs("Cart product name from web and examples are matched.").isEqualTo(miniCartProductNames);
        }
        passStepExecution("Products names on cart is verified");

    }

    /*
  User validates products mrp prices in mini cart page
*/
    @And("user validates {string} as products mrp prices in mini cart page")
    public void userValidatesAsProductsMrpPricesInMiniCartPage(String miniCartProductMrpPrices) {
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("productMrpPricesListMiniCartPage"));
        assertThat(productDetail.size()).describedAs("Products are more than 1").isGreaterThan(0);
        if (miniCartProductMrpPrices.contains(";")) {
            String[] productNamefromExamples = miniCartProductMrpPrices.split(";");
            for (int i = 0; i < productNamefromExamples.length; i++) {
                String productNameFromWeb = productDetail.get(i).getText().replace("₹", "");
                logger.info("The product mrp price from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("Cart product mrp price from web and examples are matched.").isEqualTo(productNamefromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText()).describedAs("Cart product mrp price from web and examples are matched.").isEqualTo(miniCartProductMrpPrices);
        }
        passStepExecution("Products mrp price on mini cart is verified");
    }

    /*
User validates products mop prices in mini cart page
*/
    @And("user validates {string} as products mop prices in mini cart page")
    public void userValidatesAsProductsMopPricesInMiniCartPage(String miniCartProductMopPrices) {
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("productMopPricesListMiniCartPage"));
        assertThat(productDetail.size()).describedAs("Products are more than 1").isGreaterThan(0);
        if (miniCartProductMopPrices.contains(";")) {
            String[] productNamefromExamples = miniCartProductMopPrices.split(";");
            for (int i = 0; i < productNamefromExamples.length; i++) {
                String productNameFromWeb = productDetail.get(i).getText().replace("₹", "");
                logger.info("The product mop price from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("Cart product mop price from web and examples are matched.").isEqualTo(productNamefromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText().replace("₹", "")).describedAs("Cart product mop price from web and examples are matched.").isEqualTo(miniCartProductMopPrices);
        }
        passStepExecution("Products mop price on cart is verified");
    }

    /*
    User validates added to cart message is present above recommended title
    */
    @And("user validates added to cart message is present above recommended title")
    public void userValidatesAddedToCartMessageIsPresentAboveRecommendedTitle() {
        assertStepExecution(true, getElement("addedToCartInProductTile") != null,
                "user validates added to cart message is present above recommended title");
    }

    /*
    User validates continue shopping button is not present in mini cart popup
    */
    @And("user validates continue shopping button is not present in mini cart popup")
    public void userValidatesContinueShoppingButtonIsNotPresentInMiniCartPopup() {
        assertStepExecution(false, getDriver().findElements(By.xpath(getLocator("goToContinueButton"))).size() > 0,
                "user validates continue shopping button is not present in mini cart popup");
    }

    /*
    User validates sku id from the product tile is not present in mini cart popup
    */
    @Then("user validates sku id from the product tile is not present in mini cart popup")
    public void userValidatesSkuIdFromTheProductTileIsNotPresentInMiniCartPopup() {
        assertStepExecution(false, getDriver().findElements(By.xpath(getLocator("miniCartSkuId"))).size() > 0,
                "user validates sku id from the product tile is not present in mini cart popup");
    }

    /*
   User validates proceed to cart button is present in mini cart popup
   */
    @And("user validates proceed to cart button is present in mini cart popup")
    public void userValidatesProceedToCartButtonIsPresentInMiniCartPopup() {
        assertStepExecution(true, getElement("proceedToCartBtn").isDisplayed(),
                "user validates proceed to cart button is present in mini cart popup");
    }

    /*
   User stores the first product name of the product from Please consider these other options section
   */
    @And("user stores the first product name of the product from {string} section")
    public void userStoresTheFirstProductNameOfTheProductFromSection(String sectionName) {
        String productName = getElement("productNameFromMiniCartModal", sectionName).getText().replaceAll("\\.", "");
        logger.info("The product name is:" + productName);
        setContext("ProductNameFromMiniCartModalPopUp", productName);
    }

    /*
  User validates zip protection plan section title is present with the message
  */
    @And("user validates zip protection plan section title {string} is present with the message {string}")
    public void userValidatesZipProtectionPlanSectionTitleIsPresentWithTheMessage(String zipProtectionPlanTitle, String zipProtectionPlanMessage) {
        js.executeScript("window.scrollBy(0,500)");
        logger.info("Zip protection plan title from web is: " + getElement("zipProtectionPlanTitle").getText() + " and from example: " + zipProtectionPlanTitle);
        assertThat(getElement("zipProtectionPlanTitle").getText()).isEqualToIgnoringCase(zipProtectionPlanTitle).describedAs("user validates zip protection plan section title is present");
        String zipProtectionMessage = getElement("zipProtectionPlanMessage").getText();
        assertThat(zipProtectionMessage).isEqualToIgnoringCase(zipProtectionPlanMessage).describedAs("user validates zip protection plan section title is present with message");
        passStepExecution("User validates zip protection plan section title is present with message :: Passed");
    }

    /*
  User validates section is present under the zip protection plan in product definition page
  */
    @And("user validates {string} is present under the zip protection plan in product definition page")
    public void userValidatesIsPresentUnderTheZipProtectionPlanInProductDefinitionPage(String zipProtectionPlanSection) {
        windowScrollIntoViewAdjustment_scroll(0, 600);
        windowScrollIntoViewByWebElement(getElement("zipProtectionPlanSection", zipProtectionPlanSection));
        windowScrollIntoViewAdjustment(0, 50);
        String zipProtectionPlanSectionName = getElement("zipProtectionPlanSection", zipProtectionPlanSection).getText().trim();
        logger.info("The section on pdp is: " + zipProtectionPlanSectionName + " and data from examples: " + zipProtectionPlanSection);
        assertStepExecution(true, zipProtectionPlanSectionName.equalsIgnoreCase(zipProtectionPlanSection), "user validates" + zipProtectionPlanSection + " section is present under the zip protection plan in product definition page");
    }

    /*
  User validates section title is present with the monthly cost message
  */
    @And("user validates section title {string} is present with the monthly cost message {string}")
    public void userValidatesSectionTitleIsPresentWithTheMonthlyCostMessage(String zipProtectionPlanSection, String monthlyCostMessage) {
        logger.info("Section title from web is: " + getElement("zipProtectionPlanSection", zipProtectionPlanSection).getText() + " and from example: " + zipProtectionPlanSection);
        assertThat(getElement("zipProtectionPlanSection", zipProtectionPlanSection).getText()).isEqualToIgnoringCase(zipProtectionPlanSection).describedAs("user validates section title is present");
        String monthlyCostMessageText = getElement("monthlyCostMessage", zipProtectionPlanSection).getText();
        assertThat(monthlyCostMessageText).contains(monthlyCostMessage).describedAs("user validates section title " + zipProtectionPlanSection + " is present with the monthly cost message");
        passStepExecution("User validates section title {string} is present with the monthly cost message :: Passed");

    }

    /*
  User clicks on {string} section and verify section popup should open
  */
    @And("user clicks on {string} section and verify section popup should open")
    public void userClicksOnSectionAndVerifySectionPopupShouldOpen(String zipProtectionPlanSection) {
        jsClick(getElement("zipProtectionPlanSectionClick", zipProtectionPlanSection));
        logger.info("Title of the popup page is :" + getElement("pageTitle").getText());
        assertStepExecution(true, zipProtectionPlanSection.equalsIgnoreCase(getElement("pageTitle").getText()), "user clicks on" + zipProtectionPlanSection + " section and verify section popup should open");
    }

    /*
      user validates view details hyperlink is present in extended warranty section
   */
    @And("user validates view details hyperlink is present in extended warranty section")
    public void userValidatesViewDetailsHyperlinkIsPresentInExtendedWarrantySection() {
        assertStepExecution(true, getElement("viewDetailsLink").isDisplayed(), "user validates view details hyperlink is present in extended warranty section");
    }

    /*
      user clicks on the view detail hyperlink in extended warranty section and verify section popup should open
   */
    @And("user clicks on the view detail hyperlink in extended warranty section and verify section popup should open")
    public void userClicksOnTheViewDetailHyperlinkInExtendedWarrantySectionAndVerifySectionPopupShouldOpen() {
        jsClick(getElement("viewDetailsLink"));
        logger.info("Title of the popup page is :" + getElement("pageTitle").getText());
        assertStepExecution(true, getElement("pageTitle").getText().equalsIgnoreCase("OnsiteGo - Extended Warranty"), "user clicks on the view detail hyperlink in extended warranty section and verify section popup should open");
    }

    /*
      user verifies % of buyers taking ew plan should present under ew option
   */
    @And("user verifies % of buyers taking ew plan should present under ew option")
    public void userVerifiesOfBuyersTakingEwPlanShouldPresentUnderEwOption() {
        String percentOfBuyerTakingEwPlanMessage = getElement("percentOfBuyerTakingEwPlanMessage").getText();
        logger.info("The message is : " + percentOfBuyerTakingEwPlanMessage + " and the percent value is: " + numericValuesExtractionMethod(percentOfBuyerTakingEwPlanMessage));
        assertStepExecution(true, percentOfBuyerTakingEwPlanMessage.contains("% of the people bought the warranty with the product"), "user verifies % of buyers taking ew plan should present under ew option");
    }

    /*
      user verifies % of buyers taking ew plan should present under ew option
   */
    @And("user verifies % of buyers taking ew plan should present under ew option in view details popup")
    public void userVerifiesOfBuyersTakingEwPlanShouldPresentUnderEwOptionInViewDetailsPopup() {
        String percentOfBuyerTakingEwPlanMessage = getElement("percentOfBuyerTakingEwPlanViewDetailsPopUpMessage").getText();
        logger.info("The message is : " + percentOfBuyerTakingEwPlanMessage + " and the percent value is: " + numericValuesExtractionMethod(percentOfBuyerTakingEwPlanMessage));
        assertStepExecution(true, percentOfBuyerTakingEwPlanMessage.contains("% of the people bought the warranty with the product"), "user verifies % of buyers taking ew plan should present under ew option");
    }

    /*
      user validates ew option is present under extended warranty section
   */
    @And("user validates {string} option is present under extended warranty section")
    public void userValidatesOptionIsPresentUnderExtendedWarrantySection(String extendedWarrantyPdpOption) {
        List<WebElement> extendedWarrantyPdpOptionListSize = getElements("extendedWarrantyPdpOptionSize");
        logger.info("No of options are: " + extendedWarrantyPdpOptionListSize.size());
        for (int i = pDPPageConditionFirstValue; i <= extendedWarrantyPdpOptionListSize.size(); i++) {
            String option = getElement("extendedWarrantyPdpOption", String.valueOf(i)).getText();
            logger.info("Option is: " + option + "and option from DB is: " + extendedWarrantyPdpOption);
            if (option.equalsIgnoreCase(extendedWarrantyPdpOption)) {
                logger.info("Option is present");
                break;
            }
        }
    }

    /*
      user validates ew option is selected under extended warranty section
   */
    @And("user validates {string} option is selected under extended warranty section")
    public void userValidatesOptionIsSelectedUnderExtendedWarrantySection(String extendedWarrantyPdpOption) {
        List<WebElement> extendedWarrantyPdpOptionListSize = getElements("extendedWarrantyPdpOptionSize");
        logger.info("No of options are: " + extendedWarrantyPdpOptionListSize.size());
        for (int i = pDPPageConditionFirstValue; i <= extendedWarrantyPdpOptionListSize.size(); i++) {
            String option = getElement("extendedWarrantyPdpOption", String.valueOf(i)).getText();
            logger.info("Option is: " + option + "and option from DB is: " + extendedWarrantyPdpOption);
            if (option.equalsIgnoreCase(extendedWarrantyPdpOption)) {
                logger.info(getElement("optionSelected", extendedWarrantyPdpOption).getAttribute("class"));
                assertStepExecution(true, getElement("optionSelected", extendedWarrantyPdpOption).getAttribute("class").contains("active"), "user validates" + extendedWarrantyPdpOption + " option is selected under extended warranty section");
                break;
            }
        }
    }

    /*
      user checks ew option contains duration, price, monthly cost
   */
    @And("user checks {string} option contains duration, price, monthly cost")
    public void userChecksOptionContainsDurationPriceMonthlyCost(String extendedWarrantyPdpOption) {
        List<WebElement> extendedWarrantyPdpOptionListSize = getElements("extendedWarrantyPdpOptionSize");
        logger.info("No of options are: " + extendedWarrantyPdpOptionListSize.size());
        for (int i = pDPPageConditionFirstValue; i <= extendedWarrantyPdpOptionListSize.size(); i++) {
            String option = getElement("extendedWarrantyPdpOption", String.valueOf(i)).getText();
            logger.info("Option is: " + option + "and option from DB is: " + extendedWarrantyPdpOption);
            if (option.equalsIgnoreCase(extendedWarrantyPdpOption)) {
                logger.info("The duration is : " + option + " and price value is: " + getElement("extendedWarrantyPdpOptionPrice", String.valueOf(i)).getText() + " and monthly cost value is: " + getElement("extendedWarrantyPdpOptionMonthlyCost", String.valueOf(i)).getText());
                break;
            }
        }
    }

    /*
     *This Method is used to select any protection plan with validity in PDP
     */
    @And("user selects {string} as extra protection for product of validity {string} on PDP page")
    public void userSelectsAsExtraProtectionForProductOfValidityOnPDPPage(String protectionType, String validity) throws InterruptedException {
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("addExtraProtectionArrow", protectionType) != null,
                "user clicks on extra protection section arrow");
        getElement("addExtraProtectionArrow", protectionType).click();
        Thread.sleep(2000);
        userMovesToNewWindow();
        assertStepExecution(true, getOptionalElement("addExtraProtectionPlan", protectionType, validity) != null,
                "user selects " + protectionType + " as extra protection for product of validity " + validity + " on PDP page");
        getElement("addExtraProtectionPlan", protectionType, validity).click();
        getElement("addProtectionPlanBtn").click();
    }

    /*
     *This Method is used to select extra protection for product of validity on PDP page with protection
     */
    @And("user selects {string} as extra protection for product of validity {string} on PDP page with {string} protection")
    public void userSelectsAsExtraProtectionForProductOfValidityOnPDPPageWithProtection(String protectionType, String validity, String protections) throws InterruptedException {
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(8000);
        if (Integer.parseInt(protections) == 1) {
            js.executeScript("window.scrollBy(0,500)");
            Thread.sleep(2000);
            JavaScriptUtil.windowScrollIntoViewByWebElementTrue(getElement("lastKeyFeatureOfProduct"));
            Thread.sleep(2000);
            //      JavaScriptUtil.windowScrollIntoViewByWebElementTrue(getElement("extendedWarrantyPlanText"));
        }
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("addExtraProtectionArrow", protectionType) != null,
                "user clicks on extra protection section arrow");
        getElement("addExtraProtectionArrow", protectionType).click();
        Thread.sleep(2000);
        userMovesToNewWindow();
        assertStepExecution(true, getOptionalElement("addExtraProtectionPlan", protectionType, validity) != null,
                "user selects " + protectionType + " as extra protection for product of validity " + validity + " on PDP page");
        getElement("addExtraProtectionPlan", protectionType, validity).click();
        getElement("addProtectionPlanBtn").click();
        js.executeScript("window.scrollBy(0,-200)");
    }

    /*
     *This Method is used to verifies that add to cart and buy now button is present or not in bottom of screen floating in product definition page
     */
    @And("user verifies that add to cart and buy now button is {string} in bottom of screen floating in product definition page")
    public void userVerifiesThatAddToCartAndBuyNowButtonIsInBottomOfScreenFloatingInProductDefinitionPage(String presentOrNot) throws InterruptedException {
        switch (presentOrNot) {
            case "Present":
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                assertThat(getOptionalElement("presentAddToCartButton") != null).describedAs("User verified that add to cart button is present").isEqualTo(true);
                assertThat(getOptionalElement("presentBuyNowButton") != null).describedAs("User verified that add to cart button is present").isEqualTo(true);
                passStepExecution("user verifies that add to cart and buy now button is present");
                break;
            case "Not Present":
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                assertThat(getOptionalElement("presentAddToCartButton") == null).describedAs("User verified that add to cart button is present").isEqualTo(true);
                assertThat(getOptionalElement("presentBuyNowButton") == null).describedAs("User verified that add to cart button is present").isEqualTo(true);
                passStepExecution("user verifies that add to cart and buy now button is not present");
                break;
        }
    }

    /*
     *This Method is used to validates proceed to cart button is present in bottom of screen floating in product definition page
     */
    @And("user validates proceed to cart button is present in bottom of screen floating in product definition page")
    public void userValidatesProceedToCartButtonIsPresentInBottomOfScreenFloatingInProductDefinitionPage() {
        assertStepExecution(true, getOptionalElement("proceedToCartButtonInPdp") != null,
                "user validates proceed to cart button is present in bottom of screen floating in product definition page");
    }

    /*
     *This Method is used to verifies no of items displayed in bottom of screen floating in product definition page
     */
    @And("user verifies no of items displayed in bottom of screen floating in product definition page")
    public void userVerifiesNoOfItemsDisplayedInBottomOfScreenFloatingInProductDefinitionPage() {
        logger.info("Added product details in bottom of screen floating in product definition page" + getElement("addedProductDetails").getText());
        logger.info("No. of product added: " + getElement("noOfProductAdded").getText() + " " + "Added data from web: " + getContext("itemNum"));
        assertStepExecution(true, getElement("noOfProductAdded").getText().equalsIgnoreCase(getContext("itemNum")),
                "user verifies no of items displayed in bottom of screen floating in product definition page");
    }

    /*
     *This Method is used to verifies amount displayed in bottom of screen floating in product definition page
     */
    @And("user verifies amount displayed in bottom of screen floating in product definition page")
    public void userVerifiesAmountDisplayedInBottomOfScreenFloatingInProductDefinitionPage() {
        String addedProductPrice = getElement("addedProductPrice").getText();
        logger.info("Product price in bottom of screen floating in product definition page : " + addedProductPrice + " " + "Added product price from web: " + getContext("productPriceInMiniCart"));
        assertStepExecution(true, addedProductPrice.equalsIgnoreCase(getContext("productPriceInMiniCart")),
                "user verifies amount displayed in bottom of screen floating in product definition page");

    }

    @And("user validates {string} should display under recommended text {string} in mini cart dialog box")
    public void userValidatesShouldDisplayUnderRecommendedTextInMiniCartDialogBox(String extendedWarrantyTextInMiniCart, String recommendedTextEWTile) throws InterruptedException {
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,200)");
        if (getOptionalElement("recommendedText") != null) {
            assertStepExecution(recommendedTextEWTile, getElement("recommendedText").getText(), "User validates the recommended text in EW tile");
            assertStepExecution(extendedWarrantyTextInMiniCart, getElement("extendedWarrantyTextInMiniCart").getText(), "User validates extended warranty display under recommended text");
        }
    }

    @And("user validates {string} is present under the {string} product")
    public void userValidatesIsPresentUnderTheProduct(String selectedProtectionType, String pdpProduct) {
        List<WebElement> selectedProtectionTypeListSize = getDriver().findElements(By.xpath("(//h3[@class='product-title plp-prod-title']//a[text()='" + pdpProduct + "'])//following::hr[@class='main-seperator']//preceding::div[@class='cp-product typ-plp mini-cart']"));
        logger.info("No of options are: " + selectedProtectionTypeListSize.size());
        for (int i = selectedProtectionTypeListSize.size(); i >= pDPPageConditionFirstValue; i--) {
            String option = getElement("selectedProtectionType", pdpProduct, String.valueOf(i)).getText();
            logger.info("Option is: " + option + "and option from DB is: " + selectedProtectionType);
            if (option.contains(selectedProtectionType)) {
                assertStepExecution(true, option.equalsIgnoreCase(selectedProtectionType), "Option is matched");
                logger.info(option + "Option is present under the main product");
                break;
            }
        }

    }

    /*
     This Method is used to verify Super saving section is present below pricing on pdp
     */
    @And("user verifies {string} section is present below pricing")
    public void userVerifiesSectionIsPresentBelowPricing(String superSavingTitle) throws InterruptedException {
        windowScrollIntoBottom();
        Thread.sleep(4000);
        windowScrollToTop();
        Thread.sleep(4000);
        if (getOptionalElement("pdpProductPrice") != null) {
            assertThat(getOptionalElement("superSavingsSectionText", superSavingTitle)).isNotNull().describedAs("user verifies super savings section is present below Pricing");
        }
    }

    /*
     This Method is used to verify Super saving section is present above delivery section on pdp
     */
    @And("user verifies super savings section is present above delivery {string} section on pdp")
    public void userVerifiesSuperSavingsSectionIsPresentAboveDeliverySectionOnPdp(String deliveryAtMessage) {
        if (getOptionalElement("superSavingsSectionText") != null) {
            logger.info("Super savings section text is present : " + getElement("superSavingsSectionText").getText());
            assertThat(getOptionalElement("deliveryAtMessage", deliveryAtMessage)).isNotNull().describedAs("user verifies super savings section is present above delivery section on pdp");
        }
    }

    @And("user stores all offers from super savings section on pdp")
    public void userStoresAllOffersFromSuperSavingsSectionOnPdp() throws InterruptedException {
        //List<WebElement> element = getElements("superSavingOfferPdpCarouse");
        windowScrollIntoBottom();
        Thread.sleep(4000);
        windowScrollToTop();
        Thread.sleep(4000);
        List<WebElement> element = getElements("superSavingCarouselViewMoreList");
        logger.info("Total size of super Saving Offer Pdp Carouse elements are:" + element.size());
        for (int i = pDPPageScrollDownFirstIndex; i < element.size(); i++) {
            //  getElement("superSavingCarouselViewMore",String.valueOf(i+1)).click();
            jsClick(getElement("superSavingCarouselViewMore", String.valueOf(i + 1)));
            Thread.sleep(3000);
            // getElement("close").click();
            jsClick(getElement("close"));
            if (getOptionalElement("superSavingNextArrow") != null) {
                //  getElement("superSavingNextArrow").click();
                jsClick(getElement("superSavingNextArrow"));
                Thread.sleep(5000);
            }
        }
    }


    @Then("user validates image should loop back to the first image")
    public void userValidatesImageShouldLoopBackToTheFirstImage() {
        assertStepExecution(true, getOptionalElement("productDuplicateImage").isDisplayed(), "Duplicate first image present");
    }

    @Then("user validates product price {string} should displayed in product definition page")
    public void userValidatesProductPriceShouldDisplayedInProductDefinationPage(String pdpProductPrice) {
        logger.info("The product price on pdp is" + getElement("productPriceOnPdp").getText());
        assertStepExecution(true, getElement("productPriceOnPdp").getText().equalsIgnoreCase(pdpProductPrice),
                "user verify product price should displayed");
    }

    @And("user validates the message {string} on modal popup")
    public void userValidatesTheMessageOnModalPop(String msg) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("textOnModalPopup")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String message = getElement("textOnModalPopup").getText().trim();
        assertStepExecution(msg, message, "user validates the message " + msg + " on modal pop");
    }

    @And("user validates wishlist icon is visible in the {string} on product definition page")
    public void userValidatesWishlistIconIsVisibleInTheOnProductDefinitionPage(String pdpProduct) {
        assertStepExecution(true, getElement("pdpProductWishlistIcon", pdpProduct).isDisplayed(), "user validates wishlist icon is visible in product listing page");
    }

    @And("user slides the product images")
    public void userSlidesTheProductImages() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        List<WebElement> slideImageBullet = getElements("slideImageBullet");
        logger.info("No of Images are: " + slideImageBullet.size());

        for (int i = 0; i < slideImageBullet.size() - 1; i++) {
            processScreenshot();
            WebElement el = getElement("slideImage", String.valueOf(i), String.valueOf(1));
            boolean b = el.getAttribute("class").contains("swiper-slide-active");
            assertStepExecution(true, b, "user slides the product images");
            Actions act = new Actions(getDriver());
            act.moveToElement(el).clickAndHold().moveByOffset(-180, 0).release().perform();
        }
        for (int i = slideImageBullet.size() - 1; i >= 0; i--) {
            processScreenshot();
            Thread.sleep(4000);
            WebElement el = getDriver().findElement(By.xpath(getLocator("slideImage", String.valueOf(i), (i == slideImageBullet.size() - 1) ? String.valueOf(2) : String.valueOf(1))));
            boolean b = el.getAttribute("class").contains("swiper-slide-active");
            assertStepExecution(true, b, "user slides the product images");
            Actions act = new Actions(getDriver());
            act.moveToElement(el).clickAndHold().moveByOffset(180, 0).release().perform();
        }
    }

    @And("user clicks on add to cart button of add-on product from mini cart dialog box")
    public void userClicksOnAddToCartButtonOfAddOnProductFromMiniCartDialogBox() throws InterruptedException {
        assertStepExecution(true, getElement("addToCartButtonOfAddOnProductMiniCart") != null, "Add to Cart button of Add-on product is not present in Mini cart Dialog box");
        getElement("addToCartButtonOfAddOnProductMiniCart").click();
        Thread.sleep(3000);
    }


    @Then("user validates product is present in product definition page")
    public void userValidatesProductIsPresentInProductDefinitionPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("Landed on PDP");
        String productOnPdp = getElement("pdpProductTitle").getText().trim();
        logger.info("The product on pdp is" + productOnPdp + "Saved data" + getContext("firstProductNameOfTheSection"));
    }

    @And("user clicks on choose product for exchange button in pdp")
    public void userClicksOnChoosePhoneForExchangeButtonInPdp() throws InterruptedException {
        Thread.sleep(5000);
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        scrollToWebelement(getOptionalElement("choosePhoneForExchangeBtn"));
        Thread.sleep(5000);
        conditionalWait(ExpectedConditions.elementToBeClickable(getOptionalElement("choosePhoneForExchangeBtn")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getOptionalElement("choosePhoneForExchangeBtn") != null,
                "user clicks on choose phone for exchange button in pdp");
        getElement("choosePhoneForExchangeBtn").click();
    }

    @And("user selects {string} from the dropdown for exchange product")
    public void userSelectsFromTheDropdownForExchangeProduct(String brandName) {
        windowScrollIntoViewByWebElementTrue(getElement("DropdownValueForExchangeProduct", brandName));
        conditionalWait(ExpectedConditions.visibilityOf(getElement("DropdownValueForExchangeProduct", brandName)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getElement("DropdownValueForExchangeProduct", brandName) != null,
                "user selects " + brandName + " from the dropdown for exchange product");
        getElement("DropdownValueForExchangeProduct", brandName).click();
    }

    @And("user verifies product condition for exchange product")
    public void userVerifiesPhoneConditionForExchangeProduct() throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("phoneConditionPopUp")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        List<WebElement> elemList = getElements("phoneConditionYesBtnList");
        assertStepExecution(true, elemList.size() > 0, "user verifies phone condition for exchange product");
        for (WebElement elem : elemList) {
            windowScrollIntoViewByWebElementTrue(elem);
            elem.click();
            Thread.sleep(2000);
        }
    }

    @And("user validates the exchange icon and {string} text and green tick and remove link in exchange area in pdp")
    public void userValidatesTheExchangeIconAndTextAndGreenTickAndRemoveLinkInExchangeAreaInPdp(String exchangeOfferApplied) {
        String stepDesp = "user validates the exchange icon and " + exchangeOfferApplied + " text and green tick and remove link in exchange area in pdp";
        scrollToWebelement(getElement("exchangeIcon"));
        assertStepExecution(true, getElement("exchangeIcon") != null, stepDesp);
        assertStepExecution(exchangeOfferApplied, getElement("exchangeOfferTitle").getText().trim(), stepDesp);
        assertStepExecution(true, getElement("exchangeGreenTick") != null, stepDesp);
        assertStepExecution("Remove", getElement("exchangeRemoveButton").getText().trim(), stepDesp);
    }


    @And("user validates the exchange product section is highlighted in {string}")
    public void userValidatesTheExchangeProductSectionIsHighlightedIn(String colorCode) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String el = getElement("exchangeProductSection").getCssValue("border").replace("2px solid ", "");
        String hexcolor = Color.fromString(el).asHex();
        assertStepExecution(colorCode, hexcolor.trim(), "user validates the exchange product section is highlighted in " + colorCode + "");
    }

    @And("user validates the exchange value text as {string} and {string}")
    public void userValidatesTheExchangeValueTextAsAnd(String exText, String exValue) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescp = "user validates the exchange value text as " + exText + " and " + exValue + "";
        String exchangeText = getElement("exchangeValueText").getText().trim();
        String exchangeValue = getElement("exchangeAmount").getText().trim();
        assertStepExecution(exText, exchangeText, stepDescp);
        assertStepExecution(exValue, exchangeValue, stepDescp);
    }

    @And("user validates the exchange product as {string} and {string} link and note as {string} in exchange area in pdp")
    public void userValidatesTheExchangeProductAsAndLinkAndNoteAsInExchangeAreaInPdp(String exProduct, String changeLink, String note) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescp = "user validates the exchange product as " + exProduct + " and " + changeLink + " link and note as " + note + " in exchange area in pdp";
        String exchangeProduct = getElement("exchangeProductTitle").getText().trim();
        String exChangLink = getElement("exchangeProductChangeLink").getText().trim();
        String exNote = getElement("exchangeNote").getText().trim();
        assertStepExecution(exProduct, exchangeProduct, stepDescp);
        assertStepExecution(changeLink, exChangLink, stepDescp);
        assertStepExecution(note, exNote, stepDescp);
    }

    @And("user validates the {string} button is present in exchange area in pdp")
    public void userValidatesTheButtonIsPresentInExchangeAreaInPdp(String buyWithExchange) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescp = "user validates the " + buyWithExchange + " button is present in exchange area in pdp";
        assertStepExecution(true, getElement("buyWithExchangeButton", buyWithExchange).isDisplayed(),
                stepDescp);
    }

    @And("user validates the {string} button is absent")
    public void userValidatesTheButtonIsAbsent(String buyWithExchange) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescp = "user validates the " + buyWithExchange + " button is absent";
        assertStepExecution(true, !getOptionalElement("buyWithExchangeButton", buyWithExchange).isDisplayed(),
                stepDescp);
    }

    @And("user validates the {string} button is present beside exchange offer applied in pdp")
    public void userValidatesTheButtonIsPresentBesideExchangeOfferAppliedInPdp(String removeButton) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescp = "user validates the " + removeButton + " button is present beside exchange offer applied in pdp";
        assertStepExecution(true, getElement("buyWithExchangeRemoveButton", removeButton).isDisplayed(),
                stepDescp);
        getElement("buyWithExchangeRemoveButton", removeButton).click();
    }

    @And("user validates the {string} button is removed with exchange area in pdp")
    public void userValidatesTheButtonIsRemovedWithExchangeAreaInPdp(String removeButton) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescp = "user validates the " + removeButton + " button is removed";
        assertStepExecution(true, !getOptionalElement("buyWithExchangeButton", removeButton).isDisplayed(),
                stepDescp);
        assertStepExecution(true, !getOptionalElement("exchangeProductSection").isDisplayed(),
                "user validates the Exchange details section is removed");

    }

    @And("user clicks on without exchange radio button in pdp")
    public void userClicksOnWithoutExchangeRadioButtonInPdp() {
        assertStepExecution(true, getOptionalElement("withoutExchangeRadioBtn") != null,
                "user clicks on without exchange radio button in pdp");
        getElement("withoutExchangeRadioBtn").click();
    }

    @And("user validates the {string} link is absent in PDP")
    public void userValidatesTheLinkIsAbsentInPDP(String changeLink) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        WebElement el = getElement("exchangeProductChangeLink");
        assertStepExecution(true, !el.isDisplayed(), "user validates the " + changeLink + " link is absent in PDP");

    }


    @And("user validates {string} and {string} text of add on product in mini cart dialog box")
    public void userValidatesAndTextOfAddOnProductInMiniCartDialogBox(String productTitle, String text) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescp = "user validates " + productTitle + " and " + text + " text of add on product in mini cart dialog box";
        assertThat(productTitle).describedAs(stepDescp).isEqualToIgnoringCase(getElement("addOnProductTitleInMiniCart").getText().trim());
        assertThat(text).describedAs(stepDescp).isEqualToIgnoringCase(getElement("addOnProductTextInMiniCart").getText().trim());
    }
}


