package com.croma.automationqa.util;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.PropertiesConfigurationLayout;

import java.util.HashMap;
import java.util.Set;

import static com.croma.automationqa.util.FrameworkUtil.logger;


/**
 * <h3> Purpose:  <p> <h4> &#10687; This class includes all the methods to <b>Read</b> from and <b>Write</b> into <b>.properties</b> files.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 25/04/2020
 */

public class ConfigUtil {

    /**
     * This method <b>Read</b> from <b>.properties</b> files.
     *
     * @param <b>file</b> Path to the .properties file including the file name.
     * @param <b>key</b>  Key of the expected value in the .properties file.
     * @return Property value corresponding to the provided key.
     */

    public static String configReader(String file, String key) {

        String val = "";

        try {
            // "./src/main/config/config.properties"
            PropertiesConfiguration config = new PropertiesConfiguration(file);

            val = (String) config.getProperty(key);

            logger.info("Output from ConfigReader ::  " + key + " == " + val);

            //return prop.getProperty(key);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return val;

    }


    /**
     * This method <b>Write</b> into <b>.properties</b> files.
     *
     * @param <b>filePath</b> Path to the .properties file including the file name.
     * @param <b>key</b>      Key of the property that is to be added in the .properties file.
     * @param <b>value</b>    Value of the property that is to be added in the .properties file.
     */
    public static void configWriter(String filePath, String key, String value) {

        try {

            PropertiesConfiguration config = new PropertiesConfiguration(filePath);

            config.setProperty(key, value);

            config.save();

            logger.info("Output from ConfigWriter ::  " + key + " == " + configReader(filePath, key));

        } catch (Exception ex) {
            ex.printStackTrace();
        }


    }


    /**
     * This method iterate through the provided <b>.properties</b> file and return all the properties in a <b>HashMap</b>.
     *
     * @param <b>fileName</b> Path to the .properties file including the file name.
     * @return All the properties in a <b>Key:Value</b> pair in <b>HashMap<String, String></b> format
     */
    public static HashMap<String, String> configIterator(String fileName) {

        HashMap<String, String> propMap = new HashMap<>();
        try {
            PropertiesConfiguration config = new PropertiesConfiguration(fileName);
            PropertiesConfigurationLayout layout = config.getLayout();

            Set<String> keys = layout.getKeys();
            for (String k : keys) {
                String value = layout.getConfiguration().getProperty(k).toString();
                if (value.endsWith("]") && value.startsWith("[")) {
                    value = value.substring(1, value.length() - 1);
                }
                //String value = configReader(fileName,k);
                logger.info("KEY: " + k + "  ;;  VALUE: " + value);
                propMap.put(k, value);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        logger.info("Property file read for : " + fileName);
        return propMap;
    }

}