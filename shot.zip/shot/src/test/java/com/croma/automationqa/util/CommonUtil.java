package com.croma.automationqa.util;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getLocator;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.logger;

/**
 * <h3> Purpose:  <p> <h4> &#10687;  This class is used to save generic methods (e.g. String Price to Integer value) which don't involve any activity on application elements.
 * <br> &#10687; As this class don't use any application element, locator file won't be required to support its activities.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 8/12/2020
 */
public class CommonUtil {

    public static int totalRadioBtnCart = 0;
    public static int totalProductCart = 0;

    private static final Actions action = new Actions(getDriver());
    private static final int indexOne = 1, indexZero = 0;


    public static void scrollTop() {
        action.sendKeys(Keys.HOME).build().perform();
    }

    public static void clearTextBox(WebElement webElement) {
        webElement.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        webElement.sendKeys(Keys.DELETE);
    }

    public static void clearTextBoxBackSpace(WebElement webElement) {
        webElement.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        webElement.sendKeys(Keys.BACK_SPACE);
    }

    public static void actionMoveToElementBuild(WebElement webElement) {
        new Actions(getDriver()).moveToElement(webElement).build().perform();
    }

    public static void actionMoveToElementClick(WebElement webElement) {
        new Actions(getDriver()).moveToElement(webElement).click().build().perform();
    }

    public static void actionSendKeyPageDownBuild() {
        new Actions(getDriver()).sendKeys(Keys.PAGE_DOWN).build().perform();
    }

    public static void iframeVideoFullAndMiniScreen() {
        new Actions(getDriver()).sendKeys("F").build().perform();
    }

    public static void iframeVideoPlayAndPause() {
        new Actions(getDriver()).sendKeys("K").build().perform();
    }


    public static String splitTextWithIndexing(String text, String splitOption, int arg) {
        return text.split(splitOption)[arg];
    }

    public static int numericValuesExtractionMethod(String text) {
        return Integer.parseInt(text.replaceAll("[^0-9]", ""));
    }

    public static String removeLinesBreaksMethod(String text, String splitOption) {
        return text.replace(splitOption, " ");
    }

    public static String subStringTextWithIndexing(String text, int firstIndex, int lastIndex) {
        return text.substring(firstIndex, lastIndex);
    }


    public static BufferedWriter fileWrite(String fileNameToBeUsed) throws IOException {
        File file = new File(fileNameToBeUsed);
        FileWriter fW = new FileWriter(file.getAbsoluteFile(), true);
        BufferedWriter bW = new BufferedWriter(fW);
        if (file.createNewFile()) {
            logger.info("File created: " + file.getName());
        } else {
            logger.info("File already exists " + file.getName());
        }
        return bW;
    }


    /**
     * This method generate a random alphabetic string of provided length
     *
     * @param <b>targetStringLength</b> desired length of the random string
     * @return random string
     */
    public static String randomAlphabeticString(int targetStringLength) {
        int leftLimit = 97; // letter 'a'
        int rightLimit = 122; // letter 'z'

        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        System.out.println("generated random String : " + generatedString);

        return generatedString;
    }

    /**
     * This method generate a random number of provided length
     *
     * @param <b>targetLength</b> desired length of the integer
     * @return random string
     */
    public static int randomNumber(int targetLength) {
        Random rand = new Random();
        int randNo = 1;

        while (targetLength > 0) {
            int rand_int1 = rand.nextInt(9 - 1 + 1) + 1;
            randNo = randNo * 10 + rand_int1;
            targetLength = targetLength - 1;
        }

        randNo = randNo / 10;
/*        String randStr = String.valueOf(randNo);
        randStr = randStr.substring(0,randStr.length()-1);*/

        System.out.println("generated random No : " + randNo);
        return randNo;
    }


    /*
        user moves to new window
    */
    public static void userMovesToNewWindow() {
        //    waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
        // getDriver().switchTo().window(getDriver().getWindowHandles().toArray()[1].toString());

        getDriver().switchTo().window(getDriver().getWindowHandles().toArray()[getDriver().getWindowHandles().toArray().length - 1].toString());

    }

    public static void windowScrollIntoViewLazyLoad(String... elemInfo) {
        int xAxis = 0, yAxis = 50;
        for (int j = 0; j < 10; j++) {
            ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(" + xAxis + ",-" + yAxis + ")");

            if (getOptionalElement(elemInfo) != null) {
                break;
            }
        }
    }


    /*
        user moves to new window
    */
    public static void userMovesToNewWindow_OLD() {

        Set<String> ids = getDriver().getWindowHandles();
        Iterator<String> it = ids.iterator();
        String parentid = it.next();
        String childid = it.next();
        getDriver().switchTo().window(childid);
    }


    /*
        user closes the current window and moves to old window
    */
    public static void userClosesTheCurrentWindowAndMovesToOldWindow() {

        getDriver().close();

        getDriver().switchTo().window(getDriver().getWindowHandles().toArray()[0].toString());
    }

    /*
    user closes the current window and moves to old window
*/
    public static void userClosesTheCurrentWindowAndMovesToOldWindow_OLD() {
        Set<String> ids = getDriver().getWindowHandles();
        Iterator<String> it = ids.iterator();
        String parentid = it.next();
        String childid = it.next();
        getDriver().close();
        getDriver().switchTo().window(parentid);
        //    waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
        //     getDriver().switchTo().window(getDriver().getWindowHandles().toArray()[1].toString());
        getDriver().switchTo().window(getDriver().getWindowHandles().toArray()[getDriver().getWindowHandles().toArray().length - 1].toString());
    }

    public static void pressDownArrow(WebElement webElement) {
        webElement.sendKeys(Keys.ARROW_DOWN);
    }

    public static void pressUpArrow(WebElement webElement) {
        webElement.sendKeys(Keys.ARROW_UP);
    }

    /**
     * This Method is to refresh the page based on the no of time provided.
     *
     * @param noOfTimes No of time page to be refreshed.
     */
    public static void pageRefresh(int noOfTimes) {
        if (noOfTimes > 0) {
            for (int timer = 1; timer <= noOfTimes; timer++) {
                getDriver().navigate().refresh();
            }
        }
    }

    public static String getDiscountedPrice(String actualPrice, String discount) {
        String result = discount;
        discount = discount.replace("%", "");
        discount = discount.replace("₹", "");
        actualPrice = actualPrice.replaceAll("₹", "");
        actualPrice = actualPrice.replaceAll(",", "");
        if (result.endsWith("%")) {
            result = String.format("%.2f", (Double.parseDouble(actualPrice) * Double.parseDouble(discount)) / 100);
        }
        return result;
    }
    public static String getOnlyDigitsAndDot(String str) {
        return str.replaceAll("₹", "").replaceAll(",", "").trim();
    }

    public static WebElement getElementByXpath(String... elemInfo) throws InterruptedException {
        WebElement elem=null;
        Thread.sleep(2000);
        if(getDriver().findElements(By.xpath(getLocator(elemInfo))).size()>0){
            elem = getDriver().findElement(By.xpath(getLocator(elemInfo)));
        }
        return elem;
    }
    public static void selectFromDown(WebElement selectElem, String option) {
        new Select(selectElem).selectByVisibleText(option);
    }
}


