package com.croma.automationqa.util;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryUtil implements IRetryAnalyzer {

    private ThreadLocal<Integer> count = ThreadLocal.withInitial(() -> 0);
    private static final int maxTry = 2;

    @Override
    public synchronized boolean retry(ITestResult iTestResult) {
        if (!iTestResult.isSuccess()) {                      //Check if test not succeeded
            if (count.get() < maxTry) {                            //Check if maxTry count is reached
                count.set(count.get() + 1);                                     //Increase the maxTry count by 1
                iTestResult.setStatus(ITestResult.SKIP);  //Mark test as failed
                return true;                                 //Tells TestNG to re-run the test
            } else {
                iTestResult.setStatus(ITestResult.FAILURE);  //If maxCount reached,test marked as failed
                count.set(0);
            }
        } else {
            iTestResult.setStatus(ITestResult.SUCCESS);      //If test passes, TestNG marks it as passed
        }
        return false;
    }

}
