package com.croma.automationqa.stepDefinitions;

import com.croma.automationqa.util.DriverUtil;
import com.croma.automationqa.util.JavaScriptUtil;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.text.DateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.userClicksOnMenuIconAndCloseIt;
import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.encodingProductListThroughWebElementList;
import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.userWaitsForPageLoaderToBeInvisible;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

//import static com.croma.automationqa.util.CommonUtil.windowScrollIntoViewAdjustment;
//import static com.croma.automationqa.util.CommonUtil.windowScrollIntoViewByWebElement;


/*
    All the checkout page related function defined in CromaCheckoutPageStepDef class
*/
public class CromaCheckoutPageStepDef {

    private final int checkOutPageScrollDownFirstIndex = 0, checkOutPageScrollDownLastIndex = 200;
    JavascriptExecutor js = (JavascriptExecutor) getDriver();

    /*
        User lands on checkout password page and provide password and click go
    */
    @And("^user lands on order summery page and verify order details$")
    public void userLandsOnOrderSummeryPageAndVerifyOrderDetails() {
        //    conditionalWait(ExpectedConditions.visibilityOf(getElement("productListCheckoutPage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String finalOrderProductNameDetails = encodingProductListThroughWebElementList(getElements("productListCheckoutPage"));
//       String finalOrderProductQuantityDetails = encodingProductListThroughWebElementList(getElements("productCountListCheckoutPage"));
//        String finalOrderProductPriceDetails = encodingProductListThroughWebElementList(getElements("productPriceListCheckoutPage"));
        String cartTotalPriceToOrder = getElement("checkoutOrderTotalPrice").getText();
        assertStepExecution(true, getElement("checkoutOrderTotalPrice").isDisplayed(), "Total price displayed");
//        logger.info("Final ordereded product name is: " + finalOrderProductNameDetails + " quantity details " + finalOrderProductQuantityDetails + " price details " + finalOrderProductPriceDetails + " total price in cart " + cartTotalPriceToOrder);
        logger.info("Final ordereded product name is: " + finalOrderProductNameDetails + " total price in cart " + cartTotalPriceToOrder);

        setContext("finalProductDetailsCount", String.valueOf((getElements("productListCheckoutPage")).size()));
        setContext("finalCartOrderedTotalPrice", cartTotalPriceToOrder);
        setContext("finalProductDetailsProductNamesDetails", finalOrderProductNameDetails);
//        setContext("finalProductDetailsProductQuantityDetails", finalOrderProductQuantityDetails);
//        setContext("finalProductDetailsProductPriceDetails", finalOrderProductPriceDetails);
        // For Debug
        logger.info("Final ordered product name fetch: " + getContext("finalProductDetailsCount") + " and Names " + getContext("finalProductDetailsProductNamesDetails") + " and quantity " + getContext("finalProductDetailsProductQuantityDetails"));
        if (getContext("storeDeliveryEnableFlag").equals("true")) {
            String finalOrderProductStoreDeliveryAddress = encodingProductListThroughWebElementList(getElements("productStoreDeliveryAddressListCheckoutPage"));
            String finalOrderProductStoreDeliveryExpectedDate = encodingProductListThroughWebElementList(getElements("productStoreDeliveryExpectedDateListCheckoutPage"));
            String finalOrderProductStoreDeliveryType = encodingProductListThroughWebElementList(getElements("productStoreDeliveryAddressTypeListCheckoutPage"));

            logger.info("Final ordereded product store delivery address is: " + finalOrderProductStoreDeliveryAddress + " " + finalOrderProductStoreDeliveryExpectedDate + " " + finalOrderProductStoreDeliveryType);
            setContext("finalProductDetailsProductStoreDeliveryAddress", finalOrderProductStoreDeliveryAddress);
            setContext("finalProductDetailsProductStoreDeliveryExpected", finalOrderProductStoreDeliveryExpectedDate);
            setContext("finalProductDetailsProductStoreDeliveryType", finalOrderProductStoreDeliveryType);
        }
    }


    /*
        User clicks on change address in checkout order summery page
    */
    @And("^user clicks on change address in checkout order summery page$")
    public void userClicksOnChangeAddressInCheckoutOrderSummeryPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("shippingChooseAddressLink")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("shippingChooseAddressLink").isDisplayed(), "Shipping choose address link displayed");
        getElement("shippingChooseAddressLink").click();
    }


    /*
       user unchecks the same billing address option in checkout order summery page
    */
    @And("^user unchecks the same billing address option in checkout order summery page$")
    public void userUnchecksTheSameBillingAddressOptionInCheckoutOrderSummeryPage() throws InterruptedException {
        Thread.sleep(2000);
    /*    windowScrollIntoViewByWebElement(getElement("checkBoxForSameBillingAsShippingLast"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("checkBoxForSameBillingAsShippingLast")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("checkBoxForSameBillingAsShippingLast").isDisplayed(), "Check box for same billing as shipping address displayed");
        // getElement("checkBoxForSameBillingAsShippingLast").click();*/
        jsClick(getElement("checkBoxForSameBillingAsShippingLast"));
        assertStepExecution(true, getOptionalElement("createAndUseAnotherBillingAddr") != null, "Button to create another billing address displayed");
        getElement("createAndUseAnotherBillingAddr").click();
    }


    /*
        user provides address details on checkout order summery page
    */
    @And("^user provides address details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" on checkout order summery page$")
    public void userProvidesAddressDetailsOnCheckoutOrderSummeryPage(String delivery_Address_First_Name, String delivery_Address_Last_Name, String delivery_Address_Type, String delivery_Address_Full_Address, String delivery_Address_Landmark, String delivery_Address_State, String delivery_Address_City, String delivery_Address_Pin_Code) {

        String flag = "false";
        logger.info("Delivery Address Details - First Name: " + delivery_Address_First_Name + " Last Name: " + delivery_Address_Last_Name + " Type: " + delivery_Address_Type + " Full Address: " + delivery_Address_Full_Address + " Landmark: " + delivery_Address_Landmark + " State: " + delivery_Address_State + " City: " + delivery_Address_City + "Pincode: " + delivery_Address_Pin_Code);
        clearTextBox(getElement("deliveryAddressFullNameInput"));
        getElement("deliveryAddressFullNameInput").sendKeys(delivery_Address_First_Name.concat(" ").concat(delivery_Address_Last_Name));
        switch (delivery_Address_Type) {
            case "Home":
                getElement("deliveryTypeHome").click();
                break;
            case "Work":
                getElement("deliveryTypeWork").click();
                break;
            case "Others":
                getElement("deliveryTypeOthers").click();
                break;
        }
        setContext("finalAddressTypeCheckoutPage", delivery_Address_Type);
        windowScrollIntoViewByWebElement(getElement("deliveryAddressFullAddressInput"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        clearTextBox(getElement("deliveryAddressFullAddressInput"));
        getElement("deliveryAddressFullAddressInput").sendKeys(delivery_Address_Full_Address);
        clearTextBox(getElement("deliveryAddressLandMarkInput"));
        getElement("deliveryAddressLandMarkInput").sendKeys(delivery_Address_Landmark);
        clearTextBox(getElement("deliveryAddressStateInput"));
        getElement("deliveryAddressStateInput").sendKeys(delivery_Address_State);
        getElement("deliveryAddressStateDropDown", delivery_Address_State).click();
        clearTextBox(getElement("deliveryAddressCityInput"));
        getElement("deliveryAddressCityInput").sendKeys(delivery_Address_City);
        getElement("deliveryAddressCityDropDown", delivery_Address_City).click();
        clearTextBox(getElement("deliveryAddressPinCodeInput"));
        getElement("deliveryAddressPinCodeInput").sendKeys(delivery_Address_Pin_Code);
        assertStepExecution(true, getElement("deliveryAddressPinCodeInput").isDisplayed(), "Delivery address pincode displayed");
        setContext("finalAddressFullNameCheckoutPage", delivery_Address_First_Name.concat(" ").concat(delivery_Address_Last_Name));
        setContext("finalAddressFullAddressDetailsCheckoutPage", delivery_Address_Full_Address.concat(", ").concat(delivery_Address_Landmark).concat(", ").concat(delivery_Address_City).concat(", ").concat(delivery_Address_State).concat(" - ").concat(delivery_Address_Pin_Code));
        setContext("storeDeliveryEnableFlag", flag);
    }


    /*
       user provides billing address details in checkout order summery page
    */
    @And("^user provides billing address details in checkout order summery page \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
    public void userProvidesBillingAddressDetailsInCheckoutOrderSummeryPage(String billing_Address_First_Name, String billing_Address_Last_Name, String billing_Address_Full_Address, String billing_Address_Landmark, String billing_Address_State, String billing_Address_City, String billing_Address_Pincode) {
        windowScrollIntoViewByWebElement(getElement("billingAddressFirstNameInput"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        logger.info("Billing Address Details - First Name: " + billing_Address_First_Name + " Last Name: " + billing_Address_Last_Name + " Full Address: " + billing_Address_Full_Address + " Landmark: " + billing_Address_Landmark + " State: " + billing_Address_State + " City: " + billing_Address_City + " Pincode: " + billing_Address_Pincode);
        clearTextBox(getElement("billingAddressFirstNameInput"));
        getElement("billingAddressFirstNameInput").sendKeys(billing_Address_First_Name.concat(" ").concat(billing_Address_Last_Name));
        clearTextBox(getElement("billingAddressFullAddressInput"));
        getElement("billingAddressFullAddressInput").sendKeys(billing_Address_Full_Address);
        clearTextBox(getElement("billingAddressLandMarkInput"));
        getElement("billingAddressLandMarkInput").sendKeys(billing_Address_Landmark);
        clearTextBox(getElement("billingAddressStateInput"));
        getElement("billingAddressStateInput").sendKeys(billing_Address_State);
        getElement("billingAddressStateDropDown", billing_Address_State).click();
        clearTextBox(getElement("billingAddressCityInput"));
        getElement("billingAddressCityInput").sendKeys(billing_Address_City);
        getElement("billingAddressCityDropDown", billing_Address_City).click();
        assertStepExecution(true, getElement("billingAddressPinCodeInput").isDisplayed(), "Billing address pincode displayed");
        clearTextBox(getElement("billingAddressPinCodeInput"));
        getElement("billingAddressPinCodeInput").sendKeys(billing_Address_Pincode);
    }


    /*
       User clicks on edit contact information in checkout order summery page and provide contact information
    */
    @And("^user clicks on edit contact information in checkout order summery page and provide \"([^\"]*)\", \"([^\"]*)\" contact information$")
    public void userClicksOnEditContactInformationInCheckoutOrderSummeryPageAndProvideContactInformation(String contact_Info_Email, String contact_Info_Ph) {
        windowScrollIntoViewByWebElement(getElement("contactInfoEditLink"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("contactInfoEditLink")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        //getElement("contactInfoEditLink").click();
        jsClick(getElement("contactInfoEditLink"));
        //getElement("contactInfoEditEmailId").clear();
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].value ='';", getElement("contactInfoEditEmailId"));
        getElement("contactInfoEditEmailId").sendKeys(contact_Info_Email);
        assertStepExecution(true, getOptionalElement("contactInfoEditPh") != null, "Contact info edit displayed");
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].value ='';", getElement("contactInfoEditPh"));
        getElement("contactInfoEditPh").sendKeys(contact_Info_Ph);
        setContext("finalAddressPhoneNumberDetailsCheckoutPage", contact_Info_Ph);


    }


    /*
       user clicks on payment button in checkout order summery page
    */
    @And("^user clicks on payment button in checkout order summery page$")
    public void userClicksOnPaymentButtonInCheckoutOrderSummeryPage() throws InterruptedException {
        setContext("url_Currentpage", getDriver().getCurrentUrl());
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("paymentButton")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getOptionalElement("paymentButton") != null, "Payment button displayed");
        windowScrollIntoViewByWebElement(getElement("paymentButton"));
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(3000);
        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME"))
            getElement("paymentButton").click();
        else
            getElement("mobPaymentButton").click();
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        setContext("url_Currentpage", getDriver().getCurrentUrl());
        Thread.sleep(5000);
        if (getOptionalElement("offerPopupSkipOnPayment") != null) {
            getElement("offerPopupSkipOnPayment").click();
        }
    }


    /*
        User unchecks same billing and shipping address checkbox
    */
    @And("^user unchecks the same billing address option in checkout order summery page while using existing shipping address$")
    public void userUnchecksTheSameBillingAddressOptionInCheckoutOrderSummeryPageWhileUsingExistingShippingAddress() {
        windowScrollIntoViewByWebElement(getElement("latestAddedAddressToSelectAsShippingAddress"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("latestAddedAddressToSelectAsShippingAddress")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("latestAddedAddressToSelectAsShippingAddress").isDisplayed(), "Latest added address to select as shipping address displayed");
        getElement("latestAddedAddressToSelectAsShippingAddress").click();
        getElement("billingAddressEditButton").click();
    }


    /*
      User selects latest added address
    */
    @And("^user selects the latest added address in checkout order summery page$")
    public void userSelectsTheLatestAddedAddressInCheckoutOrderSummeryPage() {
        String flag = "false";
        windowScrollIntoViewByWebElement(getElement("latestAddedAddressToSelectAsShippingAddress"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("latestAddedAddressToSelectAsShippingAddress")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        setContext("storeDeliveryEnableFlag", flag);
        assertStepExecution(true, getElement("latestAddressFromAddressBookWithNickName", getContext("finalAddressNickNameAddressPage")).isDisplayed(), "Latest added address nickname as shipping address displayed");
        getElement("latestAddressFromAddressBookWithNickName", getContext("finalAddressNickNameAddressPage")).click();
    }


    /*
        User unchecks same billing and shipping address checkbox without providing delivery address
    */
    @And("^user unchecks the same billing address option in checkout order summery page without providing delivery address$")
    public void userUnchecksTheSameBillingAddressOptionInCheckoutOrderSummeryPageWithoutProvidingDeliveryAddress() {
        windowScrollIntoViewByWebElement(getElement("checkBoxForSameBillingAsShippingLast"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("checkBoxForSameBillingAsShippingLast")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("checkBoxForSameBillingAsShippingLast").isDisplayed(), "Checkbox for same shipping address displayed");
        getElement("checkBoxForSameBillingAsShippingLast").click();
    }

    /*
        User selects the added address in checkout order summery page
    */
    @And("^user selects the added address \"([^\"]*)\" in checkout order summery page$")
    public void userSelectsTheAddedAddressInCheckoutOrderSummeryPage(String addressName) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("selectSavedAddress", addressName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("selectSavedAddress", addressName).isDisplayed(), "Select saved address displayed in checkout order summary page");
        //  getElement("selectSavedAddress", addressName).click();
        actionMoveToElementClick(getElement("selectSavedAddress", addressName));
    }

    /*
        User clicks on shipping change address link in order summary page
    */


    @And("^user clicks on shipping change address link in order summary page$")
    public void userClicksOnShippingChangeAddressLinkInOrderSummaryPage() throws InterruptedException {
        userWaitsForPageLoaderToBeInvisible();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("shippingChangeAddressLink")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("shippingChangeAddressLink").isDisplayed(), "Shipping change address link displayed in checkout order summary page");
        getElement("shippingChangeAddressLink").click();
    }

    /*
        User clicks on edit button in shipping information section
    */


    @And("^user clicks on edit button in shipping information$")
    public void userClicksOnEditButtonInShippingInformation() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("shippingEditButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("shippingEditButton").isDisplayed(), "Shipping edit button displayed in checkout order summary page");
        getElement("shippingEditButton").click();
    }

     /*
        User clicks on save address button in order summary page
     */

    @And("^user clicks on save address button in order summary page$")
    public void userClicksOnSaveAddressButtonInOrderSummaryPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("saveAddressButtonShippingAddress")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("saveAddressButtonShippingAddress").isDisplayed(), "Saved address button displayed in checkout order summary page");
        getElement("saveAddressButtonShippingAddress").click();
        //   getElement("addCloseBtn").click();
    }

    /*
        User checks the saved default address auto selected in checkout page
     */
    @And("^user checks the saved default address auto selected in checkout page$")
    public void userChecksTheSavedDefaultAddressAutoSelectedInCheckoutPage() {
        logger.info("Default address data from address page : " + getContext("finalAddressFullAddressPage") + " and NickName is : " + getContext("finalAddressNickNameAddressPage"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("defaultAddressTitle")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        logger.info("Saved default address Title: " + getElement("defaultAddressTitle").getText() + "and addressDetails" + " " + getElement("defaultAddressDetails").getText());
        assertThat(getElement("defaultAddressTitle").getText()).describedAs("Address nick name is not matching").isEqualToIgnoringCase(getContext("finalAddressNickNameAddressPage"));
        assertThat(getElement("defaultAddressDetails").getText()).describedAs("Address details is not matching").isEqualToIgnoringCase(getContext("finalAddressFullAddressPage"));
        passStepExecution("User checks the saved default address auto selected in checkout page");
    }

    /*
            User clicks on saved address edit icon in checkout order summery page
    */
    @And("^user clicks on saved address \"([^\"]*)\" edit icon in checkout order summery page$")
    public void userClicksOnSavedAddressEditIconInCheckoutOrderSummeryPage(String addressTypeName) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("editAddressIcon", addressTypeName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("editAddressIcon", addressTypeName).isDisplayed(), "Edit address icon displayed in checkout order summary page");
        getElement("editAddressIcon", addressTypeName).click();
    }

    /*
       User checks the edit address updated in checkout order summery page
    */
    @And("^user checks the edit address updated in checkout order summery page$")
    public void userChecksTheEditAddressUpdatedInCheckoutOrderSummeryPage() {
        String editAddressUpdateMsg = "Address updated";
        logger.info("Address updated message: " + getElement("editAddressUpdateMassage").getText());
        assertStepExecution(editAddressUpdateMsg, getElement("editAddressUpdateMassage").getText(),
                "Displayed update address message");
    }

    /*
      User clicks on add address in checkout order summary page
   */
    @And("^user clicks on add address in checkout order summary page$")
    public void userClicksOnAddAddressInCheckoutOrderSummaryPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addAddressButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("addAddressButton").isDisplayed(), "Add address button displayed in checkout order summary page");
        getElement("addAddressButton").click();
    }


    @And("user creates and uses another address in checkout order summary page")
    public void userCreatesAndUsesAnotherAddressInCheckoutOrderSummaryPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addAddressButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getOptionalElement("addAddressButton") != null, "Add address button displayed in checkout order summary page");
        getElement("addAddressButton").click();
    }

    /*
      User validates as discounted amount in checkout page
   */
    @Then("^user validates \"([^\"]*)\" as discounted amount in checkout page$")
    public void userValidatesAsDiscountedAmountInCheckoutPage(String todaysSavingAmount) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("todaysSavingDiscountText")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        if (!todaysSavingAmount.equalsIgnoreCase("NA")) {
            logger.info("Todays Savings amount from getText: " + getElement("todaysSavingDiscountText").getText() + " From arg " + todaysSavingAmount);
            assertThat(getElement("todaysSavingDiscountText").getText()).describedAs("Todays Savings amount is not matching").isEqualTo(todaysSavingAmount);
        } else {
            assertThat(getElement("todaysSavingDiscountText").getText()).describedAs("Todays Savings amount section should not display").isEqualTo(null);
        }
        passStepExecution("User validates discounted amount in checkout page");
    }

    @And("^user verify the offer applied \"([^\"]*)\" in order summary page$")
    public void userVerifyTheOfferAppliedInOrderSummaryPage(String appliedOffer) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("appliedOfferStatement")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(appliedOffer, getElement("appliedOfferStatement").getText(), "Applied offer is matched");
    }


    @Then("^user verify the item total price \"([^\"]*)\", total savings \"([^\"]*)\" and total price \"([^\"]*)\" of the item after offer applied$")
    public void userVerifyTheItemTotalPriceTotalSavingsAndTotalPriceOfTheItemAfterOfferApplied(String itemTotalPrice1, String totalSavings1, String totalPriceDeductingOffer1) throws InterruptedException {
        logger.info("Total price in examples is : " + itemTotalPrice1);
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        //conditionalWait(ExpectedConditions.visibilityOf(getElement("itemTotalPrice")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //Thread.sleep(10000);
        logger.info("Total Item Price from get text=" + getElement("itemTotalPrice").getText());

        assertThat((getElement("itemTotalPrice").getText())).describedAs("Total item price matched").
                isEqualTo(itemTotalPrice1);

        assertThat((getElement("totalSavings").getText())).describedAs("Total savings matched").
                isEqualTo(totalSavings1);

        assertThat(getElement("totalPriceDeductingOffer").getText()).describedAs("Total price after applying offer is matched").
                isEqualTo(totalPriceDeductingOffer1);

        passStepExecution("Order Summary page displays correct results");
    }

    @And("^user clicks on product title \"([^\"]*)\" from order summary page$")
    public void userClicksOnProductTitleFromOrderSummaryPage(String productTitleOrderSummary1) {

        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("orderSummaryProduct", productTitleOrderSummary1)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("orderSummaryProduct", productTitleOrderSummary1).isDisplayed(), "Product title is present in order summary page");
        getElement("orderSummaryProduct", productTitleOrderSummary1).click();

    }

    @And("^user clicks on Add Address on checkout page$")
    public void userClicksOnAddAddressOnCheckoutPage() {
        getElement("addAddressLink").click();
    }

    @And("^user clicks on save edit address button in order summary page$")
    public void userClicksOnSaveEditAddressButtonInOrderSummaryPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("saveEditAddressButtonShippingAddress")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("saveEditAddressButtonShippingAddress").isDisplayed(), "Saved address button displayed in checkout order summary page");
        getElement("saveEditAddressButtonShippingAddress").click();
    }

    @And("^user provides address details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" on checkout order summery page$")
    public void userProvidesAddressDetailsOnCheckoutOrderSummeryPage(String delivery_Address_First_Name, String delivery_Address_Last_Name, String delivery_Address_Type, String delivery_Address_Full_Address, String delivery_Address_Nick_Name, String delivery_Address_Phone_Number, String delivery_Address_Landmark, String delivery_Address_State, String delivery_Address_City, String delivery_Address_Pin_Code) throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("deliveryAddressFullNameInput")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String flag = "false";
        logger.info("Delivery Address Details - First Name: " + delivery_Address_First_Name + " Last Name: " + delivery_Address_Last_Name + " Type: " + delivery_Address_Type + " Nick name " + delivery_Address_Nick_Name + "Phone number" + delivery_Address_Phone_Number + " Full Address: " + delivery_Address_Full_Address + " Landmark: " + delivery_Address_Landmark + " State: " + delivery_Address_State + " City: " + delivery_Address_City + "Pincode: " + delivery_Address_Pin_Code);
        clearTextBox(getElement("deliveryAddressFullNameInput"));
        getElement("deliveryAddressFullNameInput").sendKeys(delivery_Address_First_Name.concat(" ").concat(delivery_Address_Last_Name));
        clearTextBox(getElement("deliveryAddressPhoneNumberInput"));
        getElement("deliveryAddressPhoneNumberInput").sendKeys(delivery_Address_Phone_Number);
        clearTextBox(getElement("deliveryAddressNickNameInput"));
        getElement("deliveryAddressNickNameInput").sendKeys(delivery_Address_Nick_Name);
        switch (delivery_Address_Type) {
            case "Home":
                //       getElement("deliveryTypeHome").click();
                break;
            case "Work":
                getElement("deliveryTypeWork").click();
                break;
            case "Others":
                getElement("deliveryTypeOthers").click();
                break;
        }
        clearTextBox(getElement("deliveryAddressPinCodeInput"));
        getElement("deliveryAddressPinCodeInput").sendKeys(delivery_Address_Pin_Code);
        //assertStepExecution(true, getElement("deliveryAddressPinCodeInput").isDisplayed(), "Delivery address pincode displayed");
        assertThat(getElement("deliveryAddressPinCodeInput").isDisplayed()).isEqualTo(true).describedAs("Delivery address pincode displayed");
        setContext("finalAddressTypeCheckoutPage", delivery_Address_Type);
        windowScrollIntoViewByWebElement(getElement("deliveryAddressFullAddressInput"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        clearTextBox(getElement("deliveryAddressFullAddressInput"));
        getElement("deliveryAddressFullAddressInput").sendKeys(delivery_Address_Full_Address);
        clearTextBox(getElement("deliveryAddressLandMarkInput"));
        getElement("deliveryAddressLandMarkInput").sendKeys(delivery_Address_Landmark);
        //clearTextBox(getElement("deliveryAddressStateInput"));
        //getElement("deliveryAddressStateInput").sendKeys(delivery_Address_State);
        //getElement("deliveryAddressStateDropDown", delivery_Address_State).click();
        //clearTextBox(getElement("deliveryAddressCityInput"));
        //getElement("deliveryAddressCityInput").sendKeys(delivery_Address_City);
        //getElement("deliveryAddressCityDropDown", delivery_Address_City).click();
        /*clearTextBox(getElement("deliveryAddressPinCodeInput"));
        getElement("deliveryAddressPinCodeInput").sendKeys(delivery_Address_Pin_Code);
        assertStepExecution(true, getElement("deliveryAddressPinCodeInput").isDisplayed(), "Delivery address pincode displayed");*/
        //   Thread.sleep(5000);
        String deliveryState = getDriver().findElement(By.xpath(getLocator("deliveryAddressStateInput"))).getAttribute("value");
        String deliveryCity = getDriver().findElement(By.xpath(getLocator("deliveryAddressCityInput"))).getAttribute("value");
        logger.info("Delivery State : " + deliveryState);
        logger.info("Delivery City : " + deliveryCity);
        assertThat(deliveryState).isEqualTo(delivery_Address_State).describedAs("State name should match");
        assertThat(deliveryCity).isEqualTo(delivery_Address_City).describedAs("City name should match");

        setContext("finalAddressFullNameCheckoutPage", delivery_Address_First_Name.concat(" ").concat(delivery_Address_Last_Name));
        setContext("finalAddressFullAddressDetailsCheckoutPage", delivery_Address_Full_Address.concat(", ").concat(delivery_Address_Landmark).concat(", ").concat(delivery_Address_City).concat(", ").concat(delivery_Address_State).concat(" - ").concat(delivery_Address_Pin_Code));
        setContext("storeDeliveryEnableFlag", flag);
    }

    @And("^user clicks on billing add address in checkout order summary page$")
    public void userClicksOnBillingAddAddressInCheckoutOrderSummaryPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addAddressBillingButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        windowScrollIntoViewByWebElement(getElement("addAddressBillingButton"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        assertStepExecution(true, getElement("addAddressBillingButton").isDisplayed(), "Add address button displayed in checkout order summary page");
        //getElement("addAddressBillingButton").click();
        jsClick(getElement("addAddressBillingButton"));
    }

    @And("^user clicks on billing change address link in order summary page$")
    public void userClicksOnBillingChangeAddressLinkInOrderSummaryPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("billingChangeAddressLink")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("billingChangeAddressLink").isDisplayed(), "billing change address link displayed in checkout order summary page");
        //getElement("billingChangeAddressLink").click();
        jsClick(getElement("billingChangeAddressLink"));
    }

    @And("^user validates pick another address link in delivery address section should be display and clicks on it in check out page$")
    public void userValidatesPickAnotherAddressLinkInDeliveryAddressSectionShouldBeDisplayAndClicksOnItInCheckOutPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("pickAnotherAdd")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("pickAnotherAdd").isDisplayed(), "PICK ANOTHER ADDRESS displayed in checkout order summary page");
        getElement("pickAnotherAdd").click();
    }

    @And("^user validates \"([^\"]*)\" and change the address by clicking radio \"([^\"]*)\" button in check out page$")
    public void userValidatesAndChangeTheAddressByClickingRadioButtonInCheckOutPage(String activeAddressName, String newAddressrRadioBtn) throws InterruptedException {
        String stepDescription = "user validates address and change the address by clicking radio button";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("selectDeliveryLocationText")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("selectDeliveryLocationText").isDisplayed()).describedAs("Select Delivery location text should displayed").isEqualTo(true);
        assertThat(getElement("selectDeliveryLocationSubText").isDisplayed()).describedAs("Select a delivery location to see available delivery options text should displayed").isEqualTo(true);
        assertThat(getElement("editLink").isDisplayed()).describedAs("edit Link should displayed").isEqualTo(true);
        logger.info("active Address Name" + activeAddressName);
        assertThat(getElement("activeAddressTitle", activeAddressName).isDisplayed()).isEqualTo(true).describedAs("Active address should display");

        if (getOptionalElement("nonActiveAddressRadioBtn", newAddressrRadioBtn) != null) {
            Thread.sleep(5000);

            assertThat(getElement("nonActiveAddressRadioBtn", newAddressrRadioBtn).isDisplayed()).describedAs(newAddressrRadioBtn + " radio buttons should display");
            //getElement("nonActiveAddressRadioBtn", newAddressrRadioBtn).click();
            jsClick(getElement("nonActiveAddressRadioBtn", newAddressrRadioBtn));
        } else
            getElement("nonActiveAddressRadioBtn", newAddressrRadioBtn).click();
        //jsClick( getElement("nonActiveAddressRadioBtn", newAddressrRadioBtn));
        //assertThat(getElement("otherAddressRadioBtn1", newAddressrRadioBtn).isDisplayed()).describedAs("radio buttons should display");

        assertThat(getElement("addCloseBtn").isDisplayed()).isEqualTo(true).describedAs("closed button should display");
        getElement("addCloseBtn").click();
        passStepExecution(stepDescription + " :: Passed \n");

    }


    @And("^user validates delivery date time and complete \"([^\"]*)\" address should display in check out page$")
    public void userValidatesDeliveryDateTimeAndCompleteAddressShouldDisplayInCheckOutPage(String address) throws InterruptedException {
        String stepDescription = "user validates delivery date time and complete address should display in check out page";
        assertThat(getContext("DeliveryDetails").equals(true)).describedAs("Delivery details should matched");
        Thread.sleep(5000);
        String deliveryAddress = getElement("deliveryAddress").getText().trim();
        assertThat(deliveryAddress).containsIgnoringCase(address).describedAs("Address should matched");
        passStepExecution(stepDescription + " :: Passed \n");
    }


    @And("^user validate the button ADD ADDRESS to add any new address for delivery should display and user clicks on ADD ADDRESS button in check out page$")
    public void userValidateTheButtonADDADDRESSToAddAnyNewAddressForDeliveryShouldDisplayInCheckOutPage() {
        assertStepExecution(getElement("addAddressBtn").isDisplayed(), true, "Add address should display");
        getElement("addAddressBtn").click();
    }

    @And("^user validates pick another address link in billing address section should be display and clicks on it in check out page$")
    public void userValidatesPickAnotherAddressLinkInBillingAddressSectionShouldBeDisplayAndClicksOnItInCheckOutPage() throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("pickAnotherAddBilling")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        Thread.sleep(10000);
        assertStepExecution(getElement("pickAnotherAddBilling").isDisplayed(), true, "Pick another address button should display");
        //getElement("pickAnotherAddBilling").click();
        jsClick(getElement("pickAnotherAddBilling"));
        //getElement("addCloseBtn").click();
        jsClick(getElement("addCloseBtn"));

    }

    @And("^user validates checkbox with text massage \"([^\"]*)\" and by default it will be checked$")
    public void userValidatesCheckboxWithTextMassageAndByDefaultItWillBeChecked(String sameAsShippingAddMSg) {
        String stepDescription = "user validates checkbox with text massage and by default it will be checked";
        assertThat(getElement("sameAsShippingAdd", sameAsShippingAddMSg).isDisplayed()).describedAs("Same as Shipping address Text should display").isEqualTo(true);
        assertThat(getDriver().findElement(By.id("shipping-checkbox")).isSelected()).isEqualTo(true).describedAs("Same as Shipping address check box should selected");
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user validates the complete \"([^\"]*)\" along with the \"([^\"]*)\" of the address$")
    public void userValidatesTheCompleteAlongWithTheOfTheAddress(String billingAddress, String nickName) {
        String stepDescription = "user validates the complete address along with the of the address";
        String billingAdd = getElement("billingAddress").getText().trim();
        logger.info("Billing Address :- " + billingAdd);
        // assertThat(billingAdd.contains(billingAddress)).isEqualTo(true).describedAs("billing address should match");
        assertThat(billingAdd).contains(billingAddress).describedAs("billing address should match");
        assertThat(getElement("nickName", nickName).isDisplayed()).isEqualTo(true).describedAs("Nick name should display");
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user validates the error massage should display for the \"([^\"]*)\" in checkout page$")
    public void userValidatesTheErrorMassageShouldDisplayForTheInCheckoutPage(String checkOutProductName) {

        String errorMsg = getElement("productErrorMsg").getText().trim();
        logger.info("Error Msg :-" + errorMsg);
        assertThat(getElement("unavailableErrorMsg", checkOutProductName).getText().contains("Product is unavailable for the selected delivery mode & pincode. Click here to remove product.")).describedAs("Error massage should display in checkout Page");
    }

    @And("^user validates pickup at \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" text should display$")
    public void userValidatesPickupAtAndTextShouldDisplay(String storeName, String storeAddress, String cromaStoreText) {
        String stepDescription = "user validates pickup at text should display";
        assertThat(getElement("cromaStoreTxt", cromaStoreText).isDisplayed()).describedAs("Croma Store Text should display").isEqualTo(true);
        String pickUpStoreAdd = getElement("pickUpstoreAddress").getText().trim();
        String pickUpStoreName = getElement("pickUpStore").getText().trim();
        assertThat(pickUpStoreAdd).isEqualTo(storeAddress).describedAs("Store pickup address should match");
        assertThat(pickUpStoreName).isEqualTo(storeName).describedAs("Store name should match");
        passStepExecution(stepDescription + " :: Passed \n");
    }

    /*
        user clicks on the add new address on checkout order summery page and provides address details
    */
    @And("^user provides address details \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
    public void userProvidesAddressDetails(String delivery_Address_Full_Name, String delivery_Address_Type, String delivery_Address_Flat_Number, String delivery_Address_Landmark, String delivery_Address_State, String delivery_Address_City, String delivery_Address_Pin_Code) {
        String flag = "false";
        logger.info("Delivery Address Details - Full Name: " + delivery_Address_Full_Name + " Type: " + delivery_Address_Type + " Flat No: " + delivery_Address_Flat_Number + " Flat No: " + " Landmark: " + delivery_Address_Landmark + " State: " + delivery_Address_State + " City: " + delivery_Address_City + "Pincode: " + delivery_Address_Pin_Code);
        clearTextBox(getElement("deliveryAddressFullName"));
        getElement("deliveryAddressFullName").sendKeys(delivery_Address_Full_Name);
        switch (delivery_Address_Type) {
            case "Home":
                getElement("deliveryTypeHome").click();
                break;
            case "Work":
                getElement("deliveryTypeWork").click();
                break;
            case "Others":
                getElement("deliveryTypeOthers").click();
                break;
        }
        setContext("finalAddressTypeCheckoutPage", delivery_Address_Type);
        clearTextBox(getElement("deliveryAddressFlatNumber"));
        getElement("deliveryAddressFlatNumber").sendKeys(delivery_Address_Flat_Number);
        clearTextBox(getElement("deliveryAddressLandmark"));
        getElement("deliveryAddressLandmark").sendKeys(delivery_Address_Landmark);
        clearTextBox(getElement("deliveryAddressStateInput"));
        getElement("deliveryAddressStateInput").sendKeys(delivery_Address_State);
        getElement("deliveryAddressStateDropDown", delivery_Address_State).click();
        clearTextBox(getElement("deliveryAddressCityInput"));
        getElement("deliveryAddressCityInput").sendKeys(delivery_Address_City);
        getElement("deliveryAddressCityDropDown", delivery_Address_City).click();
        assertStepExecution(true, getOptionalElement("deliveryAddressPinCode") != null, "Delivery address pin code section displayed");
        clearTextBox(getElement("deliveryAddressPinCode"));
        getElement("deliveryAddressPinCode").sendKeys(delivery_Address_Pin_Code);
        setContext("finalAddressTypeCheckoutPage", delivery_Address_Type);
        setContext("finalAddressFullNameCheckoutPage", delivery_Address_Full_Name);
        setContext("finalAddressFullAddressDetailsCheckoutPage", delivery_Address_Flat_Number.concat(", ").concat(delivery_Address_Landmark).concat(", ").concat(delivery_Address_City).concat(", ").concat(delivery_Address_State).concat(" - ").concat(delivery_Address_Pin_Code));
        setContext("storeDeliveryEnableFlag", flag);
    }

    /*
           user provides billing address details in checkout order summery page
       */
    @And("^user provides billing address details in checkout order summery page \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
    public void userProvidesBillingAddressDetailsInCheckoutOrderSummeryPage(String billing_Address_Full_Name, String billing_Address_Flat_Number, String billing_Address_Landmark, String billing_Address_State, String billing_Address_City, String billing_Address_Pin_Code) {
        logger.info("Billing Address Details - Full Name: " + billing_Address_Full_Name + " Type: " + " Flat No: " + billing_Address_Flat_Number + " Flat No: " + " Landmark: " + billing_Address_Landmark + " State: " + billing_Address_State + " City: " + billing_Address_City + "Pincode: " + billing_Address_Pin_Code);
        windowScrollIntoViewByWebElement(getElement("billingAddressFullName"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        getElement("billingAddressFullName").sendKeys(billing_Address_Full_Name);
        getElement("billingAddressFlatNumber").sendKeys(billing_Address_Flat_Number);
        getElement("billingAddressLandmark").sendKeys(billing_Address_Landmark);
        getElement("billingAddressStateInput").sendKeys(billing_Address_State);
        getElement("billingAddressStateDropDown", billing_Address_State).click();
        getElement("billingAddressCityInput").sendKeys(billing_Address_City);
        getElement("billingAddressCityDropDown", billing_Address_City).click();
        assertStepExecution(true, getOptionalElement("billingAddressPinCode") != null, "Billing address pin code section displayed");
        getElement("billingAddressPinCode").sendKeys(billing_Address_Pin_Code);
    }

    @And("^user validates \"([^\"]*)\" name should display in checkout page$")
    public void userValidatesNameShouldDisplayInCheckoutPage(String extendedwarrantyName) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getElement("extendedwarrantyNameCout", extendedwarrantyName).isDisplayed(), "Extended warranty Product should display");
    }

    @And("user lands on search result page of {string} of product")
    public void userLandsOnSearchResultPageOfOfProduct(String searchProduct) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String productOnSearchPage = getElement("searchProductWeb", searchProduct).getText().trim();
        assertStepExecution(true, productOnSearchPage.contains(searchProduct), "Searched product matched");

    }


    @And("user lands on checkout order summary page")
    public void userLandsOnCheckoutOrderSummaryPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(getElement("checkoutPageHeading").getText(), "Shipping Information",
                "user lands on checkout order summary page");
    }

    @And("user validates {string} as number of products in checkout page")
    public void userValidatesAsNumberOfProductsInCheckoutPage(String productCount) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> productList = new ArrayList<>(getDriver().findElements(By.xpath(getLocator("checkoutProductNames"))));
        assertStepExecution(productList.size(), Integer.parseInt(productCount),
                "user validates " + productCount + " as number of products in checkout page");
    }

    @And("user validates {string} as products names in checkout page")
    public void userValidatesAsProductsNamesInCheckoutPage(String products) {
        ArrayList<WebElement> productNameList = new ArrayList<>(getElements("checkoutProductNames"));
        assertThat(productNameList.size()).describedAs("Products are more than 1").isPositive();
        if (products.contains(";")) {
            String[] productNameFromExamples = products.split(";");
            for (int i = 0; i < productNameFromExamples.length; i++) {
                String productNameFromWeb = productNameList.get(i).getText();
                logger.info("The product name from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("Cart product name from web and examples are matched.").isEqualTo(productNameFromExamples[i]);
            }
        } else {
            assertThat(productNameList.get(0).getText()).describedAs("Checkout product name from web and examples are matched.").isEqualTo(products);
        }
        passStepExecution("Products names on Checkout is verified");
    }

    @And("user validates the color of all circles in progress bar on checkout page")
    public void userValidatesTheColorOfAllCirclesInProgressBarOnCheckoutPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getElement("validateColor").isDisplayed(),
                "User validates the color of all circles in progress bar on checkout page");
    }

    @And("user validates the color of first circle {string} in progress bar on checkout page")
    public void userValidatesTheColorOfFirstCircleInProgressBarOnCheckoutPage(String color) throws InterruptedException {
        String colorOfCircle = getElement("progressBarColor").getCssValue("background-color");
        String hexcolor = Color.fromString(colorOfCircle).asHex();
        logger.info("The color of progress bar circles :" + hexcolor);
        assertStepExecution(color, hexcolor, "Color of circle is verified");
        Thread.sleep(10000);
    }

    @And("user validates the color of second circle {string} in progress bar on checkout page")
    public void userValidatesTheColorOfSecondCircleInProgressBarOnCheckoutPage(String color) throws InterruptedException {
        String colorOfCircle = getElement("progressBarCircleColor").getCssValue("background-color");
        String hexcolor = Color.fromString(colorOfCircle).asHex();
        logger.info("The color of progress bar circles :" + hexcolor);
        assertStepExecution(color, hexcolor, "Color of circle is verified");
        Thread.sleep(10000);
    }

    @And("user validates the color of third circle {string} in progress bar on checkout page")
    public void userValidatesTheColorOfThirdCircleInProgressBarOnCheckoutPage(String color) throws InterruptedException {
        String colorOfCircle = getElement("progressBarCircleColor").getCssValue("background-color");
        String hexcolor = Color.fromString(colorOfCircle).asHex();
        logger.info("The color of progress bar circles :" + hexcolor);
        assertStepExecution(color, hexcolor, "Color of circle is verified");
        Thread.sleep(10000);
    }

    @And("user validates pick another address button in billing address section")
    public void userValidatesPickAnotherAddressButtonInBillingAddressSection() throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("pickAnotherAddress")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        Thread.sleep(10000);
        assertStepExecution(getElement("pickAnotherAddress").isDisplayed(), true, "Pick another address button should display");
    }

    @And("user validates create and use another address button in billing address section")
    public void userValidatesCreateAndUseAnotherAddressButtonInBillingAddressSection() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("createAndUseAnotherAddressBtn")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("createAndUseAnotherAddressBtn").isDisplayed(), "Create and use Another Address button displayed in checkout order summary page");
    }

    @And("user clicks on pick another address button in shipping address section")
    public void userClicksOnPickAnotherAddressButtonInShippingAddressSection() throws InterruptedException {
        assertStepExecution(getElement("pickAnotherAddressBtn").isDisplayed(), true, "Pick another address button should display");
        jsClick(getElement("pickAnotherAddressBtn"));
        //jsClick(getElement("addCloseBtn"));
        userMovesToNewWindow();
        Thread.sleep(8000);
    }

    @And("user lands on edit address pop up window and verifies the heading")
    public void userLandsOnEditAddressPopUpWindowAndVerifiesTheHeading() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("editAddress")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("editAddress").isDisplayed(),
                "user lands on edit address pop up window and verifies the heading");
    }

    @Then("user verifies nickname in shipping information page")
    public void userVerifiesNicknameInShippingInformationPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("deliveryAddressNickNameInput")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("deliveryAddressNickNameInput").isDisplayed(),
                "user verifies nickname in shipping information page");
    }

    @And("user verifies same as shipping address checkbox is hidden after clicking on pickup in store option")
    public void userVerifiesSameAsShippingAddressCheckboxIsHiddenAfterClickingOnPickupInStoreOption() {
        String stepDesc = "verifies same as shipping address checkbox is hidden after clicking on pickup in store option";
        assertStepExecution(true, getOptionalElement("shipmentAddressCheckboxOption") == null, stepDesc);
    }

    @And("user clicks on pickup in store radio button on checkout page")
    public void userClicksOnPickupInStoreRadioButtonOnCheckoutPage() throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("pickUpInStore")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("pickUpInStore").isDisplayed()).isEqualTo(true).describedAs("Pickup In Store radio button should display");
        getElement("pickUpInStore").click();
        Thread.sleep(5000);
    }

    @Then("user verifies billing address section is visible after clicking on pickup in store option")
    public void userVerifiesBillingAddressSectionIsVisibleAfterClickingOnPickupInStoreOption() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("billingAddressSection")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("billingAddressSection").isDisplayed(),
                "user verifies billing address section is visible after clicking on pickup in store option");
    }

    @And("user unchecks the same as shipping address option in checkout order summery page")
    public void userUnchecksTheSameAsShippingAddressOptionInCheckoutOrderSummeryPage() {
        windowScrollIntoViewByWebElement(getElement("latestAddedAddressToSelectAsShippingAddress"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("latestAddedAddressToSelectAsShippingAddress")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("latestAddedAddressToSelectAsShippingAddress").isDisplayed(), "User unchecks the same as shipping address option");
        getElement("latestAddedAddressToSelectAsShippingAddress").click();
    }

    @And("user verifies billing address is visible")
    public void userVerifiesBillingAddressIsVisible() throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("billingAddressSection")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("billingAddressSection").isDisplayed(),
                "Billing address is visible");
        Thread.sleep(5000);
    }

    @And("user checks the same as shipping address option in checkout order summery page")
    public void userChecksTheSameAsShippingAddressOptionInCheckoutOrderSummeryPage() throws InterruptedException {
        windowScrollIntoViewByWebElement(getElement("latestAddedAddressToSelectAsShippingAddress"));
        windowScrollIntoViewAdjustment(checkOutPageScrollDownFirstIndex, checkOutPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("latestAddedAddressToSelectAsShippingAddress")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("latestAddedAddressToSelectAsShippingAddress").isDisplayed(), "User unchecks the same as shipping address option");
        getElement("latestAddedAddressToSelectAsShippingAddress").click();
        Thread.sleep(5000);
    }

    @Then("user verifies billing address section is hidden")
    public void userVerifiesBillingAddressSectionIsHidden() {
        String stepDesc = "user verifies billing address section is hidden";
        assertStepExecution(true, getOptionalElement("billingAddressSection") == null, stepDesc);
    }

    @And("user verifies shipping address is visible")
    public void userVerifiesShippingAddressIsVisible() throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("shippingAddressSection")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("shippingAddressSection").isDisplayed(),
                "Shipping address is visible");
        Thread.sleep(5000);
    }

    @And("user closes address pop up on checkout page")
    public void userClosesAddressPopUpOnCheckoutPage() throws InterruptedException {
        Thread.sleep(3000);
        processScreenshot();
        if (getDriver().findElements(By.xpath("//*[contains(@class,'addAddressCross')]")).size() > 0) {
            getDriver().findElement(By.xpath("//*[contains(@class,'addAddressCross')]")).click();
            Thread.sleep(5000);
        }
    }

    @And("user validates {string} as error message on add address pop up on checkout page")
    public void userValidatesAsErrorMessageOnAddAddressPopUpOnCheckoutPage(String checkOutAddressPopUp) throws InterruptedException {
//        String errorMsg = getElement("newAddressErrorMessage").getText().trim();
//        logger.info("Error Msg :-" + errorMsg);
//        assertThat(getElement("newAddressErrorMessage", checkOutAddressPopUp).getText().contains("No matching address found for entered pincode. Please add new address")).describedAs("Error message should display on address pop up on checkout Page");
        logger.info("Displayed toast message is : " + getElement("newAddressErrorMessage").getText());
        logger.info("Argument message is : " + checkOutAddressPopUp);
        assertThat(checkOutAddressPopUp).describedAs("Error message on Address pop up").isEqualTo(getElement("newAddressErrorMessage").getText());
        Thread.sleep(10000);
    }

    @Then("user verifies if the progress bar is absent on payment screen")
    public void userVerifiesIfTheProgressBarIsAbsentOnPaymentScreen() throws InterruptedException {
        Thread.sleep(5000);
        String stepDesc = "user verifies if the progress bar is absent on payment screen";
        assertStepExecution(true, getOptionalElement("progressBar") == null, stepDesc);
    }

    @And("user clicks on Skip button on payment screen")
    public void userClicksOnSkipButtonOnPaymentScreen() throws InterruptedException {
        assertStepExecution(getElement("skipAdditionalPopUp").isDisplayed(), true, "Skip button should display on payment screen");
        jsClick(getElement("skipAdditionalPopUp"));
        Thread.sleep(5000);
    }

    @And("user validates the color of the circle {string} in progress bar on checkout page")
    public void userValidatesTheColorOfTheCircleInProgressBarOnCheckoutPage(String color) throws InterruptedException {
        String colorOfCircle = getElement("firstProgressBarColor").getAttribute("fill");
        assertStepExecution(color, colorOfCircle, "Color of circle is verified");
        Thread.sleep(10000);
    }

    @And("user validates zip delivery time on check out page")
    public void userValidatesZipDeliveryTimeOnCheckOutPage() throws InterruptedException {
        String timeFormat = getElement("zipDeliveryTime").getText();
        logger.info("Zip Delivery Time : " + timeFormat);
        assertStepExecution(true, timeFormat.matches("^([1]?[0-9]|2[0-3]) hr [1-5]?[0-9] min$"), "user validates zip delivery time on check out page");
        Thread.sleep(5000);
    }

    @And("user validates the color of second circle {string} in the progress bar on checkout page")
    public void userValidatesTheColorOfSecondCircleInTheProgressBarOnCheckoutPage(String color) throws InterruptedException {
        String colorOfCircle = getElement("progressBarColor").getCssValue("background-color");
        String hexcolor = Color.fromString(colorOfCircle).asHex();
        logger.info("The color of progress bar circles :" + hexcolor);
        assertStepExecution(color, hexcolor, "Color of circle is verified");
        Thread.sleep(10000);
    }

    @And("user selects Brand as {string} from Brand filter dropdown")
    public void userSelectsBrandAsFromBrandFilterDropdown(String brandName) {
        //String stepDesc = "user clicks on down arrow icon of " + brandName + " filter";
        getElement("brandName").sendKeys(brandName);
        assertStepExecution(true, getElement("brandName").isDisplayed(), "user enters brand name");

    }

    @And("user clicks on check price button on exchange page")
    public void userClicksOnCheckPriceButtonOnExchangePage() throws InterruptedException {
        logger.info("Clicks on check price button");
        //waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("checkPriceButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("checkPriceButton").click();
        Thread.sleep(5000);
    }

    @And("user enters IMEI {string} in the IMEI textbox")
    public void userEntersIMEIInTheIMEITextbox(String imeiNo) {
        String stepDesc = "user provides IMEI number as " + imeiNo;
        getElement("brandName").clear();
        getElement("brandName").sendKeys(imeiNo);
        assertStepExecution(imeiNo, getElement("downArrow").getAttribute("value"), stepDesc);
    }

    @And("user clicks on verify button on exchange page")
    public void userClicksOnVerifyButtonOnExchangePage() throws InterruptedException {
        Thread.sleep(6000);
        getElement("clickVerifyButton").click();
        assertStepExecution(true, getOptionalElement("clickVerifyButton").isDisplayed(),
                "Verify button on exchange page is clicked and IMEI number is verified");
    }

    @And("user validates if the IMEI number is verified")
    public void userValidatesIfTheIMEINumberIsVerified() throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("verifyExchangeStatus").isDisplayed(),
                "IMEI number is verified");
    }

    @And("user clicks on apply button on exchange page")
    public void userClicksOnApplyButtonOnExchangePage() {
        assertStepExecution(true, getOptionalElement("clickApplyButton") != null, "user clicks on apply button on exchange page");
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickApplyButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clickApplyButton").click();
    }

    @And("user selects Brand Model as {string} from Brand filter dropdown")
    public void userSelectsBrandModelAsFromBrandFilterDropdown(String brandName) {
        getElement("brandModel").sendKeys(brandName);
        assertStepExecution(true, getElement("brandName").isDisplayed(), "user enters brand model");

    }

    @And("user selects Model Variant as {string} from Brand filter dropdown")
    public void userSelectsModelVariantAsFromBrandFilterDropdown(String brandName) throws InterruptedException {
        getElement("brandVariant").sendKeys(brandName);
        assertStepExecution(true, getElement("brandName").isDisplayed(), "user enters brand model");
        Thread.sleep(5000);
    }

    @Then("user clicks on cross icon on exchange page")
    public void userClicksOnCrossIconOnExchangePage() throws InterruptedException {
        getElement("crossIcon").click();
        Thread.sleep(10000);
    }

    @And("user chooses new address {string} from shipping information page")
    public void userChoosesNewAddressFromShippingInformationPage(String addressNo) throws InterruptedException {
        assertStepExecution(true, getOptionalElement("newAddressBtn", String.valueOf(Integer.parseInt(addressNo) - 1)) != null,
                "user chooses new address " + addressNo + " from shipping information page");
        getOptionalElement("newAddressBtn", String.valueOf(Integer.parseInt(addressNo) - 1)).click();
        Thread.sleep(5000);
    }

    @And("user verifies billing address checkbox is checked or not")
    public void userVerifiesBillingAddressCheckboxIsCheckedOrNot() {
        WebElement element = getElement("shippingCheckbox");
        boolean checkbox = element.isSelected();
        assertStepExecution(true, checkbox, "user verifies billing address checkbox is checked or not");
    }

    /*
    User saves billing address
     */
    @And("user saves billing address on checkout page")
    public void userSavesBillingAddressOnCheckoutPage() {

        logger.info("displayed billing addr is: " + getElement("displayedBillingAddress").getText());
        setContext("billingAddressDisplayedOnCheckoutPage", getElement("displayedBillingAddress").getText());
    }

    /*
    User saves contact information
     */
    @And("user saves contact information on checkout page")
    public void userSavesContactInformationOnCheckoutPage() {
        logger.info("displayed contact email is: " + getElement("displayedContactEmail").getAttribute("value"));
        setContext("displayedContactEmailOnCheckoutPage", getElement("displayedContactEmail").getAttribute("value"));
        logger.info("displayed contact mobile is: " + getElement("displayedContactMobile").getAttribute("value"));
        setContext("displayedContactMobOnCheckoutPage", getElement("displayedContactMobile").getAttribute("value"));
    }

    @And("user clicks on same as billing address checkbox")
    public void userClicksOnSameAsBillingAddressCheckbox() {
        getElement("sameAsShippingCheckbox").click();
    }

    /*
           User validates shipping tab is highlighted in checkout Page
    */

    @And("user validates the shipping button is highlighted with {string} in checkout page")
    public void userValidatesTheShippingButtonIsHighlightedWithInCheckoutPage(String color) throws InterruptedException {
        Thread.sleep(4000);
        String colorOfBorder = getDriver().findElement(By.xpath(getLocator("shippingTab"))).getCssValue("border").replaceAll("2px solid ", "");
        String hexaColor = Color.fromString(colorOfBorder).asHex();
        assertStepExecution(true, hexaColor.equals(color),
                "user validates the shipping button is highlighted in checkout page");
    }
   /*
           User validates no matching address text in check out page
    */

    @And("user validates no matching address text {string} in checkout page")
    public void userValidatesNoMatchingAddressTextInCheckoutPage(String text) throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("noMatchingAddressText").getText().equals(text),
                "user validates no matching address text " + text + " in checkout page");
    }

    /*
        User clicks on click here link to add new address for a new pincode
      */
    @And("user clicks on click here link to add new address")
    public void userClicksOnClickHereLinkToAddNewAddress() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("clickHereLinkForAddingNewAdddresForNewPicode") != null,
                "user clicks on click here link to add new address");
        getElement("clickHereLinkForAddingNewAdddresForNewPicode").click();
        Thread.sleep(2000);
        userMovesToNewWindow();
        Thread.sleep(3000);
    }

    /**
     * This Method validates add new address popup is displayed
     */
    @And("user validates add new address popup {string} is displayed")
    public void userValidatesAddNewAddressPopupIsDisplayed(String text) {
        assertStepExecution(true, getOptionalElement("addNewAddressPopup").getText().equals(text),
                "user validates add new address popup " + text + " is displayed");
    }

    /**
     * This Method clicks on add or change address link under shipping address in checkout page
     */
    @And("user clicks on add or change address {string} link under shipping address in checkout page")
    public void userClicksOnAddOrChangeAddressLinkUnderShippingAddressInCheckoutPage(String linkName) throws InterruptedException {
        Thread.sleep(3000);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("addAddressOrChangeAddressLinkUnderShippingAddress", linkName)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        String nickName = getDriver().findElement(By.xpath("//div[contains(@class,'bill-ship error-bill-ship')]//div[contains(@class,'home-store')]")).getText();
        setContext("NickName", nickName);
        assertStepExecution(true, getOptionalElement("addAddressOrChangeAddressLinkUnderShippingAddress", linkName) != null,
                "user clicks on add or change address " + linkName + " link under shipping address in checkout page");
        getElement("addAddressOrChangeAddressLinkUnderShippingAddress", linkName).click();
        userMovesToNewWindow();
    }

    /**
     * This Method validates the text field is present in add or change address popup in checkout page
     */
    @And("user validates the text field {string} with placeholder {string} is present in add or change address popup in checkout page")
    public void userValidatesTheTextFieldWithPlaceholderIsPresentInAddOrChangeAddressPopupInCheckoutPage(String textField, String placeholder) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(1, getDriver().findElements(By.xpath(getLocator("addAddresspopupTextField", textField))).size(),
                "user validates the text field " + textField + " with placeholder " + placeholder + " is present in add or change address popup in checkout page");
    }

    /**
     * This Method validates address types tabs are present in add or change address popup in checkout page
     **/

    @And("user validates address types tabs {string} are present in add or change address popup in checkout page")
    public void userValidatesAddressTypesTabsArePresentInAddOrChangeAddressPopupInCheckoutPage(String fieldName) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(3, getDriver().findElements(By.xpath(getLocator("addAddresspopupAddressTypesTabs", fieldName))).size(),
                "user validates address types tabs " + fieldName + " are present in add or change address popup in checkout page");
    }

    /**
     * This Method  selects address type in add or change address popup in checkout page
     **/
    @And("user selects address type as {string} in add or change address popup in checkout page")
    public void userSelectsAddressTypeAsInAddOrChangeAddressPopupInCheckoutPage(String typeOfAddress) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("addAddresspopupAddressTypesTabsSelect", typeOfAddress) != null,
                "user selects address type as" + typeOfAddress + " in add or change address popup in checkout page");
        getElement("addAddresspopupAddressTypesTabsSelect", typeOfAddress).click();
    }

    /**
     * This Method used to validate specific addresstype button is selected or not
     **/
    @And("user validates address type tab {string} is selected in add or change address popup in checkout page")
    public void userValidatesAddressTypeTabIsSelectedInAddOrChangeAddressPopupInCheckoutPage(String typeOfAddress) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getDriver().findElement(By.xpath(getLocator("addAddresspopupAddressTypesTabsSelect", typeOfAddress))).getAttribute("class").contains("selected-add-type"),
                "user selects address type as" + typeOfAddress + " in add or change address popup in checkout page");

    }

    /**
     * This Method used to check address default checkbox is present
     **/
    @And("user validates make this address default checkbox is present")
    public void userValidatesMakeThisAddressDefaultCheckboxIsPresent() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("saveAddressCheckBox") != null,
                "user validates make this address default checkbox is present");
    }

    /**
     * This Method used to validate save address button is present in add or change address popup in checkout page
     **/
    @And("user validates save address button is present in add or change address popup in checkout page")
    public void userValidatesSaveAddressButtonIsPresentInAddOrChangeAddressPopupInCheckoutPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("saveAddressButtonShippingAddress") != null,
                "user validates make this address default checkbox is present");
    }

    /**
     * This Method used to provide value in textbox field in add or change address popup in checkout page
     **/
    @And("user provides {string} as value in {string} in add or change address popup in checkout page")
    public void userProvidesAsValueInInAddOrChangeAddressPopupInCheckoutPage(String textboxValue, String textbox) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("addAddresspopupTextField", textbox) != null,
                "user provides " + textboxValue + " as value in " + textbox + " in add or change address popup in checkout page");
        WebElement elem = getElement("addAddresspopupTextField", textbox);
        scrollToWebelement(elem);
        elem.click();
        elem.clear();
        elem.sendKeys(textboxValue);
    }

    /**
     * This Method used to provide value in second line of address field in add or change address popup in checkout page
     **/
    @And("user provides {string} as value in second line of address text box")
    public void userProvidesAsValueInSecondLineOfAddressTextBox(String textboxValue) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("addAddresspopupAddressSecondLine") != null,
                "user provides " + textboxValue + " as value in second line of address text box");
        WebElement elem = getElement("addAddresspopupAddressSecondLine");
        elem.click();
        elem.clear();
        elem.sendKeys(textboxValue);
        Thread.sleep(3000);
    }

    /**
     * This Method used to validate shipping address has beeen changed
     **/
    @And("user validates shipping address has changed")
    public void userValidatesShippingAddressHasChanged() throws InterruptedException {
        Thread.sleep(3000);
        String previousNickName = getContext("NickName");
        String nickName = getDriver().findElement(By.xpath("//div[contains(@class,'bill-ship error-bill-ship')]//div[contains(@class,'home-store')]")).getText();
        assertStepExecution(true, !(previousNickName.equals(nickName)),
                "user validates shipping address has changed");
        Thread.sleep(3000);
    }

    /**
     * This Method used to click on edit or remove button after clicking on change address
     **/
    @And("user clicks on edit or remove button as {string} for the nickname as {string} in checkout page")
    public void userClicksOnEditOrRemoveButtonAsForTheNicknameAsInCheckoutPage(String buttonName, String nickName) throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getDriver().findElement(By.xpath(getLocator("removeOrEditIcon", nickName, buttonName))) != null,
                "user clicks on edit or remove button as " + buttonName + " for the nickname as " + nickName + "  in checkout page");
        getDriver().findElement(By.xpath(getLocator("removeOrEditIcon", nickName, buttonName))).click();
        Thread.sleep(3000);
    }

    /**
     * This Method used to validates contact information section is visible in checkout page
     **/
    @And("user validates contact information section is visible in checkout page")
    public void userValidatesContactInformationSectionIsVisibleInCheckoutPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElements("contactInformationSection") != null,
                "user validates contact information section is visible in checkout page");
        Thread.sleep(3000);
    }

    /**
     * This Method used to validates contact information fields are populated or not
     **/
    @And("user validates the contact information field {string} is populated")
    public void userValidatesTheContactInformationFieldIsPopulated(String fieldName) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("contactInformationFields", fieldName).getText() != null,
                "user validates the contact information field " + fieldName + " is populated");
        String fieldValue = getElement("contactInformationFields", fieldName).getText().trim();
        if (fieldName.equals("Email"))
            setContext("ContactInformationEmail", fieldValue);
        else if (fieldName.equals("Mobile"))
            setContext("ContactInformationMobile", fieldValue);
    }

    /**
     * This Method used to click on buttons under contact information section in checkout page
     **/
    @And("user clicks on button {string} under contact information section in checkout page")
    public void userClicksOnButtonUnderContactInformationSectionInCheckoutPage(String buttonName) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElement("buttonUnderContactInformation", buttonName) != null,
                "user clicks on button " + buttonName + " under contact information section in checkout page");
        getElement("buttonUnderContactInformation", buttonName).click();
        Thread.sleep(3000);
    }

    /**
     * This Method used to validate contact information fields are editable or not
     **/
    @And("user validates the contact information field {string} is editable")
    public void userValidatesTheContactInformationFieldIsEditable(String fieldName) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("contactInformationInputFields", fieldName).getAttribute("readonly") == null,
                "user validates the contact information field " + fieldName + " is editable");
        Thread.sleep(3000);
    }

    /**
     * This Method used to update the contact information fields
     **/

    @And("user updates the contact information field {string} with value {string} in checkout page")
    public void userUpdatesTheContactInformationFieldWithValueInCheckoutPage(String fieldName, String value) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("contactInformationInputFields", fieldName) != null,
                "user updates the contact information field " + fieldName + "with value " + value + "in checkout page");
        WebElement elem = getElement("contactInformationInputFields", fieldName);
        elem.click();
        jsClear(elem);
        elem.sendKeys(value);
        Thread.sleep(3000);
    }

    /**
     * This Method used to update the contact information fields
     **/
    @And("user validates the contact information field {string} is updated")
    public void userValidatesTheContactInformationFieldIsUpdated(String fieldName) throws InterruptedException {
        Thread.sleep(3000);
        if (fieldName.equals("Email")) {
            String emailID = getContext("ContactInformationEmail");
            assertStepExecution(true, !(getOptionalElement("contactInformationFields", fieldName).getText().trim().equals(emailID)),
                    "user validates the contact information field " + fieldName + " is updated");
        } else if (fieldName.equals("Mobile")) {
            String mobileNo = getContext("ContactInformationMobile");
            assertStepExecution(true, !(getOptionalElement("contactInformationFields", fieldName).getText().trim().equals(mobileNo)),
                    "user validates the contact information field " + fieldName + " is updated");
        }
    }

    /**
     * This Method used to validate the gst information section is visible or not in checkout page
     **/

    @And("user validates the gst information section is visible in checkout page")
    public void userValidatesTheGstInformationSectionIsVisibleInCheckoutPage() throws InterruptedException {
        Thread.sleep(4000);
        scrollToWebelement(getElement("gstInformation"));
        assertStepExecution(true, getElement("gstInformation") != null,
                "user validates the gst information section is visible in checkout page");
        Thread.sleep(3000);
    }

    /**
     * This Method used to validate the shipping address section is visible in checkout page
     **/

    @And("user validates the shipping address section is visible")
    public void userValidatesTheShippingAddressSectionIsVisible() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("shippingAddressSec") != null,
                "user validates the shipping address section is visible");
    }

    /**
     * This Method used to validate the nickname  is visible under shipping address section in checkout page
     **/

    @And("user validates nickname as {string} is visible under shipping address section")
    public void userValidatesNicknameAsIsVisibleUnderShippingAddressSection(String nickName) throws InterruptedException {
        Thread.sleep(3000);
        String nick_name = getElement("nickNameShippingAddress").getText().replace("HOME", "").trim();
        assertStepExecution(true, nick_name.equals(nickName),
                "user validates nickname as " + nickName + " is visible under shipping address section");
        Thread.sleep(3000);
    }

    /**
     * This Method used to validate the  address is visible under shipping address section in checkout page
     **/

    @And("user validates address is visible under shipping address section")
    public void userValidatesAddressIsVisibleUnderShippingAddressSection() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("addressSecShippingAddress") != null,
                "user validates address is visible under shipping address section");
    }

    /**
     * This Method used to validate the  add or change address  link are visible under shipping address in checkout page
     **/

    @And("user validates add or change address {string} link are visible under shipping address")
    public void userValidatesAddOrChangeAddressLinkAreVisibleUnderShippingAddress(String linkName) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("addAddressOrChangeAddressLinkUnderShippingAddress", linkName) != null,
                "user validates add or change address " + linkName + " link are visible under shipping address");
    }

    /**
     * This Method used to validate the billing address section is visible in checkout page
     **/

    @And("user validates billing address section is visible")
    public void userValidatesBillingAddressSectionIsVisible() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("billingAddressSec") != null,
                "user validates the shipping address section is visible");
    }

    /**
     * This Method used to validate the nickname  is visible under shipping address section in checkout page
     **/

    @And("user validates nickname as {string} is visible under billing address section")
    public void userValidatesNicknameAsIsVisibleUnderBillingAddressSection(String nickName) throws InterruptedException {
        Thread.sleep(3000);
        String nick_name = getElement("nickNameBillingAddress").getText().replace("HOME", "").trim();
        assertStepExecution(true, nick_name.equals(nickName),
                "user validates nickname as " + nickName + " is visible under billing address section");
    }

    /**
     * This Method used to validate the  address is visible under billing address section in checkout page
     **/
    @And("user validates address is visible under billing address section")
    public void userValidatesAddressIsVisibleUnderBillingAddressSection() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("addressSecBillingAddress") != null,
                "user validates address is visible under billing address section");
    }

    /**
     * This Method used to validate the  add or change address  link are visible under billing address in checkout page
     **/
    @And("user validates add or change address {string} link are visible under billing address")
    public void userValidatesAddOrChangeAddressLinkAreVisibleUnderBillingAddress(String linkName) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("addAddressOrChangeAddressLinkUnderBillingAddress", linkName) != null,
                "user validates add or change address " + linkName + " link are visible under billing address");
    }

    /**
     * This Method used to validate and store the nickname of the default address in my orders page
     **/
    @And("user validate and store the nickname of the default address in my orders page")
    public void userValidateAndStoreTheNicknameOfTheDefaultAddressInMyOrdersPage() throws InterruptedException {
        userClicksOnMenuIconAndCloseIt();
        Thread.sleep(4000);
        assertStepExecution(true, getOptionalElement("defaultAddressNickName") != null,
                "user validate and store the nickname of the default address in my orders page");
        String nickname = getElement("defaultAddressNickName").getText();
        getElement("defaultAddressNickName").click();
        setContext("DefaultAddressNickName", nickname);
        Thread.sleep(2000);
    }

    /**
     * This Method used to validate billing address already have default address in check out page
     **/
    @And("user validates the billing address already have default address")
    public void userValidatesTheBillingAddressAlreadyHaveDefaultAddress() throws InterruptedException {
        Thread.sleep(4000);
        String nickNameFromMyOrdersPage = getContext("DefaultAddressNickName");
        String nickNameInCheckOutPage = getElement("nickNameBillingAddress").getText();
        assertStepExecution(true, nickNameFromMyOrdersPage.equalsIgnoreCase(nickNameInCheckOutPage),
                "user validates the billing address already have default address");
        Thread.sleep(2000);
    }

    /**
     * This Method used to validate the billing store section is visible in checkout page
     **/
    @And("user validates the store address section is visible")
    public void userValidatesTheStoreAddressSectionIsVisible() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("storeAddressSec") != null,
                "user validates the store address section is visible");
    }

    @And("user validates storename as {string} is visible under store address section")
    public void userValidatesStorenameAsIsVisibleUnderStoreAddressSection(String storeName) throws InterruptedException {
        Thread.sleep(3000);
        String store_name = getElement("nickNameStoreAddress").getText();
        assertStepExecution(true, store_name.equals(storeName),
                "user validates storename as " + storeName + " is visible under Store address section");
    }

    @And("user clicks on reschedule delivery link in checkout page")
    public void userClicksOnRescheduleDeliveryLinkInCheckoutPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        logger.info("User land on order checkout page and clicks on reschedule delivery link");
        logger.info("Delivery date and time is :" + getElement("deliveryDateAndTime").getText());
        assertStepExecution(true, getElement("clickOnRescheduleDelivery").isDisplayed(), "user reschedule delivery link is present in checkout page");
        getElement("clickOnRescheduleDelivery").click();
    }

    @And("user select time slot as {string} in schedule delivery page")
    public void userSelectTimeSlotAsInScheduleDeliveryPage(String timeSlot) throws InterruptedException {
//        Thread.sleep(3000);
//        String[] slot=timeSlot.split("-");
//        String s1=slot[0].trim();
//        logger.info("select time slot:-"+getElement("selectTimeSlot",s1).getText());
//        getElement("selectTimeSlot",s1).click();
        Thread.sleep(3000);
//        List<WebElement> scheduleSlotListDetails = getElements("timeSlotList");
//        logger.info("Count of slot list is: " + scheduleSlotListDetails.size());
//        if(scheduleSlotListDetails.size()==1)
//        {
//        getElement("clickOnNextDate").click();
//        }
        logger.info(getElement("selectTimeSlot", timeSlot).getText());
        setContext("timeSlot", getElement("selectTimeSlot", timeSlot).getText());
        getElement("selectTimeSlot", timeSlot).click();
    }

    @And("user clicks on continue button in schedule delivery page")
    public void userClicksOnContinueButtonInScheduleDeliveryPage() throws InterruptedException {
        Thread.sleep(2000);
        getElement("clickOnContinueButtonInScheduleDeliveryPage").click();
        Thread.sleep(3000);
    }

    @And("user selects different {string} shipping address modal popup in checkout page")
    public void userSelectsDifferentShippingAddressModalPopupInCheckoutPage(String nickname) throws InterruptedException {
        Thread.sleep(2000);
        getElement("selectDifferentNickname", nickname).click();
        assertStepExecution(true, getElement("selectDifferentNickname", nickname) != null,
                "user selects different " + nickname + " shipping address modal popup");
    }

    @And("user clicks on {string} button in checkout page")
    public void userClicksOnButtonInCheckoutPage(String buttonName) throws InterruptedException {
        Thread.sleep(60000);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("moveToWishlistOrRemoveButtonInCheckOutPage", buttonName)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("moveToWishlistOrRemoveButtonInCheckOutPage", buttonName) != null,
                "user selects different " + buttonName + " shipping address modal popup");
        scrollToWebelement(getElement("moveToWishlistOrRemoveButtonInCheckOutPage", buttonName));
        getElement("moveToWishlistOrRemoveButtonInCheckOutPage", buttonName).click();
        Thread.sleep(2000);
        if (buttonName.equals("Remove"))
            jsClick(getElement("clickYesButton"));
    }

    @And("user veifies the button {string} already in wishlist is enabled under the product in checkout page")
    public void userVeifiesTheButtonAlreadyInWishlistIsEnabledUnderTheProductInCheckoutPage(String buttonName) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getElement("moveToWishlistOrRemoveButtonInCheckOutPage", buttonName) != null,
                "user veifies the button " + buttonName + " already in wishlist is enabled under the product in checkout page");
    }

    @And("user veifies the button {string} already in wishlist is disabled under the product in checkout page")
    public void userVeifiesTheButtonAlreadyInWishlistIsDisabledUnderTheProductInCheckoutPage(String buttonName) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, true,
                "user veifies the button " + buttonName + " already in wishlist is disabled under the product in checkout page");
    }

    @And("user verifies ship buttons are not displayed for value added service product {string} in checkout page")
    public void userVerifiesShipButtonsAreNotDisplayedForValueAddedServiceProductInCheckoutPage(String product) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getElement("moveToWishlistOrRemoveButtonInCheckOutPage")!=null,
                "user verifies ship buttons are not displayed for value added service product " + product + " in checkout page");
    }

    @And("user verifies the proceed to pay button becomes disable in checkout page")
    public void userVerifiesTheProceedToPayButtonBecomesDisableInCheckoutPage() throws InterruptedException {
        Thread.sleep(2000);
        WebElement elem = getDriver().findElement(By.xpath(getLocator("proceedToPaymentButtonInCheckoutPage")));
        assertStepExecution(true, elem.getAttribute("disabled") != null,
                "user verifies the proceed to pay button becomes disable in checkout page");
    }

    @And("user provide search your location in Add new Address dialoug box as {string} ,{string}")
    public void userProvideSearchYourLocationInAddNewAddressDialougBoxAs(String searchAreaName1, String searchAreaName2) throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchYourLocationBox1")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("searchYourLocationBox1").click();
        getElement("searchYourLocationBox1").sendKeys(searchAreaName1);
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getElement("searchYourLocationBox2").click();
        getElement("searchYourLocationBox2").sendKeys(searchAreaName2);
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getElement("firstDropDownFromSearchYourLocationBox2").click();
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
    }
}

