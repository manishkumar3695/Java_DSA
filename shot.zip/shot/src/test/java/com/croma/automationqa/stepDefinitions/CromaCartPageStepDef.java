package com.croma.automationqa.stepDefinitions;

import com.croma.automationqa.util.ContextUtil;
import com.croma.automationqa.util.JavaScriptUtil;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.*;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;


/*
     All the cart page related function defined in CromaCartPageStepDef class
*/
public class CromaCartPageStepDef {

    private final int cartPageFirstConditionalValue = 0;
    private final int indexOne = 1;
    JavascriptExecutor js = (JavascriptExecutor) getDriver();

    /*
      User click on the check out button
    */
    @And("^user clicks on the check out button$")
    public void userClicksOnTheCheckOutButton() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_MED")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("Clicks on checkout button");
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        if (getConfig("Browser").equals("EMULATED_CHROME")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("checkOutMobileButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            windowScrollIntoViewByWebElementTrue(getElement("checkOutMobileButton"));
            getElement("checkOutMobileButton").click();
        } else if (getConfig("Browser").equals("CHROME")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("checkOutButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            windowScrollIntoViewByWebElement(getElement("checkOutButton"));
            getElement("checkOutButton").click();
        }

        Thread.sleep(5000);
    }


    /*
  User remove the product from cart
  */
    @And("^user removes the product from cart \"([^\"]*)\"$")
    public void userRemovesTheProductFromCart(String removalCartProduct1) throws InterruptedException {
        // logger.info("The Product to be removed is: " + getElement("productOnCartPage", removalCartProduct1).getText() + " From Database is: " + removalCartProduct1);
        assertStepExecution(removalCartProduct1.toLowerCase(), getElement("productOnCartPage", removalCartProduct1).getText().toLowerCase(),
                "Remove product matched");
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
        getElement("removeProductIcon", removalCartProduct1).click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnYesButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //getElement("clickOnYesButton").click();
        jsClick(getElement("clickOnYesButton"));
        Thread.sleep(5000);
    }

    /*
       User clicks on change store link in cart page and store list pop-up appears
    */
    @And("^user clicks on change store link in cart page and store list pop-up appears$")
    public void userClicksOnChangeStoreLinkInCartPageAndStoreListPopUpAppears() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnChangeStoreButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        processScreenshot();
        getElement("clickOnChangeStoreButton").click();
    }


    /*
       User selects store from pop-up
    */
    @And("^user selects store \"([^\"]*)\" from pop-up$")
    public void userSelectsStoreFromPopUp(String storeLocator) {
        logger.info("Store locator is: " + storeLocator);
        processScreenshot();
        setContext("finalStoreDeliveryName", storeLocator);
        setContext("finalStoreDeliveryAddress", getElement("storeDeliveryAddress", storeLocator).getText());
        getElement("selectStoreLocatorFromPopup", storeLocator).click();
        getElement("selectStoreLocatorFromPopupClose").click();
    }


    /*
       User validates store added to cart page
    */
    @And("^user validates store \"([^\"]*)\" added to cart page$")
    public void userValidatesStoreAddedToCartPage(String storeLocator1) {
        int splitInitialIndex = 17;
        processScreenshot();
        conditionalWait(ExpectedConditions.visibilityOf(getElement("selectedStoreLocatorOnCartPage")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        logger.info("Selected store locator message on Cart is: " + getElement("selectedStoreLocatorOnCartPage").getText() + " Selected store locator on Cart is: " + (getElement("selectedStoreLocatorOnCartPage").getText()).substring(splitInitialIndex));
        assertStepExecution(storeLocator1.toLowerCase(), getElement("selectedStoreLocatorOnCartPage").getText().substring(splitInitialIndex).toLowerCase(),
                "Store name is not matching in cart page");
    }


    /*
       User selects shipping option in cart page
    */
    @And("^user selects \"([^\"]*)\" shipping option in cart page$")
    public void userSelectsShippingOptionInCartPage(String shippingOption) throws InterruptedException {
        String flag = "true";
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        Thread.sleep(5000);
        switch (shippingOption) {
            case "3 Hour Delivery":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("threeHourDeliveryRadioButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                getElement("threeHourDeliveryRadioButton").click();
                break;
            case "Store Delivery":
                Thread.sleep(5000);
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("storeDeliveryRadioButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                getElement("storeDeliveryRadioButton").click();
                setContext("storeDeliveryEnableFlag", flag);
                logger.info(getContext("storeDeliveryEnableFlag"));
                break;
            case "Home Delivery":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("homeDeliveryRadioButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                getElement("homeDeliveryRadioButton").click();
                break;
        }
    }

    @And("user selects store pick up as shipping option in cart page")
    public void userSelectsStorePickUpAsShippingOptionInCartPage() throws InterruptedException {
        Thread.sleep(5000);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("storeDeliveryRadioButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("storeDeliveryRadioButton").click();

    }

    /*
       User provides the coupon in cart page and apply
    */
    @And("^user provides the \"([^\"]*)\" coupon in cart page and apply$")
    public void userProvidesTheCouponInCartPageAndApply(String couponCode1) {
//        conditionalWait(ExpectedConditions.visibilityOf(getElement("enterCouponCodeInTextBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        List<WebElement> todayAvailable = getDriver().findElements(By.xpath(getLocator("couponCodeDiscountAmount")));
        logger.info("No of today are: " + todayAvailable.size());
        if (todayAvailable.size() > cartPageFirstConditionalValue) {
            setContext("displayed_todays_saving_amount", getElement("couponCodeDiscountAmount").getText());
        } else {
            setContext("displayed_todays_saving_amount", String.valueOf(cartPageFirstConditionalValue));
        }
        getElement("enterCouponCodeInTextBox").sendKeys(couponCode1);
        processScreenshot();
        getElement("clickOnApplyButton").click();
        conditionalWait(ExpectedConditions.visibilityOf(getElement("couponCodeAdded")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Coupon is applied successfully" + getElement("couponCodeAdded").getText() + " " + "Coupon code is: " + couponCode1);
        assertStepExecution(couponCode1, getElement("couponCodeAdded").getText(),
                "Displayed coupon");
        processScreenshot();
    }


    /*
       User clicks on gift option in cart page
    */
    @And("^user clicks on gift option in cart page$")
    public void userClicksOnGiftOptionInCartPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnGiftItem")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("User clicks on gift option in cart page");
        processScreenshot();
        getElement("clickOnGiftItem").click();
    }


    /*
       User clicks on donation option in cart page
    */
    @And("^user clicks on donation option in cart page$")
    public void userClicksOnDonationOptionInCartPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnDonation")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("User clicks on gift option in cart page");
        processScreenshot();
        getElement("clickOnDonation").click();
    }


    /*
       User validates gift item amount is applied in cart page
    */
    @And("^user validates gift item \"([^\"]*)\" is applied in cart page$")
    public void userValidatesGiftItemIsAppliedInCartPage(String giftItemAmount) {
        String flag = "true", giftItemTitle = "Gift item";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("giftItemTitleInCartPage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Gift item title is: " + getElement("giftItemTitleInCartPage").getText() + " " + "The gift item amount is: " + getElement("giftItemAmount").getText());
        assertThat(getElement("giftItemTitleInCartPage").getText()).isEqualTo(giftItemTitle);
        setContext("finalGiftItemAmount", getElement("giftItemAmount").getText());
        setContext("gift_item_applied_flag_cart", flag);
        assertThat(getElement("giftItemAmount").getText()).isEqualTo(giftItemAmount);
        passStepExecution("User validates gift item amount is applied in cart page");
    }


    /*
       User validates donation amount is applied in cart page
    */
    @And("^user validates donation \"([^\"]*)\" is applied in cart page$")
    public void userValidatesDonationIsAppliedInCartPage(String donationAmount) {
        String flag = "true", donationTitle = "Donation";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("donationTitleInCartPage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Donation title is: " + getElement("donationTitleInCartPage").getText() + " " + "The coupon code discount amount is: " + getElement("donationAmount").getText());
        assertThat(getElement("donationTitleInCartPage").getText()).isEqualTo(donationTitle);
        setContext("finalDonationAmount", getElement("donationAmount").getText());
        setContext("donation_applied_flag_cart", flag);
        assertThat(getElement("donationAmount").getText()).isEqualTo(donationAmount);
        passStepExecution("User validates donation amount is applied in cart page");
    }


//    /*
//       User validates as number of products and as products names in cart page
//    */
//    @And("^user validates \"([^\"]*)\" as number of products and \"([^\"]*)\" as products names in cart page$")
//    public void userValidatesAsNumberOfProductsAndAsProductsNamesInCartPage(String cartProductsCounts, String cartProductsNames) {
//        String splitOption = ";", comparisonOrder = "ForwardOrder";
//        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")));
//        List<String> itemListCartProductName = generatingProductDetailsListThroughCount(cartProductsCounts, cartProductsNames, splitOption);
//       logger.info("itemListCartProductName is: " + itemListCartProductName);
//        List<WebElement> productAvailable = getElements("productCountListCartWishListPage");
//       logger.info("No of products are: " + productAvailable.size() + "and " + "Counts from DB:" + cartProductsCounts);
//        assertStepExecution(cartProductsCounts, String.valueOf(productAvailable.size()), "Total product name count is not matching in order confirmation page");
//        productComparisonValidation(productAvailable, itemListCartProductName, comparisonOrder);
//    }


    /*
       User validates products information in cart page
    */
    @Then("^user validates \"([^\"]*)\" as number of products, \"([^\"]*)\" as products names, \"([^\"]*)\" as products ids, \"([^\"]*)\" as products prices, \"([^\"]*)\" as products quantities, \"([^\"]*)\" as products mrps, \"([^\"]*)\" as products offers in cart page$")
    public void userValidatesAsNumberOfProductsAsProductsNamesAsProductsIdsAsProductsPricesAsProductsQuantitiesAsProductsMrpsAsProductsOffersInCartPage(String cartProductsCounts, String cartProductsNames, String cartProductsIds, String cartProductsPrices, String cartProductsIndividualCounts, String cartProductsIndividualMRP, String cartProductOffer) throws InterruptedException {
        String splitOption = ";", comparisonOrder = "ForwardOrder";
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(10000);
        List<String> itemListCartProductName = generatingProductDetailsListThroughCount(cartProductsCounts, cartProductsNames, splitOption);
        logger.info("itemListCartProductName is: " + itemListCartProductName);
        List<WebElement> productAvailable = getElements("productCountListCartPage");

        logger.info("Cart page validation arguments are: " + cartProductsCounts + " " + cartProductsNames + " " + cartProductsIds + " " + cartProductsPrices + " " + cartProductsIndividualCounts + " " + cartProductsIndividualMRP + " " + cartProductOffer);

        if (!(cartProductsIds.equalsIgnoreCase("NA")) && !(cartProductsIndividualMRP.equalsIgnoreCase("NA")) && !(cartProductsPrices.equalsIgnoreCase("NA")) && !(cartProductsIndividualCounts.equalsIgnoreCase("NA"))) {
            List<String> itemListCartProductIds = generatingProductDetailsListThroughCount(cartProductsCounts, cartProductsIds, splitOption);
            logger.info("itemListCartProductName is: " + itemListCartProductIds);
            List<String> itemListCartProductPrices = generatingProductDetailsListThroughCount(cartProductsCounts, cartProductsPrices, splitOption);
            logger.info("itemListCartProductName is: " + itemListCartProductPrices);
            List<String> itemListCartProductIndividualCounts = generatingProductDetailsListThroughCount(cartProductsCounts, cartProductsIndividualCounts, splitOption);
            logger.info("itemListCartProductName is: " + itemListCartProductIndividualCounts);
            List<String> itemListCartProductIndividualMRP = generatingProductDetailsListThroughCount(cartProductsCounts, cartProductsIndividualMRP, splitOption);
            logger.info("itemListCartProductName is: " + itemListCartProductIndividualMRP);
            // List<WebElement> productIdsAvailable = getElements("productIDListCartPage");
            List<WebElement> productPricesAvailable = getElements("productPriceListCartPage");
            List<WebElement> productIndividualQuantitiesAvailable = getElements("productIndividualQuantityListCartPage");
            // For MRP
            ArrayList<String> productMRPList = new ArrayList<String>();
            for (int i = 1; i <= Integer.parseInt(cartProductsCounts); i++) {
                logger.info("productMRPList :" + i);
                List<WebElement> productMRPListWebElements = getDriver().findElements(By.xpath(getLocator("productIndividualMRPListCartPage", String.valueOf(i))));
                if (productMRPListWebElements.size() > 0) {
                    logger.info("productMRPList :" + i);
                    productMRPList.add(productMRPListWebElements.get(0).getText());
                } else
                    productMRPList.add("NA");
            }
            logger.info("No of products are: " + productAvailable.size() + "and " + "Counts from DB:" + cartProductsCounts);
            //  logger.info("Cart products are: " + productAvailable + " IDs " + productIdsAvailable + " Prices " + productPricesAvailable + " Individual Quantities " + productIndividualQuantitiesAvailable + " Individual MRP " + productMRPList);
            logger.info("Cart products are from arguments: " + itemListCartProductName + " IDs " + itemListCartProductIds + " Prices " + itemListCartProductPrices + " Individual Quantities " + itemListCartProductIndividualCounts + " Individual MRPS " + cartProductsIndividualMRP);
            //  logger.info("Product ID from Web: " + numericValuesExtractionMethod(productIdsAvailable.get(0).getText()));
            logger.info("Product Price from Web: " + productPricesAvailable.get(0).getText());
            logger.info("Product Quantity from Web: " + productIndividualQuantitiesAvailable.get(0).getText());
            logger.info("Product MRP from Web: " + productMRPList.get(0));

            //productComparisonNumberExtractValidation(productIdsAvailable, itemListCartProductIds, comparisonOrder);
            //chk1
            productComparisonValidation(productPricesAvailable, itemListCartProductPrices, comparisonOrder);
            productComparisonValidation(productIndividualQuantitiesAvailable, itemListCartProductIndividualCounts, comparisonOrder);
            logger.info("productMRPList size: " + productMRPList.size() + "   itemListCartProductIndividualMRP size: " + itemListCartProductIndividualMRP.size());
            productComparisonValidation(productMRPList, itemListCartProductIndividualMRP, comparisonOrder);

            if ((!(cartProductOffer.equalsIgnoreCase("NA"))) || ((Integer.parseInt(cartProductsCounts) == 1) && (cartProductOffer.equalsIgnoreCase("NA")))) {
                // For OFFER
                List<String> itemListCartProductOffers = generatingProductDetailsListThroughCount(cartProductsCounts, cartProductOffer, splitOption);
                logger.info("itemListCartProductName is: " + itemListCartProductOffers);

                ArrayList<String> productOfferTextList = new ArrayList<String>();
                for (int i = 1; i <= Integer.parseInt(cartProductsCounts); i++) {
                    logger.info("productOfferList :" + i);
                    List<WebElement> productOfferWebelementList = getDriver().findElements(By.xpath(getLocator("productCartEachOffer", String.valueOf(i))));
                    logger.info("productOfferWebelementList size :" + productOfferWebelementList.size());
                    if (productOfferWebelementList.size() > 0) {
                        logger.info("productOfferList :" + i);
                        logger.info(encodingProductListThroughWebElementListThroughDynamicOperator(productOfferWebelementList, "_"));
                        productOfferTextList.add(encodingProductListThroughWebElementListThroughDynamicOperator(productOfferWebelementList, "_"));
                    } else
                        productOfferTextList.add("NA");
                }
                productComparisonValidation(productOfferTextList, itemListCartProductOffers, comparisonOrder);
            }
        }
        assertStepExecution(cartProductsCounts, String.valueOf(productAvailable.size()), "Total product name count is not matching in order confirmation page");
        productComparisonValidation(productAvailable, itemListCartProductName, comparisonOrder);
    }



       /*
       User removes all the products from cart page
       */

    @Then("^user removes all the products from cart page$")
    public void userRemovesAllTheProductsFromCartPage() throws InterruptedException {
        Thread.sleep(8000);
        String itemCount = getElement("itemCountOnCartIconNotification").getText();
        logger.info("Total item shown in cart icon notification=" + itemCount);
        if (Integer.parseInt(itemCount) > 0) {
            //assertStepExecution(true, getOptionalElement("cartIcon") != null, "user clicks on mini cart icon and lands on the cart page");
            jsClick(getElement("cartIcon"));
            waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
            conditionalWait(ExpectedConditions.visibilityOf(getElement("productCountListCartPage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            Thread.sleep(3000);
            List<WebElement> productList = getDriver().findElements(By.xpath(getLocator("productCountListCartPage")));
            logger.info("No of products are: " + productList.size());
            int counter = 1;
            while (productList.size() > cartPageFirstConditionalValue && counter != 10) {
                waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
                getElement("removeProductInCartPage", String.valueOf(1)).click();
                //getElement("clickOnYesButton").click();
                jsClick(getElement("clickYesButton"));
                waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
                Thread.sleep(12000);
                productList = getDriver().findElements(By.xpath(getLocator("productCountListCartPage")));
                logger.info("After deleting 1st product in cart page, no of products are: " + productList.size());
                counter++;
            }
            assertStepExecution(cartPageFirstConditionalValue, productList.size(), "user removes all the products from cart page");
        }
    }


    /*
       User removes coupon in cart page
    */
    @And("^user removes the \"([^\"]*)\" coupon in cart page$")
    public void userRemovesTheCouponInCartPage(String coupon_code) {
        // conditionalWait(ExpectedConditions.elementToBeClickable(getElement("couponCloseIcon",coupon_code)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //  assertStepExecution(true,getOptionalElement("couponCloseIcon",coupon_code)!=null,"Coupon cross button is available");
        getElement("couponCloseIcon", coupon_code).click();
        processScreenshot();
    }


    /*
       User validates coupon code and coupon amount
    */
    @And("^user validates coupon display when coupon code \"([^\"]*)\" with amount \"([^\"]*)\" is \"([^\"]*)\" in cart page$")
    public void

    userValidatesCouponDisplayWhenCouponCodeWithAmountIsInCartPage(String couponCode, String couponAmount, String couponStatus) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        String flag = "true";
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("couponCodeAdded")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        List<WebElement> couponDisplayed = getDriver().findElements(By.xpath(getLocator("couponCodeAdded")));
        logger.info("size of couponDisplayed list is: " + couponDisplayed.size());
        int cartPageSecondConditionalValue = 1;
        String splitOption = "\\.";
        switch (couponStatus) {

            case "Applied":
                // Coupon code check
                if (couponCode.contains(";")) {
                    List<String> couponsInFeatureFile = new ArrayList<>(Arrays.asList(couponCode.split(";")));
                    assertThat(couponsInFeatureFile.size()).describedAs("List size comparison for feature file coupon list and displayed coupon list").
                            isEqualTo(couponDisplayed.size());
                    for (int i = cartPageFirstConditionalValue; i < couponDisplayed.size(); i++) {
                        logger.info("Displayed coupon from list: " + couponDisplayed.get(i).getText() + " Displayed coupon from feature file: " + couponsInFeatureFile.get(i));
                        assertThat(couponDisplayed.get(i).getText()).describedAs("Displayed coupon name on cart page").
                                isEqualTo(couponsInFeatureFile.get(i));
                    }
                } else {
                    assertThat(couponDisplayed.size()).describedAs("List size comparison for feature file coupon list and displayed coupon list").
                            isEqualTo(cartPageSecondConditionalValue);
                    assertThat(couponDisplayed.get(cartPageFirstConditionalValue).getText()).
                            describedAs("Displayed coupon name on cart page").
                            isEqualTo(couponCode);
                }
                setContext("appliedCouponListSize", String.valueOf(couponDisplayed.size()));


                logger.info("Current Displayed savings amount in integer  " + numericValuesExtractionMethod(splitTextWithIndexing(getElement("couponCodeDiscountAmount").getText(), splitOption, cartPageFirstConditionalValue)) +
                        " and Asserted value to be checked  " + numericValuesExtractionMethod(splitTextWithIndexing(getContext("displayed_todays_saving_amount"), splitOption, cartPageFirstConditionalValue))
                        + Integer.parseInt(couponAmount));
                //assertThat(numericValuesExtractionMethod(splitTextWithIndexing(getElement("couponCodeDiscountAmount").getText(), splitOption, cartPageFirstConditionalValue))).describedAs("Displayed coupon amount added to total savings").isEqualTo(numericValuesExtractionMethod(splitTextWithIndexing(getContext("displayed_todays_saving_amount"), splitOption, cartPageFirstConditionalValue)) +
                // Integer.parseInt(couponAmount));
                setContext("todaysFinalSaving", String.valueOf(numericValuesExtractionMethod(splitTextWithIndexing(getElement("couponCodeDiscountAmount").getText(), splitOption, cartPageFirstConditionalValue))));
                setContext("coupon_applied_flag_cart", flag);
                break;
            case "Removed":
                assertThat(couponDisplayed.size()).describedAs("coupon code name list size").
                        isEqualTo(Integer.parseInt(getContext("appliedCouponListSize")) - cartPageSecondConditionalValue);
                setContext("appliedCouponListSize", String.valueOf(couponDisplayed.size()));
                setContext("todaysFinalSaving", String.valueOf(numericValuesExtractionMethod(splitTextWithIndexing(getElement("couponCodeDiscountAmount").getText(), splitOption, cartPageFirstConditionalValue))));
                //setContext("coupon_applied_flag_cart", flag);

                break;
        }


        passStepExecution("User validates coupon code and coupon amount");
    }

    /*
        User validates offer and total amount
     */
    @Then("^user validates \"([^\"]*)\" as discounted amount and \"([^\"]*)\" as total price in cart page$")
    public void userValidatesAsDiscountedAmountInCartPage(String todaysSavingAmount, String totalAmount) {
        String stepDescription = "user validates " + todaysSavingAmount + " as discounted amount and " + totalAmount + " as total price in cart page";
        if (!todaysSavingAmount.equalsIgnoreCase("NA")) {
            conditionalWait(ExpectedConditions.visibilityOf(getElement("todaysSavingDiscountTextCart")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
            logger.info("Todays Savings amount from getText: " + getElement("todaysSavingDiscountTextCart").getText() + " From arg " + todaysSavingAmount);
            assertThat(getElement("todaysSavingDiscountTextCart").getText()).isEqualTo(todaysSavingAmount)
                    .describedAs("Todays Savings amount is not matching");
        } else {
            assertThat(getOptionalElement("todaysSavingDiscountTextCart"))
                    .describedAs("Todays Savings amount section should not display").isNull();
        }
        logger.info("Total amount from getText: " + getElement("totalAmountTextCart").getText() + " From arg " + totalAmount);
        assertThat(getElement("totalAmountTextCart").getText()).describedAs("Total amount is not matching").
                isEqualTo(totalAmount);
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @Then("^user checks \"([^\"]*)\" offer is not applied in cart page$")
    public void userChecksIsNotAppliedInCartPage(String offerName) {

        assertStepExecution(true, getOptionalElement("specificOffer", offerName) == null,
                "user checks " + offerName + " offer is not applied in cart page");
    }


    /*
      User validates offer text, today's savings, total amount
   */

    @And("^user validates displayed \"([^\"]*)\" text, savings amount \"([^\"]*)\" and total amount \"([^\"]*)\" match or unmatch \"([^\"]*)\" on cart page$")
    public void userValidatesDisplayedTextSavingsAmountAndTotalAmountMatchOrUnmatchOnCartPage(String offerText, String savingAmt, String totalAmt, String matchUnmatch) {

        if (matchUnmatch.equalsIgnoreCase("match")) {
            logger.info("displayed offer is: " + getElement("cartOfferText").getText()
                    + "  and provided offer: " + offerText);
            assertThat(getElement("cartOfferText").getText()).describedAs("Selected offer text is not displayed").
                    isEqualTo(offerText);
            if (!savingAmt.equalsIgnoreCase("NA")) {
                conditionalWait(ExpectedConditions.visibilityOf(getElement("todaysSavingDiscountTextCart")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                logger.info("Todays Savings amount from getText: " + getElement("todaysSavingDiscountTextCart").getText() + " From arg " + savingAmt);
                assertThat(getElement("todaysSavingDiscountTextCart").getText()).describedAs("Todays Savings amount is not matching").
                        isEqualTo(savingAmt);
            } else {
                assertThat(getOptionalElement("todaysSavingDiscountTextCart").getText()).
                        describedAs("Todays Savings amount section should not display").
                        isEqualTo(null);
            }
            logger.info("Total amount from getText: " + getElement("totalAmountTextCart").getText() + " From arg " + totalAmt);
            assertThat(getElement("totalAmountTextCart").getText()).describedAs("Total amount is not matching").
                    isEqualTo(totalAmt);
        } else {
            logger.info("displayed offer is: " + getElement("cartOfferText").getText()
                    + "  and provided offer: " + offerText);
            assertThat(getElement("cartOfferText").getText()).describedAs("Selected offer text is not displayed").
                    isNotEqualTo(offerText);
            if (!savingAmt.equalsIgnoreCase("NA")) {
                conditionalWait(ExpectedConditions.visibilityOf(getElement("todaysSavingDiscountTextCart")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                logger.info("Todays Savings amount from getText: " + getElement("todaysSavingDiscountTextCart").getText() + " From arg " + savingAmt);
                assertThat(getElement("todaysSavingDiscountTextCart").getText()).describedAs("Todays Savings amount is not matching").
                        isNotEqualTo(savingAmt);
            } else {
                assertThat(getOptionalElement("todaysSavingDiscountTextCart").getText()).
                        describedAs("Todays Savings amount section should not display").
                        isEqualTo(null);
            }
            logger.info("Total amount from getText: " + getElement("totalAmountTextCart").getText() + " From arg " + totalAmt);
            assertThat(getElement("totalAmountTextCart").getText()).describedAs("Total amount is not matching").
                    isNotEqualTo(totalAmt);
        }

        passStepExecution(" User validates offer text, today's savings, total amount");
    }


    /*
     User clicks on View more offer link
  */
    @And("^user clicks on view all offers$")
    public void userClicksOnViewAllOffers() {
        assertStepExecution(true, getElement("viewMoreLink").isDisplayed(),
                "View more offers link not present");
        getElement("viewMoreLink").click();
    }


    /*
     User selects another offer and validates offer text, today's savings, total amount
  */
    @Then("^user selects offer with index \"([^\"]*)\" and validates the offer with earlier offer \"([^\"]*)\"  text, savings amount \"([^\"]*)\" and total amount \"([^\"]*)\"$")
    public void userSelectsOfferWithIndexAndValidatesTheOfferWithEarlierOfferTextSavingsAmountAndTotalAmount(String offerIndex, String earlierOffer, String earlierSavingAmt, String earlierTotalAmt) {
        getElement("offerToSelectOnCart", offerIndex).click();
        assertStepExecution(true, getElement("offerApplyClick").isDisplayed(),
                "Apply button is not displayed");
        getElement("offerApplyClick").click();

        userValidatesDisplayedTextSavingsAmountAndTotalAmountMatchOrUnmatchOnCartPage(earlierOffer, earlierSavingAmt, earlierTotalAmt, "unmatch");
    }

    @Then("^user validates the offer applied notify massage to be display$")
    public void userValidatesTheOfferAppliedNotifyMassageToBeDisplay() {

        assertThat(getElement("offerMsg").isDisplayed())
                .describedAs("Offer Applied text should be display").isEqualTo(true);
        String appliedOffers = getElement("appliedOffer").getText().trim();
        assertThat(getContext("pdpOfferNames").contains(appliedOffers))
                .describedAs("applied offer details should match");
    }

    @And("^user validates delivery options for pincode text and change link should display in cart page$")
    public void userValidatesDeliveryOptionsForTextAndChangeLinkShouldDisplayInCartPage() {
        String stepDescription = "user Validates Delivery Options For Text And Change Link Should Display in cart page";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("changeLinkCartPage")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        String chanegText = getElement("changeLinkCartPage").getText().trim();
        String deliveryText = getElement("deliveryTxt").getText().trim().split("\n" + chanegText)[0];
        logger.info("Delivery1 details :- " + deliveryText);
        assertThat(getContext("updatedPincode")).isEqualToIgnoringCase(deliveryText).describedAs("Delivery Options for Pincode should display in cart page");
        assertThat(getElement("changeLinkCart").isDisplayed()).describedAs("Change link should display in cart page").isEqualTo(true);
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user clicks on change link and provides \"([^\"]*)\" correct pincode in cart page$")
    public void userClicksOnChangeLinkAndProvidesInCartPage(String stockAvailablePincode) throws InterruptedException {
        String stepDescription = "user Clicks On Change Link And Provides";
        getElement("changeLinkCart").click();
        assertThat(getElement("pinCodeHome").getText().
                equals(getContext("pinCodeHome"))).describedAs("Out of stock pincode should display");

        assertThat(getElement("crossBtn").isDisplayed()).isEqualTo(true).describedAs("Cross button should display");
        assertThat(getElement("pinCodeHome").getAttribute("placeholder").trim()).isEqualTo("Enter pincode").describedAs("Default text Enter pincode should display");
        assertThat(getElement("pinCodeText").getText().contains("Enter a pincode")).describedAs("Enter a pincode text should display");

        Thread.sleep(5000);

        jsClear(getElement("pinCodeHome"));
        getElement("pinCodeHome").sendKeys(stockAvailablePincode);
        assertThat(getElement("pinCodeSubmit").isDisplayed()).describedAs("Apply button should display").isEqualTo(true);
        getElement("pinCodeSubmit").click();
        assertThat(getElement("pinCodecart").getText().equals(stockAvailablePincode)).describedAs("Updated pincode should display in cart");

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user validates there will be a radio button and only one delivery mode is selected in cart page$")
    public void userValidatesThereWillBeARadioButtonAndOnlyOneDeliveryModeIsSelectedInCartPage() {
        String stepDescription = "user Validates There Will Be A Radio Button And Only One Delivery ModeIsSelectedInCartPage";
        totalRadioBtnCart = getElements("radioBtn").size();
        assertThat(totalRadioBtnCart <= 3).isEqualTo(true).describedAs("Radio button count should match ");

        //assertThat(getDriver().findElement(By.id("homeDelivery")).isSelected()).describedAs("Standard delivery is selected").isEqualTo(true);
        if (getDriver().findElement(By.id("threeHourDelivery")).isSelected()) {

            assertThat(getDriver().findElement(By.id("threeHourDelivery")).isSelected()).isEqualTo(true).describedAs("ZIP delivery option is selected");

        } else if (getDriver().findElement(By.id("storePickup")).isSelected()) {
            assertThat(getDriver().findElement(By.id("storePickup")).isSelected()).isEqualTo(true).describedAs("Store pick up delivery option is selected");

        } else {
            assertThat(getDriver().findElement(By.id("homeDelivery")).isSelected()).isEqualTo(true).describedAs("home Delivery option is selected");

        }

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user change the delivery option \"([^\"]*)\" in cart page$")
    public void userChangeTheDeliveryOptionInCartPage(String deliveryOptions) {
        String stepDescription = "user Change The Delivery Option In Cart Page";
        assertThat(getElement("deliveryOptCart", deliveryOptions).isDisplayed()).isEqualTo(true).describedAs("Delivery options should diaply");
        getElement("deliveryOptCart", deliveryOptions).click();

        if (getDriver().findElement(By.id("threeHourDelivery")).isSelected()) {

            assertThat(getDriver().findElement(By.id("threeHourDelivery")).isSelected()).isEqualTo(true).describedAs("ZIP delivery option is selected");
            String deliverOpt = getElement("deliveryOpt").getText().trim();
            setContext("DeliveryDetails", deliverOpt);
        } else if (getDriver().findElement(By.id("storePickup")).isSelected()) {
            assertThat(getDriver().findElement(By.id("storePickup")).isSelected()).isEqualTo(true).describedAs("Store pick up delivery option is selected");
            String deliverOpt = getElement("deliveryOpt").getText().trim();
            setContext("DeliveryDetails", deliverOpt);
        } else {
            assertThat(getDriver().findElement(By.id("homeDelivery")).isSelected()).isEqualTo(true).describedAs("home Delivery option is selected");
            String deliverOpt = getElement("deliveryOpt").getText().trim();
            setContext("DeliveryDetails", deliverOpt);
        }
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user validates \"([^\"]*)\" should display for the product \"([^\"]*)\" in cart page$")
    public void userValidatesShouldDisplayForTheProduct(String errorMsg, String cartProductName) {
        totalProductCart = getElements("productTile").size();
        for (int productInfo = 0; productInfo == totalProductCart; productInfo++) {
            if (getElement("productOnCartPage", cartProductName).isDisplayed()) {
                String unavailableProductMsg = getElements("unavailableDeliveryMsg", cartProductName).get(productInfo).getText().trim();
                setContext("unavailableErrorMsg", unavailableProductMsg);
                assertStepExecution(unavailableProductMsg, errorMsg, "Error massage should match in product line item");
            }
        }

    }

    @And("^user validates \"([^\"]*)\" should display below delivery details$")
    public void userValidatesShouldDisplayBelowDeliveryDetails(String errorMsg) throws InterruptedException {
        if (getContext("unavailableErrorMsg").equals(true)) {
            String deliveryErrorMsg = getElement("deliveryErrorMsg").getText().trim();
            assertStepExecution(deliveryErrorMsg, errorMsg, "Error msg should display below zip delivery details");
            Thread.sleep(5000);
        }
    }

    @And("^user validates \"([^\"]*)\" text, \"([^\"]*)\" and Select Another Store link should display$")
    public void userValidatesTextAndSelectAnotherStoreLinkShouldDisplay(String deliveryOptionText, String storeName) {

        String storePickUpText = getElement("availableForPickup").getText().trim();
        String picupStoreName = getElement("cartStoreName").getText().trim();
        logger.info("Store name :- " + picupStoreName);

        assertThat(storePickUpText).isEqualTo(deliveryOptionText).describedAs("Delivery options should match");
        assertThat(picupStoreName).containsIgnoringCase(storeName).describedAs("Store name should match");
        assertThat(getElement("selectAnotherStoreLink").isDisplayed()).isEqualTo(true).describedAs("Select another store should display");

    }

    @And("^user change the store \"([^\"]*)\" by clicks on radio button$")
    public void userClicksOnSelectAnotherStoreLinkAndChangeTheByClicksOnRadioButton(String storeName) {

        conditionalWait(ExpectedConditions.visibilityOf(getElement("storeNamePopUP", storeName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("storeNamePopUP", storeName).isDisplayed()).isEqualTo(true).describedAs("Store name should display");
        assertThat(getElement("storeRadioBtn", storeName).isDisplayed()).isEqualTo(true).describedAs("Store radio button should display");
        getElement("storeRadioBtn", storeName).click();
    }


    @And("^user clicks on Select Another Store link and validates radio button, 'Select Store Location' text and subtext 'Select a delivery location to see available delivery options' should display$")
    public void userClicksOnSelectAnotherStoreLinkAndValidatesRadioButtonSelectStoreLocationTextAndSubtextSelectADeliveryLocationToSeeAvailableDeliveryOptionsShouldDisplay() {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("selectAnotherStoreLink")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("selectAnotherStoreLink").click();
        String locationText = getElement("locationText").getText().trim();
        String locationSubText = getElement("locationSubText").getText().trim();

        assertThat(locationSubText).isEqualTo("Select a delivery location to see available delivery options").describedAs("Select Store Location text should match");
        assertThat(locationText).isEqualTo("Select Store Location").describedAs("Select a delivery location to see available delivery options text should match");
    }

    @And("^user removed out of stock \"([^\"]*)\" product to proceed$")
    public void userRemovedOutOfStockProductToProceed(String outOfStockProduct) {
        String stepDescription = "user removed out of stock product to proceed";
        //assertThat(getElement("unavailableDeliveryMsg", outOfStockProduct).isDisplayed()).describedAs("Error msg should display").isEqualTo(true);
        //getElement("removeProductInCartPage", outOfStockProduct).click();
        jsClick(getElement("removeProductInCartPage", outOfStockProduct));
        getElement("removeCartItemYes").click();
        assertThat(getOptionalElement("unavailableDeliveryMsg", outOfStockProduct) == null).isEqualTo(true).describedAs("Error msg should not be display");
        passStepExecution(stepDescription + " :: Passed \n");
    }


    @And("^user stores product details in cart page$")
    public void userStoresProductDetailsInCartPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (getOptionalElement("closeCartPopup") != null) {
            getElement("closeCartPopup").click();
        }
        int totalProducts = getElements("productCountListCartPage").size();
        setContext("finalProductDetailsCount", String.valueOf(totalProducts));
        for (int product = 0; product < totalProducts; product++) {
            HashMap<String, String> mapToAdd = new HashMap<>();
            mapToAdd.put("productName", getElements("productCountListCartPage").get(product).getText());
            // mapToAdd.put("productId", getElements("productIDListCartPage").get(product).getText());
            mapToAdd.put("productQty", getElements("productIndividualQuantityListCartPage").get(product).getText());

            if (getOptionalElement("offerMsg") == null) {
                logger.info("price on cart: " + getElements("productPriceListCartPage").get(product).getText());
                logger.info("exact price entered new price: " + getElements("productPriceListCartPage").get(product).getText());
                mapToAdd.put("productPrice", getElements("productPriceListCartPage").get(product).getText());
                //mapToAdd.put("todaysSaving",getElements("couponCodeDiscountAmount").get(product).getText());
            } else {
                logger.info("exact price entered old price: " + getElements("oldPrice").get(product).getText());
                mapToAdd.put("productPrice", getElements("oldPrice").get(product).getText());
                //    mapToAdd.put("productPrice", getElements("productPriceListCartPage").get(product).getText());
            }
            productMap.add(mapToAdd);
        }
        logger.info("Cart Page Product Details : " + productMap);
    }

    /*
       User removes all the products from cart page
    */
    @Then("^user removes all the products from cart page with message \"([^\"]*)\"$")
    public void userRemovesAllTheProductsFromCartPageWithMessage(String cartProductRemoveText) {
        List<WebElement> productAvailable = getElements("productCountListCartPage");
        logger.info("No of products are: " + productAvailable.size());
        for (WebElement productAvailableEach : productAvailable) {
            getElement("removeProductInCartPage", String.valueOf((productAvailable.indexOf(productAvailableEach)) + 1)).click();
            getElement("cartClickOnProceedButton").click();
            assertThat(getElement("cartProductRemoveMessage").getText()).describedAs("Product removal pop up text").isEqualToIgnoringCase(cartProductRemoveText);
        }
        passStepExecution("User removes all the products from cart page");
    }

    /*
         User removes the product from cart
       */
    @And("^user removes the product from cart \"([^\"]*)\" from cart page with message \"([^\"]*)\"$")
    public void userRemovesTheProductFromCartFromCartPageWithMessage(String removalCartProduct1, String cartProductRemovalMessage) {
        logger.info("The Product to be removed is: " + getElement("productOnCartPage", removalCartProduct1).getText() + " From Database is: " + removalCartProduct1);
        assertThat(getElement("productOnCartPage", removalCartProduct1).getText()).describedAs("Remove product not matched").isEqualToIgnoringCase(removalCartProduct1);
        getElement("removeProductIcon", removalCartProduct1).click();
        getElement("cartClickOnProceedButton").click();
        assertThat(getElement("cartProductRemoveMessage").getText()).describedAs("Remove product not matched").isEqualToIgnoringCase(cartProductRemovalMessage);
        passStepExecution("User removes the product from cart");
    }

    @And("^user validates \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" in cart page$")
    public void userValidatesInCartPage(String extendedwarrantyName, String extendedWarrantyPrice, String extendedWarrantyProductId, String extendedWarrantyQty) {
        String stepDescription = "user Validates extended warranty In Cart Page";
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));

        String extendedWarntPrice = getElement("extendedWarntPrice").getText().trim();
        String extendedWarntProID = getElement("extendedWarntProductId").getText().trim().replace("Product Id: ", "");
        String extendedWarntQty = getElement("extendedWarntQty").getText().trim();

        logger.info("extended Warranty product ID :- " + extendedWarntProID);
        logger.info("extended Warranty Price :- " + extendedWarntPrice);
        logger.info("extended Warranty Qty :- " + extendedWarntQty);

        assertThat(getElement("productOnCartPage", extendedwarrantyName).isDisplayed()).describedAs("Extended Warranty Name should match").isEqualTo(true);
        assertThat(extendedWarntPrice).describedAs("Extended Warranty price should match").isEqualTo(extendedWarrantyPrice);
        assertThat(extendedWarntProID).describedAs("Extended Warranty product id should match").isEqualTo(extendedWarrantyProductId);
        assertThat(extendedWarntQty).describedAs("Extended Warranty product QTY should match").isEqualTo(extendedWarrantyQty);
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user validates exchange product details in cart page$")
    public void userValidatesExchangeProductDetailsInCartPage() {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("exchanegProName")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("exchanegProName").getText().trim()).containsIgnoringCase(getContext("exchangeProName")).describedAs("Exchange Product Name should match");
        assertThat(getElement("exchagePrice").getText().trim()).containsIgnoringCase(getContext("fixedExValue")).describedAs("Exchange Product price should match");
        assertThat(getElement("exchangetext").getText().trim()).containsIgnoringCase("Your old mobile will be examined before confirming exchange during delivery.").describedAs("Massage should display");
    }


    @And("^user validates the Pay on Delivery tag should display for POD eligible individual product tiles in cart page$")
    public void uservalidatesthePayonDeliverytagshoulddisplayforPODeligibleindividualproducttilesincartpage() {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("podTag", getContext("podProductName"))), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        totalProductCart = getElements("cartProductTiltle").size();
        for (int product = 0; product <= totalProductCart; product++) {
            assertStepExecution(true, getElement("podTag", getContext("podProductName")).isDisplayed(), "POD tag should display in cart");
            String podProductName = getElement("podTag", getContext("podProductName")).getText().trim();
            setContext("podProducts", podProductName);
        }
    }


    @And("^user validates \"([^\"]*)\" as number of products in cart page$")
    public void userValidatesAsNumberOfProductsInCartPage(String cartProductCount) throws InterruptedException {
        Thread.sleep(5000);
        setContext("cartProductsCount", cartProductCount);
        ArrayList<WebElement> cartProductCountWeb = new ArrayList<>(getElements("productCountListCartPage"));
        assertThat(cartProductCountWeb.size()).describedAs("Product count on cart page is matched.")
                .isEqualTo(Integer.parseInt(cartProductCount));
        passStepExecution("Product count validation on cart is done.");

    }

    @And("^user validates \"([^\"]*)\" as products names in cart page$")
    public void userValidatesAsProductsNamesInCartPage(String cartProductNames) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("productCountListCartPage"));
        assertThat(productDetail.size()).describedAs("Products are more than 1").isGreaterThan(0);
        if (cartProductNames.contains(";")) {
            String[] productNamefromExamples = cartProductNames.split(";");
            for (int i = 0; i < productNamefromExamples.length; i++) {
                String productNameFromWeb = productDetail.get(i).getText();
                logger.info("The product name from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("Cart product name from web and examples are matched.").isEqualTo(productNamefromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText()).describedAs("Cart product name from web and examples are matched.").isEqualTo(cartProductNames);
        }
        passStepExecution("Products names on cart is verified");


    }

    @And("^user validates \"([^\"]*)\" as products ids in cart page$")
    public void userValidatesAsProductsIdsInCartPage(String cartProductId) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> productIds = new ArrayList<>(getElements("productIDListCartPage"));
        assertThat(productIds.size()).describedAs("No. of product should be greater than zero").isGreaterThan(0);
        if (cartProductId.contains(";")) {
            String[] productIdFromExamples = cartProductId.split(";");

            for (int i = 0; i < productIdFromExamples.length; i++) {
                String productIdFromWeb = productIds.get(i).getText().replaceAll("\\D", "");
                logger.info("The product in cart are" + productIdFromWeb);
                assertThat(productIdFromWeb).describedAs("Product id from web and from examples are matching").isEqualTo(productIdFromExamples[i]);

            }

        } else {
            String productIdFromWeb = productIds.get(0).getText().replaceAll("\\D", "");
            logger.info("The product in cart are" + productIdFromWeb);
            assertThat(productIdFromWeb).describedAs("Product id from web and from examples are matching").isEqualTo(cartProductId);

        }
        passStepExecution("All productId from web and examples are matched on cart");

    }

    @And("^user validates \"([^\"]*)\" as products prices in cart page$")
    public void userValidatesAsProductsPricesInCartPage(String cartProductPrice) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> cartProductPriceListFromWeb = new ArrayList<>(getElements("productPriceListCartPage"));
        assertThat(cartProductPriceListFromWeb.size()).describedAs("Price should be greater than zero").isGreaterThan(0);
        if (cartProductPrice.contains(";")) {
            String[] productPrice = cartProductPrice.split(";");
            for (int i = 0; i < productPrice.length; i++) {
                String cartProductPriceFromWeb = cartProductPriceListFromWeb.get(i).getText();
                assertThat(cartProductPriceFromWeb).describedAs("Cart product prices from web and from examples are matching").isEqualTo(productPrice[i]);
            }

        } else {
            String cartProductPriceFromWeb = cartProductPriceListFromWeb.get(0).getText();
            assertThat(cartProductPriceFromWeb).describedAs("Cart product prices from web and from examples are matching").isEqualTo(cartProductPrice);
        }

        passStepExecution("All price from web and examples are matched on cart");


    }


    @And("^user validates \"([^\"]*)\" as products quantities in cart page$")
    public void userValidatesAsProductsQuantitiesInCartPage(String cartIndividualProductQuantity) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> cartIndividualQuantityFromWeb = new ArrayList<>(getElements("productIndividualQuantityListCartPage"));
        assertThat(cartIndividualQuantityFromWeb.size()).isGreaterThan(0);
        if (cartIndividualProductQuantity.contains(";")) {
            String[] cartIndividualProductQuantityFromExamples = cartIndividualProductQuantity.split(";");
            for (int i = 0; i < cartIndividualProductQuantityFromExamples.length; i++) {
                String cartIndividualQuantity = cartIndividualQuantityFromWeb.get(i).getText();
                assertThat(cartIndividualQuantity).isEqualTo(cartIndividualProductQuantityFromExamples[i]).describedAs("Individual quantity matched on cart page");
            }
        } else {
            assertThat(cartIndividualQuantityFromWeb.size()).isEqualTo(Integer.parseInt(cartIndividualProductQuantity)).describedAs("Individual quantity matched on cart page");
        }
        passStepExecution("Individual cart product quantity verified.");

    }


    @And("^user validates \"([^\"]*)\" in cart page$")
    public void userValidatesInCartPage(String cartProductsIndividualMRP) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> cartProductsIndividualMRPFromWebList = new ArrayList<>(getElements("productsMRP"));
        assertThat(cartProductsIndividualMRPFromWebList.size()).describedAs("Product mrp is present on cart").isGreaterThan(0);
        if (cartProductsIndividualMRP.contains(";")) {
            String[] cartProductsIndividualMRPFromExamplesList = cartProductsIndividualMRP.split(";");
            for (int i = 0; i < cartProductsIndividualMRPFromExamplesList.length; i++) {
                String cartProductsIndividualMRPFromWeb = cartProductsIndividualMRPFromWebList.get(i).getText();
                String cartProductIndividualMRPFromExample = cartProductsIndividualMRPFromExamplesList[i];
                assertThat(cartProductsIndividualMRPFromWeb).isEqualTo(cartProductIndividualMRPFromExample).describedAs("Cart individual mrp matched");

            }


        } else {
            assertThat(cartProductsIndividualMRPFromWebList.get(0).getText()).isEqualTo(cartProductsIndividualMRP).describedAs("Cart individual mrp matched");
        }
    }

    @And("user clicks on cross icon on cart page")
    public void userClicksOnCrossIconOnCartPage() throws InterruptedException {
        getElement("cartCrossIcon").click();
        Thread.sleep(10000);
    }

    @And("user clicks on yes button on the cart page")
    public void userClicksOnYesButtonOnTheCartPage() throws InterruptedException {
        //getElement("clickYesButton").click();
        jsClick(getElement("clickYesButton"));
        Thread.sleep(5000);
    }

    @And("user validates cart is empty")
    public void userValidatesCartIsEmpty() {
        assertStepExecution(true, getElement("cartIsEmptyText") != null, "user validates cart is empty");
    }

    @And("user lands on cart summary page {string}")
    public void userLandsOnCartSummaryPage(String cartSummaryValidationText) {
        assertStepExecution(cartSummaryValidationText, getElement("cartSummaryValidation", cartSummaryValidationText).getText(), "User lands on cart summary page and validates");
    }

    @And("user validates first cart product id in cart summary page")
    public void userValidatesFirstCartProductIdInCartSummaryPage() {
        String productId = getContext("ProductIdFromMiniCartModalPopUp");
        String firstProductId = getElement("firstProductIdFromCart").getText();
        String firstProductIdFromCart = firstProductId.replaceAll("[^0-9]", "");
        logger.info("The first product Id in Cart is=" + firstProductIdFromCart);
        assertStepExecution(productId, firstProductIdFromCart, "User validates the first product id in cart summary");

    }

    @And("user validates second product id {string} in cart summary page")
    public void userValidatesSecondProductIdInCartSummaryPage(String secondCartProductId) {
        String secondProductId = getElement("secondProductIdFromCart").getText();
        String secondProductIdFromCart = secondProductId.replaceAll("[^0-9]", "");
        logger.info("The second product Id in Cart is=" + secondProductIdFromCart);
        assertStepExecution(secondCartProductId, secondProductIdFromCart, "User validates the second product id in cart summary");
    }

    @And("user clicks on change link option on cart page")
    public void userClicksOnChangeLinkOptionOnCartPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("changeLinkCart")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        jsClick(getElement("changeLinkCart"));
        assertStepExecution(true, getOptionalElement("changeLinkCart") != null, "User clicks on change link option on cart page");

    }

    @And("user stores selected delivery option in cart page")
    public void userStoresSelectedDeliveryOptionInCartPage() {
        List<WebElement> deliveryOptionList = getDriver().findElements(By.xpath("//ul[@class='list']//input[@name='fulfilment']"));
        String deliveryOption = "";
        for (WebElement option : deliveryOptionList) {
            if (option.isSelected()) {
                deliveryOption = option.getAttribute("id");
                break;
            }
        }
        setContext("selectedDeliveryOption", deliveryOption);
        assertStepExecution(true, deliveryOption.length() > 0, "user stores selected delivery option in cart page");
    }

    @And("user validates {string} as products offers in cart page")
    public void userValidatesAsProductsOffersInCartPage(String cartProductsIndividualOffer) {
        String comparisonOrder = "ForwardOrder";
        ArrayList<String> productOfferTextList = new ArrayList<String>();
        for (int i = 1; i <= Integer.parseInt(getContext("cartProductsCount")); i++) {
            logger.info("productOfferList :" + i);
            List<WebElement> productOfferWebelementList = getDriver().findElements(By.xpath(getLocator("productCartEachOffer", String.valueOf(i))));
            logger.info("productOfferWebelementList size :" + productOfferWebelementList.size());
            if (productOfferWebelementList.size() > 0) {
                logger.info("productOfferList :" + i);
                logger.info(encodingProductListThroughWebElementListThroughDynamicOperator(productOfferWebelementList, "_"));
                productOfferTextList.add(encodingProductListThroughWebElementListThroughDynamicOperator(productOfferWebelementList, "_"));
            } else
                productOfferTextList.add("NA");
        }
        productComparisonValidation(productOfferTextList, productOfferTextList, comparisonOrder);

    }

    @And("user clicks on free ZIP delivery radio button")
    public void userClicksOnFreeZIPDeliveryRadioButton() throws InterruptedException {
        assertStepExecution(true, getElement("zipRadioBtn") != null, "Free ZIP delivery radio button should display");
        jsClick(getElement("zipRadioBtn"));
        Thread.sleep(5000);
    }

    /**
     * This method is used to validate remove or moveToWishList buttons are present in cart page
     **/
    @And("user validates {string} button is present for a product in cart page")
    public void userValidatesButtonIsPresentForAProductInCartPage(String buttonName) throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getDriver().findElements(By.xpath(getLocator("removeOrMoveToMyWishListButton", buttonName))).size() > 0,
                "user validates " + buttonName + " button is present for a product in cart page");
    }

    /**
     * This method is used to validate whether offer is showing or not for a product in cart page
     **/
    @And("user validates product level offer is applied in cart page")
    public void userValidatesProductLevelOfferIsAppliedInCartPage() throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getDriver().findElements(By.xpath(getLocator("productLevelOffer"))).size() > 0,
                "user validates product level offer is applied in cart page");
    }

    @And("^user validates the total offer applied notify massage to be display$")
    public void userValidatesTheTotalOfferAppliedNotifyMassageToBeDisplay() {
        assertThat(getElement("offerMsg").isDisplayed()).describedAs("Total offers applied text is not displayed").isEqualTo(true);
        logger.info("Total " + getElement("offerMsg").getText());
        assertThat(getElement("viewAllOffersLinkPaymentPage").isDisplayed()).describedAs("View All offers link is not displayed").isEqualTo(true);

    }

    @And("user clicks on Home Delivery radio button")
    public void userClicksOnHomeDeliveryRadioButton() throws InterruptedException {
        Thread.sleep(5000);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("homeDeliveryRadioButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("homeDeliveryRadioButton").click();
    }

    /**
     * This method is used to validate whether wishlist section is visible or not under empty cart
     **/
    @And("user validates your wishlist section is visible under cart page")
    public void userValidatesYourWishlistSectionIsVisibleUnderCartPage() throws InterruptedException {
        Thread.sleep(8000);
        //scrollToWebelement(getElement("wishlistProducts"));
        assertStepExecution(true, getElement("wishlistProducts") != null,
                "user validates your wishlist section is visible under empty cart");
        Thread.sleep(2000);
    }

    /**
     * This method is used to validate wishlist products are displayed in horizontal mode
     **/
    @And("user validates wishlist products are displayed in horizontal mode {string}")
    public void userValidatesWishlistProductsAreDisplayedInHorizontalMode(String cssProperty) throws InterruptedException {
        Thread.sleep(3000);
        String cssAttribute = getElement("wishlistSection").getCssValue("display");
        assertStepExecution(true, cssAttribute.equals(cssProperty),
                "user validates wishlist products are displayed in horizontal mode");
        Thread.sleep(2000);
    }

    /**
     * This method is used to validate all wishlist products have images displayed
     **/
    @And("user validates products images of wishlist products are visible in cart page")
    public void userValidatesProductsImagesOfWishlistProductsAreVisibleInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(6, getDriver().findElements(By.xpath(getLocator("wishlistProductsImages"))).size(),
                "user validates products images of wishlist products are visible");
    }

    /**
     * This method is used to validate all wishlist products have prices displayed
     **/
    @And("user validates products prices of wishlist products are visible in cart page")
    public void userValidatesProductsPricesOfWishlistProductsAreVisibleInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(6, getDriver().findElements(By.xpath(getLocator("wishlistProductsPrices"))).size(),
                "user validates products prices of wishlist products are visible");
    }

    /**
     * This method is used to validate all wishlist products have title displayed
     **/
    @And("user validates products title of wishlist products are visible in cart page")
    public void userValidatesProductsTitleOfWishlistProductsAreVisibleInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(6, getDriver().findElements(By.xpath(getLocator("wishlistProductsTitle"))).size(),
                "user validates products title of wishlist products are visible");
    }

    /**
     * This method is used to validate all wishlist products contains inclusive of all taxes
     **/
    @And("user validates products prices contains inclusive of all taxes text under wishlist products in cart page")
    public void userValidatesProductsPricesContainsInclusiveOfAllTaxesTextUnderWishlistProductsInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(6, getDriver().findElements(By.xpath(getLocator("wishlistProductsINCL"))).size(),
                "user validates products prices contains inclusive of all taxes text under wishlist products in cart page");
    }

    /**
     * This method is used to validate all wishlist products contains mrp with strike off text under wishlist products
     **/
    @And("user validates products contains mrp with strike off text under wishlist products in cart page")
    public void userValidatesProductsContainsMrpWithStrikeOffTextUnderWishlistProductsInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(6, getDriver().findElements(By.xpath(getLocator("wishlistProductsMrpStrikeOff"))).size(),
                "user validates products contains mrp with strike off text under wishlist products in cart page");
    }

    /**
     * This method is used to validate all wishlist products contains add to cart button
     **/
    @And("user validates add to cart button is present under all wishlist products in cart page")
    public void userValidatesAddToCartButtonIsPresentUnderAllWishlistProductsInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(6, getDriver().findElements(By.xpath(getLocator("wishlistProductsAddToCartButtons"))).size(),
                "user validates add to cart button is present under all wishlist products in cart page");
    }

    /**
     * This method is used to validate products images of wishlist products are visible in cart page for non empty cart
     **/
    @And("user validates products images of wishlist products are visible in cart page for non empty cart")
    public void userValidatesProductsImagesOfWishlistProductsAreVisibleInCartPageForNonEmptyCart() {
        List<WebElement> elementsList = getDriver().findElements(By.xpath("//div[contains(@class,'swiper-slide wish-cart-main-item')]"));
        for (WebElement elem : elementsList) {
            assertStepExecution(true, elem.findElement(By.xpath("//div[@class='wish-cart-img']//img")) != null,
                    "user validates products images of wishlist products are visible in cart page for non empty cart");
        }
    }

    /**
     * This method is used to validate products title of wishlist products are visible in cart page for non empty cart
     **/
    @And("user validates products title {string} of wishlist products are visible in cart page for non empty cart")
    public void userValidatesProductsTitleOfWishlistProductsAreVisibleInCartPageForNonEmptyCart(String productList) throws InterruptedException {
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,650)");
        List<String> prodList = generatingProductDetailsListThroughCount("5", productList, ";");
        logger.info("ProdList is " + prodList);
        Thread.sleep(5000);
        //conditionalWait(ExpectedConditions.visibilityOf(getDriver().findElement(By.xpath("//div[contains(@class,'swiper-slide wish-cart-main-item')]"))), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        List<WebElement> elementsList = getDriver().findElements(By.xpath("//div[contains(@class,'swiper-slide wish-cart-main-item')]"));
        for (int i = 0; i < elementsList.size(); i++) {
            if (i == (elementsList.size() - 1)) {
                getElement("forwardArrowOnWishlist").click();
                Thread.sleep(3000);
            }
            assertStepExecution(prodList.get(i), getElement("productsListForNonEmptyCart", (String.valueOf(i + 1))).getText(),
                    "user validates products title of wishlist products are visible in cart page for non empty cart");
        }
    }

    /**
     * This method is used to validate products prices of wishlist products are visible in cart page for non empty cart
     **/
    @And("user validates products prices {string} of wishlist products are visible in cart page for non empty cart")
    public void userValidatesProductsPricesOfWishlistProductsAreVisibleInCartPageForNonEmptyCart(String productPrices) throws InterruptedException {
        getElement("previousArrowOnWishlist").click();
        List<String> prodPrices = generatingProductDetailsListThroughCount("5", productPrices, ";");
        for (int i = 0; i < prodPrices.size(); i++) {
            if (i == (prodPrices.size() - 1)) {
                getElement("forwardArrowOnWishlist").click();
                Thread.sleep(3000);
            }
            assertStepExecution(prodPrices.get(i), getElement("productspricesForNonEmptyCart", (String.valueOf(i + 1))).getText(),
                    "user validates products prices of wishlist products are visible in cart page for non empty cart");
        }
    }

    /**
     * This method is used to validate products prices contains inclusive of all taxes text under wishlist products in cart page for non empty cart
     **/
    @And("user validates products prices contains inclusive of all taxes {string} text under wishlist products in cart page for non empty cart")
    public void userValidatesProductsPricesContainsInclusiveOfAllTaxesTextUnderWishlistProductsInCartPageForNonEmptyCart(String inclText) throws InterruptedException {
        getElement("previousArrowOnWishlist").click();
        List<WebElement> elementsList = getDriver().findElements(By.xpath("//div[contains(@class,'swiper-slide wish-cart-main-item')]"));
        for (int i = 0; i < elementsList.size(); i++) {
            if (i == (elementsList.size() - 1)) {
                getElement("forwardArrowOnWishlist").click();
                Thread.sleep(3000);
            }
            assertStepExecution(inclText, getElement("productInclForNonEmptyCart", (String.valueOf(i + 1))).getText(),
                    "user validates products prices contains inclusive of all taxes text under wishlist products in cart page for non empty cart");
        }
    }

    /**
     * This method is used to validate products prices contains inclusive of all taxes text under wishlist products in cart page for non empty cart
     **/
    @And("user validates products contains mrp {string} with strike off text under wishlist products in cart page for non empty cart")
    public void userValidatesProductsContainsMrpWithStrikeOffTextUnderWishlistProductsInCartPageForNonEmptyCart(String productMrps) throws InterruptedException {
        getElement("previousArrowOnWishlist").click();
        List<String> prodMrps = generatingProductDetailsListThroughCount("5", productMrps, ";");
        for (int i = 0; i < prodMrps.size(); i++) {
            if (i == (prodMrps.size() - 1)) {
                getElement("forwardArrowOnWishlist").click();
                Thread.sleep(3000);
            }
            assertStepExecution(prodMrps.get(i), getElement("productMrpForNonEmptyCart", (String.valueOf(i + 1))).getText().replace("MRP ", ""),
                    "user validates products contains mrp with strike off text under wishlist products in cart page for non empty cart");
        }
    }

    /**
     * This method is used to validate add to cart button is present under all wishlist products in cart page in cart page for non empty cart
     **/
    @And("user validates add to cart button {string} is present under all wishlist products in cart page in cart page for non empty cart")
    public void userValidatesAddToCartButtonIsPresentUnderAllWishlistProductsInCartPageInCartPageForNonEmptyCart(String addToCartText) throws InterruptedException {
        getElement("previousArrowOnWishlist").click();
        List<WebElement> elementsList = getDriver().findElements(By.xpath("//div[contains(@class,'swiper-slide wish-cart-main-item')]"));
        for (int i = 0; i < elementsList.size(); i++) {
            if (i == (elementsList.size() - 1)) {
                getElement("forwardArrowOnWishlist").click();
                Thread.sleep(3000);
            }
            assertThat(addToCartText).describedAs("user validates add to cart button is present under all wishlist products in cart page in cart page for non empty cart").isEqualToIgnoringCase(getOptionalElement("productAddToCartBtnForNonEmptyCart", (String.valueOf(i + 1))).getText());
//            assertStepExecution(addToCartText, getElement("productAddToCartBtnForNonEmptyCart", (String.valueOf(i + 1))).getText(),"user validates add to cart button is present under all wishlist products in cart page in cart page for non empty cart");
        }
    }

    /**
     * This method is used to validates  the plus sign beside the savings text in cart and checkout page
     **/
    @And("user validates the plus sign beside the savings text in cart and checkout page")
    public void userValidatesThePlusSignBesideTheSavingsTextInCartAndCheckoutPage() {
        assertStepExecution(true, getOptionalElement("savingsTextPlusIcon") != null,
                "user validates the plus sign beside the savings text in cart and checkout page");
    }

    /**
     * This method is used to validates order summary  section things are visible in cart and checkout page
     **/
    @And("user validates the order summary {string} section is visible in cart and checkout page")
    public void userValidatesTheOrderSummarySectionIsVisibleInCartAndCheckoutPage(String section) throws InterruptedException {
        Thread.sleep(10000);
        WebElement elem = getElement("orderSummaryCard", section);
        //elem.click();
        assertStepExecution(true, elem != null,
                "user validates the order summary " + section + " section is visible in cart and checkout pagee");
    }

    /**
     * This method is used to validates  the number of items in order summary section in cart and checkout page
     **/
    @And("user validates the number of items {string} in order summary section in cart and checkout page")
    public void userValidatesTheNumberOfItemsInOrderSummarySectionInCartAndCheckoutPage(String itemsCount) throws InterruptedException {
        Thread.sleep(6000);
        //String items = getElement("noOfItemsInOrderSummary").getText().replace("(", "").replace("item )", "").trim();
        String items = getElement("noOfItemsInOrderSummary").getText().substring(2, 3);
        assertStepExecution(itemsCount, items, "user validates the number of items in order summary section in cart and checkout page");
    }

    /**
     * This method is used to click on plus sign beside the savings text in cart and checkout page
     **/
    @And("user clicks on plus sign beside the savings text in cart and checkout page")
    public void userClicksOnPlusSignBesideTheSavingsTextInCartAndCheckoutPage() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("savingsTextPlusIcon") != null,
                "user clicks on plus sign beside the savings text in cart and checkout page");
        getElement("savingsTextPlusIcon").click();
        Thread.sleep(4000);
    }

    /**
     * This method is used validates the discount on mrp as per cart level offer under savings text in cart and checkout page
     **/
    @And("user validates the discount on mrp as per cart level offer under savings text in cart and checkout page")
    public void userValidatesTheDiscountOnMrpAsPerCartLevelOfferUnderSavingsTextInCartAndCheckoutPage() throws InterruptedException {
        Thread.sleep(3000);
        String mrpAmount = getElement("mrpOnCart").getText();
        String cartDiscount = getElement("cartLevelOffer").getText().substring(47, 50).concat(".00");
        String discountedValue = getDiscountedPrice(mrpAmount, cartDiscount);
        String actualDiscount = getElement("mrpDiscountUnderSavings").getText().replace("₹", "");
        assertStepExecution(discountedValue, actualDiscount,
                "user validates the discount on mrp as per cart level offer under savings text in cart and checkout page");
        setContext("MRPDiscount", actualDiscount);
    }

    /**
     * This method is used to validates the coupon discount on mrp under savings text in cart and checkout page
     **/
    @And("user validates the coupon discount on mrp under savings text in cart and checkout page")
    public void userValidatesTheCouponDiscountOnMrpUnderSavingsTextInCartAndCheckoutPage() throws InterruptedException {
        Thread.sleep(2000);
        String cartDiscount = getContext("MRPDiscount");
        String mrpAmount = getOnlyDigitsAndDot(getElement("mrpOnCart").getText());
        String newMRP = String.format("%.2f", Double.parseDouble(mrpAmount) - Double.parseDouble(cartDiscount));
        String couponDiscount = getElement("couponLevelDiscount").getText().substring(12, 14);
        String discountedValue = getDiscountedPrice(newMRP, couponDiscount);
        String actualDiscount = getElement("couponDiscountUnderSavings").getText().replace("₹", "");
        assertStepExecution(actualDiscount, discountedValue,
                "user validates the coupon discount on mrp under savings text in cart and checkout page");
        setContext("CouponDiscount", actualDiscount);
    }

    /**
     * This method is used to validates sections is visible under savings section in cart and checkout page
     **/
    @And("user validates {string} is visible under savings section in cart and checkout page")
    public void userValidatesIsVisibleUnderSavingsSectionInCartAndCheckoutPage(String labelText) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getElement("sectionUnderSavings", labelText).isDisplayed(),
                "user validates " + labelText + " is visible under savings section in cart and checkout page");
    }

    /**
     * This method is used to validate total savings on savings section under savings text in cart and checkout page
     **/
    @And("user validates total savings on savings section under savings text in cart and checkout page")
    public void userValidatesTotalSavingsOnSavingsSectionUnderSavingsTextInCartAndCheckoutPage() throws InterruptedException {
        Thread.sleep(2000);
        String savings = getOnlyDigitsAndDot(getElement("savingsAmount").getText()).replaceAll("-", "");
        String actualSavings = String.format("%.2f", Double.parseDouble(getContext("MRPDiscount")) + Double.parseDouble(getContext("CouponDiscount")));
        assertStepExecution(savings, actualSavings, "user validates total savings on savings section under savings text in cart and checkout page");
        setContext("TotalSavings", actualSavings);
    }

    /**
     * This method is used to validates total amount is correct as per discounts applicable in cart and checkout page
     **/
    @And("user validates total amount is correct as per discounts applicable in cart and checkout page")
    public void userValidatesTotalAmountIsCorrectAsPerDiscountsApplicableInCartAndCheckoutPage() throws InterruptedException {
        Thread.sleep(2000);
        String totalAmont = getOnlyDigitsAndDot(getElement("totalAmount").getText());
        String mrpAmount = getOnlyDigitsAndDot(getElement("mrpOnCart").getText());
        String totalSavigs = getContext("TotalSavings");
        String actualTotalAmount = String.format("%.2f", Double.parseDouble(mrpAmount) - Double.parseDouble(totalSavigs));
        assertStepExecution(totalAmont, actualTotalAmount, "user validates total amount is correct as per discounts applicable in cart and checkout page");
    }

    /**
     * This method is used to clicks on apply discount section in cart page
     **/
    @And("user clicks on apply discount section in cart page")
    public void userClicksOnApplyDiscountSectionInCartPage() throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true, getElement("applyDiscountArrow").isDisplayed(),
                "user clicks on apply discount section in cart page");
        getElement("applyDiscountArrow").click();
    }

    /**
     * This method is used provides the coupon and click on apply in cart page
     **/
    @And("user provides the coupon as {string} and click on apply in cart page")
    public void userProvidesTheCouponAsAndClickOnApplyInCartPage(String coupon) throws InterruptedException {
        Thread.sleep(3000);
        WebElement elem = getElement("cartPageCouponCodeInput");
        assertStepExecution(true, elem != null, "user provides the coupon as {string} and click on apply in cart page");
        elem.click();
        elem.sendKeys(coupon);
        getElement("clickOnApplyButton").click();
    }

    @And("user validates {string} is not visible under savings section in cart and checkout page")
    public void userValidatesIsNotVisibleUnderSavingsSectionInCartAndCheckoutPage(String labelText) throws InterruptedException {
        Thread.sleep(2000);
        List<WebElement> li = getDriver().findElements(By.xpath(getLocator("sectionUnderSavings", labelText)));
        assertStepExecution(0, li.size(),
                "user validates " + labelText + " is visible under savings section in cart and checkout page");

    }

    /**
     * This method is used validate first cart product name in cart summary page
     **/
    @And("user validates first cart product name in cart summary page")
    public void userValidatesFirstCartProductNameInCartSummaryPage() {
        String productName = getContext("ProductNameFromMiniCartModalPopUp").toLowerCase().trim();
        String firstProductName = getElement("firstProductNameFromCart").getText().toLowerCase().trim();
        logger.info("The first product Name in Cart is: =" + firstProductName + "Saved data : " + productName);
        //   assertStepExecution(true, firstProductName.contains(productName), "User validates the first product name in cart summary");
    }

    /**
     * This method is used validate bank offer section {string} is visible in cart page
     **/
    @And("user validates bank offer section {string} is visible in cart page")
    public void userValidatesBankOfferSectionIsVisibleInCartPage(String offer) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElement("bankOfferInCartPage").getText().contains(offer),
                "user validates bank offer section " + offer + " is visible in cart page");
    }

    /**
     * This method is used validate icon before the bank offers displayed in cart page
     **/
    @And("user validates icon before the bank offers displayed in cart page")
    public void userValidatesIconBeforeTheBankOffersDisplayedInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElement("bankIconInCartPage") != null,
                "user validates icon before the bank offers displayed in cart page");
    }

    /**
     * This method is used validate the bank offer text is not clickable in cart page
     **/
    @And("user validates the bank offer text is not clickable in cart page")
    public void userValidatesTheBankOfferTextIsNotClickableInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        WebElement element = getElement("bankOfferInCartPage");
        JavascriptExecutor ex = (JavascriptExecutor) getDriver();
        assertStepExecution(true, ex.executeScript("arguments[0].click()", element) == null,
                "user validates the bank offer text is not clickable in cart page");
    }

    /**
     * This method is used clicks on add to cart button on first product available in wishlist section on cart page
     **/
    @And("user clicks on add to cart button on first product available in wishlist section on cart page")
    public void userClicksOnAddToCartButtonOnFirstProductAvailableInWishlistSectionOnCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElement("productAddToCartBtnForNonEmptyCart", String.valueOf(indexOne)) != null,
                "user clicks on add to cart button on first product available in wishlist section on cart page");
        String productTitle = getElement("productsListForNonEmptyCart", String.valueOf(indexOne)).getText();
        setContext("WishlistFirstProduct", productTitle);
        getElement("productAddToCartBtnForNonEmptyCart", String.valueOf(indexOne)).click();
        Thread.sleep(5000);
    }

    /**
     * This method is used verify the first wishlist product is added to cart
     **/
    @And("user verifies the first wishlist {string} product is added to cart")
    public void userVerifiesTheFirstWishlistProductIsAddedToCart(String title) throws InterruptedException {
        Thread.sleep(7000);
        String productTitle = getContext("WishlistFirstProduct");
        assertStepExecution(productTitle, title, "user verifies the first wishlist " + title + "product is added to cart");
    }

    /**
     * This method is used verify the first wishlist product is removed from wishlist section
     **/
    @And("user verifies the first wishlist {string} product is removed from wishlist section")
    public void userVerifiesTheFirstWishlistProductIsRemovedFromWishlistSection(String title) throws InterruptedException {
        Thread.sleep(7000);
        String productTitle = getElement("productsListForNonEmptyCart", String.valueOf(indexOne)).getText();
        assertStepExecution(false, productTitle.equals(title),
                "user verifies the first wishlist " + title + " product is removed from wishlist section");
    }

    /**
     * This method is used to  click on remove or move to my wishlist button  for a product in cart page
     **/
    @And("user clicks on {string} button  for a product in cart page")
    public void userClicksOnButtonForAProductInCartPage(String buttonName) throws InterruptedException {
        Thread.sleep(7000);
        js.executeScript("window.scrollBy(0,-500)");
        Thread.sleep(9000);
        assertStepExecution(true, getOptionalElement("removeAndMoveToWishlistBtn", buttonName, String.valueOf(indexOne)) != null,
                "user clicks on " + buttonName + "button  for a product in cart page");
        getElement("removeAndMoveToWishlistBtn", buttonName, String.valueOf(indexOne)).click();
        Thread.sleep(5000);
    }

    /**
     * This method is used to  click on checkout button for more number of products due to scrolling issue
     **/
    @And("user clicks on checkout button for more number of products")
    public void userClicksOnCheckoutButtonForMoreNumberOfProducts() throws InterruptedException {
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,400)");
        Thread.sleep(2000);
        List<WebElement> list = getElements("productCountListCartPage");
        JavaScriptUtil.scrollToWebelement((list.get(list.size() - 1)));
        assertStepExecution(true, getOptionalElement("checkOutButton") != null,
                "user clicks on checkout button for more number of products");
        if (getOptionalElement("checkOutButton") != null)
            getElement("checkOutButton").click();
    }

    /**
     * This method is used to  see  buttons in wishlist section
     **/
    @And("user is able to see {string} button in wishlist section")
    public void userIsAbleToSeeButtonInWishlistSection(String btnAddToCart) throws InterruptedException {
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,400)");
        List<WebElement> list = getElements("addToCartBtnListForWishlist");
        assertThat(list.size()).describedAs("user is able to see " + btnAddToCart + " button in wishlist section").isGreaterThan(0);
    }

    /**
     * This method is used to  click on Select Another Store link in cart page
     **/
    @And("user clicks on Select Another Store link in cart page")
    public void userClicksOnSelectAnotherStoreLinkInCartPage() throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getOptionalElement("selectAnotherStoreLink") != null,
                "user clicks on Select Another Store link in cart page");
        getElement("selectAnotherStoreLink").click();
        // userMovesToNewWindow();
    }

    /**
     * This method is used to  select the store with index in cart page
     **/
    @And("user selects the store with {string} in cart page")
    public void userSelectsTheStoreWithInCartPage(String index) throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getOptionalElement("selectStoreWithIndex", index) != null,
                "user selects the store with " + index + " in cart page");
        getElement("selectStoreWithIndex", index).click();
    }

    /**
     * This method is used to  verify a specicfic offer has applied for the product
     **/
    @And("user validates {string} is applied for the product {string}")
    public void userValidatesIsAppliedForTheProduct(String productOffer, String productName) throws InterruptedException {
        Thread.sleep(3000);
        String offer = getElement("productSpecificOffer", productName).getText();
        assertStepExecution(offer.trim(), productOffer.trim(), "user validates " + productOffer + " is applied for the product " + productName + "");
    }

    @And("user can see the emi options link is visible under wishlist products in cart page")
    public void userCanSeeTheEmiOptionsLinkIsVisibleUnderWishlistProductsInCartPage() throws InterruptedException {
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,300)");
        assertStepExecution(true, getElements("emiOptionsUnderWishlist").size() > 0,
                "user can see the emi options link is visible under wishlist products   ");
    }

    @And("user clicks on emi options link under wishlist products in cart page")
    public void userClicksOnEmiOptionsLinkUnderWishlistProductsInCartPage() throws InterruptedException {
        Thread.sleep(1000);
        getElement("emiOptionsUnderWishlist").click();
        assertStepExecution(true, getElements("emiOptionsUnderWishlist").size() > 0,
                "user can see the emi options link is visible under wishlist products");
    }

    @And("user verifies the emi options popup box is displayed")
    public void userVerifiesTheEmiOptionsPopupBoxIsDisplayed() throws InterruptedException {
        Thread.sleep(2000);
        assertThat(true).describedAs("user verifies the emi options popup box is displayed").isEqualTo(getElement("emiOptionsModalBox") != null);
        assertThat(true).describedAs("user verifies the emi options popup box is displayed").isEqualTo(getElement("bankEmiOptions") != null);
        passStepExecution("user verifies the emi options popup box is displayed");
    }

    @And("user verifies offer section is visible under the product in cart page")
    public void userVerifiesOfferSectionIsVisibleUnderTheProductInCartPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getElement("offerSectionInCartPage") != null,
                "user verifies offer section is visible under the product in cart page");
    }

    @And("user verifies more offers hyperlink is present under the product offer in cart page")
    public void userVerifiesMoreOffersHyperlinkIsPresentUnderTheProductOfferInCartPage() throws InterruptedException {
        Thread.sleep(1000);
        assertStepExecution(true, getElement("OfferCountInCartPage").getText().contains(" More Offers"),
                "user verifies more offers hyperlink is present under the product offer in cart page");
        getElement("OfferCountInCartPage").click();
    }

    @And("user verifies offer popup is populated in cart page")
    public void userVerifiesOfferPopupIsPopulatedInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertThat(true).describedAs("user verifies offer popup is populated in cart page").isEqualTo(getElement("offerPopupInCartPage") != null);
        assertThat(true).describedAs("user verifies offer popup is populated in cart page").isEqualTo(getElement("offerPopupTitle") != null);
        passStepExecution("user verifies offer popup is populated in cart page");
    }

    @And("user verifies radio buttons for selection of respective offer")
    public void userVerifiesRadioButtonsForSelectionOfRespectiveOffer() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElements("radioButtonOffers").size() > 0,
                "user verifies radio buttons for selection of respective offer");
    }

    @And("user verifies the selected offer {string} is applied through popup in cart page")
    public void userVerifiesTheSelectedOfferIsAppliedThroughPopupInCartPage(String offer) throws InterruptedException {
        Thread.sleep(2000);
        scrollToWebelement(getElement("offerSelectionInCartPage",offer));
        getElement("offerSelectionInCartPage",offer).click();
    }

    @And("user clicks on cross icon on offer popup in cart page")
    public void userClicksOnCrossIconOnOfferPopupInCartPage() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getElement("crossIconOfferPopup") != null,
                "user clicks on cross icon on offer popup in cart page");
        getElement("crossIconOfferPopup").click();
    }


    @And("user verifies the {string} product is added to wishlist section for empty cart")
    public void userVerifiesTheProductIsAddedToWishlistSectionForEmptyCart(String productName) throws InterruptedException {
        Thread.sleep(10000);
        String product = getElement("wishlistProductsTitle").getText();
        assertStepExecution(productName, product,
                "user verifies the" + product + "product is added to wishlist section for empty cart");
    }

    @And("user validates the shipping address is visible in cart page")
    public void userValidatesTheShippingAddressIsVisibleInCartPage() throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("shippingAddressInCartPage")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertStepExecution(true, getElement("shippingAddressInCartPage") != null,
                "user validates the shipping address is visible in cart page");
    }

    @And("user validates the individual product quantity {string} in cart page")
    public void userValidatesTheIndividualProductQuantityInCartPage(String quantity) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("productIndividualQuantityListCartPage")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String countFromWeb = getElement("productIndividualQuantityListCartPage").getText().trim();
        assertStepExecution(quantity, countFromWeb, "user validates the individual product quantity " + quantity + " in cart page");
    }

    @And("user verifies the sign in button is present in cart page for guest user")
    public void userVerifiesTheSignInButtonIsPresentInCartPageForGuestUser() {
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("cartPageSignInButtonForGuestUser")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String stepDescp = "user verifies the sign in button is present in cart page for guest user";
        assertStepExecution(true, getElement("cartPageSignInButtonForGuestUser") != null, stepDescp);
    }

    @And("user clicks on sign in button in cart page for guest user")
    public void userClicksOnSignInButtonInCartPageForGuestUser() {
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("cartPageSignInButtonForGuestUser")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String stepDescp = "user clicks on sign in button in cart page for guest user";
        getElement("cartPageSignInButtonForGuestUser").click();
        assertStepExecution(true, getElement("cartPageSignInButtonForGuestUser") != null, stepDescp);
    }

    @And("user validates the cart page is launched")
    public void userValidatesTheCartPageIsLaunched() {
        String stepDescp = "user validates the cart page is launched";
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getElement("yourCartTextOnCartPage") != null,
                stepDescp);
    }

    @And("user validates Checkout button should be present in cart page")
    public void userValidatesCheckoutButtonShouldBePresentInCartPage() {
        assertStepExecution(true, getElement("checkOutButton").isDisplayed(), "user validates Checkout button is not present in cart page");
    }

    @Then("user validate total count {string} has been increased in cart page")
    public void userValidateTotalCountHasBeenIncreasedInCartPage(String itemCount) throws InterruptedException {
        Thread.sleep(6000);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("cartSummaryValidation", "YOUR CART")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        List<WebElement> productList = getDriver().findElements(By.xpath(getLocator("productCountListCartPage")));
        logger.info("No of products are: " + productList.size());
        assertThat(productList.size()).isEqualTo(Integer.parseInt(itemCount)).describedAs("user validate total count has been increased in cart page");
    }

    @Then("user validate Sign In button should be present for guest user")
    public void userValidateSignInButtonShouldBePresentForGuestUser() {
        assertStepExecution(true, getElement("signInButtonInCartPage").isEnabled(), "User validate that Sign in should Not be a button");
    }

    @Then("user validate Sign In {string} option should be present for guest user")
    public void userValidateSignInOptionShouldBePresentForGuestUser(String toCheckOutFasterText) {
        assertStepExecution(true, getElement("toCheckOutFasterText", toCheckOutFasterText).getText().contains(toCheckOutFasterText), "User validates SignIn to Checkout Faster text should not present for guest user");
    }

    @And("user validates Sign In button should not present for logged In user")
    public void userValidatesSignInButtonShouldNotPresentForLoggedInUser() {
        assertStepExecution(true, getOptionalElement("signInButtonInCartPage") == null, "user validates Sign In button should not present for logged In user");
    }


    @And("user clicks on the product {string}in cart page")
    public void userClicksOnTheProductInCartPage(String productName) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getElement("productincartpage", productName) != null, "Product is present in cart page");
        jsClick(getElement("productincartpage", productName));

    }

    @And("user clicks on {string} radio button on cart page")
    public void userClicksOnRadioButtonOnCartPage(String deliveryMode) throws InterruptedException {
        scrollToWebelement(getElement("deliveryMode", deliveryMode));
        conditionalWait(ExpectedConditions.visibilityOf(getElement("deliveryMode", deliveryMode)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("deliveryMode", deliveryMode).isDisplayed()).isEqualTo(true).describedAs("user clicks on " + deliveryMode + " radio button on cart page");
        getElement("deliveryMode", deliveryMode).click();
        Thread.sleep(5000);
    }

    @And("user validates the exchange product text as {string} retained and anonymous dropped")
    public void userValidatesTheExchangeProductTextAsRetainedAndAnonymousDropped(String exchangeValue) {
        assertStepExecution(true, getElement("exchangeValueTextCartPage", exchangeValue) != null, "user validates exchange product is retained");
    }

    @And("user validates all delivery mode section are visible in cart page")
    public void userValidatesAllDeliveryModeSectionAreVisibleInCartPage() {
        scrollToWebelement(getElement("deliveryModeSection"));
        conditionalWait(ExpectedConditions.visibilityOf(getElement("deliveryModeSection")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertThat(getElement("deliveryModeSection").isDisplayed()).isEqualTo(true).describedAs("user validates all delivery mode section are visible in cart page");
    }
}