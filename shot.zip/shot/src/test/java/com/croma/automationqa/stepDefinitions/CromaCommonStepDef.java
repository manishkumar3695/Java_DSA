package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static com.croma.automationqa.stepDefinitions.CromaHomePageStepDef.clickingOnCategoryLinksHomePage;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;
import static org.openqa.selenium.Keys.*;

public class CromaCommonStepDef {

    private static final int indexOne = 1, indexZero = 0, indexNine = 9;
    public static ArrayList<HashMap<String, String>> productMap = new ArrayList<>();

    /*
        User provides pincode on corresponding page and click on Apply button
     */
    @Given("^user provides pincode \"([^\"]*)\" from \"([^\"]*)\" page and submit$")
    public void userProvidesPincodeFromPageAndSubmit(String pinCode, String page) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
        logger.info("Pincode entered: " + pinCode);
        if (page.equalsIgnoreCase("header")) {
            // conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnDeliveringTo")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
            // getElement("clickOnDeliveringTo").click();
            jsClick(getElement("clickOnDeliveringTo"));
            // getElement("pinCodeHome").clear();
            getElement("pinCodeHome").sendKeys(chord(CONTROL, "a", DELETE));
        } else if (page.equalsIgnoreCase("pdpPincodeEdit")) {
            //windowScrollIntoViewByWebElement(getElement("keyFeatureText"));
            // conditionalWait(ExpectedConditions.elementToBeClickable(getElement("pdpPincodeInputField")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
            jsClick(getElement("pdpPincodeInputField"));
            clearTextBox(getElement("pinCodeHome"));
        } else if (page.equalsIgnoreCase(getConfig("Browser"))) {
            jsClick(getElement("clickOnDeliveringToForMobile"));
            clearTextBox(getElement("pinCodeHome"));
        }
//        getElement("pinCodeHome").clear();
        getElement("pinCodeHome").sendKeys(pinCode);
        setContext("pinCode_applied", pinCode);
        //      processScreenshot();
        jsClick(getElement("pinCodeSubmit"));
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
    }


    /*
        user validates pincode
    */
    @And("^user validates pincode$")
    public void userValidatesPincode() {
        logger.info("Pin code is: " + getElement("pinCodeXpath").getText() + "Saved pin code" + getContext("pinCode_applied"));
        //  processScreenshot();
        assertStepExecution(getElement("pinCodeXpath").getText(), getContext("pinCode_applied"), "Pincode match check");
    }


    /*
        User navigates back to previous page
     */
    @And("^user navigates back to previous page$")
    public void userNavigatesBackToPreviousPage() throws InterruptedException {
        logger.info("Click on Back Previous Page");
        getDriver().navigate().back();
        // getDriver().navigate().to(getContext("url_Currentpage"));
        Thread.sleep(3000);
    }


    /*
        User navigates back to home page on clicking Croma Logo Icon
     */

    @Then("^User should have the option to go back to Croma\\.com and lands on home page$")
    public void userlandsOnHomePage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(2000);
        actionMoveToElementClick(getElement("cromaLogo"));
        // jsClick(getElement("cromaLogo"));
        assertStepExecution(true, getOptionalElement("homePageCroma") != null,
                "Navigated to home page");
    }


    /*
        User closes pincode pop up
    */
    @And("^user closes the pincode pop up$")
    public void userClosesThePincodePopUp() {
        assertStepExecution(true, getOptionalElement("pinCodePopupClose").isDisplayed(), "pincode pop up close on cart page");
        getElement("pinCodePopupClose").click();
    }


    /*
        User is on croma landing page and click on the signin link
    */
    @Given("^user is on croma landing page and clicks on the signin link$")
    public void userIsOnCromaLandingPageAndClicksOnTheSigninLink() throws InterruptedException {
        //   conditionalWait(ExpectedConditions.visibilityOf(getElement("signInLink")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        if (getOptionalElement("signInUserDetails") != null) {
            userClicksOnUserIconAndClicksOnTheLinkAndLandsOnCorrespondingPage("Logout");
            userSuccessfullyLogoutValidatingInCromaHomepage("SIGN IN");
        } else {
            assertStepExecution(true, getOptionalElement("signInLink") != null,
                    "user is on croma landing page and clicks on the signin link");
            getElement("signInLink").click();
        }
    }


    /*
        User successfully login in croma homepage and validating user name details
    */
    @Then("^user successfully login validating \"([^\"]*)\" in croma homepage$")
    public void userSuccessfullyLoginValidatingInCromaHomepage(String userNameDetail) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String stepDescription = "user successfully login validating " + userNameDetail + " in croma homepage";
        logger.info("Assert word is: " + getElement("signInUserDetails").getText() + " Database argument is: " + userNameDetail);
        assertStepExecution(userNameDetail, getElement("signInUserDetails").getText(), stepDescription);
    }


    /*
       User click products category
    */
    @Given("^user clicks products category$")
    public void userClicksProductsCategory() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        jsClick(getElement("menuButtonHomePage"));
        //actionMoveToElementBuild(getElement("hoverProductOption"));
    }


    /*
        User go over category option and click on category link
    */


    @When("^user goes over \"([^\"]*)\" category$")
    public void userGoesOverCategory(String categoryOption1) throws InterruptedException {
        logger.info("User selects catagory option: " + categoryOption1);
        List<WebElement> elementPresent = getDriver().findElements(By.xpath("(//*[@class='text' and (text()='" + categoryOption1 + "')])[1]//parent::a//span[1]"));
        logger.info("No of element are: " + elementPresent.size());
        if (elementPresent.size() != 0) {
            assertStepExecution(true, getOptionalElement("categoryOptionPresent", categoryOption1) != null, "Category option found.");
            actionMoveToElementBuild(getElement("categoryOptionPresent", categoryOption1));
        } else {
            assertStepExecution(true, getOptionalElement("categoryOption", categoryOption1) != null, "Category option found.");
            actionMoveToElementClick(getElement("categoryOption", categoryOption1));
            actionMoveToElementClick(getElement("plp_Product_Index", String.valueOf(indexOne)));
            userNavigatesBackToPreviousPage();
        }
    }


    /*
       User clicks cart icon and lands on the cart page
    */
    @Then("^user clicks cart icon and lands on the cart page$")
    public void userClicksCartIconAndLandsOnTheCartPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        userHandlesTheUnexpectedMiniCartDialogPopup();
        if (getContext("product_available").equalsIgnoreCase("true")) {
            String flag = "false";
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cartIcon")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            processScreenshot();
            assertStepExecution(true, getOptionalElement("cartIcon") != null, "Cart icon locator present");
            getElement("cartIcon").click();
            setContext("coupon_applied_flag_cart", flag);
            setContext("gift_item_applied_flag_cart", flag);
            setContext("donation_applied_flag_cart", flag);
        }
    }


    /*
        User search product in global search box and pick from dropdown
    */
    @When("^user searches \"([^\"]*)\" in global search box and picks from dropdown$")
    public void userSearchesInGlobalSearchBoxAndPicksFromDropdown(String searchProduct1) throws Exception {
        Thread.sleep(2500);
        String flag = "true";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        clearTextBox(getElement("searchProductInGlobalSearchBox"));
        logger.info("Searched Product is: " + searchProduct1);
        for (char eachChar : searchProduct1.toCharArray()) {
            String charToStr = String.valueOf(eachChar);
            if (charToStr.equals(".") | (charToStr.equals("/"))) {
                StringSelection str = new StringSelection(charToStr);
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
                getElement("searchProductInGlobalSearchBox").sendKeys(chord(CONTROL, "v"));
            } else {
                getElement("searchProductInGlobalSearchBox").sendKeys(String.valueOf(eachChar));
            }
            Thread.sleep(100);
        }
        assertStepExecution(true, getElement("searchProductDropdown", searchProduct1) != null, "Search product dropdown found.");
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchProductDropdown", searchProduct1)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        actionMoveToElementClick(getElement("searchProductDropdown", searchProduct1));
        setContext("product_available", flag);
        //getElement("PopupCloseButton").click();

    }


    /*
       User clicks on common menu bar
    */
    @When("^user clicks on common menu bar$")
    public void userClicksOnCommonMenuBar() {
        scrollTop();
        assertStepExecution(true, getOptionalElement("menuButton") != null, "Menu Button found.");
        getElement("menuButton").click();
    }


    /*
       User clicks on common menu bar and clicks on common menu link
*/
    @And("^user clicks on common menu bar and clicks on \"([^\"]*)\" as menu option$")
    public void userClicksOnCommonMenuBarAndClicksOnAsMenuOption(String commonMenuLink1) {
        scrollTop();
        assertStepExecution(true, getOptionalElement("menuButton") != null, "User clicks on common menu bar and clicks on common menu link");
        getElement("menuButton").click();
        logger.info("User clicks on Store locator: " + commonMenuLink1);
        getElement("menuLink", commonMenuLink1).click();
    }

    /*
        User search product item in global search box and click the search
    */
    @When("^user searches \"([^\"]*)\" in global search box and clicks the search$")
    public void userSearchesInGlobalSearchBoxAndClicksTheSearch(String searchProduct1) throws InterruptedException {
        String flag = "true";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //clearTextBox(getElement("searchProductInGlobalSearchBox"));
        if (getConfig("Browser").equalsIgnoreCase("EMULATED_CHROME")) {
            getElement("searchProductInGlobalSearchBox").click();
            getElement("searchProductInGlobalSearchBoxForMobile").clear();
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchProductInGlobalSearchBoxForMobile")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            clearTextBoxBackSpace(getElement("searchProductInGlobalSearchBoxForMobile"));
            getElement("searchProductInGlobalSearchBoxForMobile").sendKeys(searchProduct1);
            processScreenshot();
            actionMoveToElementClick(getElement("clickSearchButton"));
            //getElement("searchProductInGlobalSearchBoxForMobile").sendKeys(ENTER);

        } else if (getConfig("Browser").equalsIgnoreCase("CHROME")) {

            getElement("searchProductInGlobalSearchBox").clear();
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            clearTextBoxBackSpace(getElement("searchProductInGlobalSearchBox"));
            getElement("searchProductInGlobalSearchBox").sendKeys(searchProduct1);
            processScreenshot();
            actionMoveToElementClick(getElement("clickSearchButton"));
            getElement("searchProductInGlobalSearchBox").sendKeys(ENTER);
        }
        setContext("product_available", flag);
        setContext("searchProduct", searchProduct1);
        Thread.sleep(5000);

    }


    /*
       User clicks store locator from header
    */
    @And("^user clicks store locator from header$")
    public void userClicksStoreLocatorFromHeader() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        logger.info(" Click on the Header Link of Store");
        processScreenshot();
        getElement("clickStoreLocatorInHeader").click();
    }


    /*
       User searches product through url and lands on pdp page
    */
    @When("^user searches \"([^\"]*)\" through url and lands on pdp page$")
    public void userSearchesThroughUrlAndLandsOnPdpPage(String searchProduct) {
        logger.info("URL is " + getConfig("URL") + "/abc/p/" + searchProduct);
        processScreenshot();
        getDriver().navigate().to(getConfig("URL") + "/abc/p/" + searchProduct);
        processScreenshot();
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        logger.info(getContext("product_available"));
    }


    /*
        User clicks on link of homepage/footer/TopCategories on home page option and validates the corresponding navigated page
    */
    @And("^user clicks on \"([^\"]*)\" as link on \"([^\"]*)\" homepage/footer page option$")
    public void userClicksOnAsLinkOnHomepageFooterPageOption(String clickableLink, String pageLinkOption) {
        int tabIndexLastValue = 5, homePageScrollUpFirstIndex = 150, homePageScrollUpSecondIndex = 300;
        List<WebElement> categoryLinksHomePageList;
        int tabIndexFirstValue = 1;
        int homePageScrollDownFirstIndex = 0;
        switch (pageLinkOption) {
            case "Footer":
                windowScrollIntoTopToBottom();
                windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpFirstIndex);
                //  conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickLinksInFooter", clickableLink)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                // processScreenshot();
//                windowScrollIntoViewByWebElement(getElement("clickLinksInFooter", clickableLink));
                //getElement("clickLinksInFooter", clickableLink).click();
                jsClick(getElement("clickLinksInFooter", clickableLink));
                break;
            case "Homepage":
                clickingOnCategoryLinksHomePage(clickableLink, "NA");
                break;

            case "HomepageTopCategories":
                windowScrollIntoTopToBottom();
                windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpSecondIndex);
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickLinksInFooter", clickableLink)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                processScreenshot();
                clickingOnCategoryLinksHomePage(clickableLink, "homePageTopCategories");
                break;
        }
        if (clickableLink.equalsIgnoreCase("FAQs")) {
            categoryLinksHomePageList = getElements("faqsDetailsListXPath");
            logger.info("No of Product details are: " + categoryLinksHomePageList.size());
            for (int i = tabIndexFirstValue; i <= tabIndexLastValue; i++) {
                processScreenshot();
                actionMoveToElementClick(getElement("faqsDetailsXpath", String.valueOf(i)));
            }
            processScreenshot();
        }
    }


    /*
       User clicks on breadcrumb option and validates the corresponding navigated page
   */
    @And("^user clicks on \"([^\"]*)\" breadcrumb option and validates the corresponding navigated page$")
    public void userClicksOnBreadcrumbOptionAndValidatesTheCorrespondingNavigatedPage(String breadcrumbOption) {
        String homePageCromaText = "Shop Safely with Croma";
        //waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("categoryBreadcrumbPageTitleOption", breadcrumbOption)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        windowScrollToTop();
        getElement("categoryBreadcrumbPageTitleOption", breadcrumbOption).click();
//        if (breadcrumbOption.equalsIgnoreCase("Croma")) {
//            logger.info("Croma Home Page");
//            assertStepExecution(homePageCromaText.toLowerCase(), getElement("homePageCroma").getText().toLowerCase(),
//                    "Home Page Navigation happened");
//        } else {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        userValidateBreadCrumbLastIndex(breadcrumbOption);
//        }
        // userValidateBreadCrumbLastIndex(breadcrumbOption);
    }


    /*
        User validates last index breadcrumb
    */
    public static void userValidateBreadCrumbLastIndex(String breadcrumbOption) {
        List<WebElement> categoryLinksBreadCrumbList = getElements("categoryLinksBreadCrumbListXPath");
        processScreenshot();
        logger.info(String.valueOf(categoryLinksBreadCrumbList.size()));
        assertThat(breadcrumbOption.toLowerCase()).describedAs("BreadCrumb option is matching").isEqualTo(getElement("categoryBreadcrumbDynamicTitle", String.valueOf(categoryLinksBreadCrumbList.size())).getText().toLowerCase());
        assertThat(getElement("categoryBreadcrumbDynamicTitle", String.valueOf(categoryLinksBreadCrumbList.size())).getText().toLowerCase()).describedAs("Croma should not present").isNotEqualToIgnoringCase("Croma");
        setContext("breadcrumOptionCount", String.valueOf(categoryLinksBreadCrumbList.size()));
    }

    /*
        User provides email id at the footer to subscribe and validates the subscription
    */
    @Then("^user provides \"([^\"]*)\" emailid at the footer to subscribe and validates the subscription$")
    public void userProvidesEmailIdAtTheFooterToSubscribeAndValidatesTheSubscription(String subscriptionEmailId) {
        String subscribeMsg = "Already subscribed";
        windowScrollIntoTopToBottom();
        windowScrollIntoViewByWebElement(getElement("provideEmailOnSubscriptionText"));
        processScreenshot();
        getElement("provideEmailOnSubscriptionText").sendKeys(subscriptionEmailId);
        processScreenshot();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickEmailOnSubscriptionText")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clickEmailOnSubscriptionText").click();
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        processScreenshot();
        logger.info(getElement("subscriptionTextMsg").getAttribute("placeholder").trim());
        assertStepExecution(subscribeMsg.toLowerCase(), getElement("subscriptionTextMsg").getAttribute("placeholder").trim().toLowerCase(),
                "Email id not subscribed");
    }


    /*
        user clicks on user icon and clicks on the link and lands on corresponding page
    */
    @Given("^user clicks on user icon and clicks on the \"([^\"]*)\" link and lands on corresponding page$")
    public void userClicksOnUserIconAndClicksOnTheLinkAndLandsOnCorrespondingPage(String userAccountLink) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("signInUserDetails", userAccountLink)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        Thread.sleep(10000);
        if (getConfig("Browser").trim().equalsIgnoreCase("CHROME")) {
            actionMoveToElementBuild(getElement("signInUserDetails"));
        } else if (getConfig("Browser").trim().equalsIgnoreCase("ANDROID") || getConfig("Browser").trim().equalsIgnoreCase("EMULATED_CHROME") || getConfig("Browser").trim().equalsIgnoreCase("IOS")) {
            actionMoveToElementClick(getElement("signInUserDetails"));
        }
        if (userAccountLink.equalsIgnoreCase("Logout")) {
            windowScrollIntoViewByWebElementTrue(getElement("userAccountLinkMenu", userAccountLink));
            Thread.sleep(4000);
        }
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("userAccountLinkMenu", userAccountLink)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        processScreenshot();
        assertStepExecution(true, getElement("userAccountLinkMenu", userAccountLink) != null, "link is present");
        actionMoveToElementClick(getElement("userAccountLinkMenu", userAccountLink));
        Thread.sleep(10000);
        processScreenshot();

    }


    /*
       user successfully logout validating SighIn in croma homepage
    */
    @And("^user successfully logout validating \"([^\"]*)\" in croma homepage$")
    public void userSuccessfullyLogoutValidatingInCromaHomepage(String userNameDetail) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("signInLink")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Logout is successful" + " " + "Assert word is: " + getElement("signInLink").getText() + "Database argument is: " + userNameDetail);
        processScreenshot();
        assertStepExecution(userNameDetail.toLowerCase(), getElement("signInLink").getText().toLowerCase(), "Username matched");
    }


    /*
       user validate category page title
    */
    public static void validateCategoryPageTitle(String webElementText, String linkText) {
        if (linkText.equalsIgnoreCase("About Croma"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("ABOUT CROMA");
        else if (linkText.equalsIgnoreCase("Order Support"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("SHIPPING INFORMATION");
        else if (linkText.equalsIgnoreCase("Bulk Enquiry"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Bulk Enquiry");
        else if (linkText.equalsIgnoreCase("E-Care"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Croma e-care");
        else if (linkText.equalsIgnoreCase("Franchise Opportunity"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Franchise Enquiries | Tata Croma Store");
        else if (linkText.equalsIgnoreCase("Gamings"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Gaming");
        else if (linkText.equalsIgnoreCase("Gaming"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Gaming");
        else if (linkText.equalsIgnoreCase("Gaming & Accessories"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Gaming");
        else if (linkText.equalsIgnoreCase("Consumable"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Campaign");
        else if (linkText.equalsIgnoreCase("Laptops & Tablets"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Computers & Tablets");
        else if (linkText.equalsIgnoreCase("Mobile Phones"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Phones & Wearables");
        else if (linkText.equalsIgnoreCase("Warranty & Services"))
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase("Accessories");
        else
            assertThat(webElementText).describedAs("Page title not matched").isEqualToIgnoringCase(linkText);

        passStepExecution("Category page title validation");
    }


    /*
    user moves to home-page after clicking Croma logo
*/
    @Then("^user should have the option to go back to Croma\\.com and lands on home page$")
    public void userShouldHaveTheOptionToGoBackToCromaComAndLandsOnHomePage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaLogo")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("cromaLogo").click();
        assertStepExecution(true, getElement("whyCroma").isDisplayed(), "Not navigated to home page");
    }


    /*
        User refreshes the page
    */
    @And("^user refreshes the page$")
    public void userRefreshesThePage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getDriver().navigate().refresh();
        Thread.sleep(5000);
    }


    /*
      user validates the corresponding navigated page homepage/footer page option
    */
    @And("^user validates the corresponding navigated page as \"([^\"]*)\" homepage/footer page option as \"([^\"]*)\"$")
    public void userValidatesTheCorrespondingNavigatedPageAsHomepageFooterPageOptionAs(String clickableLink, String pageLinkOption) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (pageLinkOption.equalsIgnoreCase("Homepage")) {
            Thread.sleep(3000);
            validateCategoryPageTitle((getElement("categoryBreadcrumbPageTitle").getText()), clickableLink);
            getElement("categoryBreadcrumbPageTitleCroma").click();
        }
        if (pageLinkOption.equalsIgnoreCase("Footer") || pageLinkOption.equalsIgnoreCase("HomepageTopCategories")) {
            if (clickableLink.equalsIgnoreCase("Televisions") || clickableLink.equalsIgnoreCase("Home Appliances") || clickableLink.equalsIgnoreCase("Kitchen Appliances") || clickableLink.equalsIgnoreCase("Phones & Wearables") || clickableLink.equalsIgnoreCase("Computers & Tablets") || clickableLink.equalsIgnoreCase("Audio & Video") || clickableLink.equalsIgnoreCase("Cameras") || clickableLink.equalsIgnoreCase("Grooming & Wellness") || clickableLink.equalsIgnoreCase("Gamings") || clickableLink.equalsIgnoreCase("Gaming") || clickableLink.equalsIgnoreCase("Accessories") || clickableLink.equalsIgnoreCase("Top Brands")) {
                actionMoveToElementBuild(getElement("categoryBreadcrumbPageTitle"));
                validateCategoryPageTitle((getElement("categoryBreadcrumbPageTitle").getText()), clickableLink);
//            }
//            else if (clickableLink.equalsIgnoreCase("Store Locator")) {
//                validateCategoryPageTitle((getElement("categoryBreadcrumbPageTitleCroma").getText()), clickableLink);
            } else
                validateCategoryPageTitle(getElement("categoryPageTitle").getText(), clickableLink);
        }

        if (pageLinkOption.equalsIgnoreCase("HomepageTopCategories"))
            getElement("categoryBreadcrumbPageTitleCroma").click();
        processScreenshot();
    }

    @And("^user validates \"([^\"]*)\" category name is present in the breadcrumb section$")
    public void userValidatesCategoryNameIsPresentInTheBreadcrumbSection(String categoryName) {
        ArrayList<String> breadCrumbList = new ArrayList<>();
        List<WebElement> breadCrumbElementList = getElements("breadcrumbList");
        for (WebElement breadCrumbElement : breadCrumbElementList) {
            breadCrumbList.add(breadCrumbElement.getText());
        }
        logger.info("Breadcrumb List : " + breadCrumbList);
        assertStepExecution(true, breadCrumbList.contains(categoryName),
                categoryName + " should present in Breadcrumb List");

    }

    public static void verifyProductAvailability(List<WebElement> webElementList) {
        if (webElementList.size() != 0)
            setContext("product_available", "false");
        else
            setContext("product_available", "true");
    }

    public static List<String> generatingProductDetailsListThroughCount(String productCount, String productDetails, String splitOption) {
        List<String> itemListProductNames = new ArrayList<>(Integer.parseInt(productCount));
        if (Integer.parseInt(productCount) == indexOne) {
            itemListProductNames.add(productDetails);
        } else {
            itemListProductNames.addAll(Arrays.asList(productDetails.split(splitOption)));
        }
        return itemListProductNames;
    }


    public static String encodingProductListThroughWebElementList(List<WebElement> productWebElementList) {
        String finalEncodedProductDetails = "";
        for (int i = indexZero; i < productWebElementList.size(); i++) {
            String productDetail = productWebElementList.get(i).getText();
            logger.info("product detail is: " + productDetail);
            if (i == (productWebElementList.size() - indexOne)) {
                finalEncodedProductDetails = finalEncodedProductDetails.concat(productWebElementList.get(i).getText());
            } else {
                finalEncodedProductDetails = finalEncodedProductDetails.concat(productWebElementList.get(i).getText()).concat("|");
            }
        }
        return finalEncodedProductDetails;
    }


    public static void productComparisonValidation(List<WebElement> productWebElementList, List<String> productDetailsList, String comparisonOrder) {
        assertThat(String.valueOf(productWebElementList.size())).describedAs("Total product name count is not matching with web page product details").contains(String.valueOf(productDetailsList.size()));
        if (comparisonOrder.equalsIgnoreCase("ReverseOrder")) //If reversed
        {
            for (int i = indexZero; i < productWebElementList.size(); i++) {
                logger.info("product name is from web element: " + productWebElementList.get(i).getText() + " And from text:ist: " + productDetailsList.get(productWebElementList.size() - (i + indexOne)));
                assertThat(productWebElementList.get(i).getText()).describedAs("Decoded product name is not matching with web page product details").containsIgnoringCase(productDetailsList.get(productWebElementList.size() - (i + indexOne)));
            }
        } else if (comparisonOrder.equalsIgnoreCase("ForwardOrder")) {
            for (int i = indexZero; i < productWebElementList.size(); i++) {
                logger.info("product name is from web element: " + productWebElementList.get(i).getText() + " And from text:ist: " + productDetailsList.get(i));
                assertThat(productWebElementList.get(i).getText()).describedAs("Product name is not matching with web page product details").containsIgnoringCase(productDetailsList.get(i));
            }
        }
        passStepExecution("Product comparison method");
    }

    public static void productComparisonValidation(ArrayList<String> productWebElementList, List<String> productDetailsList, String comparisonOrder) {
        assertThat(String.valueOf(productWebElementList.size())).describedAs("Total product name count is not matching with web page product details").contains(String.valueOf(productDetailsList.size()));
        if (comparisonOrder.equalsIgnoreCase("ReverseOrder")) //If reversed
        {
            for (int i = indexZero; i < productWebElementList.size(); i++) {
                logger.info("product name is from web element: " + productWebElementList.get(i) + " And from text:ist: " + productDetailsList.get(productWebElementList.size() - (i + indexOne)));
                assertThat(productWebElementList.get(i)).describedAs("Decoded product name is not matching with web page product details").contains(productDetailsList.get(productWebElementList.size() - (i + indexOne)));
            }
        } else if (comparisonOrder.equalsIgnoreCase("ForwardOrder")) {
            for (int i = indexZero; i < productWebElementList.size(); i++) {
                logger.info("product name is from web element: " + productWebElementList.get(i) + " And from text:ist: " + productDetailsList.get(i));
                assertThat(productWebElementList.get(i)).describedAs("Product name is not matching with web page product details").contains(productDetailsList.get(i));
            }
        }
        passStepExecution("Product comparison method");
    }

    public static void productComparisonNumberExtractValidation(List<WebElement> productWebElementList, List<String> productDetailsList, String comparisonOrder) {
        assertThat(String.valueOf(productWebElementList.size())).describedAs("Total product name count is not matching with web page product details").isEqualTo(String.valueOf(productDetailsList.size()));
        if (comparisonOrder.equalsIgnoreCase("ReverseOrder")) //If reversed
        {
            for (int i = indexZero; i < productWebElementList.size(); i++) {
                logger.info("product name is from web element: " + productWebElementList.get(i).getText() + " And from text:ist: " + productDetailsList.get(productWebElementList.size() - (i + indexOne)));
                assertThat(String.valueOf(numericValuesExtractionMethod(productWebElementList.get(i).getText()))).describedAs("Decoded product name is not matching with web page product details").isEqualToIgnoringCase(productDetailsList.get(productWebElementList.size() - (i + indexOne)));
            }
        } else if (comparisonOrder.equalsIgnoreCase("ForwardOrder")) {
            for (int i = indexZero; i < productWebElementList.size(); i++) {
                logger.info("product amount is from web element: " + productWebElementList.get(i).getText() + " And from text:ist: " + productDetailsList.get(i));
                assertThat(String.valueOf(numericValuesExtractionMethod(productWebElementList.get(i).getText()))).describedAs("Product amount is not matching with web page product details").isEqualToIgnoringCase(productDetailsList.get(i));
            }
        }
        passStepExecution("Product comparison method");
    }

    /*
            user validates breadcrumb
        */
    @And("^user validates \"([^\"]*)\" as breadcrumb$")
    public void userValidatesAsBreadcrumb(String breadCrumb) throws InterruptedException {
        windowScrollToTop();
        userValidateBreadCrumbLastIndex(breadCrumb);
        passStepExecution(" User validated breadcrumb");
        Thread.sleep(5000);

    }

    public static String encodingProductListThroughWebElementListThroughDynamicOperator(List<WebElement> productWebElementList, String dynamicOperator) {
        String finalEncodedProductDetails = "";
        for (int i = indexZero; i < productWebElementList.size(); i++) {
            String productDetail = productWebElementList.get(i).getText();
            logger.info("product detail is: " + productDetail);
            if (i == (productWebElementList.size() - indexOne)) {
                finalEncodedProductDetails = finalEncodedProductDetails.concat(productWebElementList.get(i).getText());
            } else {
                finalEncodedProductDetails = finalEncodedProductDetails.concat(productWebElementList.get(i).getText()).concat(dynamicOperator);
            }
        }
        return finalEncodedProductDetails;
    }

    @Given("^user is on croma landing page and clicks on the Help link$")
    public void userIsOnCromaLandingPageAndClicksOnTheHelpLink() {
        //waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("helpIconInHeader") != null,
                "user is on croma landing page and clicks on the Help link");
        getElement("helpIconInHeader").click();

    }


    @And("^user clicks on right arrow of \"([^\"]*)\"$")
    public void userClicksOnRightArrowOf(String carouselOption) {

        String stepDescription = "user clicks on right arrow of " + carouselOption;
        assertStepExecution(true, getOptionalElement("rightArrowOnCarousel", carouselOption) != null,
                stepDescription);
        while (getElement("rightArrowOnCarousel", carouselOption).getAttribute("aria-disabled").equalsIgnoreCase("false")) {
            getElement("rightArrowOnCarousel", carouselOption).click();
        }
    }

    @And("^user clicks on left arrow of \"([^\"]*)\"$")
    public void userClicksOnleftArrowOf(String carouselOption) {
        String stepDescription = "user clicks on right arrow of " + carouselOption;
        assertStepExecution(true, getOptionalElement("leftArrowOnCarousel", carouselOption) != null,
                stepDescription);
        while (getElement("leftArrowOnCarousel", carouselOption).getAttribute("aria-disabled").equalsIgnoreCase("false")) {
            getElement("leftArrowOnCarousel", carouselOption).click();
        }
    }


    @And("^user validates the store name in the header$")
    public void userValidatesTheStoreNameInTheHeader() {
        logger.info(getElement("clickStoreLocatorInHeader").getText());
        assertStepExecution(true, getElement("clickStoreLocatorInHeader").getText().equalsIgnoreCase(getContext("storeHeading")),
                "user validates the store name in the header");
    }

    /*
        user checks schema tags
    */
    @Given("^user checks schema tags$")
    public void userChecksSchemaTags() {
        assertStepExecution(true, getDriver().getPageSource().contains("schema"), "User checks schema tags");
    }

    /*
       user checks robots txt
   */
    @Then("^user checks robots txt$")
    public void userChecksRobotsTxt() {
        getDriver().get(getConfig("URL") + "/Robots.txt");
        assertThat(getDriver().getPageSource().contains("User-agent: *")).describedAs("User checks robots txt:- User-agent: *");
        assertThat(getDriver().getPageSource().contains("Allow: /*")).describedAs("User checks robots txt:- Allow: /*");
        assertThat(getDriver().getPageSource().contains("Disallow: /checkLoginRedirectPage")).describedAs("User checks robots txt:- Disallow: /checkLoginRedirectPage");
        assertThat(getDriver().getPageSource().contains("Disallow: /loggedInUserName")).describedAs("User checks robots txt:- Disallow: /loggedInUserName");
        assertThat(getDriver().getPageSource().contains("Disallow: */persang-pk-8162-dzire-wireless-karaoke-player-black-/p/203622*")).describedAs("User checks robots txt:- Disallow: */persang-pk-8162-dzire-wireless-karaoke-player-black-/p/203622*");
        passStepExecution("User checks robots txt");
    }

    /*
        user validates call back message in shop with video window
    */
    /* Following step definition is duplicate and is available in CromaProductDefinitionPageStepDef - commenting following - Ankur Purohit 16/03/2021
    @And("^user validates call back message as \"([^\"]*)\" in shop with video window$")
    public void userValidatesCallBackMessageAsInShopWithVideoWindow(String message) {
        assertStepExecution(getElement("callBackSuccessfulMessage").getText(), message, "Call back successful text did not match in shop with video window");
        getElement("callBackSuccessWindowClose").click();
    }
    */

    /*
        user provide leaving too early reason and submit in leaving too early window
    */
    /* Commenting below as it is duplicate and is available in CromaProductDefinitionPageStepDef - Ankur Purohit - 16/03/2021
    @And("^user provides \"([^\"]*)\" as leaving reason in leaving too early window and submit and verifies feedback message as \"([^\"]*)\"$")
    public void userProvidesAsLeavingReasonInLeavingTooEarlyWindowAndSubmitAndVerifiesFeedbackMessageAs(String reason, String feedback) {
        getElement("leavingEarlyReasonCheckBox", reason).click();
        getElement("leavingEarlyReasonSubmitButton").click();
        assertStepExecution(getElement("leavingEarlyReasonFeedbackText").getText(), feedback, "Feedback message did not match in too early window");
    }

     */

    /*
            user checks the registered mobile number present and clicks on connect button
     */
    @And("^user checks the registered mobile number present and clicks on connect button$")
    public void userChecksTheRegisteredMobileNumberPresentAndClicksOnConnectButton() {
        //      logger.info("Customer saved number is: " + getElement("savedMobileNumber").getAttribute("value") + "and phone number from DB: " + getContext("saved_user_mobile_number"));
        //    assertStepExecution(getElement("savedMobileNumber").getAttribute("value"), getContext("saved_user_mobile_number"), "User checks the registered mobile number present and clicks on connect button");
        //     getElement("clickOnConnectButton").click();
        clearTextBox(getElement("savedMobileNumber"));
        getElement("savedMobileNumber").sendKeys(getContext("saved_user_mobile_number"));

        logger.info("Customer saved number is: " + getElement("savedMobileNumber").getAttribute("value") + "and phone number from DB: " + getContext("saved_user_mobile_number"));
        assertStepExecution(getElement("savedMobileNumber").getAttribute("value"), getContext("saved_user_mobile_number"), "User checks the registered mobile number present and clicks on connect button");


        getElement("clickOnCloseButton").click();
//        getElement("customerCallMeButton").click();
    }




    /*
        user provides name, contact no, email id to shop with video window
    */
    /* Commenting step as this is also present in CromaProductDefinitionPageStepDef - Ankur Purohit 16/03/2021
    @And("^user provides \"([^\"]*)\" as name, \"([^\"]*)\" as contact no, \"([^\"]*)\" as email and submit in shop with video window$")
    public void userProvidesAsNameAsContactNoAsEmailAndSubmitInShopWithVideoWindow(String name, String contact, String email) {
        String videoTimingText="Shop with video assistance is available between 10:00 AM and 11:30 PM. Do visit again or leave your contact details & we will call you back during operational hours.";
        assertStepExecution(getElement("shopWithVideoTimingText").getText(), videoTimingText, "Video Timing text did not match in shop with video window");
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Passed arguments: " + name + " " + contact + " " +email);
        if(!name.equalsIgnoreCase("NA")) {
            clearTextBox(getElement("customerNameTextBox"));
            getElement("customerNameTextBox").sendKeys(name);
        }
        if(!contact.equalsIgnoreCase("NA")) {
            clearTextBox(getElement("customerContactTextBox"));
            getElement("customerContactTextBox").sendKeys(contact);
        }
        if(!email.equalsIgnoreCase("NA")) {
            clearTextBox(getElement("customerEmailTextBox"));
            getElement("customerEmailTextBox").sendKeys(email);
        }
        getElement("customerCallMeButton").click();
    }
    */

    /*
        user provides contact no to shop with video window and connect
    */
    @And("^user provides \"([^\"]*)\" as contact number and connect in shop with video window and clicks on call back button$")
    public void userProvidesAsContactNumberAndConnectInShopWithVideoWindowAndClicksOnCallBackButton(String contactNo) {
        String videoConnectText = "Get ready to connect to a Croma staff right away!", callBackText = "Alternately, request callback from store.";
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("connectButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertThat(getElement("connectToCromaStaffText").getText()).describedAs("Video Connect text did not match in shop with video window").isEqualToIgnoringCase(videoConnectText);
        logger.info("Passed arguments: " + contactNo);
        if (!contactNo.equalsIgnoreCase("NA")) {
            clearTextBox(getElement("customerContactTextBox"));
            getElement("customerContactTextBox").sendKeys(contactNo);
        }
        getElement("connectButton").click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("customerCallMeButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertThat(getElement("reuestCllBackText").getText()).describedAs("Alternate call back message not matching in shop with video window").isEqualToIgnoringCase(callBackText);
        getElement("customerCallMeButton").click();
        passStepExecution("Shop With Window assertion passed");
    }




    /*
        user validates call back message in shop with video window

    @And("^user validates call back message as \"([^\"]*)\" in shop with video window$")
    public void userValidatesCallBackMessageAsInShopWithVideoWindow(String message) {
        assertStepExecution(getElement("callBackSuccessfulMessage").getText(), message, "Call back successful text did not match in shop with video window");
        getElement("callBackSuccessWindowClose").click();
    }

     */


    /*
        user validates all social sharing links are present and also clicks them
    */
    @And("^user validates all social sharing links \"([^\"]*)\" are present and also clicks them$")
    public void userValidatesAllSocialSharingLinksArePresent(String socialLinks) throws InterruptedException {
        String stepDescription = "user validates all social sharing links " + socialLinks + " are present";
        windowScrollIntoTopToBottom();
        windowScrollIntoViewAdjustment(0, 150);
        Thread.sleep(3000);
        actionMoveToElementBuild(getElement("connectWithUs"));
        int totalSharingLink = getElements("footerSocialSharingLinks").size();
        logger.info("No of Social links from site : " + totalSharingLink);
        int noOfLinksShouldBe = socialLinks.split(";").length;
        assertThat(totalSharingLink).isEqualTo(noOfLinksShouldBe)
                .describedAs("No of Social links from site should be : " + noOfLinksShouldBe);
        actionMoveToElementBuild(getElements("footerSocialSharingLinks").get(0));
        for (int link = 0; link < totalSharingLink; link++) {
            WebElement socialLinkElement = getElements("footerSocialSharingLinks").get(link);
            String linkHref = socialLinkElement.getAttribute("href");
            logger.info("Link href : " + linkHref);
            logger.info("Link href should be: " + socialLinks.split(";")[link]);
            //assertThat(linkHref).isEqualTo(socialLinks.split(";")[link]);
            conditionalWait(ExpectedConditions.elementToBeClickable(socialLinkElement), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            jsClick(socialLinkElement);
            waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
            String currentUrl = getDriver().getCurrentUrl();
            String[] splitByCom = socialLinks.split(";")[link].split("com");
            assertThat(currentUrl).startsWith(splitByCom[0])
                    .describedAs("Current URL validation for Social links");
            getDriver().navigate().back();
        }
        passStepExecution(stepDescription + " :: Passed \n");
    }


    @Given("^user verify croma logo, hamburger menu, sign in button, mini cart icon , global search box and pin code field are present in header section$")
    public void userVerifyCromaLogoHamburgerMenuSignInButtonMiniCartIconGlobalSearchBoxAndPinCodeFieldArePresentInHeaderSection() {
        String stepDescription = "user verify croma logo, hamburger menu, sign in button, mini cart icon , global search box and pin code field are present in header section";
        assertThat(getElement("cromaLogoImg").getAttribute("src")).startsWith("https://media.croma.com/")
                .endsWith("logo.png").describedAs("Croma Logo Img SRC validation");
        assertThat(getOptionalElement("menuButton")).isNotNull()
                .describedAs("Hamburger Menu Button should display in header");
        assertThat(getOptionalElement("cartIcon")).isNotNull()
                .describedAs("Mini cart icon should display in header");
        assertThat(getOptionalElement("signInCroma")).isNotNull()
                .describedAs("SIGN IN Button should display in header");
        assertThat(getOptionalElement("searchProductInGlobalSearchBox")).isNotNull()
                .describedAs("Global Search Box should display in header");
        assertThat(getOptionalElement("enterPincodeField")).isNotNull()
                .describedAs("Pin code field should display in header");
        passStepExecution(stepDescription + " :: Passed \n");
    }


    /*
       user verify croma logo, products dropdown, sign in button, mini cart icon , global search box , and pin code field are present in header section

     */

    @Given("^user verify croma logo, products dropdown, sign in button, mini cart icon , global search box , and pin code field are present in header section$")
    public void userVerifyCromaLogoProductsDropdownSignInButtonMiniCartIconGlobalSearchBoxPreferredStoreAndPinCodeFieldArePresentInHeaderSection() throws InterruptedException {

        String stepDescription = "user verify croma logo, products dropdown, sign in button, mini cart icon , global search box , preferred store and pin code field are present in header section";
        Thread.sleep(5000);
        assertThat(getOptionalElement("cromaLogo")).describedAs("Croma Logo Img SRC validation").isNotNull();

        assertThat(getOptionalElement("menuButtonHomePage"))
                .describedAs("Products dropdown should display in header").isNotNull();

        assertThat(getOptionalElement("signInLink"))
                .describedAs("SIGN IN Button should display in header").isNotNull();

        assertThat(getOptionalElement("cartIcon"))
                .describedAs("Mini cart icon should display in header").isNotNull();

        assertThat(getOptionalElement("searchProductInGlobalSearchBox"))
                .describedAs("Global Search Box should display in header").isNotNull();

        assertThat(getOptionalElement("enterPincodeField"))
                .describedAs("Pin code field should display in header").isNotNull();

        passStepExecution(stepDescription + " :: Passed \n");
    }


    @And("^user clicks on mini cart icon and lands on the cart page$")
    public void userClicksOnMiniCartIconAndLandsOnTheCartPage() {
        assertStepExecution(true, getOptionalElement("cartIcon") != null, "user clicks on mini cart icon and lands on the cart page");
        getElement("cartIcon").click();
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
    }

    @And("^user reactivates the vouchagram \"([^\"]*)\"$")
    public void userReactivatesTheVouchagram(String voucherNo) {
        String selectLinkOpeninNewTab = chord(CONTROL, ENTER);
        String urlToHit = "https://pos-staging.vouchagram.net/Service" +
                "/RestServiceImpl.svc/Cancel?shopCode=WEBTEST&merchantUid=49F79EB8-061D-4A6F-B7FA-E5DC1088DBBE&voucherNumber=" +
                voucherNo + "&deviceCode=P&requestjobnumber=7CXlFty3OCnGDoN&billvalue=100&Password=DpWB%2BdGrxKnrWEEXPUZC%2FA%3D%3D\t\n";
        String tp = "https://www.google.com";

     /*   getDriver().findElement(By.linkText(tp)).
                sendKeys(selectLinkOpeninNewTab);*/
        //    actionMoveToElementClick(getElement("searchProductInGlobalSearchBox"));
        //   getDriver().findElement(By.xpath("//main[@id='container']")).sendKeys(Keys.CONTROL +"t");
        //  getElement("searchProductInGlobalSearchBox").sendKeys(Keys.CONTROL + "t"+Keys.CONTROL, "t");

        // Keys.chord(Keys.CONTROL, "t");
     /*   Robot robot = new Robot();
       robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_T);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_T);*/
        //     userMovesToNewWindow();
        getDriver().get(urlToHit);
        //   getDriver().get(getConfig(URL));
        getDriver().navigate().back();
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        //     getDriver().navigate().refresh();


        //  userClosesTheCurrentWindowAndMovesToOldWindow();
    }

    @When("^user clicks on the search bar$")
    public void userClicksOnTheSearchBar() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("searchProductInGlobalSearchBox").click();
    }

    @Then("^user validates last searched keyword \"([^\"]*)\" suggestion present in the suggestion tray$")
    public void userValidatesLastSearchedKeywordSuggestionPresentInTheSuggestionTray(String searchKeyword) {
        List<WebElement> searchKeywordSuggestionList = getDriver().findElements(By.xpath("(//div[@class= 'search-history-option']/span[@class='search-history-option-name'])"));
        logger.info("searchKeywordSuggestionList size : " + searchKeywordSuggestionList.size());
        if (searchKeywordSuggestionList.size() == indexZero) {
            logger.info("User don't have any search history");
        }
        if (searchKeywordSuggestionList.size() < indexNine) {
            for (int i = indexOne; i < searchKeywordSuggestionList.size(); i++) {
                logger.info("Product details name is: " + getElement("searchKeywordSuggestionName", String.valueOf(i)).getText());
                String searchedKeyword = getElement("searchKeywordSuggestionName", String.valueOf(i)).getText();
                if (searchKeyword.equalsIgnoreCase(searchedKeyword)) {
                    logger.info("last searched keyword present" + searchedKeyword);
                    assertStepExecution(searchedKeyword, searchKeyword, "User validates last searched keyword suggestion present in the suggestion tray");
                    break;
                }
            }
        }
    }

    @And("^user clicks on history icon in the left side of the searched keyword \"([^\"]*)\" and lands on search result page$")
    public void userClicksOnHistoryIconInTheLeftSideOfTheSearchedKeywordAndLandsOnSearchResultPage(String searchKeyword) {
        List<WebElement> searchKeywordSuggestionList = getDriver().findElements(By.xpath("(//div[@class= 'search-history-option']/span[@class='search-history-option-name'])"));
        logger.info("searchKeywordSuggestionList size : " + searchKeywordSuggestionList.size());
        if (searchKeywordSuggestionList.size() < indexNine) {
            for (int i = indexOne; i < searchKeywordSuggestionList.size(); i++) {
                logger.info("Product details name is: " + getElement("searchKeywordSuggestionName", String.valueOf(i)).getText());
                String searchedKeyword = getElement("searchKeywordSuggestionName", String.valueOf(i)).getText();
                if (searchKeyword.equalsIgnoreCase(searchedKeyword)) {
                    logger.info("last searched keyword present" + searchedKeyword);
                    assertStepExecution(searchedKeyword, searchKeyword, "User validates last searched keyword suggestion present in the suggestion tray");
                    conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchKeywordSuggestionName", String.valueOf(i))), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
                    getElement("searchKeywordSuggestionName", String.valueOf(i)).click();
                    break;
                }
            }
        }
    }

    @And("^user clicks outside the history and validates history tray closed$")
    public void userClicksOutsideTheHistoryAndValidatesHistoryTrayClosed() {
        logger.info("History tray is showing" + getElement("historyTrayNotFound").isDisplayed());
        getElement("clicksOnOutsideTheHistory").click();
        assertStepExecution(true, getOptionalElement("historyTrayNotFound") == null,
                "user clicks outside the history and validates history tray closed");

    }

    @And("^user searches \"([^\"]*)\" in global search box and validates history tray disappear$")
    public void userSearchesInGlobalSearchBoxAndValidatesHistoryTrayDisappear(String searchProduct1) {
        logger.info("History tray is showing" + getElement("historyTrayNotFound").isDisplayed());
        getElement("searchProductInGlobalSearchBox").sendKeys(searchProduct1);
//        assertStepExecution(true, getOptionalElement("historyTrayNotFound") == null,
//                "user searches keyword in global search box and validates history tray disappear");

    }

    @And("^user press the \"([^\"]*)\" arrow button and validates search suggestion toggled and displayed in search bar$")
    public void userPressTheArrowButtonAndValidatesSearchSuggestionToggledAndDisplayedInSearchBar(String arrowOption) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        List<WebElement> searchKeywordSuggestionList = getDriver().findElements(By.xpath("//li[@class='MuiAutocomplete-option']"));
        logger.info("searchKeywordSuggestionList size : " + searchKeywordSuggestionList.size());
        if (searchKeywordSuggestionList.size() < indexNine) {
            switch (arrowOption) {
                case "DownArrow":
                    for (int i = indexOne; i < searchKeywordSuggestionList.size(); i++) {
                        pressDownArrow(getElement("searchProductInGlobalSearchBox"));
                        logger.info("user pressed down arrow");
                        logger.info("Product details name is: " + getElement("searchSuggestionProductName", String.valueOf(i)).getText() + "Product details name in search bar is: " + getElement("searchProductInGlobalSearchBox").getAttribute("value"));
                        String searchedKeyword = getElement("searchSuggestionProductName", String.valueOf(i)).getText();
                        assertThat(searchedKeyword.replaceAll(" ", "")).isEqualToIgnoringCase(getElement("searchProductInGlobalSearchBox").getAttribute("value").replaceAll(" ", ""))
                                .describedAs("User press the arrow button and validates search suggestion toggled and displayed in search bar");
                    }
                    break;
                case "UpArrow":
                    for (int i = indexOne; i < searchKeywordSuggestionList.size(); i++) {
                        pressUpArrow(getElement("searchProductInGlobalSearchBox"));
                        logger.info("user pressed down arrow");
                        logger.info("Product details name is: " + getElement("searchSuggestionProductName", String.valueOf(i)).getText() + "Product details name in search bar is: " + getElement("searchProductInGlobalSearchBox").getAttribute("value"));
                        String searchedKeyword = getElement("searchSuggestionProductName", String.valueOf(i)).getText();
                        assertStepExecution(searchedKeyword.toLowerCase().replaceAll(" ", ""), getElement("searchProductInGlobalSearchBox").getAttribute("value").toLowerCase().replaceAll(" ", ""), "User press the arrow button and validates search suggestion toggled and displayed in search bar");
                        assertThat(searchedKeyword.replaceAll(" ", "")).isEqualToIgnoringCase(getElement("searchProductInGlobalSearchBox").getAttribute("value").replaceAll(" ", ""))
                                .describedAs("User press the arrow button and validates search suggestion toggled and displayed in search bar");
                    }
                    break;
            }
        }
        passStepExecution("user press the arrow button and validates search suggestion toggled and displayed in search bar");
    }

    @Given("^user searches \"([^\"]*)\" in global search box$")
    public void userSearchesInGlobalSearchBox(String searchProduct1) {
        String flag = "true";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        clearTextBox(getElement("searchProductInGlobalSearchBox"));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("searchProductInGlobalSearchBox")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("searchProductInGlobalSearchBox") != null,
                "user searches in global search box");
        getElement("searchProductInGlobalSearchBox").sendKeys(searchProduct1);
        setContext("product_available", flag);
    }

    @When("^user clicks on \"([^\"]*)\" as link from \"([^\"]*)\" option on \"([^\"]*)\" homepage/footer page option$")
    public void userClicksOnAsLinkFromOptionOnHomepageFooterPageOption(String dropdownLink, String clickableLink, String pageLinkOption) {
        int tabIndexLastValue = 5, homePageScrollUpSecondIndex = 300;
        List<WebElement> categoryLinksHomePageList;
        int tabIndexFirstValue = 1;
        switch (pageLinkOption) {
            case "Footer":
                windowScrollIntoTopToBottom();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("footerDropdown", dropdownLink)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                if (!(((getDriver().findElements(By.xpath(getLocator("footerDropdownActive", dropdownLink)))).size()) > 0))
                    getElement("footerDropdown", dropdownLink).click();
                getElement("clickLinksInFooter", clickableLink).click();
                break;
            case "Homepage":
                logger.info("Homepage/Footer Args: " + dropdownLink + " " + clickableLink + " " + pageLinkOption);
                clickingOnCategoryLinksHomePage(clickableLink, "NA");
                break;

            case "HomepageTopCategories":
                logger.info("Homepage/Footer Args: " + clickableLink + " " + dropdownLink + " " + pageLinkOption);
                windowScrollIntoTopToBottom();
                windowScrollIntoViewAdjustment(indexZero, homePageScrollUpSecondIndex);
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickLinksInFooter", clickableLink)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                clickingOnCategoryLinksHomePage(clickableLink, "homePageTopCategories");
                break;
        }

        if (clickableLink.equalsIgnoreCase("FAQs")) {
            categoryLinksHomePageList = getElements("faqsDetailsListXPath");
            logger.info("No of Product details are: " + categoryLinksHomePageList.size());
            for (int i = tabIndexFirstValue; i <= tabIndexLastValue; i++) {
                actionMoveToElementClick(getElement("faqsDetailsXpath", String.valueOf(i)));
            }
        }

        assertStepExecution(true, clickableLink != null, " Static links are enabled");
    }

    /*
     * user validates flyout sequence for my profile hover
     */
    @Then("^user hovers on user icon and validates \"([^\"]*)\" flyout sequence \"([^\"]*)\"$")
    public void userHoversOnUserIconAndValidatesFlyoutSequence(String validationYesNo, String expectedFlyoutSequence) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        actionMoveToElementBuild(getElement("signInUserDetails"));
        List<WebElement> elementPresent = getElements("displayedFlyoutSequence");

        if (validationYesNo.equalsIgnoreCase("yes")) {
            String[] flyoutSequence = expectedFlyoutSequence.split(";");
            for (int elem = 0; elem < flyoutSequence.length; elem++) {
                logger.info("elem is: " + elem + "flyoutSequence.length: " + flyoutSequence.length);
                if (elem == (flyoutSequence.length - 1)) {
                    logger.info("Flyout sequence Name is: " + flyoutSequence[elem]);
                    assertThat(getElement("logoutText").getText()).
                            isEqualToIgnoringCase(flyoutSequence[elem]).describedAs("user validates flyout sequence of My Account hover");

                    break;
                }
                String flyOutSequenceName = elementPresent.get(elem).getText();
                logger.info("Flyout sequence Name is: " + flyOutSequenceName);
                logger.info("Flyout sequence Name displayed is: " + flyoutSequence[elem]);
                assertThat(flyOutSequenceName).isEqualToIgnoringCase(flyoutSequence[elem]).describedAs("user validates flyout sequence of My Account hover");

            }

            passStepExecution("user validates flyout sequence for my profile hover");
        }
    }

    @And("^user changes pincode to \"([^\"]*)\"$")
    public void userChangesPincodeTo(String pincode) throws Throwable {
        JavascriptExecutor JS = (JavascriptExecutor) getDriver();
        windowScrollIntoViewByWebElement(getElement("keyFeatureText"));
        getElement("changePincodeButton").click();
        Thread.sleep(5000);
        //   getElement("changePincodeInput").clear();
        //      JS.executeScript("document.getElementsByName(\"pin\").item(0).value = ");
        //     Thread.sleep(5000);
        //   getElement("changePincodeInput").sendKeys(pincode);
        JS.executeScript("document.getElementsByName(\"pin\").item(0).value = " + pincode);

        Thread.sleep(5000);
        setContext("pinCode_applied", pincode);
        //    getElement("pdpPincodeChangeApply").click();
        JS.executeScript("document.getElementsByClassName(\"btn btn-secondary \")[0].click()");
        //   JS.executeScript("document.getElementsById(\"apply-pincode-btn\")[0].click()");
        logger.info("submit cclick done");
    }

    @And("^user clicks on croma logo at header section$")
    public void userClicksOnCromaLogoAtHeaderSection() {
        assertStepExecution(true, getElement("headerCromaLogo").isDisplayed(), "Croma logo should display at header section");
        //getElement("headerCromaLogo").click();
        jsClick(getElement("headerCromaLogo"));
        assertStepExecution(true, getDriver().getTitle().equalsIgnoreCase("Croma Electronics | Online Electronics Shopping | Buy Electronics Online"), "user lands on Croma homepage");
    }

    @When("^user clicks on \"([^\"]*)\" from footer$")
    public void userClicksOnFromFooter(String clickableLink) throws Throwable {
        String stepDesc = "user clicks on " + clickableLink + " from footer";
        windowScrollIntoBottom();
        int homePageScrollUpFirstIndex = 150;
        int homePageScrollDownFirstIndex = 0;
        windowScrollIntoViewAdjustment_scroll(0, 30000);
        Thread.sleep(8000);
        windowScrollIntoBottom();
//        getDriver().navigate().refresh();
//        Thread.sleep(8000);
//        windowScrollIntoBottom();
//   //     windowScrollIntoBottom();
//        windowScrollIntoTopToBottom();
//        windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpFirstIndex);
        //     Thread.sleep(5000);
        windowScrollIntoViewByWebElementTrue(getOptionalElement("clickLinksInFooter", clickableLink));
        assertStepExecution(true, getOptionalElement("clickLinksInFooter", clickableLink) != null, stepDesc);
        jsClick(getElement("clickLinksInFooter", clickableLink));
    }

    @And("^user lands on corresponding navigated page having title as \"([^\"]*)\"$")
    public void userLandsOnCorrespondingNavigatedPageHavingTitleAs(String pageTitle) throws Throwable {
        String stepDesc = "user lands on corresponding navigated page having title as " + pageTitle;
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(2000);
        String title = getElement("categoryPageTitle", pageTitle).getText();
        assertStepExecution(pageTitle, title, stepDesc);
    }

    @And("^user clicks on FAQs arrow and view it$")
    public void userClicksOnFAQsArrowAndViewIt() {
        int tabIndexFirstValue = 1, tabIndexLastValue = 5;
        List<WebElement> categoryLinksHomePageList = getElements("faqsDetailsListXPath");
        assertStepExecution(true, categoryLinksHomePageList.size() > 0, "user clicks on FAQs arrow and view it");
        logger.info("No of Product details are: " + categoryLinksHomePageList.size());
        for (int i = tabIndexFirstValue; i <= tabIndexLastValue; i++) {
            actionMoveToElementClick(getElement("faqsDetailsXpath", String.valueOf(i)));
        }
    }

    @And("^user lands on Croma homepage$")
    public void userLandsOnCromaHomepage() {
        getDriver().get(getConfig("URL"));
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getDriver().getTitle().length() > 0, "user lands on Croma homepage");
    }

    @And("^user wait for \"([^\"]*)\" seconds$")
    public void userWaitForSeconds(String second) throws Throwable {
//        assertStepExecution(true, second.length() > 0, "user wait for " + " seconds");
//        Thread.sleep(Integer.parseInt(second) * 1000);
        Thread.sleep(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_MED")) * 100);
    }

    @And("user navigates back to previous page from current page")
    public void userNavigatesBackToPreviousPageFromCurrentPage() {

        getDriver().navigate().back();
    }

    @And("user expands {string} in footer")
    public void userExpandsInFooter(String tileOption) throws InterruptedException {
        windowScrollIntoTopToBottom();
        Thread.sleep(5000);
        jsClick(getElement("footerLinkTitle", tileOption));
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("footerLinkTitle", tileOption) != null,
                "user expands " + tileOption + " in footer");
    }

    @Given("user handles the unexpected popup")
    public static void userHandlesTheUnexpectedPopup() throws InterruptedException {
        processScreenshot();
        if (getDriver().findElements(By.xpath("//*[@id='custom-icon-close']")).size() > 0) {
            //  getDriver().findElement(By.xpath("//*[@id='custom-icon-close']")).click();
            jsClick(getDriver().findElement(By.xpath("//*[@id='custom-icon-close']")));
        }


    }

    //*[@class='close-btn mini-cart-dialog-close-mob crossPosition']
    @Given("user handles the unexpected mini-cart-dialog popup")
    public static void userHandlesTheUnexpectedMiniCartDialogPopup() throws InterruptedException {
        processScreenshot();
        if (getDriver().findElements(By.xpath(getLocator("continueShopping"))).size() > 0) {
            getDriver().findElement(By.xpath(getLocator("continueShopping"))).click();

        }


    }


    @Given("user handles the unexpected pincode popup")
    public static void userHandlesTheUnexpectedPincodePopup() throws InterruptedException {

        Thread.sleep(5000);
        if (getOptionalElement("unExpectedPincodePopUp") != null) {

            getElement("unExpectedPincodePopUp").clear();
            Thread.sleep(3000);
            getElement("unExpectedPincodePopUp").sendKeys("400096");
            getDriver().findElement(By.xpath("//button[@id='apply-pincode-btn' and @type='submit']")).click();
        }

    }

    @Given("user refresh the landing page to be load properly")
    public static void userRefreshTheLandingPageToBeLoadProperly() throws InterruptedException {
        boolean isDisplayed = false;

        for (int i = 0; i < 5; i++) {
            if (getOptionalElement("cromaLogo") != null) {
                isDisplayed = true;
                assertStepExecution(true, isDisplayed, "user refresh the landing page to be load properly");
                break;
            } else {
                getDriver().navigate().refresh();
                Thread.sleep(2000);
            }
        }
        if (!isDisplayed)
            assertStepExecution(true, isDisplayed, "user refresh the landing page to be load properly");

    }


    @And("user captures the screenshot")
    public static void userCapturesTheScreenshot() {
        processScreenshot("Screenshot Attachment", "TRUE");
    }

    @And("user clicks on Help link")
    public void userClicksOnHelpLink() {
        assertStepExecution(true, getOptionalElement("helpLink") != null, "user clicks on Help link");
        getElement("helpLink").click();
    }

    @And("user successfully logged in")
    public void userSuccessfullyLoggedIn() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("myAccountLinkPresent") != null,
                "user successfully logged in");
    }

    @And("user waits for page loader to be invisible")
    public static void userWaitsForPageLoaderToBeInvisible() throws InterruptedException {
        int timer = 0;
        while (getOptionalElement("loadingIcon") != null && timer != 12) {
            logger.info("Loading Icon is present, waiting for timer " + timer);
            Thread.sleep(5000);
            timer++;
        }
    }

    @And("user validates Product is added to your cart message")
    public void userValidatesProductIsAddedToYourCartMessage() {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("addToCartSuccessMsg")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("addToCartSuccessMsg") != null,
                "user validates Product is added to your cart message");
    }

    @And("user stores the current page url")
    public void userStoresTheCurrentPageUrl() {
        setContext("url_Currentpage", getDriver().getCurrentUrl());
    }


    @And("user clicks on cross icon on mini cart pop up")
    public void userClicksOnCrossIconOnMiniCartPopUp() {
        assertStepExecution(true, getOptionalElement("crossButtonOnMiniCart") != null, "User verifies the cross button on mini cart popup");
        getElement("crossButtonOnMiniCart").click();
    }

    @Then("user validates {string} should display below pincode field")
    public void userValidatesShouldDisplayBelowPinCodeField(String errorMassage) {
        String pincodeErrorMsg = getElement("pincodeErrorMsg").getText();
        assertStepExecution(pincodeErrorMsg, errorMassage, "Error msg should display below pincode field");
    }

    @And("user checks croma store web details {string} should display in connect to store popup")
    public void userChecksCromaStoreWebDetailsShouldDisplayInConnectToStorePopup(String webDetail) {
        assertThat(getOptionalElement("connectToStoreText"))
                .describedAs("Connect to store text should display in popup").isNotNull();
        assertThat(getElement("cromaWebStore").getText())
                .describedAs("Croma web store should display below connect to store test").isEqualTo(webDetail);
        passStepExecution("Croma web store should display below connect to store test +  :: Passed \n");
    }


    @And("user checks request a call back and operational store list button should appear in connect to store popup")
    public void userChecksRequestACallBackAndOperationalStoreListButtonShouldAppearInConnectToStorePopup() {
        assertThat(getOptionalElement("requestACallBackButton"))
                .describedAs("Request a Call Back button should display in popup").isNotNull();
        assertThat(getOptionalElement("optionalStoreListButton"))
                .describedAs("Optional Store List button should display in popup").isNotNull();
        passStepExecution("user checks request a call back and operational store list button should appear in connect to store popup +  :: Passed \n");
    }

    @And("user validates appointment at store button should not appear in connect to store popup when near store not available")
    public void userValidatesAppointmentAtStoreButtonShouldNotAppearInConnectToStorePopupWhenNearStoreNotAvailable() {
        assertStepExecution(true, getOptionalElement("appointmentAtStoreButton") == null, "appointment at store button should display in popup");
    }

    @And("user clicks on request a call back button from connect to store popup and call back form should open")
    public void userClicksOnRequestACallBackButtonFromConnectToStorePopupAndCallBackFormShouldOpen() {
        assertStepExecution(true, getElement("requestACallBackButton").isDisplayed(), "Request a Call Back button should display in popup");
        getElement("requestACallBackButton").click();
    }

    @Then("user validates direct me there CTA should not appear in the request a call back form")
    public void userValidatesDirectMeThereCTAShouldNotAppearInTheRequestACallBackForm() {
        assertStepExecution(true, getOptionalElement("directMeThereNotPresent") == null, "direct me there CTA should not appear in the request a call back form");
    }

    @And("user clicks on operational store list button from connect to store popup and should redirect to operational store list page \"([^\"]*)\"$")
    public void userClicksOnOperationalStoreListButtonFromConnectToStorePopupAndShouldRedirectToOperationalStoreListPageStoresOperationalStatusPage(String storeOperationalStatusPageTitle) throws Throwable {
        assertThat(getOptionalElement("optionalStoreListButton"))
                .describedAs("Request a Call Back button should display in popup").isNotNull();
        getElement("optionalStoreListButton").click();
        assertThat(getElement("storeOperationalStatusPageTitle").getText())
                .describedAs("Store operational status title should match").isNotNull();
        passStepExecution("user clicks on operational store list button from connect to store popup and should redirect to operational store list page +  :: Passed \n");
    }

    /*
     * user validates 3 buttons CART SHIPPING AND PAYMENT buttons are present in header section
     */

    @And("user validates three buttons are present in checkout page in header section")
    public void userValidatesThreeButtonsArePresentInCheckoutPageInHeaderSection() throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getOptionalElement("cartShoppingPaymentButtons") != null,
                "user validates three buttons are present in checkout page in header section");
    }

    /*
     * user validates 3 buttons CART SHIPPING AND PAYMENT buttons are absent in header section
     */

    @And("user validates three buttons are absent in checkout page in header section")
    public void userValidatesThreeButtonsAreAbsentInCheckoutPageInHeaderSection() throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("cartShoppingPaymentButtons") == null,
                "user validates three buttons are absent in checkout page in header section");
    }

    @And("user validates last viewed widget suggestion present in the suggestion tray")
    public void userValidatesLastViewedWidgetSuggestionPresentInTheSuggestionTray() {
        List<WebElement> searchKeywordSuggestionList = getDriver().findElements(By.xpath("//div[contains(text(),'Recent Viewed Items')]//following::div[@class='product-info']"));
        logger.info("searchKeywordSuggestionList size : " + searchKeywordSuggestionList.size());
        if (searchKeywordSuggestionList.size() == indexZero) {
            logger.info("User not viewed any widget");
        }
        if (searchKeywordSuggestionList.size() < indexNine) {
            for (int i = indexOne; i <= searchKeywordSuggestionList.size(); i++) {
                logger.info("Product details name is: " + getElement("viewedWidgetProductName", String.valueOf(i)).getText() + "Product price: " + getElement("viewedWidgetProductPrice", String.valueOf(i)).getText());
                logger.info("Product Rating: " + (getElement("viewedWidgetProductRating", String.valueOf(i))).getAttribute("aria-label"));
                String searchedWidget = getElement("viewedWidgetProductName", String.valueOf(i)).getText();
                if (searchedWidget.equalsIgnoreCase(getContext("firstProductNameOfTheSection"))) {
                    logger.info("last searched keyword present" + searchedWidget + "Saved data" + getContext("firstProductNameOfTheSection"));
                    assertStepExecution(searchedWidget, getContext("firstProductNameOfTheSection"), "User validates last searched keyword suggestion present in the suggestion tray");
                    break;
                }
            }
        }

    }

    @And("user click on the close button of last searched keyword {string} suggestion present in the suggestion tray")
    public void userClickOnTheCloseButtonOfLastSearchedKeywordSuggestionPresentInTheSuggestionTray(String searchKeyword) {
        List<WebElement> searchKeywordSuggestionList = getDriver().findElements(By.xpath("(//div[@class= 'search-history-option']/span[@class='search-history-option-name'])"));
        logger.info("searchKeywordSuggestionList size : " + searchKeywordSuggestionList.size());
        if (searchKeywordSuggestionList.size() < indexNine) {
            for (int i = indexOne; i < searchKeywordSuggestionList.size(); i++) {
                logger.info("Product details name is: " + getElement("searchKeywordSuggestionName", String.valueOf(i)).getText());
                String searchedKeyword = getElement("searchKeywordSuggestionName", String.valueOf(i)).getText();
                if (searchKeyword.equalsIgnoreCase(searchedKeyword)) {
                    logger.info("last searched keyword present" + searchedKeyword);
                    assertStepExecution(searchedKeyword, searchKeyword, "User validates last searched keyword suggestion present in the suggestion tray");
                    getElement("closeSearchKeywordSuggestionName", searchKeyword).click();
                    break;
                }
            }
        }
    }

    @And("user searches three char as {string} in global search box and show autocomplete and auto suggestion options")
    public void userSearchesThreeCharAsInGlobalSearchBoxAndShowAutocompleteAndAutoSuggestionOptions(String searchProduct) throws InterruptedException {
        logger.info("Searched Product is: " + searchProduct);
        getElement("searchProductInGlobalSearchBox").sendKeys(searchProduct);
        Thread.sleep(2000);
        List<WebElement> searchKeywordSuggestionList = getDriver().findElements(By.xpath("//div[@class='auto-sugget-div search-history-option']/div"));
        logger.info("searchKeywordSuggestionList size : " + searchKeywordSuggestionList.size());
        for (int i = indexOne; i < searchKeywordSuggestionList.size(); i++) {
            logger.info("Product details name is: " + getElement("autoSuggestKeywordSuggestionName", String.valueOf(i)).getText());
            String searchedKeyword = getElement("autoSuggestKeywordSuggestionName", String.valueOf(i)).getText();
            assertThat(searchedKeyword).describedAs("user searches three char in global search box and show autocomplete and auto suggestion options").containsIgnoringCase(searchProduct);
        }
    }

    /*
     * user verifies shop by category text is present in hamburger menu
     */

    @And("user verifies shop by category text is present in hamburger menu")
    public void userVerifiesShopByCategoryTextIsPresentInHamburgerMenu() {
        assertStepExecution(true, getOptionalElement("shopByCategoryTextInHamburgerMenu") != null,
                "user verifies shop by category text is present in hamburger menu");
        logger.info("Shop By Category Text is: " + getElement("shopByCategoryTextInHamburgerMenu").getText());
    }

    /*
     * user validates corresponding navigated page having title
     */

    @Then("user validates corresponding navigated page having title as {string}")
    public void userValidatesCorrespondingNavigatedPageHavingTitleAs(String userAccountLink) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        if (!userAccountLink.equalsIgnoreCase("My Rewards")) {
            String userAccountLinkTitle = getElement("userAccountLinkTitle").getText();
            logger.info("Account link title :-" + userAccountLinkTitle);
            assertStepExecution(true, userAccountLinkTitle.contains(userAccountLink), "user validates corresponding navigated page having user account link title");
        }
    }

    /*
     * user provides pincode  from header and PDP page
     */
    @And("user provides pincode {string} from {string} page")
    public void userProvidesPincodeFromPage(String pinCode, String page) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("Pincode entered: " + pinCode);
        if (page.equalsIgnoreCase("header")) {
            jsClick(getElement("clickOnDeliveringTo"));
            getElement("pinCodeHome").clear();
        } else if (page.equalsIgnoreCase("pdpPincodeEdit")) {
            jsClick(getElement("pdpPincodeInputField"));
            clearTextBox(getElement("pinCodeHome"));
        }
        assertStepExecution(true, getOptionalElement("pinCodeHome") != null,
                "user validates pincode section is present");
        getElement("pinCodeHome").sendKeys(pinCode);
        setContext("pinCode_applied", pinCode);
    }

    /*
     * user validates continue button enable or disable in the pincode textbox
     */
    @And("user validates continue button {string} in the pincode textbox")
    public void userValidatesContinueButtonInThePincodeTextbox(String enableDisable) {
        String strClass = getElement("pinCodeSubmit").getAttribute("class");
        logger.info("class = " + strClass);
        switch (enableDisable) {
            case "Enable":
                assertThat(strClass).contains("default").describedAs("Continue button is enable");
                break;
            case "Disable":
                assertThat(strClass).contains("secondary-dark").describedAs("Continue button is disable");
                break;
        }
        passStepExecution("user validates continue button in the pincode textbox:: Passed");
    }

    /*
     * user validates continue button in the pincode textbox
     */
    @And("user clicks on continue button in the pincode textbox")
    public void userClicksOnContinueButtonInThePincodeTextbox() {
        assertStepExecution(true, getOptionalElement("pinCodeSubmit") != null,
                "user validates continue button is present in the pincode textbox");
        jsClick(getElement("pinCodeSubmit"));
    }

    /*
     * user validates error message after invalid pincode is entered
     */
    @And("user validates {string} as error message after invalid pincode is entered")
    public void userValidatesAsErrorMessageAfterInvalidPincodeIsEntered(String errorMessage) {
        String errorMessageOnPincodeTextBox = getElement("errorMessageOnPincodeTextBox", errorMessage).getText();
        logger.info("Data from web: " + errorMessageOnPincodeTextBox + "data from DB: " + errorMessage);
        assertStepExecution(true, errorMessageOnPincodeTextBox.equals(errorMessage), "user validates error message after invalid pincode is entered");
    }

    /*
     * user validates pincode popup is not present
     */
    @Then("user validates pincode popup is not present")
    public void userValidatesPincodePopupIsNotPresent() {
        assertStepExecution(true, getOptionalElement("pinCodePopupClose") == null,
                "user validates pincode popup is not present");
    }

    /*
     * user clicks on sign in to select address button in pincode textbox
     */
    @When("user clicks on sign in to select address button in pincode textbox")
    public void userClicksOnSignInToSelectAddressButtonInPincodeTextbox() {
        assertStepExecution(true, getOptionalElement("signInToSelectAddressButton") != null,
                "user validates  sign in to select address button is present in pincode textbox");
        jsClick(getElement("signInToSelectAddressButton"));
    }

    /*
     * user clicks on saved address checkbox in address popup
     */
    @And("user clicks on saved address {string} checkbox in address popup")
    public void userClicksOnSavedAddressCheckboxInAddressPopup(String addressTypeName) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addressIconRadioButton", addressTypeName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("addressIconRadioButton", addressTypeName).isDisplayed(), "Edit address icon displayed in checkout order summary page");
        logger.info("Address details is: " + getElement("selectAddressName", addressTypeName) + getElement("selectAddressType", addressTypeName) + getElement("selectAddress1", addressTypeName) + getElement("selectAddressCityName", addressTypeName) + getElement("selectAddressStateName", addressTypeName) + getElement("selectAddressPincode", addressTypeName) + getElement("selectAddressMobileNo", addressTypeName));
        getElement("addressIconRadioButton", addressTypeName).click();
    }

    /*
     * user clicks on confirm shipping address button in address popup
     */
    @And("user clicks on confirm shipping address button in address popup")
    public void userClicksOnConfirmShippingAddressButtonInAddressPopup() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("confirmShippingAddressButton") != null,
                "user clicks on confirm shipping address button in address popupx");
        jsClick(getElement("confirmShippingAddressButton"));
    }

    /*
     * user validates the pincode successful message
     */
    @And("user validates the pincode successful {string} message")
    public void userValidatesThePincodeSuccessfulMessage(String pincodeSuccessfulText) {
        String pincodeSuccessfulTextActual = getElement("pincodeSuccessfulTextValidation").getText();
        logger.info("The get texted value is=" + pincodeSuccessfulTextActual + " The message from data base is:" + pincodeSuccessfulText);
        assertStepExecution(pincodeSuccessfulText, pincodeSuccessfulTextActual,
                "User validates the pincode successful message");
    }

    /*
     * user clicks on select address button in pincode textbox
     */
    @When("user clicks on select address button in pincode textbox")
    public void userClicksOnSelectAddressButtonInPincodeTextbox() {
        assertStepExecution(true, getOptionalElement("selectAddressButton") != null,
                "user validates select address button is present in pincode textbox");
        jsClick(getElement("selectAddressButton"));
    }

    /*
     * user clicks on get current location option in pincode textbox
     */
    @And("user clicks on get current location option in pincode textbox")
    public void userClicksOnGetCurrentLocationOptionInPincodeTextbox() {
        assertStepExecution(true, getOptionalElement("getCurrentLocation") != null,
                "user validates get current location is present in pincode textbox");
        getElement("getCurrentLocation").click();
    }

    /*
     * user validates pincode changed in pincode textbox
     */
    @And("user validates pincode changed in pincode textbox")
    public void userValidatesPincodeChangedInPincodeTextbox() throws InterruptedException {
        logger.info("Updated pincode in pincode textbox is: " + getElement("pinCodeHome").getAttribute("value") + " and Saved pincode: " + getContext("pinCode_applied"));
        assertStepExecution(true, !getElement("pinCodeHome").getAttribute("value").equals(getContext("pinCode_applied")),
                "user validates pincode changed in pincode textbox");
    }

    /*
     *This method is used to validate he successful user login toaster message
     */
    @And("user verifies the toaster message {string}")
    public void userVerifiesTheToasterMessage(String message) {
        //Thread.sleep(3000);
        if (getOptionalElement("successfulUserLoginToaster") != null)
            assertStepExecution(true, getOptionalElement("successfulUserLoginToaster").getText().equals(message), "user verifies the successful user login toaster message ");
        else
            assertThat(message).describedAs("user verifies the toaster message" + message).doesNotMatch(getOptionalElement("successfulUserLoginToaster").getText());
    }

    /*
     *This method is used to validate saved addresses should present in address popup
     */
    @And("user validates saved address {string} should present in address popup")
    public void userValidatesSavedAddressShouldPresentInAddressPopup(String addressTypeName) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addressIconRadioButton", addressTypeName)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getElement("addressIconRadioButton", addressTypeName).isDisplayed(), "Edit address icon displayed in checkout order summary page");
        logger.info("Address details is: " + getElement("selectAddressName", addressTypeName) + getElement("selectAddressType", addressTypeName) + getElement("selectAddress1", addressTypeName) + getElement("selectAddressCityName", addressTypeName) + getElement("selectAddressStateName", addressTypeName) + getElement("selectAddressPincode", addressTypeName) + getElement("selectAddressMobileNo", addressTypeName));

    }

    /*
     *This method is used to validate cross to close button is present in select your address popup
     */
    @And("user validates cross to close button is present in select your address popup")
    public void userValidatesCrossToCloseButtonIsPresentInSelectYourAddressPopup() {
        assertStepExecution(true, getOptionalElement("pinCodePopupClose").isDisplayed(), "pincode pop up close on cart page");
    }

    /*
     *This method is used to validate go back arrow is present in select your address popup
     */
    @And("user validates go back arrow is present in select your address popup")
    public void userValidatesGoBackArrowIsPresentInSelectYourAddressPopup() {
        assertStepExecution(true, getOptionalElement("goBackArrow").isDisplayed(), "pincode pop up close on cart page");

    }

    /*
     *This method is used to clicks on go back arrow and navigate to pincode popup
     */
    @And("user clicks on go back arrow and navigate to pincode popup")
    public void userClicksOnGoBackArrowAndNavigateToPincodePopup() {
        assertStepExecution(true, getOptionalElement("goBackArrow").isDisplayed(), "pincode pop up close on cart page");
        getElement("goBackArrow").click();
    }

    /*
     *This method is used to validates title messages in select your address popup
     */
    @And("user validates title messages {string}, {string} in select your address popup")
    public void userValidatesTitleMessagesInSelectYourAddressPopup(String message1, String message2) {
        logger.info("displayed first message: " + getElement("firstMessage").getText());
        logger.info("displayed second message: " + getElement("secondMessage").getText());
        assertThat(getElement("firstMessage").getText()).
                describedAs("first message in select your address popup ").isEqualToIgnoringCase
                (message1);
        assertThat(getElement("secondMessage").getText()).
                describedAs("second message in select your address popup ").isEqualToIgnoringCase
                (message2);
        passStepExecution("user validates messages in select your address popup:: Passed");

    }

    /*
     *This method is used to validates saved addresses with radio button should present
     */
    @And("user validates saved addresses with radio button should present")
    public void userValidatesSavedAddressesWithRadioButtonShouldPresent() {
        List<WebElement> savedAddressDetailsList = getElements("savedAddressDetailsListXPath");
        logger.info("No of Product details are: " + savedAddressDetailsList.size());
        for (int i = indexOne; i < savedAddressDetailsList.size(); i++) {
            logger.info(i + ". " + "Address details is: " + getElement("SavedAddressName", String.valueOf(i)).getText() + getElement("SavedAddressType", String.valueOf(i)).getText() + getElement("SavedAddressFirstLine", String.valueOf(i)).getText() + getElement("SavedAddressCityName", String.valueOf(i)).getText() + getElement("SavedAddressStateName", String.valueOf(i)).getText() + getElement("SavedAddressPincode", String.valueOf(i)).getText() + getElement("SavedAddressMobileNo", String.valueOf(i)).getText());
            assertStepExecution(true, getElement("savedAddressWithRadioButton", String.valueOf(i)).isDisplayed(), "Saved address with radio button");
        }
    }

    /*
     *This method is used to validates address is not saved with message
     */
    @And("user validates address is not saved with message {string}")
    public void userValidatesAddressIsNotSavedWithMessage(String noSavedAddressMessage) {
        logger.info("No saved address message is :" + getElement("noSavedAddressMsg").getText() + "From DB massage: " + noSavedAddressMessage);
        assertStepExecution(getElement("noSavedAddressMsg").getText(), noSavedAddressMessage, "user validates address is not saved with message");
    }

    /*
     *This method is used to navigate back on pwa site from different site
     */
    @And("user launches the PWA site {string}")
    public void userLaunchesThePWASite(String cromaAppURL) {
        getDriver().get(getConfig(cromaAppURL));
        assertStepExecution(true, getDriver().getTitle().length() > 0, "Validation of application launch");
    }

    /*
     *This method is used to click on deal zone category first option
     */
    @And("user clicks on deal zone category first option")
    public void userClicksOnDealZoneCategoryFirstOptionAndLandsOnProductListingPage() {
        assertStepExecution(true, getElement("dealZoneOptionArrow") != null, "Validation of arrow present");
        getElement("dealZoneOptionArrow").click();
        getElement("dealZoneOption").click();
    }

    /*
     *This method is used to goes over deal zone category
     */
    @And("user goes over deal zone category")
    public void userGoesOverDealZoneCategory() throws InterruptedException {
        List<WebElement> elementPresent = getElements("dealZoneOptionListSize");
        logger.info("No of element are: " + elementPresent.size());
        if (elementPresent.size() != 0) {
            assertStepExecution(true, getOptionalElement("dealZoneOptionListSize") != null, "Category option found.");
            actionMoveToElementBuild(getElement("dealZoneOptionListSize"));
        }
    }

    public static void userClicksOnMenuIconAndCloseIt() throws InterruptedException {
        Thread.sleep(2000);
        getElement("menuBreadCrum").click();
        Thread.sleep(3000);
        getElement("menuCrossButton").click();
    }

    @And("user verifies the login popup")
    public void userVerifiesTheLoginPopup() throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(true, getElement("loginPopupHeading") != null,
                "user verifies the login popup");
    }

    @And("user validates the cart {string} count on cart icon")
    public void userValidatesTheCartCountOnCartIcon(String count) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("cartCountOnCartIcon")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String countFromWeb = getElement("cartCountOnCartIcon").getText().trim();
        assertStepExecution(countFromWeb, count, "user validates the cart " + count + " count on cart icon");
    }

    //Revathi
    @When("user searches the product {string}")
    public void userSearchesTheProduct(String productId) throws InterruptedException {
        logger.info("URL is " + getConfig("URL") + "/bosch-10-kg-5-star-fully-automatic-top-loading-washing-machine-woa106x0in-inox-/p/" + productId);
        getDriver().get(getConfig("URL") + "/bosch-10-kg-5-star-fully-automatic-top-loading-washing-machine-woa106x0in-inox-/p/" + productId + "");
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        setContext("product_available", "true");
    }

    @And("user validates recommended results match with the search keyword {string}")
    public void userValidatesRecommendedResultsMatchWithTheSearchKeyword(String keyWord) {
        //List<WebElement> searchKeywordSuggestionList1 = getDriver().findElements(By.xpath("//ul[@id='search-popup']//li"));
        List<WebElement> searchKeywordSuggestionList1 = getElements("Searchbarsuggestedresults");

        logger.info("size is:" + searchKeywordSuggestionList1.size());
        for (WebElement Suggestedresults : searchKeywordSuggestionList1) {
            String text = Suggestedresults.getText();
            logger.info("Recommended product name is:" + Suggestedresults.getText());
            if (keyWord.equalsIgnoreCase("Mobile") || keyWord.equalsIgnoreCase("Phone")) {
                assertStepExecution(true, text.contains(keyWord) || text.contains("Phone"), "user validates recommended results match with the search keyword");
            } else {
                assertStepExecution(true, text.contains(keyWord), "user validates recommended results match with the search keyword");
            }

        }
        clearTextBox(getElement("search1"));
    }


    @And("user validates the count as {string} on cart icon")
    public void userValidatesTheCountAsOnCartIcon(String count) throws InterruptedException {
        Thread.sleep(6000);
        String stepDesc = "user validates the count as " + count + " on cart icon";
        conditionalWait(ExpectedConditions.visibilityOf(getElement("itemCountOnCartIconNotification")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        String countOnWeb = getElement("itemCountOnCartIconNotification").getText();
        assertStepExecution(count, countOnWeb, stepDesc);
    }

    @Then("user verifies the {string} product is added to cart page as {string}")
    public void userVerifiesTheProductIsAddedToCartPageAs(String productNameInCartPage, String count) {
        String product = getElement("productNameInCartPage", productNameInCartPage).getText();
        logger.info("The name of same product is :" + product);
        assertStepExecution(productNameInCartPage, product, "user verifies the same product name is present");
        List<WebElement> productList1 = getDriver().findElements(By.xpath(getLocator("productNameInCartPage", productNameInCartPage)));
        logger.info("Number of same products are : " + productList1.size());
        assertThat(productList1.size()).isEqualTo(Integer.parseInt(count)).describedAs("user validate total count has been increased in cart page");
    }

    @And("user searches the product {string} from url")
    public void userSearchesTheProductFromUrl(String productId) throws InterruptedException {
        getDriver().get("https://dev12-pwa.croma.com/bosch-10-kg-5-star-fully-automatic-top-loading-washing-machine-woa106x0in-inox-/p/" + productId + "");
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        setContext("product_available", "true");
    }
}






