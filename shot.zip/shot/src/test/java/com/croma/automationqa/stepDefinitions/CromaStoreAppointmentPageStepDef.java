package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.*;


/*
     All the store appointment related function defined in CromaStoreAppointmentPageStepDef class
*/
public class CromaStoreAppointmentPageStepDef {


    /*
        User selects buy on a phone call option
    */
    @And("^user selects buy on a phone call option$")
    public void userSelectsBuyOnAPhoneCallOption() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clicksOnBuyOnPhoneCallButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        processScreenshot();
        getElement("clicksOnBuyOnPhoneCallButton").click();
    }


    /*
        User provides the details and clicks on raise request button
    */
    @And("^user provides the details \"([^\"]*)\" as name, \"([^\"]*)\" as phone number, \"([^\"]*)\" as remarks, \"([^\"]*)\" as preferred call back time and clicks on raise request button$")
    public void userProvidesTheDetailsAsNameAsPhoneNumberAsRemarksAsPreferredCallBackTimeAndClicksOnRaiseRequestButton(String fullName1, String phoneNumber1, String lookingFor, String callbackTime) throws InterruptedException {

        getElement("provideFullName").sendKeys(fullName1);
        getElement("provideMobileNumber").sendKeys(phoneNumber1);
        getElement("whatCanWeHelpYouWith").click();
        Thread.sleep(2000);
        getElement("selectCallBackOption", lookingFor).click();
        getElement("provideRemarks").sendKeys(lookingFor);
        getElement("preferredTime").click();
        Thread.sleep(2000);
        getElement("selectCallBackOption", callbackTime).click();
        assertStepExecution(true, getOptionalElement("callBackDoneBtn") != null, "Done Button Should Display in Call Back Modal");
        getElement("callBackDoneBtn").click();
        Thread.sleep(3000);
        // getElement("clicksOnRaiseARequestButton").click();
    }


    /*
        User validates the appointment booking confirmation message through call
    */
    @Then("^user validates the appointment booking confirmation \"([^\"]*)\" message through call$")
    public void userValidatesTheAppointmentBookingConfirmationMessageThroughCall(String appointmentBookingConfirmationMsg) {
        //  String appointmentBookingConfirmationText = getElement("appointmentBookingConfirmationTextValidationThroughCall").getText();
        //   logger.info("The get texted value is=" + appointmentBookingConfirmationText+"The message from data base is:" + appointmentBookingConfirmationMsg);
        //   processScreenshot();
       /* assertStepExecution(appointmentBookingConfirmationMsg,appointmentBookingConfirmationText,
                "User validates the appointment booking confirmation message through call");*/
        assertStepExecution(true, getElement("buyOnCallPopUpClose").isDisplayed(), "Buy on call close popup displayed");
        getElement("buyOnCallPopUpClose").click();
    }


    /*
        User selects appointment at store option on listing page
    */
    @And("^user selects appointment at store option$")
    public void userSelectsAppointmentAtStoreOption() throws InterruptedException {
        // conditionalWait(ExpectedConditions.elementToBeClickable(getElement("AppointmentAtStoreListingPage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        /*
            Conditional wait is not working if running from MainRunner, hence using Thread.sleep
         */
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("AppointmentAtStoreListingPage") != null,
                "user selects appointment at store option");
        getElement("AppointmentAtStoreListingPage").click();
    }

    /*
        User selects Buy on call on listing page
    */
    @And("^user selects buy on a phone call option on listing page$")
    public void userSelectsBuyOnAPhoneCallOptionOnListingPage() throws InterruptedException {
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("BuyOnCallListingPage")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        /*
            Conditional wait is not working if running from Main runner, hence use Thread.sleep
         */
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("BuyOnCallListingPage") != null,
                "user selects buy on a phone call option on listing page");
        getElement("BuyOnCallListingPage").click();
    }


    /*
        User lands on appointment page and provides the details and selects appointment slot and clicks on book now button
    */
    @And("^user lands on appointment page and provides the details \"([^\"]*)\" as name, \"([^\"]*)\" as email, \"([^\"]*)\" as phone number, \"([^\"]*)\" as pincode, \"([^\"]*)\" as store and selects appointment slot and clicks on book now button$")
    public void userLandsOnAppointmentPageAndProvidesTheDetailsAsNameAsEmailAsPhoneNumberAsPincodeAsStoreAndSelectsAppointmentSlotAndClicksOnBookNowButton(String fullName1, String emailId1, String phoneNumber1, String pinCode1, String store1) throws InterruptedException {

        getDriver().switchTo().frame(getElement("appointmentPageIframe"));
        Thread.sleep(3000);
        getElement("provideFullNameForAppointment").sendKeys(fullName1);
        getElement("provideEmailForAppointment").sendKeys(emailId1);
        getElement("provideMobileNumberForAppointment").sendKeys(phoneNumber1);
        getElement("providePinCodeForAppointment").sendKeys(pinCode1);
        Thread.sleep(2000);
        getElement("selectStore").click();
        getElement("selectStoreOption", store1).click();
        assertStepExecution(true, getOptionalElement("clicksOnNextButton") != null,
                "User lands on appointment page and provides the details and selects appointment slot and clicks on book now button");
        getElement("clicksOnNextButton").click();
        // conditionalWait(ExpectedConditions.elementToBeClickable(getElement("SelectAppointmentTime")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        Thread.sleep(2000);
        if (getOptionalElement("SelectAppointmentTime") != null) {
            getElement("SelectAppointmentTime").click();
        }
        //  getElement("clicksOnBookNowButton").click();
    }


    /*
        User validates the appointment booking confirmation message
    */
    @Then("^user validates the appointment booking confirmation \"([^\"]*)\" message$")
    public void userValidatesTheAppointmentBookingConfirmationMessage(String appointmentBookingConfirmationMsg) {
        //  String appointmentBookingConfirmationText = getElement("appointmentBookingConfirmationTextValidation").getText();
        // logger.info("The get texted value is=" + appointmentBookingConfirmationText + " The message from data base is:" + appointmentBookingConfirmationMsg);
        //   processScreenshot();
     /*   assertStepExecution(appointmentBookingConfirmationMsg,appointmentBookingConfirmationText,
                "User validates the appointment booking confirmation message");*/
    }

    /*
            user selects store or call option for the appointment
        */
    @And("^user selects \"([^\"]*)\" appointment at store or by phone call option in the window having message \"([^\"]*)\"$")
    public void userSelectsAppointmentAtStoreOrByPhoneCallOptionInTheWindowHavingMessage(String appointmentOption, String appointmentWindowText) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("connectToStoreWindowText")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(appointmentWindowText.toLowerCase(), getElement("connectToStoreWindowText").getText().toLowerCase(), "Connect To Store window text is matching");
        if (appointmentOption.equalsIgnoreCase("store"))
            getElement("connectToStoreAppointmentAtStore").click();
        else if (appointmentOption.equalsIgnoreCase("call"))
            getElement("connectToStoreBuyOnPhoneCall").click();
    }

    /*
       User validates the appointment booking confirmation message
   */
    @Then("^user validates the appointment booking confirmation \"([^\"]*)\" message and close the window$")
    public void userValidatesTheAppointmentBookingConfirmationMessageAndCloseTheWindow(String appointmentBookingConfirmationMsg) {
//          String appointmentBookingConfirmationText = getElement("appointmentBookingConfirmationTextValidation").getText();
//          logger.info("The get texted value is=" + appointmentBookingConfirmationText + " The message from data base is:" + appointmentBookingConfirmationMsg);
//
//        assertStepExecution(appointmentBookingConfirmationMsg,appointmentBookingConfirmationText,
//                "User validates the appointment booking confirmation message");
        // getElement("appointmentWindowClose").click();
    }
}
