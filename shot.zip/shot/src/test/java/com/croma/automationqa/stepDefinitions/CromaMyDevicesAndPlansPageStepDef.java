package com.croma.automationqa.stepDefinitions;

import com.croma.automationqa.util.JavaScriptUtil;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.sl.In;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

public class CromaMyDevicesAndPlansPageStepDef {

    JavascriptExecutor js = (JavascriptExecutor) getDriver();
    public static final int indexOne = 1;

    @And("user verifies product name {string} on my device page")
    public void userVerifiesProductNameOnMyDevicePage(String procuctName) throws InterruptedException {
        Thread.sleep(3000);
        String deviceProcuctName = getElement("productName").getText();
        assertStepExecution(true, procuctName.equalsIgnoreCase(deviceProcuctName),
                "user verifies product name on my devices and plans page");
    }

    @And("user verifies date of Purchase on my device page")
    public void userVerifiesDateOfPurchaseOnMyDevicePage() {
        String orderDate = getContext("purchasedOn");
        String deviceOrderDate = getElement("dateOfPurchase").getText();
        assertStepExecution(true, deviceOrderDate.equals(orderDate),
                "user verifies date of Purchase on my devices and plans page");
    }

    @And("user verifies order no on my device page")
    public void userVerifiesOrderNoOnMyDevicePage() throws InterruptedException {
        Thread.sleep(3000);
        String orderNo = getContext("orderId");
        setContext("name","Manish");
        getContext("name");
        String DeviceOrderNo = getElement("orderNoOnMyDevicesAndPlansPage").getText().trim();
        assertStepExecution(true, orderNo.equals(DeviceOrderNo),
                "user verifies order no on my devices and plans page");
    }

    @And("user verifies cost {string} on my device page")
    public void userVerifiesCostOnMyDevicePage(String cost) {
        String deviceCost = getElement("costAtTimeOfPurchase").getText();
        assertStepExecution(true, cost.equals(deviceCost),
                "user verifies cost on my devices and plans page");
    }

    @And("user verifies my plans {string} on my device page")
    public void userVerifiesMyPlansOnMyDevicePage(String productPlans) throws InterruptedException {
        Thread.sleep(3000);
        String startsOn = "Starts on: ";
        String expiresOn = "Expires on: ";

        List<WebElement> productPlansFromWeb = getDriver().findElements(By.xpath(getLocator("myPlansOnMyDevicesAndPlansPage")));
        assertThat(productPlansFromWeb.size()).describedAs("product plans are present there").isPositive();
        if (productPlans.contains(";")) {
            String[] productPlansFromExamples = productPlans.split(";");

            for (int plan = 0; plan < productPlansFromWeb.size(); plan++) {

                assertThat(productPlansFromExamples[plan]).describedAs("Product Plan is validated").isEqualToIgnoringCase(productPlansFromWeb.get(plan).getText());
            }
        } else {
            assertThat(productPlans).describedAs("Product quantity is validated").isEqualToIgnoringCase(productPlansFromWeb.get(0).getText());

        }
//        String myPlan = getElement("myPlansOnMyDevicesAndPlansPage").getText();
//        assertStepExecution(true, plan.equals(myPlan),
//                "user verifies my plans on my devices and plans page");
    }

    @And("user verifies extended warranty text {string} on my device page")
    public void userVerifiesExtendedWarrantyTextOnMyDevicePage(String texts) throws InterruptedException {
        Thread.sleep(3000);
        List<WebElement> productPlansHeadingFromWeb = getElements("extendedWarrantyText");
        assertThat(productPlansHeadingFromWeb.size()).describedAs("product plans are present there").isPositive();
        if (texts.contains(";")) {
            String[] productPlansHeadingFromExamples = texts.split(";");

            for (int plan = 0; plan < productPlansHeadingFromWeb.size(); plan++) {

                assertThat(productPlansHeadingFromExamples[plan]).describedAs("Product Plan is validated").isEqualToIgnoringCase(productPlansHeadingFromWeb.get(plan).getText());
            }
        } else {
            assertThat(texts).describedAs("Product quantity is validated").isEqualToIgnoringCase(productPlansHeadingFromWeb.get(0).getText());

        }

//        String warrantyText = getElement("extendedWarrantyText").getText();
//        assertStepExecution(true, text.equals(warrantyText),
//                "user verifies my plans on my devices and plans page");
    }

    @And("user verifies SKU no. {string} on my device page")
    public void userVerifiesSKUNoOnMyDevicePage(String SKUNO) throws InterruptedException {
        Thread.sleep(3000);
        String skuNo = getElement("skuID").getText().split("SKU : ")[1];
        assertStepExecution(true, SKUNO.equals(skuNo),
                "user verifies SKU no. on my devices and plans page");
    }

    @And("user clicks on My Devices tab")
    public void userClicksOnMyDevicesTab() {
        assertStepExecution(true, getOptionalElement("myDevicesTab") != null,
                "user clicks on My Devices tab");
        getElement("myDevicesTab").click();
    }

    @And("user clicks on My Plans tab")
    public void userClicksOnMyPlansTab() throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("myPlansTab") != null,
                "user clicks on My Plans tab");
        getElement("myPlansTab").click();
    }

    @And("user clicks on device tile of {string} index")
    public void userClicksOnDeviceTileOfIndex(String deviceIndex) throws InterruptedException {
        Thread.sleep(5000);
        List<WebElement> listOfDevices = getElements("devicesLinkList");
        assertStepExecution(true, listOfDevices.size() > 0,
                "user clicks on device tile of " + deviceIndex + " index");
        listOfDevices.get(Integer.parseInt(deviceIndex) - 1).click();
    }

    @And("user validates {string} as plans names in My Devices and Plans page")
    public void userValidatesAsPlansNamesInMyDevicesAndPlansPage(String plans) throws InterruptedException {
        Thread.sleep(3000);
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("plansName"));
        assertThat(productDetail.size()).describedAs("Plans are more than 1").isPositive();
        if (plans.contains(";")) {
            String[] planNamefromExamples = plans.split(";");
            for (int i = 0; i < planNamefromExamples.length; i++) {
                String planNameFromWeb = productDetail.get(i).getText();
                logger.info("The plan name from web is:" + planNameFromWeb);
                assertThat(planNameFromWeb).describedAs("My Device product name from web and examples are matched.").isEqualToIgnoringCase(planNamefromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText()).describedAs("My Device product name from web and examples are matched.").isEqualToIgnoringCase(plans);
        }
        passStepExecution("Plans names on My Device is verified");

    }

    @And("user validates {string} as plans coverage dates in My Devices and Plans page")
    public void userValidatesAsPlansCoverageDatesInMyDevicesAndPlansPage(String dates) throws InterruptedException {
        Thread.sleep(3000);
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("coverageDate"));
        assertThat(productDetail.size()).describedAs("CoverageDate are more than 1").isGreaterThan(0);
        if (dates.contains(";")) {
            String[] coverageDatesfromExamples = dates.split(";");
            for (int i = 0; i < coverageDatesfromExamples.length; i++) {
                String coverageDatesNameFromWeb = productDetail.get(i).getText();
                logger.info("The coverageDates from web is:" + coverageDatesNameFromWeb);
                assertThat(coverageDatesNameFromWeb).describedAs("My Device coverageDates from web and examples are matched.").isEqualToIgnoringCase(coverageDatesfromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText()).describedAs("My Device coverageDates from web and examples are matched.").isEqualToIgnoringCase(dates);
        }
        passStepExecution("coverageDates on My Device is verified");

    }

    @And("^user verifies product name \"([^\"]*)\" on my devices and plans page$")
    public void userVerifiesProductNameOnMyDevicesAndPlansPage(String productName) throws InterruptedException {
        Thread.sleep(3000);
//        String[] productList = productName.split(";");
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("myDeviceProductNames"));
        assertThat(productDetail.size()).describedAs("Products are more than 1").isPositive();
        if (productName.contains(";")) {
            String[] productNamefromExamples = productName.split(";");
            for (int i = 0; i < productNamefromExamples.length; i++) {
                String productNameFromWeb = productDetail.get(i).getText();
                logger.info("The product name from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("My Device product name from web and examples are matched.").isEqualToIgnoringCase(productNamefromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText()).describedAs("My Device product name from web and examples are matched.").isEqualToIgnoringCase(productName);
        }
        passStepExecution("Products names on My Device is verified");


    }

    @And("^user verifies purchase date of \"([^\"]*)\" on my devices and plans page$")
    public void userVerifiesPurchaseDateOnMyDevicesAndPlansPage(String No_of_products) throws InterruptedException {
        Thread.sleep(3000);
        Date date = new Date();
        SimpleDateFormat DateFor = new SimpleDateFormat("dd MMM yyyy");
        String stringDate = DateFor.format(date);

        ArrayList<WebElement> productPurchaseDates = new ArrayList<>(getElements("myDevicePurchaseDate"));
        assertThat(productPurchaseDates.size()).describedAs("Products are more than 1").isGreaterThan(0);
        setContext("purchasedOn", productPurchaseDates.get(0).getText());

        int NumberOfProduct = Integer.parseInt(No_of_products);
        for (int i = 0; i < NumberOfProduct; i++) {
            String purchasedOn = productPurchaseDates.get(i).getText();
            String day = purchasedOn.split(" ")[0].substring(0, (purchasedOn.split(" ")[0].length() - 2));
            String month = purchasedOn.split(" ")[1];
            String year = purchasedOn.split(" ")[2];
            String dateFromweb = day + " " + month + " " + year;
            logger.info("The Purchase Date from web is:" + dateFromweb);
            assertThat(dateFromweb).describedAs("My Device Purchase Date from web and examples are matched.").isEqualTo(stringDate);
        }
        passStepExecution("Purchase Date on My Device is verified");

    }


    @And("^user verifies product Status \"([^\"]*)\" on my devices and plans page$")
    public void userVerifiesProductStatusOnMyDevicesAndPlansPage(String productStatus) {
//        String[] productList = productName.split(";");
        ArrayList<WebElement> productStatusList = new ArrayList<>(getElements("myDeviceProductStatus"));
        assertThat(productStatusList.size()).describedAs("Products are more than 1").isGreaterThan(0);
        if (productStatus.contains(";")) {
            String[] productStatusfromExamples = productStatus.split(";");
            for (int i = 0; i < productStatusfromExamples.length; i++) {
                String productStatusFromWeb = productStatusList.get(i).getText();
                logger.info("The product status from web is:" + productStatusFromWeb);
                assertThat(productStatusFromWeb).describedAs("My Device product status from web and examples are matched.").isEqualTo(productStatusfromExamples[i]);
            }
        } else {
            assertThat(productStatusList.get(0).getText()).describedAs("My Device product status from web and examples are matched.").isEqualTo(productStatus);
        }
        passStepExecution("Products status on My Device is verified");


    }

    @And("user expands my plans and validates {string} as base devices in My Devices and Plans page")
    public void userExpandsMyPlansAndValidatesAsBaseDevicesInMyDevicesAndPlansPage(String baseDevices) throws InterruptedException {
        Thread.sleep(3000);
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        List<WebElement> myPlanArrows = getElements("myPlanArrows");
        assertThat(myPlanArrows.size()).describedAs("Products are more than 1").isPositive();
        if (baseDevices.contains(";")) {
            String[] baseDevicesFromExp = baseDevices.split(";");
            for (int device = 0; device < baseDevicesFromExp.length; device++) {
                Thread.sleep(3000);
                jsClick(myPlanArrows.get(device));
                List<WebElement> baseDeviceList = getDriver().findElements(By.xpath(getLocator("myPlanProductNames")));
                Thread.sleep(5000);
                String baseDeviceFromWeb = baseDeviceList.get(device).getText();
                logger.info("The product status from web is:" + baseDeviceFromWeb);
                assertThat(baseDeviceFromWeb).describedAs("Products under My Plans from web and examples are matched.").isEqualToIgnoringCase(baseDevicesFromExp[device]);
            }
        } else {
            Thread.sleep(3000);
            jsClick(myPlanArrows.get(0));
            Thread.sleep(5000);
            List<WebElement> baseDeviceList = getElements("myPlanProductNames");
            assertThat(baseDeviceList.get(0).getText()).describedAs("Products under My Plans from web and examples are matched.").isEqualToIgnoringCase(baseDevices);
        }
        passStepExecution("user expands my plans and validates "
                + baseDevices + " as base devices in My Devices and Plans page");
    }

    @And("user clicks on {string} button on my devices and plans page")
    public void userClicksOnButtonOnMyDevicesAndPlansPage(String button) throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(true, getOptionalElement("extendedWarrantyButton") != null,
                "user clicks on " + button + " button on my devices and plans page");
        getElement("extendedWarrantyButton").click();
        Thread.sleep(3000);
    }

    @And("user selects {string} plan from modal popup on my devices and plans page")
    public void userSelectsPlanFromModalPopupOnMyDevicesAndPlansPage(String plan) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("extendedWarrantyplan", plan) != null,
                "user selects " + plan + " plan from modal popup on my devices and plans page");
        getElement("extendedWarrantyplan", plan).click();
        Thread.sleep(2000);
    }

    @And("user clicks on buy now button on modal popup on my devices and plans page")
    public void userClicksOnBuyNowButtonOnModalPopupOnMyDevicesAndPlansPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("buyNowButtonOnMyDevicesAndPlanPage") != null,
                "user clicks on buy now button on modal popup on my devices and plans page");
        getElement("buyNowButtonOnMyDevicesAndPlanPage").click();
        Thread.sleep(2000);
    }

    @And("user waits until buy extended warranty button is visible on my devices and plans page")
    public void userWaitsUntilBuyExtendedWarrantyButtonIsVisibleOnMyDevicesAndPlansPage() throws InterruptedException {
        boolean isDisplayed = false;
        for (int i = 0; i < 10; i++) {
            if (getOptionalElement("extendedWarrantyButton") != null) {
                isDisplayed = true;
                assertStepExecution(true, isDisplayed, "user waits until buy extended warranty button is visible on my devices and plans page");
                break;
            } else {
                Thread.sleep(10000);
                getDriver().navigate().refresh();
                Thread.sleep(10000);
            }
        }
        if (!isDisplayed)
            assertStepExecution(true, isDisplayed, "user waits until buy extended warranty button is visible on my devices and plans page");

    }

    @And("user selects {string} plan for extended warranty on my device detailed page")
    public void userSelectsPlanForExtendedWarrantyOnMyDeviceDetailedPage(String plan) throws InterruptedException {
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,200)");
        JavaScriptUtil.windowScrollIntoViewByWebElementTrue(getElement("zipProtectionPlanTextOnMyDetailedDevice"));
        assertStepExecution(true, getOptionalElement("ExtendedWarrantyPlanOnMyDetailedDevicePage", plan) != null,
                "user selects " + plan + " plan for extended warranty on my device detailed page");
        getElement("ExtendedWarrantyPlanOnMyDetailedDevicePage", plan).click();
    }

    @And("user clicks on {string} button on my device detailed page")
    public void userClicksOnButtonOnMyDeviceDetailedPage(String text) throws InterruptedException {
        Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("buyExtendedWarrantyButtonOnMyDetailedDevicePage", text) != null,
                "user clicks on " + text + " button on my device detailed page");
        getElement("buyExtendedWarrantyButtonOnMyDetailedDevicePage", text).click();
    }

    @And("user verifies {string} as plans coverage dates in my detailed device page")
    public void userVerifiesAsPlansCoverageDatesInMyDetailedDevicePage(String planDates) {
        String[] planFromExample = planDates.split(";");
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd'th' MMM yyyy");
        LocalDateTime today = LocalDateTime.now();
        String todayDate = dtf.format(today);
        String nextYearDate = dtf.format(today.plusYears(1).minusDays(1));
        List<WebElement> planListFromWeb = getDriver().findElements(By.xpath(getLocator("coveragePlanDatesFromMyDetailedDevicePage")));
        for (int planDate = indexOne; planDate <= planFromExample.length; ++planDate) {
            if (planDate % 2 == 0)
                assertThat(planFromExample[planDate - 1] + " " + nextYearDate).describedAs("user verifies {string} as plans coverage dates in my detailed device page").isEqualToIgnoringCase(planListFromWeb.get(planDate - 1).getText());
            else
                assertThat(planFromExample[planDate - 1] + " " + todayDate).describedAs("user verifies {string} as plans coverage dates in my detailed device page").isEqualToIgnoringCase(planListFromWeb.get(planDate - 1).getText());
        }
        passStepExecution("user verifies " + planDates + " as plans coverage dates in my detailed device page");

    }

    @And("user verifies my plan active status for {string} in my detailed device page")
    public void userVerifiesMyPlanActiveStatusForInMyDetailedDevicePage(String productCount) throws InterruptedException {
        Thread.sleep(3000);
        int planStatus = Integer.parseInt(productCount);
        List<WebElement> planStatusFromWeb = getDriver().findElements(By.xpath(getLocator("planActiveStatus")));
        for (int plan = 0; plan < planStatus - 1; plan++) {
            assertStepExecution(true, planStatusFromWeb.get(plan).getAttribute("class").contains("status-content-green"),
                    "user verifies my plan active status for " + productCount + " in my detailed device page");
        }
    }
}
