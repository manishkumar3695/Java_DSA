package com.croma.automationqa.stepDefinitions;



import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.userValidateBreadCrumbLastIndex;
import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.validateCategoryPageTitle;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

/*
   All the Home page related function defined in CromaHomePageStepDef class
*/
public class CromaHomePageStepDef {

    public static ArrayList<String> categoriesFromHome = new ArrayList<>();
    /*
        User clicks arrow on home page to hover and validate all banners/carousel
    */
    @Given("^user hovers all \"([^\"]*)\" banners/carousel on home page$")
    public void userHoversAllBannersCarouselOnHomePage(String bannersCarouselOption) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(0,10000)");
        List<WebElement> bannerCarouselImagesList;
        if (bannersCarouselOption.equalsIgnoreCase("Banners")) {
            Thread.sleep(3000);
            bannerCarouselImagesList = getElements("bannerImagesListXPath");
            logger.info("No of Images are: " + bannerCarouselImagesList.size() + " " + bannersCarouselOption);
            for (WebElement bannerElement : bannerCarouselImagesList) {
                processScreenshot();
                actionMoveToElementBuild(bannerElement);
            }
//            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("homePageRotatingBannerLink")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
//            actionMoveToElementClick(getElement("homePageRotatingBannerLink"));
//            getDriver().navigate().back();
//            waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));

        } else {
            ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(" + 0 + ",-" + 50 + ")");
            Thread.sleep(3000);
            bannerCarouselImagesList = getElements("bannerCategoryImages", bannersCarouselOption);
            logger.info("No of Images are: " + bannerCarouselImagesList.size() + " " + bannersCarouselOption);
            for (WebElement carouselElement : bannerCarouselImagesList) {
                actionMoveToElementBuild(carouselElement);
            }
        }
    }


    /*
      User checks the list items and clicks the required item
  */
    public static void clickingOnCategoryLinksHomePage(String link, String selectOption) {
        int tabIndexFirstValue = 1, scrollIndexValue;
        List<WebElement> categoryLinksHomePageList;
        if (selectOption.equalsIgnoreCase("homePageTopCategories")) {
            scrollIndexValue = 4;
            categoryLinksHomePageList = getElements("topCategoryLinksHomePageListAtBottom");
            processScreenshot();
            logger.info("No of links are: " + categoryLinksHomePageList.size());
            for (int i = tabIndexFirstValue; i <= categoryLinksHomePageList.size(); i++) {
                logger.info("Value of i: " + i + " " + (getElement("topCategoryElementAtBottom", String.valueOf(i)).getText()));
                if (getElement("topCategoryElementAtBottom", String.valueOf(i)).getText().equalsIgnoreCase(link)) {
                    actionMoveToElementBuild(getElement("categoryLinksHomePageAtBottom", link));
                    jsClick(getElement("categoryLinksHomePageAtBottom", link));
                    break;
                } else if (i >= scrollIndexValue) {
                    jsClick(getElement("topCategoryLinksHomePageAtBottomNextOption"));
                }
            }
        } else {
            scrollIndexValue = 7;
            categoryLinksHomePageList = getElements("categoryLinksHomePageListXPath");
            logger.info("No of links are: " + categoryLinksHomePageList.size());
            for (int i = tabIndexFirstValue; i <= categoryLinksHomePageList.size(); i++) {
                if (i > scrollIndexValue) {
                    conditionalWait(ExpectedConditions.elementToBeClickable(getElement("categoryLinksHomePageNextOption")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                    actionMoveToElementClick(getElement("categoryLinksHomePageNextOption"));
                }
                logger.info("Value of i: " + i + " " + (getElement("categoryLinksHomePageListItemXPath", String.valueOf(i)).getText()));
                if ((getElement("categoryLinksHomePageListItemXPath", String.valueOf(i)).getText()).equalsIgnoreCase(link)) {
                    conditionalWait(ExpectedConditions.elementToBeClickable(getElement("categoryLinksHomePage", link)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                    getElement("categoryLinksHomePage", link).click();
                    break;
                }
            }
        }
    }


    /*
        User clicks on video demo option on homepage and chooses option and closes the pop-up
    */
    @When("^user clicks on video demo option on homepage and chooses \"([^\"]*)\" and closes the pop-up leave reason \"([^\"]*)\"$")
    public void userClicksOnVideoDemoOptionOnHomepageAndChoosesAndClosesThePopUpLeaveReason(String categoryOption, String leaveReason) throws InterruptedException {
        String demoVideoTitle = "Get ready to connect to a Croma staff right away!", demoVideoMessage = "Thank you for your feedback!";
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnVideoDemoClickToShop")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clickOnVideoDemoClickToShop").click();
        windowScrollIntoViewByWebElement(getElement("demoVideoOptionClick", categoryOption));
        processScreenshot();
        getElement("demoVideoOptionClick", categoryOption).click();
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("demoVideoOptionPageTitle")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //logger.info(getElement("demoVideoOptionPageTitle").getText());
        //assertThat(demoVideoTitle).describedAs("Title not matched").isEqualToIgnoringCase(getElement("demoVideoOptionPageTitle").getText());
        Thread.sleep(5000);
        getElement("demoVideoOptionPageClose").click();
        // Functionality Changed in Dev1
        Thread.sleep(5000);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("demoVideoPageLeaveMsgClick", leaveReason)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("demoVideoPageLeaveMsgClick", leaveReason).click();

        getElement("clickOnVideoDemoLeaveReasonSubmitButton").click();
        logger.info(getElement("demoVideoOptionMessage").getText());

        assertThat(getElement("demoVideoOptionMessage").getText()).describedAs("Message not matched").isEqualToIgnoringCase(demoVideoMessage);
        getElement("demoVideoOptionPageClose").click();
        passStepExecution("User clicks on video demo option on homepage and chooses option and closes the pop-up");
    }

    @Given("^user clicks on store at home option on homepage$")
    public void userClicksOnStoreAtHomeOptionOnHomepage() {
        assertStepExecution(true, getOptionalElement("clickOnVideoDemoClickToShop") != null, "user clicks on store at home option on homepage");
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnVideoDemoClickToShop")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //getElement("clickOnVideoDemoClickToShop").click();
        jsClick(getElement("clickOnVideoDemoClickToShop"));
    }

    @And("^user selects \"([^\"]*)\" for video demo$")
    public void userSelectsForVideoDemo(String categoryOption) throws Throwable {
        String stepDesc = "user selects " + categoryOption + " for video demo";
        windowScrollIntoViewByWebElement(getElement("demoVideoOptionClick", categoryOption));
        assertStepExecution(true, getOptionalElement("demoVideoOptionClick", categoryOption) != null, stepDesc);
        getElement("demoVideoOptionClick", categoryOption).click();
    }

    @And("^user closes the connect to Croma staff pop up$")
    public void userClosesTheConnectToCromaStaffPopUp() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("demoVideoOptionPageClose") != null, "user closes the connect to Croma staff pop up");
        Thread.sleep(5000);
        getElement("demoVideoOptionPageClose").click();
        Thread.sleep(5000);
    }

    @And("^user provides the reason for leaving as \"([^\"]*)\"$")
    public void userProvidesTheReasonForLeaving(String leaveReason) {
        assertStepExecution(true, leaveReason.length() > 0, "user provides the reason for leaving as " + leaveReason);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("demoVideoPageLeaveMsgClick", leaveReason)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("demoVideoPageLeaveMsgClick", leaveReason).click();
    }

    @And("^user clicks on submit button in video demo leaving modal$")
    public void userClicksOnSubmitButtonInVideoDemoLeavingModal() {
        assertStepExecution(true, getOptionalElement("clickOnVideoDemoLeaveReasonSubmitButton") != null, "user clicks on submit button in video demo leaving modal");
        getElement("clickOnVideoDemoLeaveReasonSubmitButton").click();
    }

    @Then("^user validates video demo feedback message \"([^\"]*)\" is displayed$")
    public void userValidatesVideoDemoFeedbackMessageIsDisplayed(String demoVideoMessage) {
        String feedBackMsg = getElement("demoVideoOptionMessage").getText();
        logger.info(feedBackMsg);
        assertThat(feedBackMsg).describedAs("Message not matched").isEqualToIgnoringCase(demoVideoMessage);
    }

    /*
        User enters pincode on faster delivery option on homepage and validates the corresponding navigated page
    */
    @And("^user enters \"([^\"]*)\" pincode on faster delivery option on homepage and validates the corresponding navigated page$")
    public void userEntersPinCodeOnFasterDeliveryOptionOnHomepageAndValidatesTheCorrespondingNavigatedPage(String fasterDeliveryPinCode) {
        String deliveryPageName = "3hour Delivery";
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnThreeHourEnterPinCode")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clickOnThreeHourEnterPinCode").click();
        clearTextBox(getElement("provideThreeHourPinCode"));
        getElement("provideThreeHourPinCode").sendKeys(fasterDeliveryPinCode);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnThreeHourGoButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clickOnThreeHourGoButton").click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("categoryPageTitle")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info(getElement("categoryPageTitle").getText());
        assertStepExecution(deliveryPageName.toLowerCase(), (getElement("categoryPageTitle").getText().toLowerCase()),
                "Text not matched");
    }

    @Given("^user clicks on express delivery option of Why Croma section in homepage$")
    public void userClicksOnExpressDeliveryOptionOfWhyCromaSectionInHomepage() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("clickOnThreeHourEnterPinCode") != null,
                "user clicks on express delivery option of Why Croma section in homepage");
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnThreeHourEnterPinCode")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        //getElement("clickOnThreeHourEnterPinCode").click();
        jsClick(getElement("clickOnThreeHourEnterPinCode"));
        Thread.sleep(5000);
    }

    @Given("^user enters \"([^\"]*)\" pincode on faster delivery option on homepage$")
    public void userEntersPincodeOnFasterDeliveryOptionOnHomepage(String fasterDeliveryPinCode) throws Throwable {
        String stepDesc = "^user enters " + fasterDeliveryPinCode + " pincode on faster delivery option on homepage";
        clearTextBox(getElement("provideThreeHourPinCode"));
        getElement("provideThreeHourPinCode").sendKeys(fasterDeliveryPinCode);
        assertStepExecution(getElement("provideThreeHourPinCode").getAttribute("value"), fasterDeliveryPinCode, stepDesc);
    }

    @And("^user clicks on apply button in faster delivery$")
    public void userClicksOnApplyButtonInFasterDelivery() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("clickOnThreeHourGoButton") != null, "user clicks on apply button in faster delivery");
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnThreeHourGoButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clickOnThreeHourGoButton").click();
        Thread.sleep(5000);
    }

    @Then("^user user lands on three hours delivery page$")
    public void userUserLandsOnThreeHoursDeliveryPage() {
        String deliveryPageName = "3 Hr Zip Delivery";
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("categoryPageTitle")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        String pageTitle = getElement("categoryPageTitle").getText();
        logger.info(pageTitle);
        assertStepExecution(pageTitle.toLowerCase(), deliveryPageName.toLowerCase(), "user user lands on three hours delivery page");
    }

    @Then("^user verify \"([^\"]*)\" section is present in the HomePage$")
    public void userVerifySectionIsPresentInTheHomePage(String sectionName) {
        int homePageScrollUpFirstIndex = 150;
        int homePageScrollDownFirstIndex = 0;
        windowScrollIntoTopToBottom();
        windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpFirstIndex);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("carouselLinks", sectionName)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        actionMoveToElementBuild(getElement("carouselLinks", sectionName));
        assertStepExecution(true, getOptionalElement("anyHeaderSectionInHomePage", sectionName) != null,
                "user verify " + sectionName + " section is present in the HomePage");
    }

    @Then("^user verify \"([^\"]*)\" is present in the first position of Recently Viewed section$")
    public void userVerifyIsPresentInTheFirstPositionOfRecentlyViewedSection(String recentlyViewedProduct) {
        String firstProductOnRecentlyViewedSection = getElements("recentlyViewedProducts").get(0).getText();
        logger.info("First Product Heading on Recently Viewed Section :" + firstProductOnRecentlyViewedSection);
       /* if (firstProductOnRecentlyViewedSection.endsWith(".")) {
            firstProductOnRecentlyViewedSection = firstProductOnRecentlyViewedSection.replaceAll("\\.", "");
            logger.info("Product Heading after Removing Dots :" + firstProductOnRecentlyViewedSection);
            assertStepExecution(true, recentlyViewedProduct.contains(firstProductOnRecentlyViewedSection),
                    "user verify " + recentlyViewedProduct + " is present in First Index in Recently Viewed section");
        } else {
            assertStepExecution(true, recentlyViewedProduct.equalsIgnoreCase(firstProductOnRecentlyViewedSection),
                    "user verify " + recentlyViewedProduct + " is present in First Index in Recently Viewed section");
        }*/
        assertStepExecution(true, recentlyViewedProduct.equalsIgnoreCase(firstProductOnRecentlyViewedSection),
                "user verify " + recentlyViewedProduct + " is present in First Index in Recently Viewed section");

    }

    @And("^user clicks on \"([^\"]*)\" under Top Brands Section$")
    public void userClicksOnUnderTopBrandsSection(String brand) {
        String stepDescription = "user clicks on " + brand + " under Top Brands Section";
        assertStepExecution(true, getOptionalElement("clicksOnAnyTopBrands", brand) != null,
                stepDescription);
        getElement("clicksOnAnyTopBrands", brand).click();
    }

    @Then("^user validates paragraph content above footer$")
    public void userValidatesParagraphContentAboveFooter() {
        String stepDescription = "user validates paragraph content above footer";
        int numberOfParagraphs = getElements("paragraphsOnHomePage").size();
        logger.info("Number of Paragraph Section :" + numberOfParagraphs);
        assertThat(numberOfParagraphs).isGreaterThan(0).describedAs("Paragraph should be there in HomePgae above Footer");
        for (int paragraph = 0; paragraph < numberOfParagraphs; paragraph++) {
            String paragraphContent = getElements("paragraphsOnHomePage").get(paragraph).getText();
            logger.info(paragraphContent);
            assertThat(paragraphContent).isNotEmpty().describedAs("Paragraph over Footer Should not be Empty");
        }
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @Given("^user clicks on View All button of \"([^\"]*)\" Product Carousel having View All button$")
    public void userClicksOnViewAllButtonOfProductCarouselHavingViewAllButton(String productCarouselOption) {

        String stepDescription = "user clicks on View All button of " + productCarouselOption + " Product Carousel having View All button";

        assertStepExecution(true, getElement("viewAllBtnOnProductCarousel", productCarouselOption) != null,
                stepDescription);
        getElement("viewAllBtnOnProductCarousel", productCarouselOption).click();

    }

    @And("^user clicks on all \"([^\"]*)\" and navigates back$")
    public void userClicksOnAllAndNavigatesBack(String carouselOption) throws Throwable {

        String stepDescription = "user clicks on all " + carouselOption + " and navigates back";
        int totalLinks = getElements("carouselLinks", carouselOption).size();
        assertThat(totalLinks).isGreaterThan(0).describedAs("At least one link should be there in " + carouselOption + "Section");

        for (int link = 0; link < totalLinks; link++) {
            WebElement element = getElements("carouselLinks", carouselOption).get(link);
            String elementHref = getElements("carouselLinks", carouselOption).get(link).getAttribute("href");
            element.click();
            assertThat(getDriver().getCurrentUrl()).endsWith(elementHref)
                    .describedAs("Current URL should ends with the " + elementHref);
            getDriver().get(getConfig("URL"));

        }
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^User clicks on Terms of Use$")
    public void userClicksOnTermsOfUse() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        getElement("termsConditionsLink").click();
    }

    @Then("^User is navigated to Terms and Conditions page$")
    public void termsOfUseValidation() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        userMovesToNewWindow();
        assertStepExecution(true, getElement("termsOfUse").isDisplayed(),
                "Terms and Conditions page is displayed");
    }

    @Given("^user clicks on register now button below connect to store of Shop Safely with Croma scetion in homepage$")
    public void userClicksOnRegisterNowButtonBelowConnectToStoreOfShopSafelyWithCromaScetionInHomepage() {

        String stepDescription = "user clicks on register now button below connect to store of Shop Safely with Croma scetion in homepage";
        assertThat(getOptionalElement("homePageConnectToStoreSection")).isNotNull()
                .describedAs("Connect to Store Scetion should there in homepage");

        assertThat(getOptionalElement("homePageRegisterNowBtnOfConnectToStore")).isNotNull()
                .describedAs("Register Now button should display");

        getElement("homePageRegisterNowBtnOfConnectToStore").click();
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @When("^user clicks on video demo option on homepage and chooses \"([^\"]*)\"$")
    public void userClicksOnVideoDemoOptionOnHomepageAndChooses(String categoryOption) {
        String demoVideoTitle = "Get ready to connect to a Croma staff right away!";
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnVideoDemoClickToShop")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("clickOnVideoDemoClickToShop").click();
        windowScrollIntoViewByWebElement(getElement("demoVideoOptionClick", categoryOption));
        getElement("demoVideoOptionClick", categoryOption).click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("demoVideoOptionPageTitle")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info(getElement("demoVideoOptionPageTitle").getText());
        assertStepExecution(demoVideoTitle.toLowerCase(), (getElement("demoVideoOptionPageTitle").getText().toLowerCase()),
                "user clicks on video demo option on homepage");
    }

    @And("^user croma band explore now link in homepage$")
    public void userCromaBandExploreNowLinkInHomepage() {
        String cromaTitle = "Croma";
        assertStepExecution(true, getOptionalElement("homepageLinkExploreNow") != null, " user croma band explore now link in homepage");
        getElement("homepageLinkExploreNow").click();
        validateCategoryPageTitle(getElement("cromaExploreNowPageTitle").getText(), cromaTitle);
    }

    @When("^user clicks on \"([^\"]*)\" category and lands on corresponding page as \"([^\"]*)\"$")
    public void userClicksOnCategoryAndLandsOnCorrespondingPageAs(String categoryTiles, String plpPageOptions) throws Throwable {
        String[] catList = categoryTiles.split(";");
        for (int cat = 0; cat < catList.length; cat++) {
            clickingOnCategoryLinksHomePage(catList[cat], "NA");
            waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
            //Validating last Breadcrumb
            userValidateBreadCrumbLastIndex(plpPageOptions.split(";")[cat]);
            //Validating PLP Banners and clicking
            List<WebElement> bannerImagesList = getDriver().findElements(By.xpath("//a[contains(@href,'#item-')]"));
            logger.info("No of Images in PLP banners are: " + bannerImagesList.size());
            for (WebElement bannerElement : bannerImagesList) {
                actionMoveToElementBuild(bannerElement);
            }
            if (bannerImagesList.size() > 0) {
                actionMoveToElementClick(getElement("plpRotatingBannerLink"));
            }
            getDriver().get(getConfig("URL"));
        }
    }

    @When("^user clicks on \"([^\"]*)\" in Top Categories$")
    public void userClicksOnInTopCategories(String category) throws Throwable {
        String stepDesc = "user clicks on " + category + " in Top Categories";
        int homePageScrollUpSecondIndex = 300;
        int homePageScrollDownFirstIndex = 0;
        windowScrollIntoTopToBottom();
        windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpSecondIndex);
        WebElement catElem = getOptionalElement("homePageTopCat", category);
        while (catElem == null && getElement("rightArrowOnCarousel", "Top Categories").getAttribute("aria-disabled").equalsIgnoreCase("false")) {
            jsClick(getElement("rightArrowOnCarousel", "Top Categories"));
            catElem = getOptionalElement("homePageTopCat", category);
        }
        assertStepExecution(true, catElem != null, stepDesc);
        actionMoveToElementBuild(catElem);
        jsClick(catElem);
    }

    @And("user clicks products category of mobile")
    public void userClicksProductsCategoryOfMobile() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        jsClick(getElement("mobileMenuButtonHomePage"));
    }

    @And("user clicks on plus icon of the product category")
    public void userClicksOnPlusIconOfTheProductCategory() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        jsClick(getElement("plusIconOfProductCategory"));
        Thread.sleep(10000);
    }

    @And("user clicks on {string} as breadcrumb")
    public void userClicksOnAsBreadcrumb(String breadCrumb) {
        windowScrollToTop();
        userValidateBreadCrumbLastIndex(breadCrumb);
        passStepExecution(" User validated breadcrumb");
        jsClick(getElement("breadCrumbOption"));

    }

    @And("user stores all shop by categories widget on home page")
    public void userStoresAllShopByCategoriesWidgetOnHomePage() throws InterruptedException {
        List<WebElement> element = getElements("homePageShopByCategoriesWidget");
        logger.info("Total size of elements are:" + element.size());
        for (int i = 0; i < element.size(); i++) {
            if (i > 8) {
                jsClick(getElement("CategoryNextArrow"));
                Thread.sleep(5000);
            }
            categoriesFromHome.add(element.get(i).getText());
        }
        logger.info("The categories from Home page are:" + categoriesFromHome);
    }

    @And("user clicks on the first product of {string} section in the homepage")
    public void userClicksOnTheFirstProductOfSectionInTheHomepage(String sectionName) {
//        int homePageScrollUpFirstIndex = 150;
//        int homePageScrollDownFirstIndex = 0;
//        windowScrollIntoTopToBottom();
//        windowScrollIntoViewAdjustment(homePageScrollDownFirstIndex, homePageScrollUpFirstIndex);
//        conditionalWait(ExpectedConditions.visibilityOf(getElement("carouselLinks", sectionName)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
//        actionMoveToElementBuild(getElement("carouselLinks", sectionName));
//        assertStepExecution(true, getOptionalElement("carouselLinkFirstProduct", sectionName) != null,
//                "user verify product is present in the HomePage");
        logger.info("Product name is:" + getElement("carouselLinkProductName", sectionName).getText());
        setContext("firstProductNameOfTheSection", getElement("carouselLinkFirstProduct", sectionName).getText());
        assertStepExecution(true, getOptionalElement("carouselLinkFirstProduct", sectionName) != null,
                "user verify product is present in the HomePage");
        actionMoveToElementClick(getElement("carouselLinkFirstProduct", sectionName));
    }

    @And("user clicks on the {string} product of {string} section in the homepage")
    public void userClicksOnTheProductOfSectionInTheHomepage(String index, String sectionName) {
        logger.info("Product name is:"+getElement("carouselLinkFirstProduct", sectionName,index).getText());
        setContext("firstProductNameOfTheSection", getElement("carouselLinkFirstProduct", sectionName,index).getText());
        assertStepExecution(true, getOptionalElement("carouselLinkFirstProduct", sectionName,index) != null,
                "user verify product is present in the HomePage");
        actionMoveToElementClick(getElement("carouselLinkFirstProduct", sectionName,index));
    }

    @And("user validates add new address button is present in select your address popup")
    public void userValidatesAddNewAddressButtonIsPresentInSelectYourAddressPopup() {
        assertStepExecution(true, getElement("addNewAddressInSelectYourAddressPopup").isDisplayed(),
                "user verify add new address button is present in select your address popup");

    }

    @And("user clicks on add new address button in select your address popup")
    public void userClicksOnAddNewAddressButtonInSelectYourAddressPopup() {
        getElement("addNewAddressInSelectYourAddressPopup").click();
    }

    @And("user validates add new address popup title is displayed")
    public void userValidatesAddNewAddressPopupTitleIsDisplayed() {
        assertStepExecution(true, getElement("addNewAddressPopupTitle").isDisplayed(),
                "user verify add new address popup is displayed");
    }

    @And("user validates pincode {string} updated in header pincode section")
    public void userValidatesPincodeUpdatedInHeaderPincodeSection(String pincode) throws InterruptedException {
        Thread.sleep(2000);
        logger.info(getElement("pincodeInHeaderSection", pincode).getText());
        assertStepExecution(true, getElement("pincodeInHeaderSection", pincode).getText().equalsIgnoreCase(pincode),
                "user verify pincode updated in header pincode section");
    }

    @And("user lands on the page title of {string}")
    public void userLandsOnThePageTitleOf(String categoryOption) throws InterruptedException {
        Thread.sleep(5000);
        assertStepExecution(categoryOption, getElement("categoryOptionTitlePage", categoryOption).getText(), "User lands on plp");

    }

    @And("user verifies floating carousal present in homepage")
    public void userVerifiesFloatingCarousalPresentInHomepage()  {
        assertStepExecution(true, getElement("carouselBanner").isDisplayed(),"User verifies that carousel is present in home page");
    }





    @And("user validate the section {string} present in homepage")
    public void userValidateTheSectionPresentInHomepage(String section) {
        windowScrollIntoViewByWebElement(getElement("sectionInHomePage", section));
        WebElement str = getElement("sectionInHomePage", section);
        logger.info("The section is" + str);
        assertStepExecution(true, (getElement("sectionInHomePage", section).isDisplayed()),
                "user verify this section is present in homepage");

    }

    @And("user verifies ascending and descending functionalities in carousel")
    public void userVerifiesAscendingAndDescendingFunctionalitiesInCarousel() {
        //getElement("carousalForwardArrow").click();
        getOptionalElement("carousalForwardArrow").click();

    }

    @When("user goes over {string} brand category")
    public void userGoesOverBrandCategory(String category) {
        List<WebElement> element = getElements("brandGategory");
        for (WebElement option : element) {

        }

    }


    @And("user validate the carousel for {string} and {string}")
    public void userValidateTheCarouselForAnd(String section, String categorysection) {
        windowScrollIntoViewByWebElement(getElement("categoryInBrandPage",section));
        List<WebElement> element = getElements("macbookCarouselInBrandPage");
        for (WebElement sectionTitle: element) {
            if (sectionTitle.isDisplayed()) {
                logger.info("Title#### " + sectionTitle.getText());
                String text = sectionTitle.getText();
                assertThat(text).containsIgnoringCase(categorysection).describedAs("User verifies the categorysection is present in the title of the product ");
            } else {
                getElement("categoryInBrandPageForwardArrow").click();
                String text = sectionTitle.getText();
                logger.info("Get Text " + text);
                assertThat(text).containsIgnoringCase(categorysection).describedAs("User verifies the categorysection is present in the title of the product ");
            }
        }
}





    @And("validate user redirect to CLP page with category title {string} by click the category from Carousal")
    public void validateUserRedirectToCLPPageWithCategoryTitleByClickTheCategoryFromCarousal(String titleCategory) {
        String categoryTitle = getElement("categoryInCLPPage").getText();
        logger.info("categoryTitle =" + categoryTitle);
        assertStepExecution(true,categoryTitle.equalsIgnoreCase(titleCategory)," user redirect to CLP page with category title by click the category from Carousal");
    }

    @When("user clicks one of the category from carousal for guest user")
    public void userClicksOneOfTheCategoryFromCarousalForGuestUser() throws InterruptedException {
        getElement("firstImageOfCarousal").click();
        Thread.sleep(2000);
        /*getOptionalElement("signInPopupCloseButton").click();
        Thread.sleep(2000);*/

    }

    @When("user clicks one of the category from carousal for Signed user")
    public void userClicksOneOfTheCategoryFromCarousalForSignedUser() throws InterruptedException {
        getElement("firstImageOfCarousal").click();
        Thread.sleep(2000);
       /* if(getElement("signInPopupCloseButton").isDisplayed()) {
            getElement("signInPopupCloseButton").click();
            Thread.sleep(2000);
        }*/
    }


    @And("user validate {string} should not present in homepage when never viewed any product")
    public void userValidateShouldNotPresentInHomepageWhenNeverViewedAnyProduct(String sectionInHome) {
        assertStepExecution(true, getOptionalElement("sectionInHomePage", sectionInHome) == null, "user validates Recently viewed section should not present in Homepage for logged In user");
    }

    @And("user verify the category in carousel")
    public void userVerifyTheCategoryInCarousel() {
        List<WebElement> element = getElements("carousalImage");
        for (WebElement sectionTitle : element) {
            logger.info("Total images " + element);
            if(!(sectionTitle.isDisplayed())){
                if(getElement("carousalForwardArrow").isEnabled()){
                    getElement("carousalForwardArrow").click();
                    assertStepExecution(true, sectionTitle.isDisplayed(), "The carousel category is displayed");
                }
                assertStepExecution(true, sectionTitle.isDisplayed(), "The carousel category is displayed");

            }
        }
        assertStepExecution(true, getElement("carousalBackwardArrow").isEnabled(), "The Backward arrow is displayed");
        getElement("carousalBackwardArrow").click();
    }

    @And("user scroll the carousel to right and left")
    public void userScrollTheCarouselToRightAndLeft() throws InterruptedException {
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(3000,0)","carouselBanner");
        Thread.sleep(3000);
    }

    @And("user verifying the same product {string} under recently viewed section in homepage {string}")
    public void userVerifyingTheSameProductUnderRecentlyViewedSectionInHomepage(String productOnPdp, String sectionInHome) {
        windowScrollIntoViewByWebElement(getElement("sectionInHomePage", sectionInHome));
        String RecentlyViewedProduct = getElement("recentlyViewedProductInHomePage").getAttribute("alt");
        logger.info("The title of the product " + productOnPdp);
        logger.info("RecentlyViewedProduct " + RecentlyViewedProduct);
        assertThat(productOnPdp).isEqualTo(RecentlyViewedProduct);
    }


    @And("user lands on product definition page and validate product name {string}")
    public void userLandsOnProductDefinitionPageAndValidateProductName(String product) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));

        String productOnPdp = getElement("pdpProductTitle").getText();
        assertThat(productOnPdp).isEqualTo(product);
    }

}

