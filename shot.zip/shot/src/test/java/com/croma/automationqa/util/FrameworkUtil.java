package com.croma.automationqa.util;

import com.google.common.base.Charsets;
import io.appium.java_client.MobileElement;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;

import static com.croma.automationqa.util.AssertUtil.updateQMetryExecution;
import static com.croma.automationqa.util.ConfigUtil.configIterator;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DBConnUtil.dbConnect;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ScenarioUtil.getScenario;

/**
 * <h3> Purpose:  <p> <h4> &#10687; This class includes all the generic methods which perform various diverse activities in the framework.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @author Abhishek Samanta (samanta.abhishek1@tcs.com)
 * @version 1.0 29/03/2020
 */
public class FrameworkUtil {


    public static final String configPath = "config/";
    public static final String featurePath = "features/";
    public static final String locatorPath = "locators/";
    public static final String finalFeatureFullPath = "src/test/resources/finalFeatures/";
    public static ArrayList<String> arrayListAllCol = new ArrayList<>();
    public static String scName;
    public static String finalStr;
    public static boolean backGroundFlag = false;
    private static HashMap<String, HashMap<String, String>> configMap = new HashMap<String, HashMap<String, String>>();
    public static CromaLoggerUtil logger = new CromaLoggerUtil();


    /**
     * This method implements <b>fluent wait</b> for maximum <b>60secs</b> and returns <b>WebElement</b> object
     *
     * @param <b>driver</b> Current WebDriver instance
     * @param <b>by</b>     Selenium By object containing locator information
     * @return <b>WebElement</b> object
     */
    public static WebElement fluentWaitUtil(WebDriver driver, String xpathLocator, int timeOut) {

        Duration totalWait = Duration.ofSeconds(timeOut);
        Duration pollingWait = Duration.ofMillis(500);

        Wait wait = new FluentWait(driver)
                .withTimeout(totalWait)
                .pollingEvery(pollingWait)
                .ignoring(org.openqa.selenium.NoSuchElementException.class)
                .ignoring(org.openqa.selenium.ElementNotInteractableException.class);

/*        WebElement foo = (WebElement) wait.until(new Function<WebDriver, WebElement>() {
            public WebElement apply(WebDriver driver) {
                return driver.findElement(LocalBy);
            }
        });*/

        Function<WebDriver, WebElement> fun = d -> d.findElement(By.xpath(xpathLocator));
        WebElement foo = (WebElement) wait.until(fun);

        if (foo.isDisplayed() && foo.isEnabled()) {
            logger.info("Fluent Wait Successful");
        }
        return foo;
    }


    /**
     * This method implements <b>WebDriverWait</b>  for specified timeframe and returns <b>WebElement</b> object
     *
     * @param <b>driver</b>       Current WebDriver instance
     * @param <b>xpathLocator</b> XPATH Locator of the element on which wait is applied
     * @param <b>timeOut</b>      Maximum Timespan to be waited for the element in Seconds.
     * @return <b>WebElement</b> object
     */
    public static WebElement masterWait(WebDriver driver, String xpathLocator, int timeOut) {


        WebElement elem = null;

        try {
            logger.info("Inside WebDriverWait >> Element XPATH:- " + xpathLocator);
            WebDriverWait w = new WebDriverWait(driver, timeOut, 250);
            // w.ignoring(org.openqa.selenium.NoSuchElementException.class);


            // Anonymous Class Implementation
/*                w.until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver driver) {
                    WebElement e = driver.findElement(By.xpath(xpathLocator));
                    if (e != null && e.isDisplayed() && e.isEnabled()) {
                        return true;
                    } else {
                        return false;
                    }
                }
            });*/

            // Lambda Expression Implementation
            w.until(d -> {
                WebElement e = d.findElement(By.xpath(xpathLocator));
                return (e != null && e.isDisplayed() && e.isEnabled());
            });

            elem = driver.findElement(By.xpath(xpathLocator));

        } catch (TimeoutException e) {
            e.printStackTrace();
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            String stackTrace = sw.toString(); // stack trace as a string
            updateQMetryExecution("Test Step Failed \n\n" + stackTrace, "Test Step Failed", "Fail");
            throw e;
        }

        return elem;

    }


    /**
     * This method implements <b>WebDriverWait</b> for Android & iOS Devices for specified timeframe and returns <b>MobileElement</b> object
     *
     * @param <b>driver</b>       Current WebDriver instance
     * @param <b>xpathLocator</b> XPATH Locator of the element on which wait is applied
     * @param <b>timeOut</b>      Maximum Timespan to be waited for the element in Seconds.
     * @return <b>MobileElement</b> object
     */
    public static MobileElement masterMobileWait(WebDriver driver, final String xpathLocator, final int timeOut) {


        MobileElement elem = null;

        try {
            logger.info("Inside WebDriverWait >> Element XPATH:- " + xpathLocator);
            WebDriverWait w = new WebDriverWait(driver, timeOut, 250);
            // w.ignoring(org.openqa.selenium.NoSuchElementException.class);

            w.until(new ExpectedCondition<Boolean>() {
                public Boolean apply(WebDriver driver) {
                    MobileElement e = (MobileElement) driver.findElement(By.xpath(xpathLocator));
                    if (e != null && e.isDisplayed() && e.isEnabled()) {
                        return true;
                    } else {
                        return false;
                    }
                }
            });

            elem = (MobileElement) driver.findElement(By.xpath(xpathLocator));

        } catch (TimeoutException e) {
            e.printStackTrace();
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            String stackTrace = sw.toString(); // stack trace as a string
            updateQMetryExecution("Test Step Failed \n\n" + stackTrace, "Test Step Failed", "Fail");
            throw e;
        }

        return elem;

    }


    /**
     * This method implements <b>WebDriverWait</b> for any <b>ExpectedCondition</b> and specified time-frame and returns <b>Boolean</b> value.
     * It can be used for various conditions such as <b>conditionalWait(ExpectedConditions.elementToBeClickable(getElement("SearchBox")), 120);</b>
     *
     * @param <b>driver</b>       Current WebDriver instance
     * @param <b>xpathLocator</b> XPATH Locator of the element on which wait is applied
     * @param <b>timeOut</b>      Maximum Timespan to be waited for the element in Seconds.
     * @return <b>WebElement</b> object
     */
    public static boolean conditionalWait(ExpectedCondition<?> exp, int timeOut) {

        WebDriver driver = getDriver();
        WebDriverWait w = new WebDriverWait(driver, timeOut, 250);
        try {
            w.ignoring(NoSuchElementException.class);
            w.ignoring(StaleElementReferenceException.class);
            w.ignoring(ElementClickInterceptedException.class);
            w.ignoring(ElementNotInteractableException.class);
            w.ignoring(ElementNotSelectableException.class);
            w.ignoring(ElementNotVisibleException.class);

            w.until(exp);

        } catch (TimeoutException e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            String sStackTrace = sw.toString();
            updateQMetryExecution("Test Step Failed \n\n" + sStackTrace, "Test Step Failed", "Fail");
            throw e;
        }
        return true;
    }


    /**
     * This method implements <b>WebDriverWait</b> for any <b>ExpectedCondition</b> and specified time-frame and returns <b>Boolean</b> value.
     * It can be used for various conditions such as <b>conditionalWait(ExpectedConditions.elementToBeClickable(getElement("SearchBox")), 120);</b>
     *
     * @param <b>driver</b>       Current WebDriver instance
     * @param <b>xpathLocator</b> XPATH Locator of the element on which wait is applied
     * @param <b>timeOut</b>      Maximum Timespan to be waited for the element in Seconds.
     * @return <b>WebElement</b> object
     */
    public static Boolean pageLoadWait(int timeOut) {

        // wait for jQuery to load
        ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                try {
                    return ((Long) ((JavascriptExecutor) getDriver()).executeScript("return jQuery.active") == 0);
                } catch (Exception e) {
                    return true;
                }
            }
        };

        // wait for Javascript to load
        ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) getDriver()).executeScript("return document.readyState")
                        .toString().equals("complete");
            }
        };


        conditionalWait(jsLoad, timeOut);
        conditionalWait(jQueryLoad, timeOut);

        return true;
    }

    /**
     * This method polls a webpage and waits till the webpage source/HTML DOM is stabilized.
     * It compares DOM from previous polling with current DOM and checks for change.
     * Use this method with caution. Use this method only when conventional Explicit wait is not working.
     * Certain webpages might keep on changing due to certain elements like Carousal/Slideshow etc.
     * This wait will not work for those pages.
     *
     * @param <b>maxWaitSec</b>           Maximum length of time (Seconds) to wait for the page loading
     * @param <b>pollDelimiterMiliSec</b> Length of time (MiliSeconds) between each polling of page
     */
    public static void waitForJavascript(int maxWaitSec, int pollDelimiterMiliSec) {
        try {
            maxWaitSec = maxWaitSec * 1000;
            double startTime = System.currentTimeMillis();
            while (System.currentTimeMillis() < startTime + maxWaitSec) {
                String prevState = getDriver().getPageSource();
                Thread.sleep(pollDelimiterMiliSec);  // Always keep the pollDelimiter greater than 1000ms
                if (prevState.equals(getDriver().getPageSource())) {
                    return;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    /**
     * This method selects a provided value in dropdown element
     *
     * @param <b>driver</b>          Current WebDriver instance
     * @param <b>value</b>           Value to be selected in the dropdown field.
     * @param <b>xpathLocator</b>    XPATH Locator of the dropdown element
     * @param <b>partialTextFlag</b> If this flag is True, this method will select any option of the dropdown which contains the provided value parameter. Otherwise it will do a total match.
     */
    public void selectDropDown(WebDriver driver, String value, String xpathLocator, Boolean partialTextFlag) {

        //driver.findElement(By.xpath(xpathLocator)).click();

        if (partialTextFlag) {
            driver.findElement(By.xpath(xpathLocator + "//option[contains(text(),'" + value + "')]")).click();
        } else {
            driver.findElement(By.xpath(xpathLocator + "//option[text()='" + value + "']")).click();
        }
    }


    /**
     * This method captures screenshot and embeds into current Scenario object.
     */
    public static void captureScreen() {
        logger.info("getScenario().getName() :: " + getScenario().getName());
//        if (getConfig("StepFlag").equals("true") || getScenario().getStatus().equals("failed")) {
        if (getConfig("StepFlag").equals("true") || getContext("testStatus").equalsIgnoreCase("failed")) {
            try {

                //Thread.sleep(3000);

                WebDriver augmentedDriver = new Augmenter().augment(getDriver());
                File screenshot = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
                //String fileName = scn.getName().replaceAll("[; !@#$%^&()+=]", "_")+ ".png";
//                String fileName = getScenario().getName().replaceAll("[; !@#$%^&()+=]", "_") + ".png";
                /*String fileName = getScenario().getId().replaceAll("[; !@#$%^&()+=]", "_") + ".png";
                FileUtils.copyFile(screenshot, new File("./target/screenshots/" + fileName));*/
                final byte[] data = FileUtils.readFileToByteArray(screenshot);
                // byte[] screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                getScenario().attach(data, "image/png", "scrnshot");
                //Thread.sleep(15000);
                logger.info("Screenshot captured at " + new Timestamp(System.currentTimeMillis()));


            } catch (Exception ex) {
                ex.printStackTrace();

            }

        }

    }

    /**
     * This method captures screenshot, embeds it in Cucumber Scenario & returns screenshot file name.
     * Input param scrnshotDetails is a VarArg. This method accepts  either no argument, 1 argument or 2 arguments.
     * First String of scrnshotDetails[] is used to capture Scrnshot Name (if tester wants to override the default name)
     * Second String of scrnshotDetails[] is used to capture adHocFlag. Its value must be "true" or "false".
     * If tester wants to invoke this method to capture adhoc screenshots, its mandatory to put either a blank String or a Screenshot Name as first param.
     *
     * @param <b>scrnshotDetails</b>       Current WebDriver instance
     * @return <b>fileName</b> Screenshot file name
     */
    public static String processScreenshot(String... scrnshotDetails) {

        String fileName = "";
        try {
            String path = "./target/Screenshots/", filePrefix = "Screenshot_";
            fileName = captureScreenToFile(path, filePrefix);
            File fi = new File(path + fileName);

            String scrnshotName = "Test Step ScreenShot", adHocFlag = "";

            if (scrnshotDetails.length > 1) {
                scrnshotName = (scrnshotDetails[0].length() == 0 ? "Test Step ScreenShot" : scrnshotDetails[0]);
                adHocFlag = scrnshotDetails[1].trim();
            }

            if (scrnshotDetails.length == 1) {
                scrnshotName = (scrnshotDetails[0].length() == 0 ? "Test Step ScreenShot" : scrnshotDetails[0]);
            }

            // Embed screenshot data into Cucumber Scenario
            if (getConfig("StepFlag").equals("true") || getContext("testStatus").equalsIgnoreCase("Failed") ||
                    adHocFlag.equalsIgnoreCase("TRUE")) {
                final byte[] data = Files.readAllBytes(fi.toPath());
                getScenario().attach(data, "image/jpg", scrnshotName);
            }

            System.out.println(LocalDateTime.now().toString().trim());
        } catch (IOException e) {
            e.printStackTrace();
        }
        setContext("screenshotName", fileName);
        return fileName;
    }


    /**
     * This method captures screenshot and save it to a provided path as a JPG file.
     *
     * @param <b>path</b>       Path where the screenshot needs to be captured.
     * @param <b>filePrefix</b> Initial part of the file name.
     * @return <b>fileName</b> - It will contain the String after the replacement of Gherkin Keywords.
     */
    public synchronized static String captureScreenToFile(String path, String filePrefix) throws IOException {

        String fileName = "";

        // Take Step Execution Screenshot
        WebDriver augmentedDriver = new Augmenter().augment(getDriver());
        File screenshot = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
        String t = LocalDateTime.now().toString().trim();
        t = t.replace(":", "-").replace('T', '_').replace(".", "-");
        fileName = filePrefix + t + ".jpg";

        // Compress Screenshot
        BufferedImage originalImage = ImageIO.read(screenshot);
        BufferedImage convertedImg = null;

        if (originalImage.getColorModel().hasAlpha()) {
            convertedImg = new BufferedImage(originalImage.getWidth(), originalImage.getHeight(), BufferedImage.TYPE_INT_RGB);
            convertedImg.getGraphics().drawImage(originalImage, 0, 0, null);
        }

        // Write the screenshot file
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(convertedImg, "jpg", baos);
        baos.flush();
        byte[] imageInByte = baos.toByteArray();
//        FileUtils.writeByteArrayToFile(new File("./target/Screenshots/" + fileName), imageInByte);
        FileUtils.writeByteArrayToFile(new File(path + fileName), imageInByte);


        return fileName;
    }


    /**
     * <p>
     * This Method will take Cucumber steps as a parameters and will replace all the Gherkin Keywords by String {@code "SplitPosition"}
     *
     * @param <b>str</b> A String variable to contain any Feature Steps as String
     * @return <b>String</b> - It will contain the String after the replacement of Gherkin Keywords.
     */
    public static String replaceKeywords(String str) {
        try {
            str = str.replace("Given", "SplitPosition");
            str = str.replace("When", "SplitPosition");
            str = str.replace("And", "SplitPosition");
            str = str.replace("Then", "SplitPosition");
            str = str.replace("But", "SplitPosition");
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return str;
    }

    /**
     * <p>
     * This Method will get a step as a parameter and it will convert this step name to corresponding method that
     * is defined inside any of the class in {@link com.croma.automationqa.stepDefinitions} Package and return the Method name.
     *
     * @param <b>step</b> A String type variable which will contain a step of Feature File.
     * @return <b>String</b> - Name of the method in Step Definition class
     * @see java.lang.Exception
     * @see Exception#printStackTrace()
     * @see java.lang.System#exit(int)
     */
    public static String getMethod(String step) {
        String method = "";
        try {
            /**
             * {@code words} An array of String which will contain individuals word of step.
             * @see String#trim()
             * @see String#split(String)
             * @see String#equals(Object)
             * @see String#contains(CharSequence)
             * @see String#substring(int, int)
             * @see String#length()
             */
            String words[] = step.trim().split(" ");
            for (int word = 0; word < words.length; word++) {
                if (!(words[word].equals("") || words[word].contains("<"))) {
                    method += words[word] + "_";
                }
            }
            method = method.substring(0, method.length() - 1);
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return method;
    }

    /**
     * <p>
     * This Method will take required 'Scenario Outline' data rows for a particular 'Scenario'
     * and make the 'Scenario Outline' data rows as a formatted way to fit in 'Example'
     * of 'Scenario Outline' and return the final Scenario.
     *
     * @param <b>finalListMap</b> An ArrayList of HashMap which will contain all the required Scenario Outline data rows for a particular Scenario
     * @return <b>String</b> - A String which will contain the final Scenario Outline data rows as a formatted way to fit in Example of Scenario Outline.
     * @see ArrayList#size()
     * @see ArrayList#get(int)
     * @see HashMap#get(Object)
     * @see java.lang.Exception
     * @see Exception#printStackTrace()
     * @see java.lang.System#exit(int)
     */
    public static String getFinalScenario(ArrayList<HashMap<String, String>> finalListMap) {
        String returnString = "";
        try {
            for (int col = 0; col < arrayListAllCol.size(); col++) {
                if (col < arrayListAllCol.size() - 1) {
                    returnString += "|" + arrayListAllCol.get(col);
                } else {
                    returnString += "|" + arrayListAllCol.get(col) + "|\n";
                }
            }
            for (int colData = 0; colData < finalListMap.size(); colData++) {
                HashMap<String, String> map = finalListMap.get(colData);
                for (int col = 0; col < arrayListAllCol.size(); col++) {
                    if (col < arrayListAllCol.size() - 1) {
                        returnString += "|" + map.get(arrayListAllCol.get(col));
                    } else {
                        returnString += "|" + map.get(arrayListAllCol.get(col)) + "|\n";
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return returnString;
    }

    /**
     * <p>
     * This Method will take all Gherkin Keywords replaced steps as String
     * and make an ArrayList of steps and return the list.
     *
     * @param <b>allSteps</b> A String variable to contain Feature file steps as String
     * @return <b>ArrayList of Strings</b> - List of Feature file steps.
     * @see java.lang.Exception
     * @see Exception#printStackTrace()
     * @see java.lang.System#exit(int)
     */
    public static ArrayList<String> getListOfSteps(String allSteps) {
        ArrayList<String> listOfStep = new ArrayList<>();
        try {
            /**
             *{@code steps} An array of String to contain Feature file steps.
             * Here all the steps inside {@code steps} array, has been added to {@code listOfStep} ArrayList.
             * @see String#split(String)
             * @see ArrayList#add(Object)
             * @see String#trim()
             */
            String[] steps = allSteps.split("SplitPosition");
            for (int step = 1; step < steps.length; step++) {
                listOfStep.add(steps[step].trim());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return listOfStep;
    }


    /**
     * <p>
     * This Method will query the Database {@code Step_Map} Table and fetch all the steps of  {@code Step_Map} Table and add in {@code listOfDSteps} ArrayList to return it.
     *
     * @return <b>ArrayList of Strings</b> - All the steps present inside DB of {@code Step_Map} Table.
     * @see java.lang.Exception
     * @see Exception#printStackTrace()
     * @see java.lang.System#exit(int)
     */
    public static ArrayList<String> getListOfDbSteps() {
        ArrayList<String> listOfDSteps = new ArrayList<>();
        try {
            /**
             *  {@code arrayListOfStepsMap} An ArrayList of HashMap with key as {@code Step_Name} and with value as step
             *  to store Database fetched data.
             *
             * {@code fetchStepQuery} A String variable that contains fetch Select Query.
             *
             * {@code dbStepMap} A HashMap to store single row of data
             *
             * @see com.croma.automationqa.util.DBConnUtil#dbConnect(String)
             * @see ArrayList#add(Object)
             */
            String fetchStepQuery = "select  \"Step_Name\" from \"" + getConfig("SchemaName") + "\".\"Step_Map\";";
            ArrayList<HashMap<String, String>> arrayListOfStepsMap = dbConnect(fetchStepQuery);
            for (HashMap<String, String> dbStepMap : arrayListOfStepsMap) {
                listOfDSteps.add(dbStepMap.get("Step_Name"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return listOfDSteps;
    }

    /**
     * <p>
     * This Method will take list of steps of Feature file and Query the Database to fetch all the data rows for particular Scenario.
     *
     * @param <b>listOfStep</b> An ArrayList of String which will contain list of steps of Feature file
     * @return <b>ArrayList of HashMap</b> - It stores all the rows fetched from DB
     */
    public static ArrayList<HashMap<String, String>> getListOfColumnsData(ArrayList<String> listOfStep) {

        ArrayList<HashMap<String, String>> arrayListAllColData = new ArrayList<>();
        try {
            /**
             * {@code uniqueQuery} An String type variable to store query to fetch all distinct
             *                      table name in {@code Step_Map} Table
             *
             * {@code arrayListOfTable} An ArrayList of HashMap with String key and String value to
             *                          to store Unique Table name.
             *
             * {@code dbTableMap} An HashMap of String key and String value which is an Instance of {@code arrayListOfTable}
             *
             * {@code table} An String variable to store Table Name
             *
             * {@code query} An String variable to store query to fetch steps of {@code Step_Map} Table
             *               for individual Table Name
             *
             * {@code arrayListOfDBStepMap}  An ArrayList of HashMap with String key ad String value
             *                               to store Table Name wise Step Name
             *
             * {@code columnsToFetch} An ArrayList of String to contain column name for which data
             *                        needs to be fetched
             *
             *  {@code colsDataQuery} A String variable to store query to fetch required column data from DB
             *
             * {@code try} A block where an Exception my occurs.
             *
             * {@code catch} A block to catch any Exception.
             *
             * {@code ex} An Istance of {@link Exception} Class.
             *
             * @see java.lang.Exception
             * @see Exception#printStackTrace()
             * @see java.lang.System#exit(int)
             * @see ArrayList
             * @see DBConnUtil#dbConnect(String)
             * @see HashMap#get(Object)
             * @see String#trim()
             * @see
             * @see
             */
            String uniqueQuery = "select distinct \"Table\" from \"" + getConfig("SchemaName") + "\".\"Step_Map\";";

            ArrayList<HashMap<String, String>> arrayListOfTable = dbConnect(uniqueQuery);
            /**
             *  Iterating through each Table Name to fetch Table Name wise steps
             */
            for (HashMap<String, String> dbTableMap : arrayListOfTable) {
                String table = dbTableMap.get("Table").trim();

                String query = "select \"Step_Name\" from \"" + getConfig("SchemaName") + "\".\"Step_Map\" where \"Table\"=" + "'" + table + "';";
                /**
                 *  Calling {@link DBConnUtil#dbConnect(String)} Method to fetched Table wise steps
                 */
                ArrayList<HashMap<String, String>> arrayListOfDBStepMap = dbConnect(query);

                ArrayList<String> columnsToFetch = new ArrayList<>();
                String colsDataQuery = "select ";
                /**
                 * Iterating through each steps to consolidate all the required columns
                 *
                 *  {@code dbStepMap} An HashMap of String key and String value to contain DB step
                 *
                 *  {@code stepName} A string variable to store actual Database step name
                 */
                for (HashMap<String, String> dbStepMap : arrayListOfDBStepMap) {

                    String stepName = dbStepMap.get("Step_Name").trim();
                    /**
                     * This {@code if} block is to check if a particular DB step
                     * is present in current Scenario. If present then splitting the steps
                     * into word to consolidate column name
                     *
                     * {@code word} A String variable to store individuals word of step
                     * @see String#contains(CharSequence)
                     * @see String#split(String)
                     * @see String#substring(int, int)
                     * @see String#indexOf(String)
                     *
                     */
                    if (listOfStep.contains(stepName)) {
                        String[] words = stepName.split("\\s|,|and");
                        for (String word : words) {
                            if (word.contains("<")) {
                                String column = word.substring(word.indexOf("<") + 1, word.indexOf(">"));
                                columnsToFetch.add(column);
                                if (!backGroundFlag) {
                                    arrayListAllCol.add(column);
                                }
                            }
                        }
                    }
                }
                /**
                 *  Iterating each column inside {@code columnsToFetch} to form the data fetched query
                 * @see columnsToFetch
                 * @see ArrayList#size()
                 */
                for (int col = 0; col < columnsToFetch.size(); col++) {
                    if (col == columnsToFetch.size() - 1) {
                        colsDataQuery = colsDataQuery + "\"" + columnsToFetch.get(col) + "\"";
                    } else {
                        colsDataQuery = colsDataQuery + "\"" + columnsToFetch.get(col) + "\",";
                    }
                }
                /**
                 *  This {@code if} block will decide if there is some column for which data needs to be fetched
                 */
                if (columnsToFetch.size() > 0) {
                    /**
                     * This {@code if} block will decide if this  query is for Background data or Scenario data
                     */
                    if (backGroundFlag) {

                        colsDataQuery += " from \"" + getConfig("SchemaName") + "\".\"" + table + "\" where \"Scenario_Id\" like '" + scName.trim() + "%' limit 1;";
                    } else {

                        colsDataQuery += " from \"" + getConfig("SchemaName") + "\".\"" + table + "\" where \"Scenario_Id\" like '" + scName.trim() + "%';";
                    }
                    /**
                     * {@code arrayListColData} An ArrayList of HashMap with String key and String value which contain
                     *                          DB data rows fetched data
                     *
                     * Calling {@link DBConnUtil#dbConnect(String)}  Method to fetch data rows from DB and
                     *  merging the column data rows
                     *
                     *  {@code colData} An HashMap with String key-value represent key as column name and value
                     *  as its corresponding value
                     *
                     *  {@code map} An HashMap with String key-value represent single data row
                     *
                     * @see ArrayList#size()
                     * @see ArrayList#add(Object)
                     * @see HashMap#get(Object)
                     * @see HashMap.Entry#entrySet()
                     * @see HashMap.Entry#getKey()
                     * @see HashMap.Entry#getValue()
                     */
                    ArrayList<HashMap<String, String>> arrayListColData = dbConnect(colsDataQuery);
                    if (arrayListAllColData.size() < 1) {
                        for (HashMap<String, String> colData : arrayListColData) {
                            arrayListAllColData.add(colData);
                        }
                    } else {
                        for (int item = 0; item < arrayListColData.size(); item++) {
                            HashMap<String, String> map = arrayListColData.get(item);
                            for (Map.Entry<String, String> hmap : map.entrySet()) {
                                arrayListAllColData.get(item).put(hmap.getKey(), hmap.getValue());
                            }
                        }
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return arrayListAllColData;
    }

    /**
     * <p>
     * This Method will take all Background data row as a parameter and replace the background parameters with its value to make
     * final background of Feature file
     *
     * @param <b>backGroundMapData</b> An ArrayList of HashMap with String key-value pair that contains fetched Background DB rows
     * @see java.lang.Exception
     * @see Exception#printStackTrace()
     * @see java.lang.System#exit(int)
     */
    public static void getFinalBackground(ArrayList<HashMap<String, String>> backGroundMapData) {
        try {
            for (HashMap<String, String> hashMap : backGroundMapData) {
                for (Map.Entry<String, String> hmap : hashMap.entrySet()) {
                    logger.info("Key:" + hmap.getKey() + "Val:" + hmap.getValue());
                    finalStr = finalStr.replace("<" + hmap.getKey() + ">", hmap.getValue());
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
    }


    /**
     * <p>
     * This Method will take the name of the config property and return its value.
     * If a System Environment property (from Azure Build Pipeline) exists with the same name as the requested config, then it returns the property value from Azure pipeline.
     * Internally it creates a HashMap&lt;String, HashMap&lt;String, String&gt;&gt; to save all the properties for the first time.
     * Each .properties file is saved in a HashMap&lt;String, String&gt; and then all such HashMaps are stored in
     * HashMap&lt;String, HashMap&lt;String, String&gt;&gt; keeping filename as key.
     *
     * @param <b>configName</b> Name of the config/environment property saved in 'config' folder as .properties file
     * @return <b>String</b> - Value of the config property
     */
    public static String getConfig(String configName) {
        String value = "";
        try {
            if (configMap.isEmpty()) {

                /* Config Map Construction */
                InputStream is = FrameworkUtil.class.getClassLoader().getResourceAsStream(configPath);
                List<String> files = IOUtils.readLines(is, Charsets.UTF_8);
                for (String fileName : files) {
                    configMap.put(fileName, configIterator(configPath + fileName));
                }
            }

            String envParam = System.getenv(configName.toUpperCase());
            if (envParam == null) {
                for (String file : configMap.keySet()) {
                    if (configMap.get(file).containsKey(configName)) {
                        value = configMap.get(file).get(configName);

                        break;
                    }
                }
            } else {
                value = envParam;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return value;

    }

    /**
     * <p>
     * This Method accepts System Environment Variables as Strings and adds them in System on the go.
     * System Environment variable must be provided in this format "NAME::VALUE"
     * Always put double-colon '::' between Variable name and Value.
     * Don't put any additional SPACE before or after name/value.
     * Any number of variables can be provided this way.
     *
     * @param <b>envVars</b> Name::Value of the environment properties. This is a Var Arg field.
     */
    public static void setEnvVar(String... envVars) throws Exception {

        Map<String, String> newenv=null;
        try {
            newenv = new HashMap<>();
            String varName, varValue;
            for (String var : envVars) {
                var = var.trim();
                if (var.contains("::")) {
                    varName = var.split("::")[0].trim();
                    varValue = var.split("::")[1].trim();
                    newenv.put(varName, varValue);
                }
            }

            Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
            Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
            theEnvironmentField.setAccessible(true);
            Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
            env.putAll(newenv);
            Field theCaseInsensitiveEnvironmentField = processEnvironmentClass.getDeclaredField("theCaseInsensitiveEnvironment");
            theCaseInsensitiveEnvironmentField.setAccessible(true);
            Map<String, String> cienv = (Map<String, String>) theCaseInsensitiveEnvironmentField.get(null);
            cienv.putAll(newenv);
        } catch (NoSuchFieldException e) {
            Class[] classes = Collections.class.getDeclaredClasses();
            Map<String, String> env = System.getenv();
            for (Class cl : classes) {
                if ("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
                    Field field = cl.getDeclaredField("m");
                    field.setAccessible(true);
                    Object obj = field.get(env);
                    Map<String, String> map = (Map<String, String>) obj;
                    map.clear();
                    map.putAll(newenv);
                }
            }
        }
    }



}
