package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.clearTextBox;
import static com.croma.automationqa.util.CommonUtil.clearTextBoxBackSpace;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;


/*
     All the address book page related function defined in CromaAddressBookPage class
*/
public class CromaAddressBookPageStepDef {

    private final int addressPageScrollDownFirstIndex = 0, addressPageScrollDownLastIndex = 350;

    /*
        User clicks on the add new address
    */
    @And("^user clicks on the add new address$")
    public void userClicksOnTheAddNewAddress() throws InterruptedException {
        getElement("defaultAddressNickName").click();
        Thread.sleep(5000);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnNewAddress")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        processScreenshot();
        getElement("clickOnNewAddress").click();
    }


    /*
        User provide the address details
    */
    @And("^user provides the address details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and save the address$")
    public void userProvidesTheAddressDetailsAndSaveTheAddress(String addressFullName1, String addressMobileNumber1, String addressNickName1, String addressDetails1, String addressDetails2, String addressType1, String addressState1, String addressCity1, String addressPincode1, String addressDefaultOption) {
        logger.info("Address is: " + addressFullName1 + " " + addressMobileNumber1 + " " + addressNickName1 + " " + addressDetails1 + " " + addressDetails2 + " " + addressType1 + " " + " " + addressState1 + " " + addressCity1 + " " + addressPincode1);
        clearTextBox(getElement("addressName"));
        getElement("addressName").sendKeys(addressFullName1);
        clearTextBox(getElement("addressPhoneNumber"));
        getElement("addressPhoneNumber").sendKeys(addressMobileNumber1);
        clearTextBox(getElement("addressNickName"));
        getElement("addressNickName").sendKeys(addressNickName1);
        clearTextBoxBackSpace(getElement("addressPinCode"));
        getElement("addressPinCode").sendKeys(addressPincode1);
        clearTextBoxBackSpace(getElement("addressDetails1"));
        getElement("addressDetails1").sendKeys(addressDetails1);
        clearTextBoxBackSpace(getElement("addressDetails2"));
        getElement("addressDetails2").sendKeys(addressDetails2);
        //clearTextBoxBackSpace(getElement("addressState"));
//        getElement("addressState").sendKeys(addressState1);
//        getElement("selectAddressState", addressState1).click();
//        clearTextBoxBackSpace(getElement("addressCity"));
//        getElement("addressCity").sendKeys(addressCity1);
//        getElement("selectAddressCity", addressCity1).click();
        //clearTextBoxBackSpace(getElement("addressPinCode"));
        //getElement("addressPinCode").sendKeys(addressPincode1);
        getElement("addressType", addressType1).click();
        if (addressDefaultOption.equals("True")) {
            getElement("defaultAddressCheckboxOnUpdatePage").click();
            setContext("defaultAddressFlag", addressDefaultOption);
        }
        setContext("address_nickname", getElement("addressNickName").getAttribute("value"));
        setContext("finalAddressFullNameAddressPage", addressFullName1);
        setContext("finalAddressTypeAddressPage", addressType1);
        setContext("finalAddressFullAddressPage", addressDetails1.concat(", ").concat(addressDetails2).concat(", ").concat(addressCity1).concat(", ").concat(addressState1).concat(" - ").concat(addressPincode1));
        setContext("finalAddressPhoneNumberAddressPage", addressMobileNumber1);
        setContext("finalAddressNickNameAddressPage", addressNickName1);
        logger.info("Nick name " + getElement("addressNickName").getAttribute("value") + "Nick name from previous " + getContext("address_nickname") + " " + getContext("finalAddressFullNameAddressPage") + " " + getContext("finalAddressTypeAddressPage") + " " + getContext("finalAddressFullAddressPage") + " " + getContext("finalAddressPhoneNumberAddressPage") + " " + getContext("finalAddressNickNameAddressPage"));
        assertStepExecution(true, getElement("addressSaveButton").isEnabled(),
                "user verify address save button enabled");
        getElement("addressSaveButton").click();
    }


    /*
        User clicks on delete button of selected address
    */
    @Then("^user clicks on delete button of selected address as type \"([^\"]*)\", option \"([^\"]*)\" and validates the delete message as \"([^\"]*)\"$")
    public void userClicksOnDeleteButtonOfSelectedAddressAsTypeOptionAndValidatesTheDeleteMessageAs(String deleteOptionType, String deleteAddressOption, String deleteAddressMessage) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        windowScrollIntoViewByWebElement(getElement("addressScrollToAddressType", getContext("finalAddressSavedIndexCount")));
        windowScrollIntoViewAdjustment(addressPageScrollDownFirstIndex, addressPageScrollDownLastIndex);
        if (deleteOptionType.equals("Checkout")) {
            searchCheckoutAddressIndex();
        } else if (deleteOptionType.equals("Address")) {
            searchMyAddressIndex();
        }
        logger.info("Current address index is: " + getContext("finalAddressSavedIndexCount"));
        Thread.sleep(3000);
        jsClick(getElement("addressDelete", getContext("finalAddressSavedIndexCount")));
        switch (deleteAddressOption) {
            case "Proceed":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addressPopupProceed")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                getElement("addressPopupProceed").click();
                logger.info("The get texted value is=" + getElement("addressDeleteMsgValidation").getText() + " " + " The message from data base is:" + deleteAddressMessage);
                assertThat(getElement("addressDeleteMsgValidation").getText()).describedAs(" Delete address text is not matching in address book  page").isEqualToIgnoringCase(deleteAddressMessage);
                break;
            case "Cancel":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addressPopupCancel")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                assertThat(getOptionalElement("addressPopupCancel") != null).describedAs(" Cancel button is visible ").isEqualTo(true);
                getElement("addressPopupCancel").click();
                break;
        }
        passStepExecution("User clicks on delete button of selected address");
    }

    /*
        User clicks on update button of selected address in the address book page
    */
    @And("^user clicks on update button of selected address in the address book page$")
    public void userClicksOnUpdateButtonOfSelectedAddressInTheAddressBookPage() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addressUpdate", getContext("finalAddressSavedIndexCount"))), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        processScreenshot();
        getElement("addressUpdate", getContext("finalAddressSavedIndexCount")).click();
    }


    /*
        user validates previously added address is added or updated in the address book page
    */
    @And("^user validates previously added address is as \"([^\"]*)\" in the address book page \"([^\"]*)\"$")
    public void userValidatesPreviouslyAddedAddressIsAsInTheAddressBookPage(String addressValidationOption, String addressValidationPageType1) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        int phoneNumberDigit = 10;
        String addressType, addressFullName, fullAddress, addressPhoneNumber, nickName;
        List<WebElement> cromaAddressListDetails = getElements("addressListInAddressPage");
        setContext("totalMyAddressIndex", String.valueOf(cromaAddressListDetails.size()));
        switch (addressValidationOption) {
            case "Present":
                logger.info("Count of address list is: " + cromaAddressListDetails.size() + " " + " Address validation option is: " + addressValidationOption + " " + " Address validation page type is: " + addressValidationPageType1);
                setContext("finalAddressSavedIndexCount", String.valueOf(cromaAddressListDetails.size()));
                break;
            case "Update":
                searchMyAddressIndex();
                logger.info("Current address index is: " + getContext("finalAddressSavedIndexCount"));
                break;
        }
        windowScrollIntoViewByWebElement(getElement("addressScrollToAddressType", getContext("finalAddressSavedIndexCount")));
        windowScrollIntoViewAdjustment(addressPageScrollDownFirstIndex, addressPageScrollDownLastIndex);
        addressType = getElement("addressTypeInAddressPage", getContext("finalAddressSavedIndexCount")).getText();
        addressFullName = getElement("addressFullNameInAddressPage", getContext("finalAddressSavedIndexCount")).getText();
        fullAddress = getElement("addressFullInAddressPage", getContext("finalAddressSavedIndexCount")).getText();
        nickName = getElement("addressScrollToAddressType", getContext("finalAddressSavedIndexCount")).getText();
        addressPhoneNumber = getElement("addressPhoneNumberInAddressPage", getContext("finalAddressSavedIndexCount")).getText();
        addressPhoneNumber = addressPhoneNumber.substring((addressPhoneNumber.length() - phoneNumberDigit), addressPhoneNumber.length());
        processScreenshot();
        logger.info("Address details are: " + addressType + " " + addressFullName + " " + fullAddress + " " + addressPhoneNumber + " " + nickName + "Address details from DB are: " + getContext("finalAddressTypeAddressPage") + " " + getContext("finalAddressFullNameAddressPage") + " " + getContext("finalAddressFullAddressPage") + " " + getContext("finalAddressPhoneNumberAddressPage") + " " + getContext("finalAddressNickNameAddressPage") + " " + addressValidationPageType1);
        if (addressValidationPageType1.equals("Checkout")) {
            logger.info("Saved data from checkout page are: " + getContext("finalAddressTypeCheckoutPage") + " " + getContext("finalAddressFullNameCheckoutPage") + " " + getContext("finalAddressFullAddressDetailsCheckoutPage") + " " + getContext("finalAddressPhoneNumberDetailsCheckoutPage"));
            assertThat(getContext("finalAddressTypeCheckoutPage")).describedAs("Address type is not matching in address book  page").isEqualToIgnoringCase(addressType);
            assertThat(getContext("finalAddressFullNameCheckoutPage")).describedAs("Address full name is not matching in address book  page").isEqualToIgnoringCase(addressFullName);
            assertThat(getContext("finalAddressFullAddressDetailsCheckoutPage")).describedAs("Address is not matching in address book  page").isEqualToIgnoringCase(fullAddress);
            assertThat(getContext("finalAddressPhoneNumberDetailsCheckoutPage")).describedAs("Address phone number is not matching in address book  page").isEqualTo(addressPhoneNumber);
        } else if (addressValidationPageType1.equals("Address")) {
            logger.info("Saved data from address page are: " + getContext("finalAddressTypeAddressPage") + " " + getContext("finalAddressFullNameAddressPage") + " " + getContext("finalAddressFullAddressPage") + " " + getContext("finalAddressPhoneNumberAddressPage"));
            assertThat(getContext("finalAddressTypeAddressPage")).describedAs("Address type is not matching in address book  page").isEqualToIgnoringCase(addressType);
            assertThat(getContext("finalAddressFullNameAddressPage")).describedAs("Address full name is not matching in address book  page").isEqualToIgnoringCase(addressFullName);
            assertThat(getContext("finalAddressFullAddressPage")).describedAs("Address is not matching in address book  page").isEqualToIgnoringCase(fullAddress);
            assertThat(getContext("finalAddressPhoneNumberAddressPage")).describedAs("Address phone number is not matching in address book  page").isEqualToIgnoringCase(addressPhoneNumber);
            assertThat(nickName).isEqualToIgnoringCase(getContext("finalAddressNickNameAddressPage"));
        }
        passStepExecution("user validates previously added address is added or updated in the address book page");
    }


    /*
        user removes all the addresses from address page
    */
    @Then("^user removes all the addresses from address page$")
    public void userRemovesAllTheAddressesFromAddressPage() throws InterruptedException {
        int addressPageLastValue = 2;
        List<WebElement> cromaAddressListDetails = getElements("addressListInAddressPage");
        logger.info("Count of address list is: " + cromaAddressListDetails.size());
        processScreenshot();
        for (int i = cromaAddressListDetails.size(); i >= addressPageLastValue; i--) {
            Thread.sleep(6000);
            getElement("addressDelete", String.valueOf(i)).click();
            getElement("addressPopupProceed").click();
            String deleteAddressMessage = "Address removed from profile";
            logger.info("The get texted value is=" + getElement("addressDeleteMsgValidation").getText() + " " + " The message from data base is:" + deleteAddressMessage);
            assertStepExecution(deleteAddressMessage, getElement("addressDeleteMsgValidation").getText(),
                    "Delete address text is matching in address book  page");
        }

    }


    /*
        user validates that address is set as default address in the address book page coming as option
    */
    @And("^user validates that address is set as default address in the address book page coming as option$")
    public void userValidatesThatAddressIsSetAsDefaultAddressInTheAddressBookPageComingAsOption() {
        String defaultAddressText = "DEFAULT ADDRESS";
        logger.info("Final update count: " + getContext("finalAddressSavedIndexCount") + "get context value of finalAddressNickNameAddressPage: " + getContext("finalAddressNickNameAddressPage") + "nickname found from get dynamic element: " + getElement("addressScrollToAddressType", getContext("finalAddressSavedIndexCount")).getText() + "defaultAddressDisplayText displayed is: " + getElement("defaultAddressDisplayText", getContext("finalAddressSavedIndexCount")).getText());
        assertStepExecution(defaultAddressText, getElement("defaultAddressDisplayText", getContext("finalAddressSavedIndexCount")).getText(),
                "Default Address display");
    }


    /*
        user checks/unchecks the default address checkbox from added address and validates default address got added/removed in the address book page coming as option
    */
    @And("^user \"([^\"]*)\" checks/unchecks the default address checkbox from added address and validates default address got added/removed in the address book page coming as option$")
    public void userChecksUnchecksTheDefaultAddressCheckboxFromAddedAddressAndValidatesDefaultAddressGotAddedRemovedInTheAddressBookPageComingAsOption(String checkUnchekOption) {
        logger.info("dynamicIndex value to check/uncheck the default address: " + getContext("finalAddressSavedIndexCount") + " And checkUnchekOption: " + checkUnchekOption);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("defaultAddressCheckboxOnAddressBook", getContext("finalAddressSavedIndexCount"))), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        getElement("defaultAddressCheckboxOnAddressBook", getContext("finalAddressSavedIndexCount")).click();
        setContext("defaultAddressFlag", checkUnchekOption);
        processScreenshot();
        searchMyAddressIndex();
        logger.info("dynamicIndex value to check/uncheck the default address: " + getContext("finalAddressSavedIndexCount") + " And defaultAddressFlag: " + getContext("defaultAddressFlag"));
        deFaultAddressValidation();
    }


    /*
       user searches the required address from the address list
    */
    public void searchMyAddressIndex() {
        String nickname = getContext("address_nickname");
        int addressFirstIndex = 1;
        logger.info("get context nickname is: " + nickname);
        List<WebElement> cromaAddressListDetails = getElements("addressListInAddressPage");
        logger.info("List size is: " + cromaAddressListDetails.size());
        assertStepExecution(true, getOptionalElement("addressListInAddressPage") != null, " user searches the required address from the address list");
        for (WebElement nickNameAll : cromaAddressListDetails) {
            nickNameAll = getElement("nickNameAddressCellAddressBook");
            logger.info("inside for each the str value which is equal: " + nickNameAll.getText());
            if (nickNameAll.getText().equals(nickname)) {
                logger.info("inside for each  inside if: " + nickNameAll.getText());
                break;
            }
        }
        for (int i = addressFirstIndex; i <= Integer.parseInt(getContext("totalMyAddressIndex")); i++) {
            String addressNickName = getElement(("addressScrollToAddressType"), String.valueOf(i)).getText();
            logger.info("Printing the xpath : " + getElement(("addressScrollToAddressType"), String.valueOf(i)).getText() + addressNickName);
            if (addressNickName.equalsIgnoreCase(nickname)) {
                setContext("finalAddressSavedIndexCount", String.valueOf(i));
                logger.info("Update address for loop i: " + i + " address for loop nickname is: " + addressNickName + " Value of get context of finalAddressSavedIndexCount: " + getContext("finalAddressSavedIndexCount"));
                break;
            }
        }
    }

    /*
           user searches the required checkout address from the address list
        */
    public void searchCheckoutAddressIndex() {
        String fullName = getContext("finalAddressFullNameCheckoutPage");
        int addressFirstIndex = 1;
        logger.info("get context nickname is: " + fullName);
        List<WebElement> cromaAddressListDetails = getElements("addressListInAddressPage");
        logger.info("List size is: " + cromaAddressListDetails.size());
        for (WebElement fullNameAll : cromaAddressListDetails) {
            fullNameAll = getElement("fullNameAddressCellAddressBook");
            logger.info("inside for each the str value which is equal: " + fullNameAll.getText());
            if (fullNameAll.getText().equals(fullName)) {
                logger.info("inside for each  inside if: " + fullNameAll.getText());
                break;
            }
        }
        for (int i = addressFirstIndex; i <= Integer.parseInt(getContext("totalMyAddressIndex")); i++) {
            String addressFullName = getElement(("addressScrollToFullName"), String.valueOf(i)).getText();
            logger.info("Printing the xpath : " + getElement(("addressScrollToFullName"), String.valueOf(i)).getText() + addressFullName);
            if (addressFullName.equalsIgnoreCase(fullName)) {
                setContext("finalAddressSavedIndexCount", String.valueOf(i));
                logger.info("Update address for loop i: " + i + " address for loop nickname is: " + addressFullName + " Value of get context of finalAddressSavedIndexCount: " + getContext("finalAddressSavedIndexCount"));
                break;
            }
        }
    }

    /*
       user validates default address enabled or not
    */
    private void deFaultAddressValidation() {
        String defaultAddress = "DEFAULT ADDRESS";
        logger.info("dynamicIndex value of default address in address validation: " + getContext("finalAddressSavedIndexCount") + " And defaultAddressFlag: " + getContext("defaultAddressFlag"));
        if (getContext("defaultAddressFlag").equalsIgnoreCase("True"))
            assertThat(getElement("defaultAddressDisplayText", getContext("finalAddressSavedIndexCount")).getText()).describedAs("Default Address checking/unchecking not matching").isEqualToIgnoringCase(defaultAddress);
        else {
            List<WebElement> defaultAddressList = getDriver().findElements(By.xpath("(//div[@class='cp-address']/ul/li)[" + getContext("finalAddressSavedIndexCount") + "]//h3[@class='address-name']//preceding::span[1]"));
            logger.info("Size of the default address list is: " + defaultAddressList.size() + " And defaultAddressFlag: " + getContext("defaultAddressFlag") + " And index is: " + getContext("finalAddressSavedIndexCount"));
            // After solving default address issue - uncomment the below line
            // int zero = 0;
            // assertThat(defaultAddressList.size()).describedAs("Default Address checking/unchecking not matching").isEqualTo(zero);
        }
        passStepExecution("user validates default address enabled or not");
    }

    /*
        User clicks on delete button of selected address
    */
    @And("^user clicks on delete button of selected address as option \"([^\"]*)\" and validates the delete message as \"([^\"]*)\"$")
    public void userClicksOnDeleteButtonOfSelectedAddressAsOptionAndValidatesTheDeleteMessageAs(String deleteAddressOption, String deleteAddressMessage) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
//        CommonUtil.windowScrollIntoViewByWebElement(getElement("addressScrollToAddressType", getContext("finalAddressSavedIndexCount")));
//        CommonUtil.windowScrollIntoViewAdjustment(addressPageScrollDownFirstIndex, addressPageScrollDownLastIndex);
        searchMyAddressIndex();
        logger.info("Current address index is: " + getContext("finalAddressSavedIndexCount"));
        getElement("addressDelete", getContext("finalAddressSavedIndexCount")).click();
        switch (deleteAddressOption) {
            case "Proceed":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addressPopupProceed")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                getElement("addressPopupProceed").click();
                logger.info("The get texted value is=" + getElement("addressDeleteMsgValidation").getText() + " " + " The message from data base is:" + deleteAddressMessage);
                assertThat(getElement("addressDeleteMsgValidation").getText()).describedAs(" Delete address text is not matching in address book  page").isEqualToIgnoringCase(deleteAddressMessage);
                break;
            case "Cancel":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("addressPopupCancel")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                assertThat(getOptionalElement("addressPopupCancel") != null).describedAs(" Cancel button is visible ").isEqualTo(true);
                getElement("addressPopupCancel").click();
                break;
        }
        passStepExecution("User clicks on delete button of selected address");
    }

    /*
        user removes all the addresses from address page
    */
    @Then("^user removes all the addresses from address page and validates the delete message as \"([^\"]*)\"$")
    public void userRemovesAllTheAddressesFromAddressPageAndValidatesTheDeleteMessageAs(String deleteAddressMessage) {
        List<WebElement> cromaAddressListDetails = getElements("addressListInAddressPage");
        logger.info("Count of address list is: " + cromaAddressListDetails.size());
        for (WebElement cromaAddressEach : cromaAddressListDetails) {
            getElement("addressDelete", String.valueOf(cromaAddressListDetails.indexOf(cromaAddressEach) + 1)).click();
            getElement("addressPopupProceed").click();
            conditionalWait(ExpectedConditions.visibilityOf(getElement("addressDeleteMsgValidation")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            assertThat(getElement("addressDeleteMsgValidation").getText()).describedAs("Delete address text is not matching in address book  page").isEqualToIgnoringCase(deleteAddressMessage);
        }

        passStepExecution("user removes all the addresses from address page");
    }

    @And("user click on update button for default address")
    public void userClickOnUpdateButtonForDefaultAddress() {

        getElement("clickOnDefaultAddressUpdateButton").click();
    }

    /*
    This function is used for update pincode and addresses (E2E test)
     */
    @And("user provides the address details {string}, {string}, {string} and save the address")
    public void userProvidesTheAddressDetailsAndSaveTheAddress(String addressPincode1, String addressDetails1, String addressDetails2) {
        clearTextBoxBackSpace(getElement("addressPinCode"));
        getElement("addressPinCode").sendKeys(addressPincode1);
        clearTextBoxBackSpace(getElement("addressDetails1"));
        getElement("addressDetails1").sendKeys(addressDetails1);
        clearTextBoxBackSpace(getElement("addressDetails2"));
        getElement("addressDetails2").sendKeys(addressDetails2);
        getElement("addressSaveButton").click();
    }

    /*
    This function is used for update pincode and addresses (E2E test)
     */
    @And("user select date as {string} in schedule delivery page")
    public void userSelectDateAsInScheduleDeliveryPage(String selectDate) throws InterruptedException {
        Thread.sleep(3000);
        getElement("clickOnTheDate", selectDate).click();
    }

    /*
    This function is used to verify the address fields error messages
     */
    @And("user validates the address fields error messages {string}, {string}, {string}, {string}, {string}, {string}, {string}, {string}")
    public void userValidatesTheAddressFieldsErrorMessages(String addressFullNameErrorMsg, String addressMobileNoErrorMessage, String addressNickNameErrorMessage, String addressDetailsFirstLineErrorMessage, String addressDetailsSecondLineErrorMessage, String addressStateErrorMessage, String addressCityErrorMessage, String addressPincodeErrorMessage) {
        logger.info("Name field error message" + " " + getElement("addressNameErrorMsg").getText() + " " + "phone number field error message" + " " + getElement("addressPhoneNumberErrorMsg").getText() + " " + " " + "pin code field error message" + " " + getElement("addressPinCodeErrorMsg").getText() + " " + " " + "city field error message" + " " + getElement("selectAddressCityErrorMsg").getText() + " " + " " + "nick name error message" + " " + getElement("addressNickNameErrorMsg").getText() + " " + " " + "address details 1 field error message" + " " + getElement("addressDetails1ErrorMsg").getText() + " " + " " + "address details 2 field error message" + " " + getElement("addressDetails2ErrorMsg").getText() + " " + " " + "state field error message" + " " + getElement("selectAddressStateErrorMsg").getText() + " ");
        assertThat(getElement("addressNameErrorMsg").getText()).isEqualTo(addressFullNameErrorMsg);
        assertThat(getElement("addressPhoneNumberErrorMsg").getText()).isEqualTo(addressMobileNoErrorMessage);
        assertThat(getElement("addressNickNameErrorMsg").getText()).isEqualTo(addressNickNameErrorMessage);
        assertThat(getElement("addressDetails1ErrorMsg").getText()).isEqualTo(addressDetailsFirstLineErrorMessage);
        assertThat(getElement("addressDetails2ErrorMsg").getText()).isEqualTo(addressDetailsSecondLineErrorMessage);
        assertThat(getElement("selectAddressStateErrorMsg").getText()).isEqualTo(addressStateErrorMessage);
        assertThat(getElement("selectAddressCityErrorMsg").getText()).isEqualTo(addressCityErrorMessage);
        assertThat(getElement("addressPinCodeErrorMsg").getText()).isEqualTo(addressPincodeErrorMessage);

        passStepExecution("User validates the address fields error messages");
    }

    @And("user validates the star mark is presented on every field in add new address page")
    public void userValidatesTheStarMarkIsPresentedOnEveryFieldInAddNewAddressPage() throws InterruptedException {
        Thread.sleep(2000);
        List<WebElement> list = getElements("fieldList");
        for (int i = 0; i < list.size() - 2; i++) {
            assertStepExecution(true, list.get(i).getText().contains("*"),
                    "user validates the star mark is presented on every field in add new address page");
        }
    }
}
