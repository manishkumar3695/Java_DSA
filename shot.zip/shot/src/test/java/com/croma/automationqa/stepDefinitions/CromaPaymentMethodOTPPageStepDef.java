package com.croma.automationqa.stepDefinitions;


import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementClick;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

/*
     All the payment method otp page related function defined in CromaPaymentMethodOTPPageStepDef class
*/
public class CromaPaymentMethodOTPPageStepDef {


    /*
        User clicks on successful button in bank page while payment
    */
    @And("^user clicks on successful button in bank page while payment$")
    public void userClicksOnSuccessfulButtonInBankPageWhilePayment() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("bankSuccessfulSubmitButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("User clicks on successful button");
        processScreenshot();
        getElement("bankSuccessfulSubmitButton").click();
    }

    /*
          User provides bank OTP and submit
     */
    @And("^user provides \"([^\"]*)\" OTP$")
    public void userProvidesOTP(String bankotp) {
        logger.info("OTP method has been executed." + bankotp);
        getElement("BankOtpTextBox").sendKeys(bankotp);
        assertStepExecution(true, getOptionalElement("BankOtpSubmitButton") != null, "User provides bank OTP and submit");
        getElement("BankOtpSubmitButton").click();
    }

    @And("^user provides otp \"([^\"]*)\" post credit debit details on payment page$")
    public void userProvidesOtpPostCreditDebitDetailsOnPaymentPage(String otp) {
        getElement("ccDcOtpPaymentPage").sendKeys(otp);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("submitAndPayButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("submitAndPayButton").isDisplayed(), "User choose payment method as tata pay and fill card details and click pay");
        actionMoveToElementClick(getElement("submitAndPayButton"));
    }


    /*

    Old Failure page validations
    */

    @And("user validates payment failure page for payment page {string}")
    public void userValidatesPaymentFailurePageForPaymentPage(String paymentMethod) {
        logger.info("inside failure page");

        logger.info("displayed error on failure page: " + getElement("failurePageErrorMessage").getText());
        logger.info("displayed payment mode on failure page: " + getElement("failurePagePaymentMode").getText());
        logger.info("displayed price on failure page : " + getElement("failurePageTotalAmount").getText() + "     " + getContext("finalCartOrderedTotalPrice"));
        assertThat(getElement("failurePageErrorMessage").getText()).describedAs("failurePage error message comparison").isEqualToIgnoringCase("Your transaction could not be completed.");

        //assertThat(getElement("failurePageTotalAmount").getText()).describedAs("failure page price comparison").isEqualToIgnoringCase(getContext("finalCartOrderedTotalPrice"));

        assertThat(getElement("failurePagePaymentMode").getText()).describedAs("failure page price comparison").isEqualToIgnoringCase(paymentMethod);

        assertThat(getElement("failurePageRetryButton").isDisplayed());

        passStepExecution("Failure page validation");
    }


    //user clicks on cancel button payment OTP page

    @And("user clicks on cancel button payment OTP page")
    public void userClicksOnCancelButtonPaymentOTPPage() {
        assertStepExecution(true, getElement("userClicksOnCancelButtonPaymentOTPPage").isDisplayed(), "user clicks on cancel button payment OTP page");
        getElement("userClicksOnCancelButtonPaymentOTPPage").click();
        getElement("userClicksOnCancelPaymentButton").click();
    }

    @And("user clicks on Success button of bank simulator")
    public void userClicksOnSuccessButtonOfBankSimulator() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("bankSimulatorSuccess")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("bankSimulatorSuccess").isDisplayed(), "Secure and Pay button displayed");
        getElement("bankSimulatorSuccess").click();
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
    }
}
