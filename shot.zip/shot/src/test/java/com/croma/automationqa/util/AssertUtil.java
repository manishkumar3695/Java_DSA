package com.croma.automationqa.util;

import org.assertj.core.api.Assertions;
import org.opentest4j.AssertionFailedError;

import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.FrameworkUtil.logger;
import static com.croma.automationqa.util.FrameworkUtil.processScreenshot;
import static com.croma.automationqa.util.QMetryUtil.updateTestStepExecution;

/**
 * <h3> Purpose:  <p> <h4> &#10687; This class includes all the methods to handle AssertJ Assertions along with QMetry Test Step execution.
 * <br> &#10687; Most commonly used assertion methods for all Java Data-Types are implemented.
 * <br> &#10687; As AssertJ has wide range of assertions, in case of a requirement to implement other assert functions of AssertJ, this class can be updated with implementation of such methods in similar manner.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 01/09/2020
 */
public class AssertUtil extends Assertions {

    /**
     * This method is using AssertJ library to perform any Number-based assertion to compare Byte, Short, Integer, Long, Float and Double.
     * It also update execution result of a test step into QMetry based on the result of the above-mentioned Assertion.
     *
     * @param <b>expNumber</b>       - Expected result as per Test Step
     * @param <b>actNumber</b>       - Actual result found during execution
     * @param <b>stepDescription</b> - A brief description of the Test Step validation
     * @return <b>boolean</b>
     */
    public static boolean assertStepExecution(Number expNumber, Number actNumber, String stepDescription) {
        Boolean assertionFlag = false;
        try {
            assertThat(actNumber)
                    .describedAs(stepDescription)
                    .isEqualTo(expNumber);

            updateQMetryExecution(stepDescription + " :: Passed ", "Working as intended. Test Step Passed", "Pass");
            setContext("testStatus", "Passed");
            logger.info(" ####### Test Step - '" + stepDescription + "' :: PASSED ####### ");
            assertionFlag = true;

        } catch (AssertionFailedError err) {
            String errMsg = err.getMessage();
            err.printStackTrace();
            updateQMetryExecution(stepDescription + " :: Failed \n\n" + errMsg, "Test Step Failed", "Fail");
            throw err;
        }

        return assertionFlag;

    }


    /**
     * This method is using AssertJ library to perform any Boolean-based assertion.
     * It also update execution result of a test step into QMetry based on the result of the above-mentioned Assertion.
     *
     * @param <b>expected</b>        - Expected result as per Test Step
     * @param <b>actual</b>          - Actual result found during execution
     * @param <b>stepDescription</b> - A brief description of the Test Step validation
     * @return <b>boolean</b>
     */
    public static boolean assertStepExecution(Boolean expected, Boolean actual, String stepDescription) {
        Boolean assertionFlag = false;
        try {
            assertThat(actual)
                    .describedAs(stepDescription)
                    .isEqualTo(expected);

            updateQMetryExecution(stepDescription + " :: Passed ", "Working as intended. Test Step Passed", "Pass");
            setContext("testStatus", "Passed");
            logger.info(" ####### Test Step - '" + stepDescription + "' :: PASSED ####### ");
            assertionFlag = true;

        } catch (AssertionFailedError err) {
            String errMsg = err.getMessage();
            err.printStackTrace();
            updateQMetryExecution(stepDescription + " :: Failed \n\n" + errMsg, "Test Step Failed", "Fail");
            throw err;
        }

        return assertionFlag;

    }

    /**
     * This method is using AssertJ library to perform any String-based equality check assertion.
     * It also update execution result of a test step into QMetry based on the result of the above-mentioned Assertion.
     *
     * @param <b>expected</b>        - Expected result as per Test Step
     * @param <b>actual</b>          - Actual result found during execution
     * @param <b>stepDescription</b> - A brief description of the Test Step validation
     * @return <b>boolean</b>
     */


    public static boolean assertStepExecution(String expected, String actual, String stepDescription) {
        Boolean assertionFlag = false;
        try {


            assertThat(actual)
                    .describedAs(stepDescription)
                    .isEqualTo(expected);

            updateQMetryExecution(stepDescription + " :: Passed ", "Working as intended. Test Step Passed", "Pass");
            setContext("testStatus", "Passed");
            logger.info(" ####### Test Step - '" + stepDescription + "' :: PASSED ####### ");
            assertionFlag = true;

        } catch (AssertionFailedError err) {
            String errMsg = err.getMessage();
            err.printStackTrace();
            updateQMetryExecution(stepDescription + " :: Failed \n\n" + errMsg, "Test Step Failed", "Fail");
            throw err;

        }

        return assertionFlag;

    }

    /**
     * This method is updating execution result of a test step into QMetry
     *
     * @param <b>actResult</b> - Actual result found during execution
     * @param <b>comment</b>   - Comment to be logged for the test step execution
     * @param <b>status</b>    - A brief description of the Test Step validation
     * @return <b>boolean</b>
     */
    public static boolean updateQMetryExecution(String actResult, String comment, String status) {


        if (status.equalsIgnoreCase("fail")) {
            setContext("testStatus", "Failed");
        }

        processScreenshot();
        //captureScreen();

        actResult = actResult.replaceAll("\"", "'");

        if (updateTestStepExecution(actResult, comment, status))
            return true;
        else
            return false;
    }

    /**
     * This method update execution result of a passed test step into QMetry.
     * This method is to be used only at the end of a try block of StepDefinition Method which contains multiple Assertions.
     * DO NOT use this method for StepDefinition Methods having single assertion.
     * DO NOT call this method multiple times in same StepDefinition Method.
     *
     * @param <b>actResult</b> - Actual result found during execution
     * @param <b>comment</b>   - Comment to be logged for the test step execution
     * @return <b>boolean</b>
     */
    public static boolean passStepExecution(String actResult) {

        setContext("testStatus", "Passed");
        logger.info(actResult);
        //captureScreen();
        processScreenshot();

        if (updateTestStepExecution(actResult, "Working as intended. Test Step Passed", "Pass"))
            return true;
        else
            return false;
    }


    /**
     * This method update execution result of a failed test step into QMetry.
     * This method is to be used only inside catch block of StepDefinition Method which contains multiple Assertions.
     * DO NOT use this method for StepDefinition Methods having single assertion.
     * DO NOT call this method multiple times in same StepDefinition Method.
     *
     * @param <b>actResult</b> - Actual result found during execution
     * @param <b>comment</b>   - Comment to be logged for the test step execution
     * @return <b>boolean</b>
     */
   /* public static boolean failStepExecution(String actResult) {


        setContext("testStatus", "Failed");
        //captureScreen();
        logger.info(actResult);


        actResult = actResult.replaceAll("\"", "'");

        if (updateTestStepExecution(actResult, "Test Step Failed", "Fail"))
            return true;
        else
            return false;
    }*/


}
