package com.croma.automationqa.stepDefinitions;

import com.croma.automationqa.util.JavaScriptUtil;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.windowScrollIntoViewAdjustment;
import static org.assertj.core.api.Assertions.assertThat;

/*
     All the order history page related function defined in CromaOrderHistoryPageStepDef class
*/
public class CromaOrderHistoryPageStepDef {


    /*
        User validate order history details
    */
    @Then("^user validates order history details \"([^\"]*)\" as order id \"([^\"]*)\" as date$")
    public void userValidatesOrderHistoryDetailsAsOrderIdAsDate(String order_confirmation_id_history_1, String order_confirmation_date_history_1) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("orderHistoryPageOrderIdForClick", order_confirmation_id_history_1)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        processScreenshot();
        getElement("orderHistoryPageOrderIdForClick", order_confirmation_id_history_1).click();
        logger.info("Date value displayed on order history page is: " + getElement("orderHistoryPageDateValue", order_confirmation_id_history_1).getText());
        processScreenshot();
        assertStepExecution(("Purchased on " + order_confirmation_date_history_1), getElement("orderHistoryPageDateValue", order_confirmation_id_history_1).getText(),
                "Order History displayed date on panel");

    }
    /*
        User clicks on any button in order history details
    */

    @And("^user clicks on the \"([^\"]*)\" button of \"([^\"]*)\" for order id \"([^\"]*)\" having status \"([^\"]*)\"$")
    public void userClicksOnTheButtonOfForOrderIdHavingStatus(String buttonOption, String productName, String orderId, String orderStatus) throws Throwable {
        String stepDesc = "user clicks on the " + buttonOption + "button of " + productName + " for order id " + orderId + " having status " + orderStatus;
        assertStepExecution(true, getElement("orderHistoryButtons", orderId, orderStatus, productName, buttonOption).isDisplayed(),
                stepDesc);
        WebElement elem = getElement("orderHistoryButtons", orderId, orderStatus, productName, buttonOption);
        actionMoveToElementBuild(elem);
        elem.click();
    }

    @And("^user validates \"([^\"]*)\" information for order id \"([^\"]*)\" in my orders page$")
    public void userValidatesInformationForOrderIdInMyOrdersPage(String productName, String orderId) throws Throwable {
        String stepDescription = "user validates " + productName + "information for order id " + orderId + " in my orders page";
//        Thread.sleep(Long.parseLong(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")));
//        getDriver().navigate().refresh();
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(4000);
        List<WebElement> orderIdProductCount = getDriver().findElements(By.xpath("//dd[contains(text(),'" + orderId + "')]"));
        int sizeOfOrderIdProductList = orderIdProductCount.size();
        assertThat(sizeOfOrderIdProductList).isGreaterThan(0)
                .describedAs("Order ID should be present in order history page");

        String orderIdProductName = getElement("orderIdProductName", orderId, productName).getText();
        assertThat(orderIdProductName).isEqualToIgnoringCase(productName)
                .describedAs("Product Name on order history page :  " + productName);

        String orderIdProductId = numericValuesExtractionMethod(getElement("orderIdProductId", orderId, productName).getText()) + "";
        String orderIdProductPrice = getElement("orderIdProductPrice", orderId, productName).getText();
        String orderIdProductQty = getElement("orderIdProductQty", orderId, productName).getText();
        String orderIdProductArrivingDate = getElement("orderIdProductArrivingDate", orderId, productName).getText();

        logger.info(orderIdProductName + "," + orderIdProductId + "," + orderIdProductPrice + "," + orderIdProductQty + "," + orderIdProductArrivingDate);

        setContext("orderIdProductName", orderIdProductName);
        setContext("orderIdProductId", orderIdProductId);
        setContext("orderIdProductPrice", orderIdProductPrice);
        setContext("orderIdProductQty", orderIdProductQty);
        setContext("orderIdProductArrivingDate", orderIdProductArrivingDate);

        passStepExecution(stepDescription + " :: Passed");
    }

    @And("^user validates order cancellation message \"([^\"]*)\"$")
    public void userValidatesOrderCancellationMessage(String cancellationMessage) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("cancellationMessage", cancellationMessage)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        logger.info("Cancellation message is: " + getElement("cancellationMessage", cancellationMessage).getText());
        assertStepExecution(cancellationMessage, getElement("cancellationMessage", cancellationMessage).getText(), "user validates order cancellation message");
    }


    @Then("^user validates status \"([^\"]*)\" for order id \"([^\"]*)\" of the product \"([^\"]*)\" in my orders page$")
    public void userValidatesStatusForOrderIdOfTheProductIdInMyOrdersPage(String status, String orderId, String productId) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String orderStatus = getElement("orderStatus", orderId, productId).getText();
        logger.info("The order status for order number " + orderId + "and product Id " + productId + "is :" + orderStatus);
        assertThat(orderStatus).isEqualToIgnoringCase(status)
                .describedAs("Order status on order history page :  " + status);

    }

    @And("^user verify only alphanumeric, space , @ and comma of the characters have been entered in the comment field$")
    public void userVerifyOnlyAlphanumericSpaceAndCommaOfTheCharactersHaveBeenEnteredInTheCommentField() {
        String charSetToBeEntered = getConfig("alphaNumericSpecialCharSets");
        getElement("orderHistoryCommentField").sendKeys(charSetToBeEntered);
        String charSetEntered = getElement("orderHistoryCommentField").getText();
        logger.info("Characters Entered : " + charSetEntered);
        assertThat(charSetEntered).isNotEqualTo(charSetToBeEntered);
        assertThat(charSetEntered).matches("^[a-zA-Z0-9,@ ]*$");
    }

    @And("^user validates breadcrumb link \"([^\"]*)\" and page title as \"([^\"]*)\" in order history page$")
    public void userValidatesBreadcrumbLinkInOrderHistoryPage(String breadcrumb, String pageTitle) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat(getElement("orderPageHeading").getText()).isEqualToIgnoringCase(pageTitle)
                .describedAs("Page title should be : " + pageTitle);
        String[] breadcrumbArr = breadcrumb.split(";");
        for (int elem = 0; elem < breadcrumbArr.length; elem++) {
            String breadcrumbTitle = getDriver().findElements(By.xpath(getLocator("orderHistoryBreadcrumbList"))).get(elem).getText();
            assertThat(breadcrumbTitle).isEqualToIgnoringCase(breadcrumbArr[elem]).describedAs("user validates breadcrumb link in order history page");
        }
        passStepExecution("user validates breadcrumb link in order history page");

    }

    @And("^user validates \"([^\"]*)\" buttons for order id \"([^\"]*)\" of the product \"([^\"]*)\" having status \"([^\"]*)\" are \"([^\"]*)\"$")
    public void userValidatesButtonsForOrderIdOfTheProductHavingAre(String buttons, String orderId, String productName, String orderStatus, String enableOrDisableFlag) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        List<WebElement> buttonWebElemList;
        if (enableOrDisableFlag.equalsIgnoreCase("enabled")) {
            if (buttons.contains(";")) {
                String[] buttonArr = buttons.split(";");
                for (String btn : buttonArr) {
                    buttonWebElemList = getDriver().findElements(By.xpath(getLocator("orderHistoryButtons", orderId, orderStatus, productName, btn)));
                    assertThat(buttonWebElemList.size()).isGreaterThan(0);
                }
            } else {
                buttonWebElemList = getDriver().findElements(By.xpath(getLocator("orderHistoryButtons", orderId, orderStatus, productName, buttons)));
                assertThat(buttonWebElemList.size()).isGreaterThan(0);
            }
        } else if (enableOrDisableFlag.equalsIgnoreCase("disabled")) {
            if (buttons.contains(";")) {
                String[] buttonArr = buttons.split(";");
                for (String btn : buttonArr) {
                    buttonWebElemList = getDriver().findElements(By.xpath(getLocator("orderHistoryButtons", orderId, orderStatus, productName, btn)));
                    assertThat(buttonWebElemList.size()).isEqualTo(0);
                }
            } else {
                buttonWebElemList = getDriver().findElements(By.xpath(getLocator("orderHistoryButtons", orderId, orderStatus, productName, buttons)));
                assertThat(buttonWebElemList.size()).isEqualTo(0);
            }
        }
    }

    @And("^user validates no orders available \"([^\"]*)\" in my order page$")
    public void userValidatesNoOrdersAvailableInMyOrderPage(String noOrderavailableMessage) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(noOrderavailableMessage.toLowerCase(), getElement("noOrderAvailableMessage", noOrderavailableMessage).getText().toLowerCase(),
                "No Order is available");
    }


    @And("^user clicks on continue shopping button in my orders page and lands on home page$")
    public void userClicksOnContinueShoppingButtonInMyOrdersPageAndLandsOnHomePage() {
        getElement("continueShoppingButton").click();
        assertStepExecution(true, getOptionalElement("homePageCroma") != null,
                "Navigated to home page");
    }

    @And("^user validates order id \"([^\"]*)\" history details$")
    public void userValidatesOrderIdHistoryDetails(String orderId) {
        logger.info("Page heading is: " + getElement("orderPageHeading").getText());
        logger.info("Order id is : " + getElement("orderIdOrderPage").getText() + " " + "Product name: " + getElement("ProductNameOrderPage").getText() + " " + "Product id" + getElement("ProductIdOrderPage").getText() + "Price" + getElement("ProductPriceOrderPage").getText() + "Qty:" + getElement("ProductQtyOrderPage").getText() + "Arriving date is:" + getElement("arrivingDateOrderPage").getText());
        assertThat(orderId).isEqualToIgnoringCase(getElement("orderIdOrderPage").getText()).describedAs("Product id on order page");
        assertThat(getContext("orderIdProductName")).isEqualToIgnoringCase(getElement("ProductNameOrderPage").getText()).describedAs("Product name on order page");
        assertThat(getContext("orderIdProductId")).isEqualToIgnoringCase(numericValuesExtractionMethod(getElement("ProductIdOrderPage").getText()) + "").describedAs("Product Id on order page");
        assertThat(getContext("orderIdProductPrice")).isEqualToIgnoringCase(getElement("ProductPriceOrderPage").getText()).describedAs("Product price on order page");
        assertThat(getContext("orderIdProductQty")).isEqualToIgnoringCase(getElement("ProductQtyOrderPage").getText()).describedAs("Product qty on order page");
        //  assertThat(getContext("orderIdProductArrivingDate")).isEqualToIgnoringCase(getElement("arrivingDateOrderPage").getText()).describedAs("Arriving date on order page");
        passStepExecution("User validates order id history details");
    }

    @And("^user selects reason details as \"([^\"]*)\"$")
    public void userSelectsReasonDetailsAs(String reason) {
        logger.info("Title of Reason for request is: " + getElement("ReasonForOrderTitle").getText());
        assertThat(getElement("ReasonForOrderTitle").getText()).containsIgnoringCase("*").describedAs("Reason for request should be mandatory");
        getElement("clicksOnSelectReasonDropdown").click();
        getElement("ClicksOnReason", reason).click();
        logger.info("Selected reason is: " + getElement("selectedReason").getText());
        assertThat(reason).isEqualToIgnoringCase(getElement("selectedReason").getText()).describedAs("user selects reason for request details");
        passStepExecution("User selects reason for request details");
    }


    @And("^user provides the details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" in the form to initiate \"([^\"]*)\" process$")
    public void userProvidesTheDetailsInTheFormToInitiateProcess(String firstName, String lastName, String mobileNo, String alternateMobileNo, String invoiceNo, String addressFlatNo, String addressLocality, String addressState, String addressCity, String addressPincode, String returnOrReplace) {
        logger.info("Heading of the form is: " + getElement("formHeading").getText());
        //assertThat(getElement("formHeading").getText()).isEqualToIgnoringCase(returnOrReplace).describedAs("Form heading should contain return or replace");
        logger.info(getElement("firstNameOrderHistoryPage").getAttribute("value"));
        assertThat(getElement("firstNameOrderHistoryPage").getAttribute("value")).isNotEmpty().describedAs("First name should auto populate");
        clearTextBox(getElement("firstNameOrderHistoryPage"));
        getElement("firstNameOrderHistoryPage").sendKeys(firstName);
        clearTextBox(getElement("lastNameOrderHistoryPage"));
        getElement("lastNameOrderHistoryPage").sendKeys(lastName);
        logger.info(getElement("mobileNumberOrderHistoryPage").getAttribute("value"));
        assertThat(getElement("mobileNumberOrderHistoryPage").getAttribute("value")).isEqualToIgnoringCase(mobileNo);
        getElement("alternateMobileNumberOrderHistoryPage").sendKeys(alternateMobileNo);
        logger.info(getElement("invoiceNumberOrderHistoryPage").getAttribute("value"));

        assertThat(getElement("invoiceNumberOrderHistoryPage").getAttribute("value")).isNotEmpty();


        assertThat(getOptionalElement("shippingAddressSelectedByDefault"))
                .describedAs("Shipping Address for the respective Order should be present by default")
                .isNotNull();
        assertThat(getElement("shipAddressDefault").getText()).describedAs("Shipping address is not empty").isNotEmpty();

        getElement("requestChangeAddressButton").click();
        getElement("clickOnAddAddressButton").click();
        getElement("addressFlatNoOrderHistoryPage").sendKeys(addressFlatNo);
        getElement("addressLandmarkOrderHistoryPage").sendKeys(addressLocality);
        clearTextBoxBackSpace(getElement("addressStateOrderHistoryPage"));
        getElement("addressStateOrderHistoryPage").sendKeys(addressState);
        getElement("selectAddressState", addressState).click();
        clearTextBoxBackSpace(getElement("addressCityOrderHistoryPage"));
        getElement("addressCityOrderHistoryPage").sendKeys(addressCity);
        getElement("selectAddressCity", addressCity).click();
        getElement("addressPincodeOrderHistoryPage").sendKeys(addressPincode);
        getElement("defaultAddressCheckboxOrderHistoryPage").click();
        getElement("userClicksOnSavedAddressButton").click();
        assertThat(getOptionalElement("selectSavedFirstAddressRadioButton")).describedAs("Saved first address selected").isNotNull();

        passStepExecution("User provides the details in the form to initiate process");
    }

    @And("^user clicks on \"([^\"]*)\" button in order page$")
    public void userClicksOnButtonInOrderPage(String yesCloseContinueOption) {
        String stepDesc = "user clicks on " + yesCloseContinueOption + " button in order page";
        assertStepExecution(true, getElement("clicksOnYesOrCancelOrContinueButton", yesCloseContinueOption) != null, stepDesc);
        getElement("clicksOnYesOrCancelOrContinueButton", yesCloseContinueOption).click();
    }

    @And("^user provides comments as \"([^\"]*)\" in order page$")
    public void userProvidesCommentsAsInOrderPage(String reasonComment) {
        logger.info("Comment title is : " + getElement("commentTitle").getText());
        assertThat(getElement("commentTitle").getText()).doesNotContain("*").describedAs("Comment should not be mandatory");
        getElement("orderHistoryCommentField").sendKeys(randomAlphabeticString(256));
        assertThat(getElement("orderHistoryCommentField").getText().length()).isEqualTo(255);
        clearTextBox(getElement("orderHistoryCommentField"));
        getElement("orderHistoryCommentField").sendKeys(reasonComment);
        passStepExecution("user provides comments in cancel order page");
    }

    @And("^user lands on product definition page and validates review \"([^\"]*)\" section$")

    public void userLandsOnProductDefinitionPageAndValidatesReviewSection(String reviewSection) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(reviewSection, getElement("reviewSectionfromSite").getText(), "Review section is matched");
        Thread.sleep(5000);
        assertStepExecution(reviewSection, getElement("reviewSectionfromSite").getText(), "Review section is matched");
    }

    @Then("^user verifies the email invoice message \"([^\"]*)\"$")
    public void userVerifiesTheEmailInvoiceMessage(String emailInvoiceMessage) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat(getElement("modalTickSign").getAttribute("src")).isNotEmpty().describedAs("Modal tick is present");
        String fullMessageTextInvoice = getElement("fullMessageInvoice").getText().trim().replaceAll("\n", " ");
        logger.info("The full Message from site is :" + fullMessageTextInvoice);
        assertThat(fullMessageTextInvoice).isEqualTo(emailInvoiceMessage).describedAs("Full Message matched");
        passStepExecution("Everything is asserted and passed.");


    }

    @And("^user validates the color of \"([^\"]*)\" for order id \"([^\"]*)\" of the product \"([^\"]*)\" in my orders page$")
    public void userValidatesTheColorOfForOrderIdOfTheProductInMyOrdersPage(String status, String orderId, String productname) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String orderStatusColor = getElement("orderStatus", orderId, productname).getCssValue("color");
        logger.info("The color of the order status for order number " + orderId + "and product name " + productname + "is :" + orderStatusColor);


    }

    @And("^user validates the color \"([^\"]*)\" of \"([^\"]*)\" for order id \"([^\"]*)\" of the product \"([^\"]*)\" in my orders page$")
    public void userValidatesTheColorOfForOrderIdOfTheProductInMyOrdersPage(String color, String status, String orderId, String productName) {


    }

    @And("^user validates the color \"([^\"]*)\" of status \"([^\"]*)\" for order id \"([^\"]*)\" of the product \"([^\"]*)\" in my orders page$")
    public void userValidatesTheColorOfStatusForOrderIdOfTheProductInMyOrdersPage(String color, String status, String orderId, String productName) {
        String colorOfStatus = getElement("orderstatuscolor", orderId, productName).getCssValue("color");
        String hexcolor = Color.fromString(colorOfStatus).asHex();
        logger.info("The color of order status :" + hexcolor);
        assertStepExecution(color, hexcolor, "Order status color is matched");
    }


    @And("^user validates track order sequence \"([^\"]*)\"$")
    public void userValidatesTrackOrderSequence(String trackOrderSequence) throws Throwable {
        Thread.sleep(4000);
        String[] trackOrderArr = trackOrderSequence.split(";");
        for (int elem = 0; elem < trackOrderArr.length; elem++) {
            String trackOrderSequenceName = getDriver().findElements(By.xpath(getLocator("trackOrderSequenceList"))).get(elem).getText();
            logger.info("Track Order Sequence Name is: " + trackOrderSequenceName);
            assertThat(trackOrderSequenceName).isEqualToIgnoringCase(trackOrderArr[elem]).describedAs("user validates track order sequence in order history page");
        }

        passStepExecution("user validates track order status for order type");
    }

    @And("^user validates track order expanded tile collapsed$")
    public void userValidatesTrackOrderExpandedTileCollapsed() {
        assertStepExecution(false, getOptionalElement("trackOrderSequenceList") != null, "user validates track order expanded tile collapsed");
    }

    @Then("^user validates count \"([^\"]*)\", \"([^\"]*)\" for bundle order id \"([^\"]*)\"$")
    public void userValidatesCountForBundleOrderId(String count, String datestatement, String orderId) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        int countint = Integer.parseInt(count);
        assertThat(getElements("productNameCount", orderId).size()).isEqualTo(countint).describedAs("Product Name count is matched");
        assertThat(getElements("productIdCount", orderId).size()).isEqualTo(countint).describedAs("Product ID count is matched");
        assertThat(getElements("productPriceCount", orderId).size()).isEqualTo(countint).describedAs("Product price count is matched");
        assertThat(getElements("productQuantityCount", orderId).size()).isEqualTo(countint).describedAs("Product Quantity count is matched");
        assertThat(getElements("dateStatement", orderId).size()).isEqualTo(countint).describedAs("Product Quantity count is matched");
        assertThat(getElement("dateStatement", orderId).getText()).contains(datestatement).describedAs("date statement is matched");
        passStepExecution("Everything is asserted and passed.");
    }

    @And("^user waits for the order to be visible in order history page$")
    public void userWaitsForTheOrderToBeVisibleInOrderHistoryPage() throws InterruptedException {
        boolean isDisplayed = false;
        String orderId = getContext("orderId");
        logger.info("Order Id : " + orderId);
        for (int i = 0; i < 15; i++) {
            //   getOptionalElement("paymentStatusHeadingOnMyOrders", orderId).getText().trim().equalsIgnoreCase("Order Placed") ||
            if (getOptionalElement("orderHistoryPageOrderIdForClick", orderId) != null && getOptionalElement("paymentStatusHeadingOnMyOrders", orderId).getText().trim().equalsIgnoreCase("Ready for Pick Up")) {
                isDisplayed = true;
                Thread.sleep(5000);
                assertStepExecution(true, isDisplayed, "user waits here for the order id to be visible in order history page");
                break;
            } else {
                Thread.sleep(10000);
                getDriver().navigate().refresh();
                Thread.sleep(10000);
            }
        }
        if (!isDisplayed)
            assertStepExecution(true, isDisplayed, "user waits for the order to be visible in order history page");
    }

    @And("^user clicks on the \"([^\"]*)\" button of recently placed order$")
    public void userClicksOnTheButtonOfRecentlyPlacedOrder(String buttonOption) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        String orderStatus = getContext("orderStatus");
        String stepDesc = "user clicks on the " + buttonOption + " button of " + productName + " for order id " + orderId + " having status " + orderStatus;
        assertStepExecution(true, getOptionalElement("orderHistoryButtons", orderId, orderStatus, productName, buttonOption) != null,
                stepDesc);
        getElement("orderHistoryButtons", orderId, orderStatus, productName, buttonOption).click();
    }

    @And("^user validates product information of recently placed order$")
    public void userValidatesProductInformationOfRecentlyPlacedOrder() {
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        List<WebElement> orderIdProductCount = getDriver().findElements(By.xpath(getLocator("orderHistoryPageOrderIdForClick", orderId)));
        int sizeOfOrderIdProductList = orderIdProductCount.size();
        assertThat(sizeOfOrderIdProductList).isGreaterThan(0)
                .describedAs("Order ID should be present in order history page");
        String orderIdProductName = getElement("orderIdProductName", orderId, productName).getText();
        assertThat(orderIdProductName).isEqualToIgnoringCase(productName)
                .describedAs("Product Name on order history page :  " + productName);
        String orderIdProductId = numericValuesExtractionMethod(getElement("orderIdProductId", orderId, productName).getText()) + "";
        String orderIdProductPrice = getElement("orderIdProductPrice", orderId, productName).getText();
        String orderIdProductQty = getElement("orderIdProductQty", orderId, productName).getText();
        String orderIdProductArrivingDate = getElement("orderIdProductArrivingDate", orderId, productName).getText();
        logger.info(orderIdProductName + "," + orderIdProductId + "," + orderIdProductPrice + "," + orderIdProductQty + "," + orderIdProductArrivingDate);
        setContext("orderIdProductName", orderIdProductName);
        setContext("orderIdProductId", orderIdProductId);
        setContext("orderIdProductPrice", orderIdProductPrice);
        setContext("orderIdProductQty", orderIdProductQty);
        setContext("orderIdProductArrivingDate", orderIdProductArrivingDate);
        passStepExecution("user validates product information of recently placed order" + " :: Passed");
    }

    @And("^user waits for status to be \"([^\"]*)\" of recently placed order$")
    public void userWaitsForStatusToBeOfRecentlyPlacedOrder(String status) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        String stepDesc = "user waits for status to be " + status + " of recently placed order";
        Boolean isExpectedStatus = false;
        String orderStatus = "";
        for (int i = 0; i < 10; i++) {
            orderStatus = getElement("orderStatus", orderId, productName).getText();
            logger.info("Status Captured is : " + status);
            if (orderStatus.trim().equalsIgnoreCase(status)) {
                isExpectedStatus = true;
                setContext("orderStatus", status);
                assertStepExecution(true, true, stepDesc);
                break;
            } else {
                Thread.sleep(5000);
                getDriver().navigate().refresh();
                Thread.sleep(5000);
            }
        }
        if (!isExpectedStatus)
            assertStepExecution(true, false, stepDesc);
    }


    @And("^user validates order id of recently placed order in history details$")
    public void userValidatesOrderIdOfRecentlyPlacedOrderInHistoryDetails() {
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        logger.info("Page heading is: " + getElement("orderPageHeading").getText());
        logger.info("Order id is : " + getElement("orderIdOrderPage").getText() + " " + "Product name: " + getElement("ProductNameOrderPage").getText() + " " + "Product id" + getElement("ProductIdOrderPage").getText() + "Price" + getElement("ProductPriceOrderPage").getText() + "Qty:" + getElement("ProductQtyOrderPage").getText() + "Arriving date is:" + getElement("arrivingDateOrderPage").getText());
        assertThat(orderId).isEqualToIgnoringCase(getElement("orderIdOrderPage").getText()).describedAs("Product id on order page");
        assertThat(getContext("orderIdProductName")).isEqualToIgnoringCase(getElement("ProductNameOrderPage").getText()).describedAs("Product name on order page");
        assertThat(getContext("orderIdProductId")).isEqualToIgnoringCase(numericValuesExtractionMethod(getElement("ProductIdOrderPage").getText()) + "").describedAs("Product Id on order page");
        assertThat(getContext("orderIdProductPrice")).isEqualToIgnoringCase(getElement("ProductPriceOrderPage").getText()).describedAs("Product price on order page");
        assertThat(getContext("orderIdProductQty")).isEqualToIgnoringCase(getElement("ProductQtyOrderPage").getText()).describedAs("Product qty on order page");
        //  assertThat(getContext("orderIdProductArrivingDate")).isEqualToIgnoringCase(getElement("arrivingDateOrderPage").getText()).describedAs("Arriving date on order page");
        passStepExecution("User validates order id history details");
    }

    @And("^user validates breadcrumb link \"([^\"]*)\" and page title as \"([^\"]*)\" in order history page of recently placed order$")
    public void userValidatesBreadcrumbLinkAndPageTitleAsInOrderHistoryPageOfRecentlyPlacedOrder(String breadcrumb, String pageTitle) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertThat(getElement("orderPageHeading").getText()).isEqualToIgnoringCase(pageTitle)
                .describedAs("Page title should be : " + pageTitle);
        String[] breadcrumbArr = breadcrumb.split(";");
        for (int elem = 0; elem < breadcrumbArr.length - 1; elem++) {
            String breadcrumbTitle = getDriver().findElements(By.xpath(getLocator("orderHistoryBreadcrumbList"))).get(elem).getText();
            logger.info(breadcrumbTitle);
            assertThat(breadcrumbTitle).isEqualToIgnoringCase(breadcrumbArr[elem]).describedAs("user validates breadcrumb link in order history page");
        }
        String breadcrumbTitle = getDriver().findElements(By.xpath(getLocator("orderHistoryBreadcrumbList"))).get(2).getText();
        logger.info(breadcrumbTitle);
        assertThat(breadcrumbTitle).isEqualToIgnoringCase(breadcrumbArr[2] + " " + getContext("orderId")).describedAs("user validates breadcrumb link in order history page");
        passStepExecution("user validates breadcrumb link in order history page");
    }

    @Then("^user validates status \"([^\"]*)\" of recently placed order$")
    public void userValidatesStatusOfRecentlyPlacedOrder(String status) throws Throwable {
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String orderStatus = getElement("orderStatus", orderId, productName).getText();
        logger.info("The order status for order number " + orderId + "and product Name " + productName + "is :" + orderStatus);
        assertThat(orderStatus).isEqualToIgnoringCase(status)
                .describedAs("Order status on order history page :  " + status);
    }

    @And("user scrolls un-till {string} order to be loaded")
    public void userScrollsUnTillOrderToBeLoaded(String orderId) throws InterruptedException {
        Thread.sleep(10000);
        if (getOptionalElement("orderHistoryPageOrderIdForClick", orderId) == null) {
            while (true) {
                String prevPageSource = getDriver().getPageSource();
                JavaScriptUtil.windowScrollIntoTopToBottom();
                Thread.sleep(5000);
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
                String currentPageSource = getDriver().getPageSource();
                if (prevPageSource.equals(currentPageSource) || currentPageSource.contains(orderId)) {

                    actionMoveToElementBuild(getElement("orderHistoryPageOrderIdForClick", orderId));
                    Thread.sleep(3000);
                    break;
                }
            }
        }
        assertStepExecution(true, getOptionalElement("orderHistoryPageOrderIdForClick", orderId) != null,
                "user scrolls un-till " + orderId + " order to be loaded");
    }

    /**
     * This method is used to validate retry button is present in myOrder Page
     **/
    @And("user validates {string} button is present in my Orders page")
    public void userValidatesButtonIsPresentInMyOrderPage(String Retry) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LONG")));
        Thread.sleep(5000);
        assertStepExecution(true, getDriver().findElements(By.xpath(getLocator("retryButtonInMyOrdersPage", Retry))).size() > 0,
                "user validates " + Retry + " button is present for a product in MyOrders page");
    }

    /**
     * This method is used to validate NO retry button is present in myOrder Page for failed Orders
     **/
    @And("user validates {string} button is NOT present in my Orders page")
    public void userValidatesButtonIsNOTPresentInMyOrdersPage(String NotRetry) throws InterruptedException {
        Thread.sleep(4000);
        assertStepExecution(false, getDriver().findElements(By.xpath(getLocator("retryButtonInMyOrdersPage", NotRetry))).size() > 0,
                "user validates " + NotRetry + " button is present for a product in MyOrders page");
        //assertStepExecution(false, getOptionalElement("retryButtonInMyOrdersPage") != null, "User validates Retry button is not displayed for that particular order in My Orders page");
    }

    /**
     * This method is used to click on retry-button present in myOrders Page
     **/
    @And("user clicks on retry button in my Orders Page")
    public void userClicksOnRetryButtonInMyOrdersPage() throws InterruptedException {
        assertStepExecution(true, getElement("retryButtonInMyOrdersPage").isDisplayed(), "user clicked on retry button in My orders page");
        getElement("retryButtonInMyOrdersPage").click();
        Thread.sleep(5000);
        assertStepExecution(true, getOptionalElement("paymentPageValidation") != null, "Navigated to Payment Page");
    }

    /**
     * This Method is used to click on cancel order link in my orders page
     **/
    @And("user clicks on cancel order button of first product in my orders page")
    public void userClicksOnCancelOrderButtonOfFirstProductInMyOrdersPage() throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getOptionalElement("cancelFirstOrderFromMyOrdersProductsList")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getOptionalElement("cancelFirstOrderFromMyOrdersProductsList") != null,
                "user clicks on cancel order button of first product in my orders page");
        getElement("cancelFirstOrderFromMyOrdersProductsList").click();
    }

    /**
     * This Method is used to validate Whether user lands on my orders page or not
     **/
    @And("user lands on cancel order page")
    public void userLandsOnCancelOrderPage() {
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("cancelOrderHeading")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getOptionalElement("cancelOrderHeading").isDisplayed(),
                "user lands on cancel order page");
    }

    @And("user selects {string} in select reason for cancellation dropdown in cancel order page")
    public void userSelectsInSelectReasonForCancellationDropdownInCancelOrderPage(String reason) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("CancelDropdown") != null,
                "user selects " + reason + " in select reason for cancellation dropdown in cancel order page");
        getElement("CancelDropdown").click();
        getElement("reasonForCancelDropdown", reason).click();
    }

    @And("user clicks on yes cancel button in cancel order page")
    public void userClicksOnYesCancelButtonInCancelOrderPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("yesCancelButton") != null,
                "user clicks on yes cancel button in cancel order page");
        getElement("yesCancelButton").click();

    }

    @And("user verifies the order is cancelled in my orders page")
    public void userVerifiesTheOrderIsCancelledInMyOrdersPage() {
        String orderId = getContext("orderId");
        conditionalWait(ExpectedConditions.visibilityOf(getOptionalElement("paymentStatusHeadingOnMyOrders", orderId)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("paymentStatusHeadingOnMyOrders", orderId).getText().equalsIgnoreCase("Order Cancelled"),
                "user verifies the order is cancelled in my orders page");
    }

    @And("user validates product details {string} is present in return replace page")
    public void userValidatesProductDetailsIsPresentInReturnReplacePage(String productName) {
        String productNameOnReturnReplacePage = getElement("productTitleOnReturnReplacePage").getText();
        logger.info("Data from web: " + productNameOnReturnReplacePage + "data from DB: " + productName);
        assertStepExecution(true, productNameOnReturnReplacePage.equalsIgnoreCase(productName), "user validates product details matched");
    }

    @And("user checks title message {string} is present in return replace page")
    public void userChecksTitleMessageIsPresentInReturnReplacePage(String titleMessage) {
        String titleMessageInReturnReplacePage = getElement("titleMessageInReturnReplacePage").getText();
        logger.info("Data from web: " + titleMessageInReturnReplacePage + "data from DB: " + titleMessage);
        assertStepExecution(true, titleMessageInReturnReplacePage.equalsIgnoreCase(titleMessage), "user validates product title matched");
    }

    @And("user validates return option {string} is present in return replace page")
    public void userValidatesReturnOptionIsPresentInReturnReplacePage(String returnOption) {
        String returnOptionInReturnReplacePage = getElement("returnOptionInReturnReplacePage", returnOption).getText();
        logger.info("Data from web: " + returnOptionInReturnReplacePage + "data from DB: " + returnOption);
        assertStepExecution(true, returnOptionInReturnReplacePage.equalsIgnoreCase(returnOption), "user validates return option matched");

    }

    @And("user checks continue button is {string} in return replace page")
    public void userChecksContinueButtonIsInReturnReplacePage(String enableOrDisableOption) {
        String strClass = getElement("buttonContinue").getAttribute("class");
        logger.info("strClass = " + strClass);
        switch (enableOrDisableOption) {
            case "Enable":
                assertThat(strClass).contains("default").describedAs("Continue button is enable");
                break;
            case "Disable":
                assertThat(strClass).contains("disable").describedAs("Continue button is disable");
                break;
        }
        passStepExecution("user validates continue button in return replace page:: Passed");

    }

    @And("user clicks on the radio button reason {string} for the option {string} in return replace page")
    public void userClicksOnTheRadioButtonReasonForTheOptionInReturnReplacePage(String returnReason, String returnOption) {
        assertStepExecution(true, getOptionalElement("selectReasonRadioButton", returnOption, returnReason) != null,
                "user clicks on the radio button reason " + returnReason + "for the option" + returnOption + " in return replace page");
        getElement("selectReasonRadioButton", returnOption, returnReason).click();
        setContext("returnReason", returnReason);
    }

    @And("user validates help us message {string} is present in return replace page")
    public void userValidatesHelpUsMessageIsPresentInReturnReplacePage(String helpUsMessage) {
        String helpUsMessageInReturnReplacePage = getElement("helpUsMessageInReturnReplacePage", helpUsMessage).getText();
        logger.info("Data from web: " + helpUsMessageInReturnReplacePage + "data from DB: " + helpUsMessage);
        assertStepExecution(true, helpUsMessageInReturnReplacePage.equalsIgnoreCase(helpUsMessage), "user validates help us message matched");
    }

    @And("user validates response message {string} is present with selected return reason {string} in return replace page")
    public void userValidatesResponseMessageIsPresentWithSelectedReturnReasonInReturnReplacePage(String responseMsg, String returnReason) {
        String stepDesc = "user validates response message " + responseMsg + " is present with selected return reason " + returnReason + " in return replace page";
        String responseMessageInReturnReplacePage = getElement("responseMessageInReturnReplacePage").getText();
        logger.info("Data from web: " + responseMessageInReturnReplacePage + "data from DB: " + responseMsg);
        assertThat(responseMessageInReturnReplacePage).isEqualTo(responseMsg).describedAs("user validates response message message matched");
        String returnResponseReasonInReturnReplacePage = getElement("returnResponseReasonInReturnReplacePage").getText();
        logger.info("Data from web: " + returnResponseReasonInReturnReplacePage + "data from DB: " + getContext("returnReason"));
        assertThat( returnResponseReasonInReturnReplacePage).contains(responseMsg).describedAs( "user validates response message message matched");
        passStepExecution(stepDesc + " :: Passed \n");
    }

    @And("user checks {string} option is present under help us message in return replace page")
    public void userChecksOptionIsPresentUnderHelpUsMessageInReturnReplacePage(String returnReplaceOption) {
        String returnReplaceOptionInReturnReplacePage = getElement("returnReplaceOptionInReturnReplacePage", returnReplaceOption).getText();
        logger.info("Data from web: " + returnReplaceOptionInReturnReplacePage + "data from DB: " + returnReplaceOption);
        assertStepExecution(true, returnReplaceOptionInReturnReplacePage.equalsIgnoreCase(returnReplaceOption), "user validates return replace option is present under help us message in return replace page");
    }


    @And("user validates replace refund subtext {string} of {string} message is present in return replace page")
    public void userValidatesReplaceRefundSubtextOfMessageIsPresentInReturnReplacePage(String subtext, String returnReplaceOption) {
        String subtextOfReturnReplaceOptionInReturnReplacePage = getElement("subtextOfReturnReplaceOptionInReturnReplacePage", returnReplaceOption).getText();
        logger.info("Data from web: " + subtextOfReturnReplaceOptionInReturnReplacePage + "data from DB: " + subtext);
        assertStepExecution(true, subtextOfReturnReplaceOptionInReturnReplacePage.equalsIgnoreCase(subtext), "user validates return replace subtext is present in return replace page");

    }

    @And("user clicks on {string} radio button in return replace page")
    public void userClicksOnRadioButtonInReturnReplacePage(String returnReplaceOption) {
        assertStepExecution(true, getOptionalElement("selectReturnReplaceRadioButton", returnReplaceOption) != null,
                "user clicks on the " + returnReplaceOption + "option radio button in return replace page");
        getElement("selectReturnReplaceRadioButton", returnReplaceOption).click();
    }

    @And("user validates order cancelled date of recently placed order")
    public void userValidatesOrderCancelledDateOfRecentlyPlacedOrder() {
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        String stepDesc = "user validates order cancelled date with status of recently placed order";
        assertThat(getOptionalElement("orderHistoryCancelledDate", orderId, productName)).isNotNull().describedAs(stepDesc);
        logger.info("Cancelled date:" + getElement("orderHistoryCancelledDate", orderId, productName).getText());
        assertThat(getElement("orderHistoryCancelledDate", orderId, productName).getText()).contains("Cancelled on").describedAs(stepDesc);
        passStepExecution(stepDesc + " :: Passed \n");
    }

    @And("user validates refund status {string} is visible of recently placed order")
    public void userValidatesRefundStatusIsVisibleOfRecentlyPlacedOrder(String refundStatus) {
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        String stepDesc = "user validates refund status" + refundStatus + " is visible of recently placed order";
        logger.info("Cancelled order refund status:" + getElement("orderIdRefundStatus", orderId, productName).getText());
        assertStepExecution(true, getElement("orderIdRefundStatus", orderId, productName).getText().equalsIgnoreCase(refundStatus),
                stepDesc);
    }

    @And("user clicks on confirm checkbox in return replace page")
    public void userClicksOnConfirmCheckboxInReturnReplacePage() {
        assertStepExecution(true, getOptionalElement("clickOnConfirmCheckbox") != null,
                "user clicks on confirm checkbox in return replace page");
        getElement("clickOnConfirmCheckbox").click();
    }



    @Then("^user validates status \"([^\"]*)\" of recently placed order1$")
    public void userValidatesStatusOfRecentlyPlacedOrder1(String status) throws Throwable {
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String refundStatus = getElement("refundStatus", orderId, productName).getText();
        logger.info("The refund status for order number " + orderId + "and product Name " + productName + "is :" + refundStatus);
        assertThat(refundStatus).isEqualToIgnoringCase(status)
                .describedAs("refund status on order history page :  " + status);
    }

    @And("^user provides comments as \"([^\"]*)\" in order return replace page$")
    public void userProvidesCommentsAsInOrderReturnReplacePage(String reasonComment) {
        logger.info("Comment title is : " + getElement("commentTitle").getText());
        assertThat(getElement("commentTitle").getText()).doesNotContain("*").describedAs("Comment should not be mandatory");
        getElement("orderHistoryCommentField").sendKeys(randomAlphabeticString(301));
        assertThat(getElement("orderHistoryCommentField").getText().length()).isEqualTo(300);
        clearTextBox(getElement("orderHistoryCommentField"));
        getElement("orderHistoryCommentField").sendKeys(reasonComment);
        passStepExecution("user provides comments in return replace order page");
    }

    @And("user checks submit button is {string} in return replace page")
    public void userChecksSubmitButtonIsInReturnReplacePage(String enableOrDisableOption) {
        String strClass = getElement("buttonSubmit").getAttribute("class");
        logger.info("strClass = " + strClass);
        switch (enableOrDisableOption) {
            case "Enable":
                assertThat(strClass).contains("default").describedAs("Submit button is enable");
                break;
            case "Disable":
                assertThat(strClass).contains("disable").describedAs("Submit button is disable");
                break;
        }
        passStepExecution("user validates Submit button in return replace page:: Passed");

    }

    @And("user clicks on submit button in return replace page")
    public void userClicksOnSubmitButtonInReturnReplacePage() {
        assertStepExecution(true, getOptionalElement("buttonSubmit") != null,
                "user clicks on submit button in return replace page");
        getElement("buttonSubmit").click();
    }

    @And("user validates order replacement successful message {string}")
    public void userValidatesOrderReplacementSuccessfulMessage(String replaceSuccessfulMsg) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("replacementMessage", replaceSuccessfulMsg)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        logger.info("Return request message is: " + getElement("replacementMessage", replaceSuccessfulMsg).getText());
        assertStepExecution(replaceSuccessfulMsg, getElement("replacementMessage", replaceSuccessfulMsg).getText(), "user validates order replacement message");
    String getSRIDNo=getElement("getSRIDNo").getText();
    logger.info("SR Id number is: "+getSRIDNo);
    setContext("getSRIDNo",getSRIDNo);
    logger.info("Return request message is: "+getElement("returnRequestMsg").getText());
    }

    @And("user closes the return replace popup")
    public void userClosesTheReturnReplacePopup() {
        assertStepExecution(true, getOptionalElement("returnReplacePopupClose").isDisplayed(), "ser closes the return replace popup");
        getElement("returnReplacePopupClose").click();
    }

    @And("user validates refund status {string} is visible for the order id {string}, product name {string}")
    public void userValidatesRefundStatusIsVisibleForTheOrderIdProductName(String refundStatus, String orderId, String productName) {
        String stepDesc = "user validates refund status" + refundStatus + " is visible for the order id, product name";
        logger.info("Order refund status:" + getElement("orderRefundStatus", orderId, productName).getText());
        assertStepExecution(true, getElement("orderRefundStatus", orderId, productName).getText().equalsIgnoreCase(refundStatus),
                stepDesc);
    }


    @And("user checks add photo title is present in replace page")
    public void userChecksAddPhotoTitleIsPresentInReplacePage() {
        String addPhoto="ADD PHOTO";
        assertStepExecution(true, getElement("addPhotoTitle").getText().equals(addPhoto), "user checks add photo title is present in replace page");
    }

    @And("user checks upload photo message {string} is present in replace page")
    public void userChecksUploadPhotoMessageIsPresentInReplacePage(String uploadPhotoMsg) {
        assertStepExecution(true, getElement("uploadPhotoMsg").getText().equals(uploadPhotoMsg), "user checks add photo title is present in replace page");
    }

    @And("user upload the photo of the item {string} with visible defects and details")
    public void userUploadThePhotoOfTheItemWithVisibleDefectsAndDetails(String photoName) throws AWTException {
        WebElement button=getElement("clickOnUpload");
        JavascriptExecutor js=(JavascriptExecutor)getDriver();
        js.executeScript("arguments[0].click();",button);
        String filePath = "";
        File fileObj = new File(getConfig(photoName));
        filePath = fileObj.getAbsolutePath();
        logger.info(filePath);
        assertStepExecution(true,filePath.length()>0,"user uploads customer ID proof for customer pick up");

        Robot rb= new Robot();
        rb.delay(2000);
        StringSelection ss=new StringSelection(filePath);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss,null);

        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_V);
        rb.delay(2000);
        rb.keyRelease(KeyEvent.VK_CONTROL);
        rb.keyRelease(KeyEvent.VK_V);
        rb.delay(2000);
        rb.keyPress(KeyEvent.VK_ENTER);
        rb.keyRelease(KeyEvent.VK_ENTER);
    }

    @And("user validates image upload error message {string} in order return replace page")
    public void userValidatesImageUploadErrorMessageInOrderReturnReplacePage(String photoUploadErrorMsg) {
        logger.info("Displayed toast message is : " + getElement("photoUploadErrorMessage").getText());
        logger.info("Argument message is : " + photoUploadErrorMsg);
        assertThat(photoUploadErrorMsg).describedAs("user validates image upload error message in order return replace page").isEqualTo(getElement("photoUploadErrorMessage").getText());
    }

    @And("user closes the order replacement success popup")
    public void userClosesTheOrderReplacementSuccessPopup() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("clickOnCloseButtonInOrderReplacementPopup").isDisplayed(), "ser closes the return replace popup");
        getElement("clickOnCloseButtonInOrderReplacementPopup").click();
        Thread.sleep(10000);
    }

    @And("user validates service request number is present in my service requests page")
    public void userValidatesServiceRequestNumberIsPresentInMyServiceRequestsPage() throws InterruptedException {
        Thread.sleep(3000);
        String srId = getContext("getSRIDNo");
        logger.info("SR id is in service request page : " + getElement("srIdNum").getText() + " " + "SR id from order history page: " + srId);
    }

    @Then("user validates order details are present in my orders page")
    public void userValidatesOrderDetailsArePresentInMyOrdersPage() {
            logger.info("Page heading is: " + getElement("orderPageHeading").getText());
            logger.info("Order details are : "+ "\n" + getElement("orderIdOrderPage").getText() + "\n" + getElement("ProductNameOrderPage").getText() + "\n" + getElement("ProductIdOrderPage").getText() + "\n" + "Price :" + getElement("ProductPriceOrderPage").getText() + "\n" + "QTY :" + getElement("ProductQtyOrderPage").getText() + "\n" + "Arriving date is :" + getElement("arrivingDateOrderPage").getText()+ "Purchased date is :" + getElement("purchasedDateOrderPage").getText());
            assertThat(getElement("orderIdOrderPage").getText()).describedAs("Product id on order page").isNotEmpty();
            assertThat(getElement("ProductNameOrderPage").getText()).describedAs("Product name on order page").isNotEmpty();
            assertThat(getElement("ProductIdOrderPage").getText()).describedAs("Product Id on order page").isNotEmpty();
            assertThat(getElement("ProductPriceOrderPage").getText()).describedAs("Product price on order page").isNotEmpty();
            assertThat(getElement("ProductQtyOrderPage").getText()).describedAs("Product qty on order page").isNotEmpty();
           // assertThat(getElement("arrivingDateOrderPage").getText()).describedAs("Arriving date on order page").isNotEmpty();
           assertThat(getElement("purchasedDateOrderPage").getText()).describedAs("Arriving date on order page").isNotEmpty();

            passStepExecution("User validates order history details");
        }


    @And("user validates order id history details")
    public void userValidatesOrderIdHistoryDetails() {

    }

    @And("user clicks on the track order button of recently placed order")
    public void userClicksOnTheTrackOrderButtonOfRecentlyPlacedOrder() {
        String orderId = getContext("orderId");
        String productName = getContext("productName");
        assertStepExecution(true,getElement("trackOrderButtonForRecentOrderId",orderId,productName)!=null,"track order button is presnt for recent order");
        getElement("trackOrderButtonForRecentOrderId",orderId,productName).click();
    }

    @Then("user validates latest order details is present in my orders page")
    public void userValidatesLatestOrderDetailsIsPresentInMyOrdersPage() throws InterruptedException, ParseException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(4000);
        List<WebElement> orderIdProductCount = getElements("purchasedDateOrderPage");
        int sizeOfOrderIdProductList = orderIdProductCount.size();
        assertThat(sizeOfOrderIdProductList).isGreaterThan(0)
                .describedAs("Order ID should be present in order history page");
        logger.info("latest product purchased date"+getElement("purchasedDateOrderPageFirst").getText().split("Purchased on ")[1]);
        logger.info("second product purchased date"+getElement("purchasedDateOrderPageSecond").getText().split("Purchased on ")[1]);
        String date1string=getElement("purchasedDateOrderPageFirst").getText().split("Purchased on ")[1];
        String date2string=getElement("purchasedDateOrderPageSecond").getText().split("Purchased on ")[1];
        Date date1 = new SimpleDateFormat("dd MMM yyyy").parse(date1string);
        Date date2 = new SimpleDateFormat("dd MMM yyyy").parse(date2string);
        assertThat(date1).isAfterOrEqualTo(date2);
    }
}
