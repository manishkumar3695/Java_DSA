package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementClick;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.*;

/*
    All the store locator related function defined in CromaStoreLocatorPageStepDef class
*/
public class CromaStoreLocatorPageStepDef {


    /*
        User provides store location and find store
    */
    @And("^user provides \"([^\"]*)\" and finds store$")
    public void userProvidesAndFindsStore(String store) throws InterruptedException {
        String stepDescription = "user provides " + store + " and finds store";
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        logger.info("Store Location is: " + store);
        Thread.sleep(2000);
        getElement("enterStoreLocatorDetailsTextBox").sendKeys(store);
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("selectStoreLocator") != null,
                stepDescription);
        actionMoveToElementClick(getElement("selectStoreLocator"));
    }


    /*
        User validate store location should displayed
    */
    @Then("^user validates \"([^\"]*)\" should displayed$")
    public void userValidatesShouldDisplayed(String storeAddress) throws InterruptedException {
        Thread.sleep(5000);
        logger.info("Store Location address is: " + getElement("storeAddress", storeAddress).getText());
        conditionalWait(ExpectedConditions.visibilityOf(getElement("storeAddress", storeAddress)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getElement("storeAddress", storeAddress).getText().contains(storeAddress),
                "Address is present in store locator");
    }

    @And("^user selects the \"([^\"]*)\" as his or her preferred store$")
    public void userSelectsTheAsHisOrHerPreferredStore(String storeAddress) throws InterruptedException {

        Thread.sleep(5000);
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("storeAddress", storeAddress)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        String preferredStoreSelectMsg = "Preferred store has been set successfully!";
        getElement("storeAddress", storeAddress).click();

        Thread.sleep(10000);
        //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("storeNameInModal",storeAddress)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        String storeHeading = getElement("storeNameInModal", storeAddress).getText();
        setContext("storeHeading", storeHeading);

        // conditionalWait(ExpectedConditions.visibilityOf(getElement("storeNameInModal",storeAddress)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        Thread.sleep(5000);
        getElement("selectStoreBtnOnModal", storeAddress).click();

        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("preferredStoreBtn")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        Thread.sleep(5000);
        getElement("preferredStoreBtn").click();

        // No message is coming as per current functionality , hence commented
        //String appearedMSG = getElement("preferredStoreSelectedMSG").getText();

        assertStepExecution(true, true, "Preferred store has been set successfully!- Message appears");


    }
}