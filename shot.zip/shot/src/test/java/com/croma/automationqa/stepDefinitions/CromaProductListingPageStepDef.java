package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.encodingProductListThroughWebElementList;
import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.verifyProductAvailability;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.*;
import static org.assertj.core.api.Assertions.assertThat;

//import static com.croma.automationqa.util.CommonUtil.windowScrollIntoViewByWebElement;


/*
     All the product listing page related function defined in CromaProductListingPageStepDef class
*/
public class CromaProductListingPageStepDef {


    private final int pLPPageScrollDownFirstIndex = 0, pLPPageScrollDownLastIndex = 500, plpSearchResultFirstIndex = 1;

    JavascriptExecutor js = (JavascriptExecutor) getDriver();


    /*
       User lands on product listing page and selects product
    */
    @Then("^user lands on product listing page and selects \"([^\"]*)\" product$")
    public void userLandsOnProductListingPageAndSelectsProduct(String plpProduct1) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product", plpProduct1)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
            logger.info("The selected product name on PLP is: " + plpProduct1);
            // js.executeScript("window.scrollBy(0,1000)");
            // windowScrollIntoViewByWebElement(getElement("plp_product1",plpProduct1));
            getElement("plp_Product", plpProduct1).click();
        }
    }


    /*
        User select product in product listing page
    */
    @And("^user selects \"([^\"]*)\" product in product listing page$")
    public void userSelectsProductInProductListingPage(String itemIndex) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            windowScrollIntoViewByWebElement(getElement("plp_Product_Index", itemIndex));
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);

            //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product_Index", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            logger.info("The product name on PLP is: " + getElement("plp_Product_Index", itemIndex).getText() + "Index " + itemIndex);
            getElement("plp_Product_Index", itemIndex).click();
        }
    }


    /*
        User selects filter by option
    */
    @And("^user selects filter by option \"([^\"]*)\"$")
    public void userSelectsFilterByOption(String categoryOption) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getElement("categoryCheckBox", categoryOption).click();
        Thread.sleep(2000);
        windowScrollIntoViewByWebElement(getElement("getAvailableProductDetails"));
        windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
        String availableProductDetails = getElement("getAvailableProductDetails").getText();
        logger.info("Number of product available are: " + numericValuesExtractionMethod(availableProductDetails));

        assertStepExecution(true, (numericValuesExtractionMethod(availableProductDetails) > pLPPageScrollDownFirstIndex),
                "No products available in PLP");
    }


    /*
       User selects category
    */
    @And("^user selects category \"([^\"]*)\"$")
    public void userSelectsCategory(String categoryFilter) {


        logger.info("Category name is: " + categoryFilter);
        windowScrollIntoViewByWebElement(getElement("filterByCatagory", categoryFilter));
        windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("filterByCatagory", categoryFilter)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));

        getElement("filterByCatagory", categoryFilter).click();
    }


    /*
    User lands on product listing page and select category sort by filter
*/
    @And("^user lands on product listing page and selects \"([^\"]*)\" sort by filter$")
    public void userLandsOnProductListingPageAndSelectsSortByFilter(String sortByFilter) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getElement("productOptionName").click();
        logger.info("Selected product is: " + getElement("productOptionName").getText());
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("sortByInPLP")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        getElement("sortByInPLP").click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("sortByHighestInPLP", sortByFilter)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("sortByHighestInPLP", sortByFilter).click();
        String availableProductDetails = getElement("getAvailableProductDetails").getText();
        logger.info("Number of product available are: " + numericValuesExtractionMethod(availableProductDetails));
        assertStepExecution(true, ((numericValuesExtractionMethod(availableProductDetails)) > (pLPPageScrollDownFirstIndex)),
                "No products available in PLP");
    }

    /*
       user scrolls down and validates view more option in the page and clicks on it
    */
    @Then("^user scrolls down and validates view more option in the page and clicks on it$")
    public void userScrollsDownAndValidatesViewMoreOptionInThePageAndClicksOnIt() {
        String viewmore = "view all";
        ((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(0,document.body.scrollHeight-100)");
        windowScrollIntoViewByWebElement(getElement("getViewMore"));
        windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);

        logger.info(getElement("getViewMore").getText());
        assertStepExecution(viewmore.toLowerCase(), getElement("getViewMore").getText().toLowerCase(),
                "View more option not coming in PLP");

        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("getViewMore")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("getViewMore").click();
        windowScrollIntoViewByWebElement(getElement("getAvailableProductDetails"));
        windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);

    }


    /*
         User lands on listing and scroll down and select check box of product to compare the products
    */
    @And("^user lands on listing and scrolls down and selects check box of \"([^\"]*)\" product to compare the products$")
    public void UserLandsOnListingAndScrollsDownAndSelectsCheckBoxOfProductToCompareTheProducts(String compareProduct1) throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product", compareProduct1)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        //windowScrollIntoViewByWebElement(getElement("plp_Product", compareProduct1));
        //windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
        js.executeScript("arguments[0].scrollIntoView();", getElement("plp_Product", compareProduct1));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product", compareProduct1)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        logger.info("The compare product name on PLP is:" + getElement("plp_Product", compareProduct1).getText() + " Tag name : " + getElement("clickOnAddToCompareLinkOnPLP", compareProduct1).getAttribute("class"));
        assertStepExecution(true, getOptionalElement("clickOnAddToCompareLinkOnPLP", compareProduct1).isDisplayed(), "Compare checkbox is not present for the product");
        getElement("clickOnAddToCompareLinkOnPLP", compareProduct1).click();
        Thread.sleep(5000);
    }


    /*
          User clicks compare button from popup
    */
    @And("^user clicks compare button from popup$")
    public void userClicksCompareButtonFromPopup() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnCompareButton")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));

        getElement("clickOnCompareButton").click();
    }


    /*
     User lands on product listing page and validate product available in page
 */
    @And("^user lands on product listing page and validates product \"([^\"]*)\" available in page$")
    public void userLandsOnProductListingPageAndValidatesProductAvailableInPage(String plpAvailableProduct) throws InterruptedException {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product", plpAvailableProduct)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        logger.info("The product name on PLP from DB is: " + plpAvailableProduct + " The product name on PLP is: " + getElement("plp_Product", plpAvailableProduct).getText());

        assertStepExecution(plpAvailableProduct.toLowerCase(), getElement("plp_Product", plpAvailableProduct).getText().toLowerCase(),
                "Product name is not available in PLP");
        Thread.sleep(8000);
    }


    /*
        User lands on product listing page and validate the searched keyword
    */
    @And("^user lands on product listing page and validates the searched keyword \"([^\"]*)\"$")
    public void userLandsOnProductListingPageAndValidatesTheSearchedKeyword(String misspelledSearchKeyword) throws InterruptedException {
        Thread.sleep(8000);
        logger.info("Message on PLP MisspelledSearchKeyword is: " + getElement("getMisspelledSearchKeyword").getText());

        assertThat(getElement("getMisspelledSearchKeyword").getText()).describedAs("Product name (misspelled) is not available in PLP").contains(misspelledSearchKeyword);
        String availableProductDetails = getElement("getAvailableProductDetails").getText();

        logger.info("Number of product available are: " + numericValuesExtractionMethod(availableProductDetails));
        Thread.sleep(5000);
        assertThat((numericValuesExtractionMethod(availableProductDetails))).describedAs("Available product is not greater").isGreaterThan(pLPPageScrollDownFirstIndex);
        passStepExecution("User lands on product listing page and validate the searched keyword");
    }


    /*
      User lands on product listing page and validate no product found
    */
    @And("^user lands on product listing page and validates no product \"([^\"]*)\" found$")
    public void userLandsOnProductListingPageAndValidatesNoProductFound(String plpNotAvailable) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        Thread.sleep(3000);
        logger.info("Message on PLP is: " + getElement("noProductFound").getText());

        assertStepExecution(plpNotAvailable, getElement("noProductFound").getText(),
                "user lands on product listing page and validates no product found");
    }

    /*
        user lands on product listing page and validates number of product showing
    */
    @And("^user lands on product listing page and validates number of product showing is \"([^\"]*)\"$")
    public void userLandsOnProductListingPageAndValidatesNumberOfProductShowingIs(String noOfProduct) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        int noOfProductShowingInPLP = getElements("noProductFound").size();
        logger.info("Number of products showing in PLP : " + noOfProductShowingInPLP);
        assertStepExecution(noOfProductShowingInPLP, Integer.parseInt(noOfProduct),
                "Number of products showing in PLP should be equal to " + noOfProduct);
    }

    /*
        User lands on product listing page and selects buy now of the product and lands on the cart page
    */
    @And("^user lands on product listing page and selects buy now of the product \"([^\"]*)\" and lands on the cart page$")
    public void userLandsOnProductListingPageAndSelectsBuyNowOfTheProductAndLandsOnTheCartPage(String plpProduct1) {
        String flag = "false";
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnPlpProductBuyNowButton", plpProduct1)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        logger.info("The product name on PLP from DB is: " + plpProduct1 + " The product name on PLP is: " + getElement("plp_Product", plpProduct1).getText());
        logger.info("The product name on PLP is: " + plpProduct1);

        getElement("clickOnPlpProductBuyNowButton", plpProduct1).click();
        setContext("coupon_applied_flag_cart", flag);
        setContext("gift_item_applied_flag_cart", flag);
        setContext("donation_applied_flag_cart", flag);
    }


    /*
       User clicks on Add to cart button of PLP product
    */
    @And("^user clicks add to cart from product listing page for \"([^\"]*)\" product$")
    public void userClicksAddToCartFromProductListingPageForProduct(String itemIndex) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            logger.info("The product name on PLP is: " + getElement("plp_Product_Index", itemIndex).getText() + "Index " + itemIndex);

            windowScrollIntoViewByWebElement(getElement("plp_Product_Index", itemIndex));
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);

            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product_Index", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            getElement("plp_IndexProductAddToCartButton", itemIndex).click();
        }
    }


    /*
        User clicks on connect to store option from product listing page
    */
    @And("^user clicks on connect to store option from product listing page for product index \"([^\"]*)\"$")
    public void userClicksOnConnectToStoreOptionFromProductListingPageForProductIndex(String productIndex) throws InterruptedException {
        //   conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnConnectToStoreButtonFromPLP")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        Thread.sleep(2000);
        logger.info("Page url is: " + getDriver().getCurrentUrl());
        String url = getDriver().getCurrentUrl();
        setContext("url_Currentpage", url);
        getElement("clickOnConnectToStoreButtonFromPLP", productIndex).click();
    }

    /*
        User notes down the displayed product count and compares with earlier product count
    */
    @And("^user notes down the product count on product listing page and validates product count as \"([^\"]*)\"$")
    public void userNotesDownTheProductCountOnProductListingPageAndValidatesProductCountAs(String plp_product_count_validation) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        switch (plp_product_count_validation) {
            case "NA":
                logger.info("Total product count value NA case: " + getElement("plpProductCount").getText());
                setContext("plp_Product_Count", String.valueOf(numericValuesExtractionMethod(getElement("plpProductCount").getText())));
                break;

            case "Decrement":
                logger.info("Decrement count value:: " + Integer.parseInt(getContext("plp_Product_Count")) +
                        "   " + getElement("plpProductCount").getText());
                assertThat(Integer.parseInt(getContext("plp_Product_Count"))).describedAs
                        ("Count Decrement case the product count > Displayed product count").isGreaterThan
                        (numericValuesExtractionMethod(getElement("plpProductCount").getText()));
                setContext("plp_Product_Count", String.valueOf(numericValuesExtractionMethod(getElement("plpProductCount").getText())));
                break;

            case "Increment":
                logger.info("Increment count value:: " + Integer.parseInt(getContext("plp_Product_Count")) +
                        "   " + getElement("plpProductCount").getText());
                assertThat(numericValuesExtractionMethod(getElement("plpProductCount").getText())).describedAs
                        ("Count Increment case the product count < Displayed product count").isGreaterThan
                        (Integer.parseInt(getContext("plp_Product_Count")));
                setContext("plp_Product_Count", String.valueOf(numericValuesExtractionMethod(getElement("plpProductCount").getText())));
                break;

            case "Validate":
                logger.info("Value to be validated: " + numericValuesExtractionMethod(getElement("plpProductCount").getText()) +
                        "   " + getElement("plpProductCount").getText());
                assertThat(numericValuesExtractionMethod(getElement("plpProductCount").getText())).describedAs
                        ("Count Validate case the product count equals Displayed product count").isEqualTo
                        (Integer.parseInt(getContext("plp_Product_Count")));
                break;
        }
        passStepExecution("User notes down the displayed product count and compares with earlier product count");
    }


    /*
        User clicks on the Filter tab option to get the subsequent filter options
    */
    @And("^user selects the filter option tab \"([^\"]*)\" on product listing page$")
    public void userSelectsTheFilterOptionTabOnProductListingPage(String selected_filter_option) {
        logger.info("Value of selected_filter_option is: " + selected_filter_option);
        windowScrollIntoViewByWebElement(getElement("selectedFilterOptionTab", selected_filter_option));
        windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("selectedFilterOptionTab", selected_filter_option)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));

        if (getOptionalElement("expandArrow", selected_filter_option) != null) {
            getElement("selectedFilterOptionTab", selected_filter_option).click();
        }


    }


    /*
    User validates one of the product name which contains given keyword
*/
    @And("^user validates the one of the list product name\"([^\"]*)\" containing \"([^\"]*)\" on product listing page$")
    public void userValidatesTheOneOfTheListProductNameContainingOnProductListingPage(String itemIndex, String category_option_filter) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        logger.info("The product name on PLP is: " + getElement("plp_Product_Index", itemIndex).getText() + "   Index " + itemIndex + "   Selected filter is: " + category_option_filter);
        assertStepExecution(true, getElement("plp_Product_Index", itemIndex).getText().toLowerCase().contains(category_option_filter.toLowerCase()),
                "Product contains selected filter name");
    }


    /*
        User removes the filter
    */
    @And("^user removes filter \"([^\"]*)\" from product listing page using \"([^\"]*)\" option$")
    public void userRemovesFilterFromProductListingPageUsingOption(String category_option_filter, String plp_filter_remove_option) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        switch (plp_filter_remove_option) {
            case "Untick checkbox":

                getElement("categoryCheckBox", category_option_filter).click();
                break;
            case "Close Button":
                windowScrollToTop();
                getElement("plpRemoveFilterByCloseButtonClick").click();
                break;
        }
    }


    /*
        User compares the product values on plp and the range
    */
    @Then("^user validates product \"([^\"]*)\" range as \"([^\"]*)\" of filtered product list and compares the values of \"([^\"]*)\" and \"([^\"]*)\" products$")
    public void userValidatesProductRangeAsOfFilteredProductListAndComparesTheValuesOfAndProducts(String sort_validation_option, String category_option_filter, String plp_item_index_1, String plp_item_index_2) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));

        String splitOption, splitOptionOne, amount;
        logger.info("inside amount / discountvalidation method");
        int indexValueTwo = 2;
        switch (sort_validation_option) {
            case "discount":
                //Compare the discount range
                splitOption = "\\s+";
                splitOptionOne = "%";
               /* assertStepExecution(true, numericValuesExtractionMethod(getElement("plp_IndexProductDiscountValue", plp_item_index_1).getText())
                                > Integer.parseInt(splitTextWithIndexing(category_option_filter, splitOptionOne, pLPPageScrollDownFirstIndex)),
                        "Discount descending sorting, discount of 1st product > discount lower limit");*/

                assertThat(numericValuesExtractionMethod(getElement("plp_IndexProductDiscountValue", plp_item_index_1).getText())).describedAs
                        ("Discount descending sorting, discount of 1st product > discount lower limit").isGreaterThan
                        (Integer.parseInt(splitTextWithIndexing(category_option_filter, splitOptionOne, pLPPageScrollDownFirstIndex)));


                amount = splitTextWithIndexing(category_option_filter, splitOption, indexValueTwo);
                amount = splitTextWithIndexing(amount, splitOptionOne, pLPPageScrollDownFirstIndex);
                assertThat(Integer.parseInt(amount)).describedAs
                        ("Discount descending sorting, discount upper limit >= discount of 1st product").isGreaterThanOrEqualTo
                        (numericValuesExtractionMethod(getElement("plp_IndexProductDiscountValue", plp_item_index_1).
                                getText()));
                //Compare discounts of different products post Descending Discount operation
                windowScrollIntoViewByWebElement(getElement("plp_IndexProductAmountValue", plp_item_index_2));
                assertThat(numericValuesExtractionMethod(getElement("plp_IndexProductDiscountValue", plp_item_index_1).
                        getText())).describedAs
                        ("Discount descending sorting, discount of 1st product > subsequent product").isGreaterThan
                        (numericValuesExtractionMethod(getElement("plp_IndexProductDiscountValue", plp_item_index_2).
                                getText()));
                break;

            case "amount":
                int minValue = 0, maxValue = 0;
                splitOptionOne = "-";
                if (!(splitTextWithIndexing(category_option_filter, splitOptionOne, pLPPageScrollDownFirstIndex).equals("NA"))) {
                    minValue = numericValuesExtractionMethod(splitTextWithIndexing(category_option_filter, splitOptionOne, pLPPageScrollDownFirstIndex));
                    logger.info("printing values: min val, and displayed value: " + minValue + " " + numericValuesExtractionMethod(getElement("plp_IndexProductAmountValue", plp_item_index_2).
                            getText()));
                    assertThat(numericValuesExtractionMethod(getElement("plp_IndexProductAmountValue", plp_item_index_2).
                            getText())).describedAs
                            ("Amount comparison for lowest value").isGreaterThanOrEqualTo
                            (minValue);
                }

                if (!(splitTextWithIndexing(category_option_filter, splitOptionOne, plpSearchResultFirstIndex).equals("NA"))) {
                    maxValue = numericValuesExtractionMethod(splitTextWithIndexing(category_option_filter, splitOptionOne, plpSearchResultFirstIndex));
                    logger.info("printing values: max val, and displayed value: " + maxValue + " " + numericValuesExtractionMethod(getElement("plp_IndexProductAmountValue", plp_item_index_2).
                            getText()));
                    assertThat(maxValue).describedAs("Amount comparison for highest value").isGreaterThanOrEqualTo
                            (numericValuesExtractionMethod(getElement("plp_IndexProductAmountValue", plp_item_index_2).
                                    getText()));
                }
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + sort_validation_option);
        }
        passStepExecution("User compares the product values on plp and the range");
    }


    /*
        User clicks add to wishlist from product listing page
    */
    @And("^user clicks add to wishlist \"([^\"]*)\" from product listing page$")
    public void userClicksAddToWishlistFromProductListingPage(String itemIndex) {

        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plpWishListIndex", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        logger.info("Index " + itemIndex);
        getElement("plpWishListIndex", itemIndex).click();
    }


    /*
        user moves to new window from product listing page
    */
    @And("^user moves to new window from product listing page$")
    public void userMovesToNewWindowFromProductListingPage() throws InterruptedException {
        //  if (getContext("product_available").equalsIgnoreCase("true")) {
        //  logger.info("After clicking on product in PLP page" + "Current window title is: " + getDriver().getTitle());
//            Set<String> ids = getDriver().getWindowHandles();
//            Iterator<String> it = ids.iterator();
//            String parentid = it.next();
//            String childid = it.next();
//            getDriver().switchTo().window(childid);
//        Thread.sleep(5000);
        userMovesToNewWindow();
        logger.info("New window title is: " + getDriver().getTitle());
    }
    //}


    /*
    User validates the sort option displayed
*/
    @And("^user validates the sort option displayed \"([^\"]*)\"$")
    public void userValidatesTheSortOptionDisplayed(String displayedSortOption) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")));
        logger.info(getElement("sortByInPLP").getText());
        assertStepExecution(displayedSortOption.toLowerCase(), getElement("sortByInPLP").getText().toLowerCase(),
                "Product contains selected filter name not correct");
    }


    /*
        user validates the list item name for the keyword
    */
    @And("^user validates the list item name for the keyword$")
    public void userValidatesTheListItemNameForTheKeyword() throws IOException {
        int plpSearchResultSecondtIndex = 13, plpSearchViewMoreItem = 20;
        logger.info("before keyword print");
        String keywordToCheck, searchMismatch = "Searched keyword not found in";
        if ((getDriver().findElements(By.xpath(getLocator("didUMeanKeyword")))).size() > pLPPageScrollDownFirstIndex) {
            keywordToCheck = getDriver().findElement(By.xpath(getLocator("didUMeanKeyword"))).getText();
            keywordToCheck = subStringTextWithIndexing(keywordToCheck, pLPPageScrollDownFirstIndex, keywordToCheck.length() - plpSearchResultFirstIndex);
        } else {
            keywordToCheck = getDriver().findElement(By.xpath(getLocator("searchResultFor"))).getText();
            keywordToCheck = subStringTextWithIndexing(keywordToCheck, plpSearchResultSecondtIndex, keywordToCheck.length() - plpSearchResultFirstIndex);
        }
        logger.info("keywordToCheck keyword is: " + keywordToCheck);

        for (int i = pLPPageScrollDownFirstIndex; i <=
                (((Integer.parseInt(getContext("plp_Product_Count")) / plpSearchViewMoreItem)) - plpSearchResultFirstIndex); i++) {
            logger.info("i value in for loop is: " + i);
            if ((getDriver().findElements(By.xpath(getLocator("viewMoreDisplayed")))).size() > pLPPageScrollDownFirstIndex)
                userScrollsDownAndValidatesViewMoreOptionInThePageAndClicksOnIt();
            else {
                logger.info("in else part of checking view more: " + i);
                break;
            }
        }
        List<WebElement> searchResultItemList = getElements("searchPageItemList");
        logger.info("Some of the elements in list: " + searchResultItemList.get(3).getText());
        Date objDate = new Date();
        long timeMilli = objDate.getTime();
        logger.info("Date to be used: " + objDate.toString().replaceAll("\\s", "") + " file name: " +
                getConfig("Search_Text_File_Path") + "_" + keywordToCheck.
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");
        File file = new File(getConfig("Search_Text_File_Path") + "_" + keywordToCheck.
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");
        FileWriter fW = new FileWriter(file.getAbsoluteFile(), true);
        BufferedWriter bW = new BufferedWriter(fW);
        if (file.createNewFile()) {
            logger.info("File created: " + file.getName());
        } else {
            logger.info("File already exists " + file.getName());
        }
        String searchProductNameMismatch = "";
        if (keywordToCheck.contains(" ")) {
            String[] keywordArray = keywordToCheck.split(" ");
            for (WebElement searchProductName : searchResultItemList) {
                for (int i = pLPPageScrollDownFirstIndex; i <=
                        ((keywordArray.length) - plpSearchResultFirstIndex); i++) {
                    logger.info("keyword chk is : " + keywordArray[i]);
                    if (((searchProductName.getText()).toLowerCase()).contains(keywordArray[i].toLowerCase())) {
                        searchProductNameMismatch = "";
                        break;
                    } else {
                        searchProductNameMismatch = ("Search mismatch for the index: " + searchResultItemList.indexOf(searchProductName) + " for product: " + searchProductName.getText());
                    }
                }
                if (!(searchProductNameMismatch.isEmpty())) {
                    logger.info("product name Value in for loop if it does not contain keyword is : "
                            + searchProductName.getText());
                    bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" + searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
                }
            }
        } else {
            for (WebElement searchProductName : searchResultItemList) {
                if (!(((searchProductName.getText()).toLowerCase()).contains(keywordToCheck.toLowerCase()))) {
                    logger.info("product name Value in for loop if it does not contain keyword is : "
                            + searchProductName.getText());
                    bW.write("Searched Keyword: " + keywordToCheck + "  Search list mismatch product Name:" + searchProductName.getText() + "\n" + searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
                }
            }
        }
        bW.close();
    }


    /*
         user validates the list item name for the keyword
    */
    @And("^user validates the list item name for the keyword for \"([^\"]*)\"$")
    public void userValidatesTheListItemNameForTheKeywordFor(String searchValOption) throws IOException {
        int plpSearchResultSecondtIndex = 13, plpSearchViewMoreItem = 20;
        logger.info("before keyword print");
        String keywordToCheck, searchMismatch = "Searched keyword not found in";
        // Extracting keyword. If keyword is present, take it from results text else take it from Did you mean text
        if ((getDriver().findElements(By.xpath(getLocator("didUMeanKeyword")))).size() > pLPPageScrollDownFirstIndex) {
            keywordToCheck = getDriver().findElement(By.xpath(getLocator("didUMeanKeyword"))).getText();
            keywordToCheck = subStringTextWithIndexing(keywordToCheck, pLPPageScrollDownFirstIndex, keywordToCheck.length() - plpSearchResultFirstIndex);
        } else {
            keywordToCheck = getDriver().findElement(By.xpath(getLocator("searchResultFor"))).getText();
            keywordToCheck = subStringTextWithIndexing(keywordToCheck, plpSearchResultSecondtIndex, keywordToCheck.length() - plpSearchResultFirstIndex);
        }
        logger.info("keywordToCheck keyword is: " + keywordToCheck);
        // Clicking on View more if search needs to be done for all the pages
        for (int i = pLPPageScrollDownFirstIndex; i <=
                (((Integer.parseInt(getContext("plp_Product_Count")) / plpSearchViewMoreItem)) - plpSearchResultFirstIndex); i++) {
            logger.info("i value in for loop is: " + i);
            if ((getDriver().findElements(By.xpath(getLocator("viewMoreDisplayed")))).size() > pLPPageScrollDownFirstIndex)
                userScrollsDownAndValidatesViewMoreOptionInThePageAndClicksOnIt();
            else {
                logger.info("in else part of checking view more: " + i);
                break;
            }
        }
        // Taking all the searched displayed result products in the list
        List<WebElement> searchResultItemList = getElements("searchPageItemList");
        logger.info("Some of the elements in list: " + searchResultItemList.get(3).getText());
        // File write code
        Date objDate = new Date();
        long timeMilli = objDate.getTime();
        logger.info("Date to be used: " + objDate.toString().replaceAll("\\s", "") + " file name: " +
                getConfig("Search_Text_File_Path") + "_" + keywordToCheck.
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");
        File file = new File(getConfig("Search_Text_File_Path") + "_" + keywordToCheck.
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");
        FileWriter fW = new FileWriter(file.getAbsoluteFile(), true);
        BufferedWriter bW = new BufferedWriter(fW);
        if (file.createNewFile()) {
            logger.info("File created: " + file.getName());
        } else {
            logger.info("File already exists " + file.getName());
        }
        //splitting the keyword if multiple keywords are present
        String searchProductNameMismatch = "";
        if (keywordToCheck.contains(" ")) {
            String[] keywordArray = keywordToCheck.split(" ");
            logger.info("printing sitch value: " + searchValOption);
            switch (searchValOption) {
                case "randomMatch":
                    logger.info("inside randomMatch case");
                    for (WebElement searchProductName : searchResultItemList) {
                        for (int i = pLPPageScrollDownFirstIndex; i <=
                                ((keywordArray.length) - plpSearchResultFirstIndex); i++) {
                            logger.info("keyword chk is : " + keywordArray[i]);
                            if (((searchProductName.getText()).toLowerCase()).contains(keywordArray[i].toLowerCase())) {
                                searchProductNameMismatch = "";
                                break;
                            } else {
                                searchProductNameMismatch = ("Search mismatch for the index: " + searchResultItemList.indexOf(searchProductName) + " for product: " + searchProductName.getText());
                            }
                        }
                        if (!(searchProductNameMismatch.isEmpty())) {
                            logger.info("product name Value in for loop if it does not contain keyword is : "
                                    + searchProductName.getText());
                            bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" + searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
                        }
                    }
                    break;

                case "exactMatch":
                    String[] fileArray = keywordArray;
                    for (WebElement searchProductName : searchResultItemList) {
                        logger.info("inside exactMatch case");
                        for (int i = pLPPageScrollDownFirstIndex; i <= ((keywordArray.length) - plpSearchResultFirstIndex); i++) {
                            logger.info("keyword chk is : " + keywordArray[i]);
                            if (((searchProductName.getText()).toLowerCase()).contains(keywordArray[i].toLowerCase())) {
                                fileArray[i] = "";
                            } else {
                                searchProductNameMismatch = ("Search mismatch for the index: " + searchResultItemList.indexOf(searchProductName) +
                                        " and sub keyword: " + "\"" + fileArray[i] + "\"" + " for product: " + searchProductName.getText());
                                bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" +
                                        searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
                            }
                        }
                    }
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + searchValOption);
            }
        } else {
            for (WebElement searchProductName : searchResultItemList) {
                if (!(((searchProductName.getText()).toLowerCase()).contains(keywordToCheck.toLowerCase()))) {
                    logger.info("product name Value in for loop if it does not contain keyword is : "
                            + searchProductName.getText());
                    bW.write("Searched Keyword: " + keywordToCheck + "  Search list mismatch product Name:" + searchProductName.getText() + "\n" + searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
                }
            }
        }
        bW.close();
    }


    /*
        user validates the list item name for the keyword and amount range
    */
    @And("^user validates the list item name for the keyword with \"([^\"]*)\" and amount range \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userValidatesTheListItemNameForTheKeywordWithAndAmountRangeAnd(String keywordToCheck, String minValueArgument, String maxValueArgument) throws IOException {
        int plpSearchViewMoreItem = 20, indexOfListElement = 0, productDisplayedPrice = 0;
        String searchMismatch = "Searched keyword not found in", splitOptionKeyword = " ", splitOptionSynonym = "/";
        // Clicking on View more if search needs to be done for all the pages
        if (Integer.parseInt(getContext("plp_Product_Count")) > plpSearchViewMoreItem) {
            logger.info("inside if of items > 20");
            for (int i = pLPPageScrollDownFirstIndex; i <=
                    (((Integer.parseInt(getContext("plp_Product_Count")) / plpSearchViewMoreItem)) - plpSearchResultFirstIndex); i++) {
                if ((getDriver().findElements(By.xpath(getLocator("viewMoreDisplayed")))).size() > pLPPageScrollDownFirstIndex)
                    userScrollsDownAndValidatesViewMoreOptionInThePageAndClicksOnIt();
                else {
                    logger.info("in else part of checking view more: " + i);
                    break;
                }
            }
        }
        // Taking all the searched displayed result products in the list
        List<WebElement> searchResultItemList = getElements("searchPageItemList");
        // File write code
        Date objDate = new Date();
        long timeMilli = objDate.getTime();
        logger.info("Date to be used: " + objDate.toString().replaceAll("\\s", "") + " file name: " +
                getConfig("Search_Text_File_Path") + "_" + splitTextWithIndexing(keywordToCheck, splitOptionSynonym, pLPPageScrollDownFirstIndex).
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");

        File file = new File(getConfig("Search_Text_File_Path") + "_" + splitTextWithIndexing(keywordToCheck, splitOptionSynonym, pLPPageScrollDownFirstIndex).
                replaceAll("\\s", "") + "_" + timeMilli + ".txt");
        FileWriter fW = new FileWriter(file.getAbsoluteFile(), true);
        BufferedWriter bW = new BufferedWriter(fW);
        if (file.createNewFile()) {
            logger.info("File created: " + file.getName());
        } else {
            logger.info("File already exists " + file.getName());
        }
        //splitting the keyword if multiple keywords are present
        String searchProductNameMismatch = "";
        String[] keywordArray = keywordToCheck.split(splitOptionKeyword);
        //Loop for product list
        for (WebElement searchProductName : searchResultItemList) {
            indexOfListElement = (searchResultItemList.indexOf(searchProductName) + plpSearchResultFirstIndex);
            keywordArray = keywordToCheck.split(splitOptionKeyword);
            logger.info("Printing product list index value: " + indexOfListElement);
            //For loop for sub keyword exact match
            // If sub keyword is not present in the given name of the list element
            for (int i = pLPPageScrollDownFirstIndex; i <=
                    ((keywordArray.length) - plpSearchResultFirstIndex); i++)
                if (!(((searchProductName.getText()).toLowerCase()).contains(keywordArray[i].toLowerCase()))) {
                    //If sub keyword contains synonym words, go for synonym loop and check if one of the synonym word is present in name else print in file
                    if (keywordArray[i].contains(splitOptionSynonym)) {
                        String[] synonymArray = keywordArray[i].split(splitOptionSynonym);
                        // Loop for the synonym word
                        for (String s : synonymArray) {
                            // If one of the synonym is present in the name of the list product, control comes out of synonym for loop else saves data in required format
                            if (((searchProductName.getText()).toLowerCase()).contains(s.toLowerCase())) {
                                searchProductNameMismatch = "";
                                break;
                            } else {
                                searchProductNameMismatch = ("Search mismatch for the index: " + indexOfListElement +
                                        " and sub keyword: " + "\"" + keywordArray[i] + "\"" + " for product: " + searchProductName.getText());
                            }
                        }
                        if (!(searchProductNameMismatch.isEmpty())) {
                            logger.info("product name Value in for loop if it does not contain keyword is : "
                                    + searchProductName.getText());
                            bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" + searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");

                        }
                    } else {
                        searchProductNameMismatch = ("Search mismatch for the index: " + indexOfListElement +
                                " and sub keyword: " + "\"" + keywordArray[i] + "\"" + " for product: " + searchProductName.getText());
                        logger.info("product name Value in for loop if it does not contain keyword is : "
                                + searchProductName.getText());
                        bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" +
                                searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
                    }
                }
            // Amount comparison for minimum and maximum value
            if (!(minValueArgument.equals("NA")) || !(maxValueArgument.equals("NA"))) {
                productDisplayedPrice = numericValuesExtractionMethod(getElement("plp_IndexProductAmountValue",
                        Integer.toString(indexOfListElement)).getText());
                logger.info("printing displayed value: " + productDisplayedPrice);
            }
            //  If product amount is less than given price band, write in file
            if (!(minValueArgument.equals("NA")) && (productDisplayedPrice < numericValuesExtractionMethod(minValueArgument))) {
                logger.info("inside if of displayed value < min value" + productDisplayedPrice);
                searchProductNameMismatch = ("Search mismatch for the index: " + indexOfListElement +
                        " and displayed amount " + "\"" + getElement("plp_IndexProductAmountValue",
                        Integer.toString(indexOfListElement)).getText() + "\"" + " not in mentioned price band" + " for product: " +
                        searchProductName.getText());
                bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" +
                        searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
            }
            //  If product amount is greater than given price band, write in file
            if (!(maxValueArgument.equals("NA")) && (productDisplayedPrice > numericValuesExtractionMethod(maxValueArgument))) {
                logger.info("inside if of displayed value > max value" + productDisplayedPrice);
                searchProductNameMismatch = ("Search mismatch for the index: " + indexOfListElement +
                        " and displayed amount " + "\"" + getElement("plp_IndexProductAmountValue",
                        Integer.toString(indexOfListElement)).getText() + "\"" + " not in mentioned price band" + " for product: " +
                        searchProductName.getText());
                bW.write("Searched Keyword: " + keywordToCheck + "\n" + searchProductNameMismatch + "\n" +
                        searchMismatch + " " + getConfig("URL") + " on Date and Time: " + objDate.toString() + "\n\n");
            }
        }
        bW.close();
    }

    /*
            user validates banners in product listing page
    */
    @And("^user validates banners in product listing page$")
    public void userValidatesBannersInProductListingPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        List<WebElement> bannerImagesList = getDriver().findElements(By.xpath("//a[contains(@href,'#item-')]"));
        logger.info("No of Images in PLP banners are: " + bannerImagesList.size());
        for (WebElement bannerElement : bannerImagesList) {
            actionMoveToElementClick(bannerElement);

        }
    }

    /*
           user validates the facets list
   */
    @And("^user validates particular filter \"([^\"]*)\" is present or absent \"([^\"]*)\" in the filter list$")
    public void userValidatesParticularFilterIsPresentOrAbsentInTheFilterList(String filterName, String presentOrAbsentCheck) {
        String stepDescription = "user validates particular filter is present or absent in the filter list";
        if (getConfig("Browser").equalsIgnoreCase(("EMULATED_CHROME"))) {
            getElement("filterIcon").click();
        }

        List<WebElement> facetNames = getElements("facetNameList");

        for (WebElement facetName : facetNames) {
            logger.info("Facet name is present in facet list: " + facetName.getText());

            if (facetName.getText().equalsIgnoreCase(filterName)) {
                logger.info("Facet name is present in facet list: " + facetName.getText());
                if (presentOrAbsentCheck.equalsIgnoreCase("absent")) {
                    assertThat(facetName.getText()).describedAs("facet name is present in the facet list").isNotEqualToIgnoringCase(filterName);
                    break;
                } else {
                    assertThat(facetName.getText()).describedAs("facet name is not present").isEqualToIgnoringCase(filterName);
                    break;
                }
            }
            passStepExecution(stepDescription + " :: Passed \n");
        }
    }

    @And("^verify the result in PLP with the sort filter already applied \"([^\"]*)\"$")
    public void verifyTheResultInPLPWithTheSortFilterAlreadyApplied(String FilterValue) throws InterruptedException {
        String stepDescription = "verify the result in PLP with the sort filter already applied “Latest arrival";
        Thread.sleep(5000);
        String searchResultTxt = getElement("searchResultText").getText().trim();
        logger.info("Search result text is :" + searchResultTxt);
        assertThat(searchResultTxt).containsIgnoringCase(getContext("searchProduct"))
                .describedAs("Search keyword should display");
        assertThat(getElement("latestArrival", FilterValue).isDisplayed()).
                describedAs("Shot by Latest arrival should already applied").isEqualTo(true);
        passStepExecution(stepDescription + " :: Passed \n");
        logger.info("verify the result in PLP with the sort filter already applied :- Pass");
    }

    @And("^verify \"([^\"]*)\" filter option shown in PLP and click on it$")
    public void verifyFilterOptionShownInPLPAndClickOnIt(String FilterValue) throws InterruptedException {
        String stepDescription = "Verify filter option shown in PLP and click on it";
        getDriver().navigate().refresh();
        String totalProduct = getElement("productCount").getText().split(" Products found")[0];
        logger.info("Total Product Count 1 :- " + totalProduct);
        setContext("TotalProductCount1", totalProduct);

        assertThat(getElement("stockAvailability").isDisplayed()).
                describedAs("Stock Availability filter option should display").isEqualTo(true);

        getElement("stockAvailability").click();

        assertThat(getElement("stockAvailabilityValue", FilterValue).isDisplayed()).
                describedAs("Include Out of Stock filter option should display").isEqualTo(true);

        String includeOutofStock = getElement("stockAvailabilityValue", FilterValue).getText();
        logger.info("Include Out of Stock is :- " + includeOutofStock);
        setContext("IncludeOutofStock", includeOutofStock);

        getElement("stockAvailabilityValue", FilterValue).click();
        getElement("stockAvailability").click();
        assertThat(getElement("stockAvailabilityValue", "Exclude Out of Stock").isDisplayed()).
                describedAs("Exclude Out of Stock filter option should display").isEqualTo(true);

        String excludeOutofStock = getElement("stockAvailabilityValue", "Exclude Out of Stock").getText();
        logger.info("Exclude Out of Stock is :- " + excludeOutofStock);
        setContext("ExcludeOutofStck", excludeOutofStock);

        Thread.sleep(5000);
        String exTotalProduct = getElement("productCount").getText().split(" Products found")[0];
        logger.info("Total Product Count 2 :- " + exTotalProduct);
        setContext("TotalProductCount2", exTotalProduct);
        assertThat(getContext("TotalProductCount2")).isLessThan(getContext("TotalProductCount1")).
                describedAs("Total Product Count should not be match");

        // getElement("stockAvailability").click();
        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^verify \"([^\"]*)\" filter option should not be displayed and \"([^\"]*)\" filter option should displayed$")
    public void verifyFilterOptionShouldNotBeDisplayAndOptionFilterShouldDisplay(String Value1, String Value2) {
        String stepDescription = "Verify Include Out of Stock filter option should not be display and Exclude Out of Stock filter option should be display";

        assertThat(getContext("IncludeOutofStock")).isNotEqualTo(getElement("stockAvailValue").getText()).
                describedAs("Include Out of Stock filter option should not display");
        assertThat(getContext("ExcludeOutofStck")).isEqualTo(getElement("stockAvailValue").getText()).
                describedAs("Exclude Out of Stock filter option should display");

        passStepExecution(stepDescription + " :: Passed \n");
    }


    /*
       user removes product from compare palet
    */
    @And("^user removes \"([^\"]*)\" from the compare palet$")
    public void userRemovesFromTheComparePalet(String productName) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("comparePaletRemoveProduct", productName)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        getElement("comparePaletRemoveProduct", productName).click();
        assertStepExecution(false, getElement("comparePaletRemoveProduct", productName).isDisplayed(),
                "Product should display");
    }


    /*
       user clicks add to cart of product from product listing page
    */
    @And("^user clicks add to cart of the product \"([^\"]*)\" from product listing page$")
    public void userClicksAddToCartOfTheProductFromProductListingPage(String productName) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("POLLING_WAIT")));
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            assertStepExecution(true, getContext("product_available").equalsIgnoreCase("true"), "Products should display");
            processScreenshot();
            windowScrollIntoViewByWebElement(getElement("plpProductAddToCart", productName));
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
            processScreenshot();
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plpProductAddToCart", productName)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
            getElement("plpProductAddToCart", productName).click();
        }
    }


    /*
       user selects and validate all the product info in plp
    */
    @And("^user lands on product listing page, selects and validates \"([^\"]*)\" as product name, \"([^\"]*)\" as product id, \"([^\"]*)\" as product price, \"([^\"]*)\" as product mrp price, \"([^\"]*)\" as product discount Percent, \"([^\"]*)\" as product review, \"([^\"]*)\" as product star available in page and select the product$")
    public void userLandsOnProductListingPageSelectsAndValidatesAsProductNameAsProductIdAsProductPriceAsProductMrpPriceAsProductDiscountPercentAsProductReviewAsProductStarAvailableInPageAndSelectTheProduct(String plpProductName, String plpProductId, String plpProductPrice, String plpProductMrpPrice, String plpProductDiscountPercent, String plpProductReview, String plpProductStar) {
        String invalid = "NA";
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            logger.info("The selected product name on PLP is: " + plpProductName + " " + "id" + plpProductId + " " + "price" + plpProductPrice + " " + "discounted price" + plpProductMrpPrice + " " + "Discount percent" + plpProductDiscountPercent + "Review" + plpProductReview + "Star" + plpProductStar);
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product", plpProductName)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));

            logger.info("Product details are:" + getElement("plp_Product", plpProductName).getText() + " " + numericValuesExtractionMethod(getElement("plp_Product_Id", plpProductName).getText()) + " " + getElement("plp_Product_Actual_Price", plpProductName).getText());
            assertThat(getElement("plp_Product", plpProductName).getText()).describedAs("Product name is not matching in plp").isEqualToIgnoringCase(plpProductName);

            if ((!(plpProductId.equalsIgnoreCase("NA"))) && (!(plpProductPrice.equalsIgnoreCase("NA"))) && (!(plpProductReview.equalsIgnoreCase("NA"))) && (!(plpProductStar.equalsIgnoreCase("NA")))) {
                //product ID
                assertThat(String.valueOf(numericValuesExtractionMethod(getElement("plp_Product_Id", plpProductName).getText()))).describedAs("Product id is not matching in plp").isEqualTo(plpProductId);
                //product price
                //    assertThat(getElement("plp_Product_Actual_Price", plpProductName).getText()).describedAs("Product actual price is not matching in plp").isEqualTo(plpProductPrice);
                assertThat(getElement("plp_Product_Actual_Price", plpProductName).getText().substring(plpSearchResultFirstIndex)).
                        describedAs("Product actual price is not matching in plp").isEqualTo(plpProductPrice);
                //product discount and MRP price
                logger.info(" MRP " + getDriver().findElements(By.xpath(getLocator("discountPercent", plpProductName))).size());
                if ((getDriver().findElements(By.xpath(getLocator("discountPercent", plpProductName)))).size() > pLPPageScrollDownFirstIndex) {
                    logger.info("Discount details are:" + getElement("discountPrice", plpProductName).getText() + " " + getElement("discountPercent", plpProductName).getText());
                    assertThat(getElement("discountPrice", plpProductName).getText()).describedAs("Product discount Price  is not matching in plp ").isEqualTo(plpProductMrpPrice);
                    assertThat(getElement("discountPercent", plpProductName).getText()).describedAs("Product discount Percent is not matching in plp ").isEqualTo(plpProductDiscountPercent);
                } else {
                    assertThat(plpProductMrpPrice).describedAs("Product discount Price  is not matching in plp ").isEqualTo(invalid);
                    assertThat(plpProductDiscountPercent).describedAs("Product discount Percent is not matching in plp ").isEqualTo(invalid);
                }
                //product review and review
                logger.info("Review and star details are:" + getElement("discountReview", plpProductName).getText().replaceAll("\\(", "").replaceAll("\\)", "") + " and " + getElement("discountStar", plpProductName).getAttribute("aria-label"));
                assertThat(getElement("discountReview", plpProductName).getText().replaceAll("\\(", "").replaceAll("\\)", "")).describedAs("Product discount review  is not matching in plp").isEqualTo(plpProductReview);
                assertThat(getElement("discountStar", plpProductName).getAttribute("aria-label")).describedAs("Product discount Star is not matching in plp").isEqualTo(plpProductStar);
            }

            //     processScreenshot();
            passStepExecution("User lands on product listing page and validates product details and click");
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product", plpProductName)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
            getElement("plp_Product", plpProductName).click();
        }
    }


    @When("^user lands on \"([^\"]*)\" category landing page and validates products count greater than \"([^\"]*)\"$")
    public void userLandsOnCategoryLandingPageAndValidatesProductsCountGreaterThan(String categoryName, String minimumProductCount) {

        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));

        String stepDescription = "user lands on " + categoryName + " category landing page and validates products count greater than " + minimumProductCount;

        String plpCategoryTitle = getElement("plpCategoryTitle").getText();

        logger.info("Category Title on PLP : " + plpCategoryTitle);

        assertThat(plpCategoryTitle).isEqualTo(categoryName)
                .describedAs("Corresponding Category Title should display");

        int plpProductCount = Integer.parseInt(getElement("plpProductCount").getText().split("Products found")[0].trim());

        logger.info("PLP Product Count :" + plpProductCount);

        assertThat(plpProductCount).isGreaterThan(Integer.parseInt(minimumProductCount))
                .describedAs("PLP Product count should be grater than " + minimumProductCount);

        passStepExecution(stepDescription + " :: Passed \n");

    }


    @And("^user clicks on \"([^\"]*)\" filter value$")
    public void userClicksOnFilterValue(String categoryValue) {
        assertStepExecution(true, getElement("categoryValue", categoryValue).isDisplayed(),
                "Category Value should display");
        getElement("categoryValue", categoryValue).click();
    }

    /*
            user lands on product listing page and clicks on interlinking option on footer content
    */
    @And("^user lands on product listing page and clicks on interlinking option \"([^\"]*)\" on footer content$")
    public void userLandsOnProductListingPageAndClicksOnInterlinkingOptionOnFooterContent(String interlinkingOption) {
        windowScrollIntoViewByWebElement(getElement("interlinkingOptionXpath", interlinkingOption));
        windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
        logger.info(getElement("interLinkingValue", interlinkingOption).getAttribute("href"));
        assertStepExecution(true, getElement("interlinkingOptionXpath", interlinkingOption).isDisplayed(), "Interlinking option displayed");
        getElement("interlinkingOptionXpath", interlinkingOption).click();
    }

    /*
           user validates the corresponding navigated page
   */
    @Then("^user validates the corresponding navigated page as \"([^\"]*)\"$")
    public void userValidatesTheCorrespondingNavigatedPageAs(String interlinkingCode) {
        String url = getDriver().getCurrentUrl();
        logger.info("Page url is: " + getDriver().getCurrentUrl());
        assertStepExecution(true, getDriver().getCurrentUrl().endsWith("c/" + interlinkingCode), "User validates the corresponding navigated page");
    }

    /*
       user clicks on shop with video option for the plp product and close the window
    */
    @And("^user clicks on shop with video option for the \"([^\"]*)\" from product listing page and close the video window$")
    public void userClicksOnShopWithVideoOptionForTheFromProductListingPageAndCloseTheVideoWindow(String productName) {
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            windowScrollIntoViewByWebElement(getElement("plpProductShopWithVideo", productName));
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plpProductShopWithVideo", productName)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
            assertStepExecution(true, getElement("plpProductShopWithVideo", productName).isDisplayed(), "Shop with video displayed in plp");
            getElement("plpProductShopWithVideo", productName).click();
        }
    }

    @Then("^verify PLP should display applied \"([^\"]*)\" products$")
    public void verifyPLPShouldDisplayAppliedProducts(String categoryValue) {
        String stepDescription = "verify PLP should display applied products";
        assertThat(getElement("selectCategory").isDisplayed()).isEqualTo(true).
                describedAs("Applied Filter Value should display");

        int totalProducts = getElements("productName").size();
        logger.info("Total Count" + totalProducts);
        /*for (int ProName = 0; ProName == totalProducts; ProName++) {
            String pLPProductName = getElement("productName").getText().trim();
            logger.info("PLP Product Name:-" + pLPProductName);
            assertThat(pLPProductName).containsIgnoringCase(categoryValue).
                    describedAs("PLP product name should contains category Value ");
        }*/
        passStepExecution(stepDescription + " :: Passed \n");
    }


    @And("^user clicks on cross icon & remove the \"([^\"]*)\" product from compare tray$")
    public void userClicksOnCrossIconRemoveTheProductFormCompareTray(String ComProductName) throws InterruptedException {
        String stepDescription = "user clicks on cross icon & remove the product from compare tray";
        int totalProducts = getElements("addedProductInCompareBox").size();
        String removeProductName = getElement("comProductName", ComProductName).getText().trim();

        assertThat(getElement("compareXbtn", ComProductName).isDisplayed()).isEqualTo(true)
                .describedAs("Cross icon of that product should display");
        assertThat(getElement("comProductName", ComProductName).isDisplayed()).isEqualTo(true)
                .describedAs("Product should display in the compare tray");
        getElement("compareXbtn", ComProductName).click();
        int afterremoveproducts = getElements("addedProductInCompareBox").size();
        String CompareTrayProductName = getElement("compareTrayProductName").getText();
        assertThat(removeProductName).isNotEqualTo(CompareTrayProductName)
                .describedAs("Product should not be display in the tray");
        assertThat(afterremoveproducts).isLessThan(totalProducts)
                .describedAs("Product sucessfully remove from the day");
        passStepExecution(stepDescription + " :: Passed \n");

    }

    @And("^user lands on product listing page and checks exclude OOS products toggle button at the top of Filters$")
    public void userLandsOnProductListingPageAndValidatesExcludeOOSProductsToggleButtonAtTheTopOfFilters() {
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("excludeOutOfStockButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
            assertStepExecution(true, getOptionalElement("excludeOutOfStockButton") != null, "user lands on product listing page and checks exclude OOS products toggle button at the top of Filters");
            getElement("excludeOutOfStockButton").isDisplayed();
        }
    }

    @And("^user validates by default the toggle button should not be applied$")
    public void userValidatesByDefaultTheToggleButtonShouldNotBeApplied() {
        if (getDriver().getCurrentUrl().contains("excludeOOSFlag")) {
            logger.info("Checkbox is toggled on");
            logger.info("User turns on the toggle button");
            getElement("excludeOutOfStockButton").click();
        } else {
            logger.info("By default the toggle button should not be applied");
            logger.info("Page url is: " + getDriver().getCurrentUrl());
            assertStepExecution(true, !getDriver().getCurrentUrl().contains("excludeOOSFlag"), "user validates by default the toggle button should not be applied");
        }
    }

    @Then("^user turns on the toggle button$")
    public void userTurnsOnTheToggleButton() {
        logger.info("User turns on the toggle button");
        getElement("excludeOutOfStockButton").click();
    }


    @Then("^user validates OOS products excluded$")
    public void userValidatesOOSProductsExcluded() {
        logger.info("Page url is: " + getDriver().getCurrentUrl());
        assertStepExecution(true, getDriver().getCurrentUrl().contains("excludeOOSFlag"), "user validates OOS products excluded");
    }

        /*
       User lands on PLP and Clicks on Sort icon
    */

    @And("^user lands on product listing page and clicks on sort icon$")
    public void userLandsOnProductListingPageAndClicksOnSortIcon() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("productOptionName")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        assertStepExecution(true, getOptionalElement("productOptionName") != null, " User lands on PLP and Clicks on Sort icon");
        logger.info("Selected product is: " + getElement("productOptionName").getText());
        getElement("sortIcon").click();
    }


    /*
         User selects sort by option
    */
    @And("^user selects \"([^\"]*)\" sort by option$")
    public void userSelectsSortByOption(String sortByOption) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("sortByHighestInPLP", sortByOption)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("sortByHighestInPLP", sortByOption).click();
        String availableProductDetails = getElement("getAvailableProductDetails").getText();
        logger.info("Number of product available are: " + numericValuesExtractionMethod(availableProductDetails));
        assertStepExecution(true, numericValuesExtractionMethod(availableProductDetails) > pLPPageScrollDownFirstIndex, " No products are available in PLP");
    }


    /*
        User clicks on filter option
     */

    @And("^user clicks on filter option$")
    public void userClicksOnFilterOption() {
        assertStepExecution(true, getOptionalElement("filterIcon") != null, " User clicks on filter option");
        getElement("filterIcon").click();
    }

     /*
        User selects filter by option and clicks on apply button
   */

    @And("^user selects filter by option \"([^\"]*)\" and clicks on apply button$")
    public void userSelectsFilterByOptionAndClicksOnApplyButton(String filterByOption) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("categoryCheckBox", filterByOption)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
        getElement("categoryCheckBox", filterByOption).click();
        getElement("applyButton").click();
        windowScrollIntoViewByWebElement(getElement("getAvailableProductDetails"));
        String availableProductDetails = getElement("getAvailableProductDetails").getText();
        logger.info("Number of product available are: " + numericValuesExtractionMethod(availableProductDetails));
        assertStepExecution(true, numericValuesExtractionMethod(availableProductDetails) > pLPPageScrollDownFirstIndex, "No products available in PLP");
    }

    @And("^user clicks on clear filter and clicks on apply button$")
    public void userClicksOnClearFilterAndClicksOnApplyButton() {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("filterClear")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        //  assertStepExecution(true, getOptionalElement("filterClear") != null, " user clicks on clear filter and clicks on apply button");
        getElement("filterClear").click();
        getElement("applyButton").click();
    }

    @And("^user removes filter \"([^\"]*)\" and clicks on apply button from product listing page$")
    public void userRemovesFilterandClicksOnApplyButtonFromProductListingPage(String categoryOptionFilter) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("categoryCheckBox", categoryOptionFilter)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        //    assertStepExecution(true, getOptionalElement("categoryCheckBox").isDisplayed(), "user removes filter");
        getElement("categoryCheckBox", categoryOptionFilter).click();
        getElement("applyButton").click();
    }


    @And("^user goes over \"([^\"]*)\" category and clicks$")
    public void userGoesOverCategoryAndClicks(String categoryOption3) throws InterruptedException {
        logger.info("User selects catagory option: " + categoryOption3);
        //  List<WebElement> elementPresent = getDriver().findElements(By.xpath("(//*[@class='text' and (text()='" + categoryOption3 + "')])[1]//parent::a//span[1]"));
        List<WebElement> elementPresent = getDriver().findElements(By.xpath("(//*[contains(@class,'text') and (text()='" + categoryOption3 + "')])[1]//parent::a//span[1]"));
        logger.info("No of element are: " + elementPresent.size());
        if (elementPresent.size() != 0) {
            if (categoryOption3.equals("Croma Outlet")) {
                assertStepExecution(true, getOptionalElement("categoryOptionCromaOutletPresent", categoryOption3) != null, "Category option found.");
                actionMoveToElementBuild(getElement("categoryOptionCromaOutletPresent", categoryOption3));
                Thread.sleep(5000);
            } else {
                assertStepExecution(true, getOptionalElement("categoryOptionPresent", categoryOption3) != null, "Category option found.");
                actionMoveToElementBuild(getElement("categoryOptionPresent", categoryOption3));
                Thread.sleep(5000);
            }
            // actionMoveToElementBuild(getDriver().findElement(By.xpath("//div[@id='menu-holder' and @style='display: block;']//*[contains(@class, 'tablinks link')]//*[text()='Home Appliances']")));
            //Thread.sleep(5000);
            // actionMoveToElementBuild(getElement("categoryOptionPresent", categoryOption3));
        } else {
            if (categoryOption3.equals("Croma Outlet")) {
                assertStepExecution(true, getOptionalElement("categoryOptionCromaOutletPresent", categoryOption3) != null, "Category option found.");
                actionMoveToElementClick(getElement("categoryOptionCromaOutletPresent", categoryOption3));
            } else {
                assertStepExecution(true, getOptionalElement("categoryOptionPresent", categoryOption3) != null, "Category option found.");
                actionMoveToElementClick(getElement("categoryOptionPresent", categoryOption3));
                //actionMoveToElementClick(getElement("plp_Product_Index", String.valueOf(indexOne)));
                //userNavigatesBackToPreviousPage();
            }
        }

    }

    @And("^user stores the landing page url$")
    public void userStoresTheLandingPageUrl() {
        logger.info("Page url is: " + getDriver().getCurrentUrl());
        String url = getDriver().getCurrentUrl();
        setContext("url_Currentpage", url);
    }

    @And("user clicks on Exclude out of stock items radio button")
    public void userClicksOnExcludeOutOfStockItemsRadioButton() throws InterruptedException {
        assertThat(getElement("ExcludeOutOff").isDisplayed()).isEqualTo(true).describedAs("Exclude out of stock should display as Off");
        //getElement("ExcludeOutOff").click();
        int totalProductsBeforeExcludeOOS = getElements("productName").size();
        logger.info("Total Count is :- " + totalProductsBeforeExcludeOOS);

        String totalProText = getElement("productCountText").getText().replace(" Products found", "");
        logger.info("Total Count text1 :- " + totalProText);

        jsClick(getElement("ExcludeOutOff"));
        Thread.sleep(5000);

        String totalProText1 = getElement("productCountText").getText().replace(" Products found", "");
        logger.info("Total Count text1 :- " + totalProText1);
        assertThat(getElement("ExcludeOutOn").isDisplayed()).isEqualTo(true).describedAs("Exclude out of stock should display as On");
        assertThat(totalProText1).isLessThan(totalProText).describedAs("Product count text should display");
        int totalProductsAfterExcludeOOS = getElements("productName").size();
        logger.info("Total Count 1:- " + totalProductsAfterExcludeOOS);


    }


    @And("user verify Exclude out of stock items radio button should be enabled")
    public void userVerifyExcludeOutOfStockItemsRadioButtonShouldBeEnabled() throws InterruptedException {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("ExcludeOutOn")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        assertThat(getElement("ExcludeOutOn").isDisplayed()).isEqualTo(true).describedAs("Exclude out of stock should display as On");

    }

    @And("user clicks add to cart from search result page")
    public void userClicksAddToCartFromSearchResultPage() {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getOptionalElement("addToCartButton").isDisplayed(), "Add to cart button present");
        getElement("addToCartButton").click();

    }

    @And("user validates add to cart success message {string}")
    public void userValidatesAddToCartSuccessMessage(String addToCartSuccessMessage) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        String addToCartSuccessMessageFromWeb = getElement("addToCartSuccessMessage", addToCartSuccessMessage).getText().trim();
        logger.info("Success message is: " + addToCartSuccessMessageFromWeb);
        String itemNo = String.valueOf(numericValuesExtractionMethod(addToCartSuccessMessageFromWeb));
        setContext("itemNum", itemNo);
        assertStepExecution(true, addToCartSuccessMessageFromWeb.contains(addToCartSuccessMessage), "Add to cart success message matched");
    }

    @And("user lands on {string} category landing page")
    public void userLandsOnCategoryLandingPage(String shopByCategoryOption) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(shopByCategoryOption, getElement("categoryTitle", shopByCategoryOption).getText(), "User verified the category title");
    }

    @And("user lands on product listing page and selects add to cart of the product {string}")
    public void userLandsOnProductListingPageAndSelectsAddToCartOfTheProduct(String plpProduct1) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getOptionalElement("plpAddToCartButton", plpProduct1).isDisplayed(), "User validates the add to cart button on PLP product:" + plpProduct1);
        getElement("plpAddToCartButton", plpProduct1).click();

    }

    @And("user stores the EW product id from mini cart dialog box")
    public void userStoresTheEWProductIdFromMiniCartDialogBox() {
        WebElement wb = getElement("ewProductIdExtract");
        String ewProductId = wb.getAttribute("id");
        setContext("ProductIdFromMiniCartModalPopUp", ewProductId);

    }

    @And("user clicks on add to cart button for added ew product")
    public void userClicksOnAddToCartButtonForAddedEwProduct() throws InterruptedException {
        assertStepExecution(true, getOptionalElement("ewAddToCartButtonInMiniCartPopUp").isDisplayed(), "User validates the add to cart button for EW product");
        getElement("ewAddToCartButtonInMiniCartPopUp").click();
        Thread.sleep(5000);
    }

    @And("user validates after adding ew product in cart no add to cart button is displaying for ew product")
    public void userValidatesAfterAddingEwProductInCartNoAddToCartButtonIsDisplayingForEwProduct() {
        assertStepExecution(false, getOptionalElement("ewAddToCartButtonInMiniCartPopUp") != null, "User validates no add to cart button is present for EW product");

    }

    @And("user lands on product listing page of {string}")
    public void userLandsOnProductListingPageOf(String categoryOption) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(categoryOption, getElement("categoryOptionPlp", categoryOption).getText(), "User lands on plp");
    }


    @And("user verifies free delivery by, pick up today at and not available messages present in {string} on product listing page")
    public void userVerifiesFreeDeliveryByPickUpTodayAtAndNotAvailableMessagesPresentInOnProductListingPage(String plpProduct) throws InterruptedException {

//        if (getOptionalElement("pickUpTodayAtMessageOnPlp",plpProduct) == null) {
//            if (getOptionalElement("freeDeliveryByMessageAtPlp", plpProduct) == null) {
//                assertThat(getOptionalElement("notAvailableMessageAtPlp", plpProduct) != null).describedAs("User verifies Not Available message on PLP").isEqualTo(true);
//            }
//        }
//            else if (getOptionalElement("pickUpTodayAtMessageOnPlp",plpProduct) != null) {
//                assertThat(getElement("freeDeliveryByMessageAtPlp",plpProduct)!=null).describedAs("User verifies free delivery by text message").isEqualTo(true);
//                getElement("viewStoresLink",plpProduct).click();
//                Thread.sleep(3000);
//                assertThat(getElement("storeListPopUp").getText()).describedAs("User verifies the croma stores pop up").isEqualToIgnoringCase("Croma Stores");

        if (getOptionalElement("notAvailableMessageAtPlp", plpProduct) != null) {
            assertThat(getOptionalElement("notAvailableMessageAtPlp", plpProduct) != null).describedAs("User verifies Not Available message on PLP").isEqualTo(true);
        } else if (getOptionalElement("productDeliveryMessageAtPlp", plpProduct) != null) {
            assertThat(getOptionalElement("productDeliveryMessageAtPlp", plpProduct) != null).describedAs("User verifies Not Available message on PLP").isEqualTo(true);
            logger.info("Product is available for " + getElement("productDeliveryMessageAtPlp", plpProduct).getText());
            if (getOptionalElement("productDeliveryForOtherOptionMessageAtPlp", plpProduct) != null) {
                logger.info("Product is available for other option " + getElement("productDeliveryForOtherOptionMessageAtPlp", plpProduct).getText());
            }
        }
    }

    @Then("user verifies not available messages present in {string} on product listing page")
    public void userVerifiesNotAvailableMessagesPresentInOnProductListingPage(String plpProduct) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("notAvailableMessageAtPlp", plpProduct) != null, "User verifies Not Available message on PLP");
        assertStepExecution(true, getOptionalElement("errorSignAtPlp", plpProduct) != null, "User verifies Not Available message on PLP");
    }

    @And("user clicks on {string}")
    public void userClicksOn(String plpProduct1) {
        assertStepExecution(true, getOptionalElement("plp_Product", plpProduct1) != null, "Product is available on PLP");
        getElement("plp_Product", plpProduct1).click();
    }

    @And("user clicks on add to cart button for {string}")
    public void userClicksOnAddToCartButtonFor(String plpProduct) {
        assertStepExecution(true, getOptionalElement("addToCartPlp", plpProduct) != null, "Add to cart button is available on PLP for product " + plpProduct);
        getElement("addToCartPlp", plpProduct).click();

    }

    @And("user verifies {string}, {string}, {string}, and {string} in mini cart pop up from plp")
    public void userVerifiesAndInMiniCartPopUpFromPlp(String productName, String productId, String productPrice, String unavailabilityMsg) {
        assertThat(getElement("productNameMiniCartPopUp", productName).getText()).describedAs("User verifies the product name on miniCart pop up")
                .isEqualTo(productName);
        assertThat(getElement("productIdMiniCartPopUp", productName).getText().replaceAll("[^0-9]", "")).describedAs("User verifies the product ID on miniCart pop up")
                .isEqualTo(productId);
        assertThat(getElement("productPriceMiniCartPopUp", productName).getText()).describedAs("User verifies the product price on miniCart pop up")
                .isEqualTo(productPrice);
        assertThat(getElement("productUnavailbilityMsg").getText()).describedAs("User verifies the product unavailability on miniCart pop up")
                .isEqualTo(unavailabilityMsg);
        passStepExecution("Product details in mini cart plp is verified.");


    }

    @And("user clicks on buy now button for {string}")
    public void userClicksOnBuyNowButtonFor(String plpProduct) {
        assertStepExecution(true, getOptionalElement("buyNowButton", plpProduct) != null, "buy now button is available on PLP for product " + plpProduct);
        getElement("buyNowButton", plpProduct).click();
    }

    @And("user verifies {string}, {string}, {string} in mini cart pop up from plp")
    public void userVerifiesInMiniCartPopUpFromPlp(String productName, String productId, String productPrice) {

        assertThat(getElement("productNameMiniCartPopUpPDP", productName).getText()).describedAs("User verifies the product name on miniCart pop up")
                .isEqualTo(productName);
//        assertThat(getElement("productIdMiniCartPopUp",productName).getText().replaceAll("[^0-9]","")).describedAs("User verifies the product ID on miniCart pop up")
//                .isEqualTo(productId);
        assertThat(getElement("productPriceMiniCartPopUpPDP", productName).getText()).describedAs("User verifies the product price on miniCart pop up")
                .isEqualTo(productPrice);
        passStepExecution("Product details in mini cart plp is verified.");
    }


    @And("user clicks on pincode in product tile of {string}")
    public void userClicksOnPincodeInProductTileOf(String plpProduct) throws InterruptedException {
        assertStepExecution(true, getOptionalElement("pincodeOptionInPlpProductTile", plpProduct) != null, "User verifies pincode option in plp product tile");
        // getElement("pincodeOptionInPlpProductTile",plpProduct).click();
        jsClick(getElement("pincodeOptionInPlpProductTile", plpProduct));
        Thread.sleep(5000);

    }

    @And("user provides {string} and clicks on apply button")
    public void userProvidesAndClicksOnApplyButton(String pinCode) throws InterruptedException {
        assertStepExecution(true, getOptionalElement("pinCodePlp") != null, "User verifies the pincode field in plp product tile");
        getElement("pinCodePlp").clear();
        Thread.sleep(2000);
        getElement("pinCodePlp").sendKeys(pinCode);
        getElement("pinCodePlpSubmit").click();
        Thread.sleep(2000);
    }

    /*
      User clicks on Buy Now button of PLP product
     */
    @And("user clicks buy now from product listing page for {string} product")
    public void userClicksBuyNowFromProductListingPageForProduct(String itemIndex) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        Thread.sleep(4000);
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            logger.info("The product name on PLP is: " + getElement("plp_Product_Index", itemIndex).getText() + "Index " + itemIndex);

            windowScrollIntoViewByWebElement(getElement("plp_Product_Index", itemIndex));
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);

            conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product_Index", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            getElement("plp_IndexProductBuyNowButton", itemIndex).click();
        }
    }

    /*
  User validates sort By Or Filter By option is present in product listing page
 */
    @And("user validates {string} option is present in product listing page")
    public void userValidatesOptionIsPresentInProductListingPage(String sortByOrFilterBy) {
        assertStepExecution(true, getElement("sortByOrFilterByXpath", sortByOrFilterBy) != null, "User verifies the pincode field in plp product tile");
        logger.info("Option is: " + getElement("sortByOrFilterByXpath", sortByOrFilterBy).getText());
    }

    /*
 User validates color of sort By Or Filter By option
*/
    @And("user validates color {string} of {string} option in product listing page")
    public void userValidatesColorOfOptionInProductListingPage(String color, String sortByOrFilterBy) {
        String colorOfText = getElement("sortByOrFilterByXpath", sortByOrFilterBy).getCssValue("color");
        String hexcolor = Color.fromString(colorOfText).asHex();
        logger.info("The color of text :" + hexcolor);
        assertStepExecution(color, hexcolor, "Color of text is verified");

    }

    /*
 User validates type of sort By Or Filter By option
*/
    @And("user validates font type {string} of {string} option in product listing page")
    public void userValidatesFontTypeOfOptionInProductListingPage(String type, String sortByOrFilterBy) {
        logger.info("Size is :" + getElement("sortByOrFilterByXpath", sortByOrFilterBy).getCssValue("font-size") + " and font-family is : " + getElement("sortByOrFilterByXpath", sortByOrFilterBy).getCssValue("font-family"));
        assertStepExecution(getElement("sortByOrFilterByXpath", sortByOrFilterBy).getCssValue("font-family"), type, "Type of text is verified");
    }

    /*
 User validates search option in filter is not present in product listing page
*/
    @Then("user validates search option in filter is not present in product listing page")
    public void userValidatesSearchOptionInFilterIsNotPresentInProductListingPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("filterBtn") == null, "user validates search option in filter is not present in product listing page");
    }

    /*
User validates store the product count in product listing page
*/
    @And("user store the product count in product listing page")
    public void userStoreTheProductCountInProductListingPage() {
        List<WebElement> productCountList = getElements("productCountList");
        logger.info("No of products in PLP are: " + productCountList.size());
        setContext("productCountInPLP", String.valueOf(productCountList.size()));
    }

    /*
User validates the product count increased in product listing page
*/
    @And("user validates the product count increased in product listing page")
    public void userValidatesTheProductCountIncreasedInProductListingPage() {
        List<WebElement> productCountList = getElements("productCountList");
        logger.info("Now No of products in PLP are: " + productCountList.size());
        String productCount = String.valueOf(productCountList.size());
        assertThat(productCount).describedAs("user validates the product count increased in product listing page").isGreaterThan(getContext("productCountInPLP"));
    }

    @And("user validates product id is not present in product listing page")
    public void userValidatesProductIdIsNotPresentInProductListingPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("productID") == null, "user validates product id is not present in product listing page");
    }

    @And("user validates connect to store is not present in product listing page")
    public void userValidatesConnectToStoreIsNotPresentInProductListingPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("clickOnConnectToStoreButtonFromPLP") == null, "user validates connect to store is not present in product listing page");
    }

    @And("user validates shop with video is not present in product listing page")
    public void userValidatesShopWithVideoIsNotPresentInProductListingPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getOptionalElement("plpProductShopWithVideo") == null, "user validates search option in filter is not present in product listing page");
    }

    @And("user validates {string} as products title in product listing page")
    public void userValidatesAsProductsTitleInProductListingPage(String plpProductNames) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> productDetail = new ArrayList<>(getElements("productCountList"));
        assertThat(productDetail.size()).describedAs("Products are more than 1").isGreaterThan(0);
        if (plpProductNames.contains(";")) {
            String[] productNamefromExamples = plpProductNames.split(";");
            for (int i = 0; i < productNamefromExamples.length; i++) {
                String productNameFromWeb = productDetail.get(i).getText();
                logger.info("The product name from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("plp product name from web and examples are matched.").isEqualTo(productNamefromExamples[i]);
            }
        } else {
            assertThat(productDetail.get(0).getText()).describedAs("plp product name from web and examples are matched.").isEqualTo(plpProductNames);
        }
        passStepExecution("Products names on cart is verified");
    }

    @And("user validates {string} as products mop price in product listing page")
    public void userValidatesAsProductsMopPriceInProductListingPage(String plpProductMrp) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> plpProductPriceListFromWeb = new ArrayList<>(getElements("productMrp"));
        assertThat(plpProductPriceListFromWeb.size()).describedAs("Price should be greater than zero").isGreaterThan(0);
        if (plpProductMrp.contains(";")) {
            String[] productPrice = plpProductMrp.split(";");
            for (int i = 0; i < productPrice.length; i++) {
                String plpProductPriceFromWeb = plpProductPriceListFromWeb.get(i).getText();
                assertThat(plpProductPriceFromWeb).describedAs("plp product prices from web and from examples are matching").isEqualTo(productPrice[i]);
            }

        } else {
            String cartProductPriceFromWeb = plpProductPriceListFromWeb.get(0).getText();
            assertThat(cartProductPriceFromWeb).describedAs("plp product prices from web and from examples are matching").isEqualTo(plpProductMrp);
        }

        passStepExecution("All price from web and examples are matched on plp");


    }

    @And("user validates {string} as products strike of mrp price in product listing page")
    public void userValidatesAsProductsStrikeOfMrpPriceInProductListingPage(String plpProductStrikeOfMrp) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> plpProductStrikeOfMrpPriceListFromWeb = new ArrayList<>(getElements("productStrikeOfMrp"));
        assertThat(plpProductStrikeOfMrpPriceListFromWeb.size()).describedAs("strike of mrp prices should be greater than zero").isGreaterThan(0);
        if (plpProductStrikeOfMrp.contains(";")) {
            String[] productPrice = plpProductStrikeOfMrp.split(";");
            for (int i = 0; i < productPrice.length; i++) {
                String plpProductStrikeOfMrpPriceFromWeb = plpProductStrikeOfMrpPriceListFromWeb.get(i).getText().replaceAll("MRP: ", "");
                assertThat(plpProductStrikeOfMrpPriceFromWeb).describedAs("plp product strike of mrp prices from web and from examples are matching").isEqualTo(productPrice[i]);
            }

        } else {
            String cartProductPriceFromWeb = plpProductStrikeOfMrpPriceListFromWeb.get(0).getText().replaceAll("MRP: ", "");
            assertThat(cartProductPriceFromWeb).describedAs("plp product strike of mrp prices from web and from examples are matching").isEqualTo(plpProductStrikeOfMrp);
        }

        passStepExecution("All strike of mrp prices from web and examples are matched on plp");

    }

    @And("user validates {string} as products save amount in product listing page")
    public void userValidatesAsProductsSaveAmountInProductListingPage(String productSaveAmount) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> plpProductSaveAmountListFromWeb = new ArrayList<>(getElements("productSaveAmount"));
        assertThat(plpProductSaveAmountListFromWeb.size()).describedAs("SaveAmount should be greater than zero").isGreaterThan(0);
        if (productSaveAmount.contains(";")) {
            String[] productSavedAmount = productSaveAmount.split(";");
            for (int i = 0; i < productSavedAmount.length; i++) {
                String plpProductStrikeOfMrpPriceFromWeb = plpProductSaveAmountListFromWeb.get(i).getText().replaceAll("\\(", "").replaceAll("Save ", "").replaceAll("\\)", "");
                assertThat(plpProductStrikeOfMrpPriceFromWeb).describedAs("plp product save amount from web and from examples are matching").isEqualTo(productSavedAmount[i]);
            }

        } else {
            String cartProductPriceFromWeb = plpProductSaveAmountListFromWeb.get(0).getText().replaceAll("\\(", "").replaceAll("Save ", "").replaceAll("\\)", "");
            assertThat(cartProductPriceFromWeb).describedAs("plp product save amount from web and from examples are matching").isEqualTo(productSaveAmount);
        }

        passStepExecution("All save amount from web and examples are matched on plp");

    }

    @And("user validates {string} as products save discount in product listing page")
    public void userValidatesAsProductsSaveDiscountInProductListingPage(String productSaveDiscount) throws InterruptedException {
        Thread.sleep(5000);
        ArrayList<WebElement> plpProductSaveDiscountListFromWeb = new ArrayList<>(getElements("productSaveDiscount"));
        assertThat(plpProductSaveDiscountListFromWeb.size()).describedAs("Save discount should be greater than zero").isGreaterThan(0);
        if (productSaveDiscount.contains(";")) {
            String[] productSavedDiscount = productSaveDiscount.split(";");
            for (int i = 0; i < productSavedDiscount.length; i++) {
                String plpProductStrikeOfMrpPriceFromWeb = plpProductSaveDiscountListFromWeb.get(i).getText().replaceAll("Off", "").trim();
                assertThat(plpProductStrikeOfMrpPriceFromWeb).describedAs("plp product save discount from web and from examples are matching").isEqualTo(productSavedDiscount[i]);
            }

        } else {
            String cartProductPriceFromWeb = plpProductSaveDiscountListFromWeb.get(0).getText().replaceAll("Off", "").trim();
            assertThat(cartProductPriceFromWeb).describedAs("plp product save discount from web and from examples are matching").isEqualTo(productSaveDiscount);
        }

        passStepExecution("All save discount from web and examples are matched on plp");

    }

    @And("user validates compare cta is visible in the {string} on product listing page")
    public void userValidatesCompareCtaIsVisibleInTheOnProductListingPage(String plpProduct) {
        assertStepExecution(true, getElement("plpProductCompare", plpProduct).isDisplayed(), "user validates compare is visible in product listing page");
    }

    @And("user validates product image is visible in the {string} on product listing page")
    public void userValidatesProductImageIsVisibleInTheOnProductListingPage(String plpProduct) {
        assertStepExecution(true, getElement("plpProductImage", plpProduct).isDisplayed(), "user validates image is visible in product listing page");
    }

    @And("user validates wishlist icon is visible in the {string} on product listing page")
    public void userValidatesWishlistIconIsVisibleInTheOnProductListingPage(String plpProduct) {
        assertStepExecution(true, getElement("plpProductWishlistIcon", plpProduct).isDisplayed(), "user validates wishlist icon is visible in product listing page");
    }


    @And("user clicks on stores in pickup at store present in {string} on product listing page")
    public void userClicksOnStoresInPickupAtStorePresentInOnProductListingPage(String plpProduct) throws InterruptedException {
        if (getOptionalElement("productDeliveryForOtherOptionMessageAtPlp", plpProduct) != null) {
            logger.info("Product is available for other option " + getElement("productDeliveryForOtherOptionMessageAtPlp", plpProduct).getText());
            if (getOptionalElement("storeAvailableLink", plpProduct) != null) {
                getElement("storeAvailableLink", plpProduct).click();
                Thread.sleep(3000);
                assertStepExecution(true, getElement("cromaStoresPopup") != null, "User lands on croma store page");
                getElement("closeCromaStoresPopup").click();
            }
        } else {
            logger.info("Pick up at store is not available");
        }
    }

    @And("user validates review and rating section is visible in the {string} on product listing page")
    public void userValidatesReviewAndRatingSectionIsVisibleInTheOnProductListingPage(String plpProduct) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        if (getOptionalElement("productBeTheFirstOneToReviewAtPlp", plpProduct) != null) {
            logger.info("Review not present message is: " + getElement("productBeTheFirstOneToReviewAtPlp", plpProduct).getText());
            getElement("productBeTheFirstOneToReviewAtPlp", plpProduct).click();
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);
            assertStepExecution(true, getElement("writeAReviewTab") != null, "user validates write a review section should present");
        } else {
            assertStepExecution(true, getElement("productReviewRating", plpProduct).isDisplayed(), "Rating and review section is present");
            logger.info("Rating and review count is: " + getElement("productReviewRating", plpProduct).getText());
            assertStepExecution(true, getElement("productReviewRating", plpProduct).getText().contains("Ratings"), "user validates review and rating section is not visible for the product in product listing page");
        }
    }


    @And("user clicks view more option button in product definition page {string}")
    public void userClicksViewMoreOptionButtonInProductDefinitionPage(String pdpsection) throws InterruptedException {
        //windowScrollIntoViewByWebElement(getElement("viewMoreButtonPresentForTheOption",pdpsection));
        windowScrollIntoViewAdjustment_scroll(0, 2100);
        //windowScrollIntoViewAdjustment(0,2300);
        Thread.sleep(3000);
        assertStepExecution(true, getElement("viewMoreButtonPresentForTheOption", pdpsection).isDisplayed(), "User validates the viewmore button is enable or not");
        getElement("viewMoreButtonPresentForTheOption", pdpsection).click();

    }

    @And("user clicks filter option {string} in product listing page")
    public void userClicksFilterOptionInProductListingPage(String section) {
        //windowScrollIntoViewByWebElementTrue(getElement("filteroptionsinplp",section));
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].value ='';", getElement("filterOptionsInPlp", section));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("filterOptionsInPlp", section)), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        getElement("filterOptionsInPlp", section).click();

    }


    @And("user validates selected section {string} in product definition page {string}")
    public void userValidatesSelectedSectionInProductDefinitionPage(String section, String sectiontitle) throws InterruptedException {
        //((JavascriptExecutor) getDriver()).executeScript("window.scrollBy(0,2000)");
        windowScrollIntoViewAdjustment_scroll(0, 2000);
        Thread.sleep(3000);
        /*windowScrollIntoViewByWebElement(getElement("sectioninpdp",section));
        logger.info(getElement("section in pdp page is:" + "sectioninpdp",section).getText());
*/
        assertStepExecution(true, getElement("sectionInPdp", sectiontitle).getText().equalsIgnoreCase(section), "user validates the section is present in pdp page");

    }

    @And("user select the options {string} from {string}")
    public void userSelectTheOptionsFrom(String filteroption, String filtermenu1) throws InterruptedException {

        List<WebElement> processoroptions = getElements("filterOptions", filtermenu1);

        logger.info("size is:" + processoroptions.size());
        for (WebElement options : processoroptions) {

            String text = options.getText();
            logger.info("Search term is:" + options.getText());
            if (text.contains(filteroption)) {
                assertStepExecution(true, text.contains(filteroption), "user validates that option is available in the filter");
                options.click();
            }
           /* assertStepExecution(true, text.contains(filteroption), "user select the generation from the options");
            options.click();*/
            windowScrollToTop();

        }
        Thread.sleep(3000);

    }

    @And("user clicks see more option for filter menu {string}")
    public void userClicksSeeMoreOptionForFilterMenu(String filtermenuseemoreoption) {

        //assertThat(getElement("filtermenuseemoreoption",filtermenuseemoreoption).isDisplayed());
        assertStepExecution(true, getElement("filterMenuSeeMoreOption", filtermenuseemoreoption).isDisplayed(), "User validates see more option is present in the filter menu");
        getElement("filterMenuSeeMoreOption", filtermenuseemoreoption).click();

    }

    @And("user validates {string} should be display for the product in product listing page {string}")
    public void userValidatesShouldBeDisplayForTheProductInProductListingPage(String filterOption, String itemIndex) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            windowScrollIntoViewByWebElement(getElement("plp_Product_Index", itemIndex));
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);

            //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product_Index", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            logger.info("The product name on PLP is: " + getElement("plp_Product_Index", itemIndex).getText() + "Index " + itemIndex);
            //getElement("plp_Product_Index", itemIndex).click();
            String filteroption1 = filterOption.split("\\s+")[0];
            logger.info("The splitted string from selected option:" + filteroption1);
            assertStepExecution(true, getElement("plp_Product_Index", itemIndex).getText().contains(filteroption1), "User validates selected filter option is present in the product");


        }
    }


    @And("user validates {string} should be display for product in product listing page {string}")
    public void userValidatesShouldBeDisplayForProductInProductListingPage(String filterOption, String itemIndex) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
        verifyProductAvailability(getDriver().findElements(By.xpath(getLocator("noProductFoundText"))));
        if (getContext("product_available").equalsIgnoreCase("true")) {
            windowScrollIntoViewByWebElement(getElement("plp_Product_Index", itemIndex));
            windowScrollIntoViewAdjustment(pLPPageScrollDownFirstIndex, pLPPageScrollDownLastIndex);

            //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("plp_Product_Index", itemIndex)), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
            logger.info("The product name on PLP is: " + getElement("plp_Product_Index", itemIndex).getText() + "Index " + itemIndex);
            //getElement("plp_Product_Index", itemIndex).click();
            //String filteroption1= filterOption.split("\\s+")[0];
            //logger.info("The splitted string from selected option:" + filteroption1);
            assertStepExecution(true, getElement("plp_Product_Index", itemIndex).getText().contains(filterOption), "User validates selected filter option is present in the product");


        }
    }


    @And("user selects {string} category_2 from category_1 {string} clicks in Mobile")
    public void userSelectsCategoryFromCategoryClicksInMobile(String categoryOption1, String categoryOption2) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        assertStepExecution(true, getOptionalElement("categoryOptionMobile1", categoryOption1) != null,
                "user goes over category and clicks " + categoryOption1 + " in mobile");
        getElement("categoryOptionMobile1", categoryOption1).click();

        getElement("categoryOptionMobile2", categoryOption2).click();

    }
}





