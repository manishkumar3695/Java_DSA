package com.croma.automationqa.runners;


import com.croma.automationqa.util.ListenerUtil;
import com.croma.automationqa.util.RetryUtil;
import io.cucumber.testng.*;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.Reportable;
import net.masterthought.cucumber.json.support.Status;
import net.masterthought.cucumber.presentation.PresentationMode;
import org.testng.annotations.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@CucumberOptions(
        features = {"src/test/resources/finalFeatures"},
        glue = {"com/croma/automationqa/stepDefinitions"},
        plugin = {"pretty", "json:target/cucumber-report/cucumber.json",
                "junit:target/cucumber-junit-reports/Cucumber-JUnit-Report.xml",

        },
        dryRun = false,
        monochrome = true,
        tags = "@CromaPWASmokeTest328"
)
@Listeners(ListenerUtil.class)
public class CucumberRunner extends AbstractTestNGCucumberTests {


    private TestNGCucumberRunner testNGCucumberRunner;

    @BeforeSuite()
    public void setUpSuite() {
        System.out.println("Test BeforeSuite");
    }

    @BeforeClass(alwaysRun = true)
    public void setUpClass() {
        System.out.println("Test BeforeClass");
        this.testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }

    @BeforeMethod(alwaysRun = true)
    public void setUpTest() {
        System.out.println("Test BeforeMethod");
    }


    @Test(
            groups = {"cucumber"},
            description = "Runs Cucumber Scenarios",
            dataProvider = "scenarios",
            retryAnalyzer = RetryUtil.class
    )
    public void runScenario(PickleWrapper pickleWrapper, FeatureWrapper featureWrapper) {
        System.out.println(pickleWrapper.getPickle().getName() + " :: " + pickleWrapper.getPickle().getScenarioLine());
        this.testNGCucumberRunner.runScenario(pickleWrapper.getPickle());
    }

    @DataProvider(parallel = false)
    public Object[][] scenarios() {
        Object[][] ob = this.testNGCucumberRunner == null ? new Object[0][0] : this.testNGCucumberRunner.provideScenarios();
        System.out.println("hi");
        return ob;
    }

    @AfterMethod(alwaysRun = true)
    public void tearDownTest() {
        System.out.println("Test AfterMethod");
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() {
        System.out.println("Test AfterClass");
        if (this.testNGCucumberRunner != null) {
            this.testNGCucumberRunner.finish();
        }
    }

    @AfterSuite()
    public void tearDownSuite() {
        System.out.println("Test AfterSuite");


        try {
            File reportOutputDirectory = new File("target");
            List<String> jsonFiles = new ArrayList<>();
            jsonFiles.add("target/cucumber-report/cucumber.json");
            // jsonFiles.add("cucumber-report-2.json");

            String buildNumber = "1";
            String projectName = "cucumberProject";

            Configuration configuration = new Configuration(reportOutputDirectory, projectName);
            // optional configuration - check javadoc for details
            configuration.addPresentationModes(PresentationMode.RUN_WITH_JENKINS);
            // do not make scenario failed when step has status SKIPPED
            configuration.setNotFailingStatuses(Collections.singleton(Status.SKIPPED));
            configuration.setBuildNumber(buildNumber);
            // addidtional metadata presented on main page
            configuration.addClassifications("Platform", "Windows");
            configuration.addClassifications("Browser", "Chrome");
            // configuration.addClassifications("Branch", "release/1.0");

            // optionally add metadata presented on main page via properties file
/*        List<String> classificationFiles = new ArrayList<>();
        classificationFiles.add("properties-1.properties");
        classificationFiles.add("properties-2.properties");
        configuration.addClassificationFiles(classificationFiles);*/

            // optionally specify qualifiers for each of the report json files
/*        configuration.addPresentationModes(PresentationMode.PARALLEL_TESTING);
        configuration.setQualifier("cucumber-report-1", "First report");
        configuration.setQualifier("cucumber-report-2", "Second report");*/

            ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
            Reportable result = reportBuilder.generateReports();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
