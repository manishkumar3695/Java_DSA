package com.croma.automationqa.util;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.GeckoDriverService;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static com.croma.automationqa.util.FrameworkUtil.getConfig;
import static com.croma.automationqa.util.FrameworkUtil.logger;


/**
 * <h3> Purpose:  <p> <h4> &#10687; This class includes all the methods to create, return and remove Thread-specific WebDriver Objects.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 18/04/2020
 */
public class DriverUtil {

    private static DriverUtil instance;
    private HashMap<String, WebDriver> driverMap;
    public static File tempFile = null;

    /**
     * This constructor is kept <b>private</b> to prevent users from creating instance of this class by invoking '<b>new</b>' keyword from outside of this class.
     */
    private DriverUtil() {
    }


    /**
     * This method implements <b>Thread-safe Singleton design pattern</b> by allowing users to create only one instance of this class.
     *
     * @return <b>DriverUtil</b> object.
     */
    public static synchronized DriverUtil getInstance() {

        if (instance == null) {
            instance = new DriverUtil();
            instance.driverMap = new HashMap<String, WebDriver>();
            logger.info("DriverUtil instantiated...");
        }

        return instance;
    }


    /**
     * This method <b>Return</b> already created WebDriver instance from HashMap using Thread id as key.
     * If Driver instance is not created already for current thread, it creates a ChromeDriver/FirefoxDriver/IEDriver instance according to provided specifications and returns it.
     * This method accepts var arg i.e. 0, 1 or multiple(technically feasible, but not needed in this case) strings.
     * If user calls this method like : getDriver(), it instantiates a driver according to "Browser" property in Environment.properties.
     * If user calls this method with browser name passed as parameter like : getDriver("Chrome"), it instantiates a driver according to Browser name passed as String.
     * This method always accepts the first param as browser name & doesn't utilize any other String passed on thereafter.
     * So, calling this method like : getDriver("Firefox", "Chrome") is NOT RECOMMENDED. This example will return a Firefox instance.
     * Browser names passed as method param MUST follow same namings as suggested in Environment.properties.
     *
     * @return WebDriver reference corresponding to current thread's Thread id.
     */
    public static synchronized WebDriver getDriver(String... browserParam) {

        String tId = null;
        String browser = "";

        try {
            tId = String.valueOf(Thread.currentThread().getId());

            if (!instance.driverMap.containsKey(String.valueOf(tId))) {

                if (browserParam.length != 0) {
                    browser = browserParam[0];
                } else {
                    browser = getConfig("Browser").trim();
                }


                if (browser.equalsIgnoreCase("CHROME")) {
                    String chromeVersion = getChromeVersion();
                    logger.info("Chrome Version >>> " + chromeVersion);
                    WebDriverManager.chromedriver().version(chromeVersion).setup();
//                    if (chromeVersion.equalsIgnoreCase("LATEST"))
//                    {        WebDriverManager.chromedriver().setup();
//                    }
//                    else
//                    {
//                        WebDriverManager.chromedriver().version(chromeVersion.split("\\.")[0]).setup();
//                    }
//                   WebDriverManager.chromedriver().setup();
//                   WebDriverManager.chromedriver().version("111.0.5563.110").setup();
//
//                    /*---  Use such version specific setup only when generic setup doesn't work  ----*/
//                    WebDriverManager.chromedriver().version("85.0.4183").setup();
//                    WebDriverManager.chromedriver().version("93.0.4577.82").setup();

                    ChromeOptions options = new ChromeOptions();
                    String optArr[] = getConfig("Chrome_Options").split("&&");

                    for (String opt : optArr) {
                        options.addArguments(opt.trim());
                        logger.info("Chrome option added :" + opt.trim());
                    }

                    //
                    Map<String, Object> prefs = new HashMap<String, Object>();
                    Map<String, Object> profile = new HashMap<String, Object>();
                    Map<String, Object> contentSettings = new HashMap<String, Object>();

                    // SET CHROME OPTIONS
                    // 0 - Default, 1 - Allow, 2 - Block
                    contentSettings.put("geolocation", 1);
                    profile.put("managed_default_content_settings", contentSettings);
                    prefs.put("profile", profile);
                    options.setExperimentalOption("prefs", prefs);


                    WebDriver driver = new ChromeDriver(options);
                    instance.driverMap.put(tId, driver);

                } else if (browser.equalsIgnoreCase("EMULATED_CHROME")) {
                    WebDriverManager.chromedriver().setup();
                    //WebDriverManager.chromedriver().version("96.0.4664.110").setup();
                    Map<String, String> mobileEmulation = new HashMap<>();
                    mobileEmulation.put("deviceName", getConfig("EmulatedDeviceName"));
                    ChromeOptions chromeOptions = new ChromeOptions();
                    chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
                    String optArr[] = getConfig("Emulated_Chrome_Options").split("&&");
                    for (String opt : optArr) {
                        chromeOptions.addArguments(opt.trim());
                        logger.info("Emulated Chrome option added :" + opt.trim());
                    }

                    Map<String, Object> prefs = new HashMap<String, Object>();
                    Map<String, Object> profile = new HashMap<String, Object>();
                    Map<String, Object> contentSettings = new HashMap<String, Object>();

                    // SET CHROME OPTIONS
                    // 0 - Default, 1 - Allow, 2 - Block
                    contentSettings.put("geolocation", 1);
                    profile.put("managed_default_content_settings", contentSettings);
                    prefs.put("profile", profile);
                    chromeOptions.setExperimentalOption("prefs", prefs);
                    WebDriver driver = new ChromeDriver(chromeOptions);
                    instance.driverMap.put(tId, driver);
                } else if (browser.equalsIgnoreCase("CHROME_NETWORK")) {

                    WebDriverManager.chromedriver().setup();

                    ChromeOptions options = new ChromeOptions();
                    String optArr[] = getConfig("Chrome_Options").split("&&");

                    for (String opt : optArr) {
                        options.addArguments(opt.trim());
                        logger.info("Chrome option added :" + opt.trim());
                    }

                    WebDriver driver = new ChromeDriver(options);
                    instance.driverMap.put(tId, driver);

                } else if (browser.equalsIgnoreCase("FIREFOX")) {

                    WebDriverManager.firefoxdriver().version("66.0.3").setup();
                    GeckoDriverService service;

                    // tell firefox to log http requests
                    // at level 4 = PR_LOG_DEBUG: debug messages, notices
                    // you could log everything at level 5, but the log file will
                    // be larger.
                    // create a temporary log file that will be parsed for
                    // response code
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("MOZ_LOG", "timestamp,sync,nsHttp:4");

                    tempFile = new File("MyLogFile.txt");

                    map.put("MOZ_LOG_FILE", tempFile.getAbsolutePath());

                    GeckoDriverService.Builder builder = new GeckoDriverService.Builder();
                    service = builder.usingAnyFreePort()
                            .withEnvironment(map)
                            .build();

                    service.start();

                    WebDriver driver = new FirefoxDriver(service);

                    /*WebDriver driver = new FirefoxDriver();*/
                    driver.manage().window().maximize();
                    instance.driverMap.put(tId, driver);

                } else if (browser.equalsIgnoreCase("IE")) {


                    WebDriverManager.iedriver().setup();
                    WebDriver driver = new InternetExplorerDriver();

                    driver.manage().window().maximize();
                    instance.driverMap.put(tId, driver);

                } else if (browser.equalsIgnoreCase("ANDROID")) {


                    DesiredCapabilities cromaAppCapabilities = new DesiredCapabilities();
                    cromaAppCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, getConfig("AndroidDeviceName"));
                    cromaAppCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, getConfig("AndroidPlatformName"));
                    cromaAppCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, getConfig("AndroidPlatformVersion"));
                    cromaAppCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, getConfig("AndroidAutomationName"));
                    cromaAppCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, getConfig("AndroidBrowserName"));  // browserName for web apps
                    // cromaAppCapabilities.setCapability("autoAcceptAlerts", true);  // pop up auto accept
                    cromaAppCapabilities.setCapability("unicodeKeyboard", true);
                    cromaAppCapabilities.setCapability("resetKeyboard", true);

                    instance.driverMap.put(tId, new AppiumDriver<AndroidElement>(new URL(getConfig("AndroidAppiumServerConnectionUrl")), cromaAppCapabilities));

                } else if (browser.equalsIgnoreCase("IOS")) {

                    DesiredCapabilities iOSCapabilities = new DesiredCapabilities();
                    iOSCapabilities.setCapability("platformName", getConfig("PlatformName"));
                    iOSCapabilities.setCapability("platformVersion", getConfig("PlatformVersion"));
                    iOSCapabilities.setCapability("deviceName", getConfig("DeviceName"));
                    iOSCapabilities.setCapability("automationName",getConfig("AutomationName"));
                    iOSCapabilities.setCapability("browserName", getConfig("BrowserName")); // browserName for web apps
                    // iOSCapabilities.setCapability("App", getConfig("app");  // app for Native apps
                    iOSCapabilities.setCapability("acceptSslCerts",true);
                    iOSCapabilities.setCapability("acceptInsecureCerts",true);
                    iOSCapabilities.setCapability("autoAcceptAlerts",true);
                    iOSCapabilities.setCapability("unicodeKeyboard",true);
                    iOSCapabilities.setCapability("resetKeyboard",true);
                    instance.driverMap.put(tId, new AppiumDriver<IOSElement>(new URL(getConfig("AppiumServerConnectionUrl")), iOSCapabilities));


                } else if (browser.equalsIgnoreCase("CHROME_EA")) {

                    Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");   // Removing all currently open Chrome instances as it blocks Chrome User Data Directory

                    WebDriverManager.chromedriver().setup();

                    Map<String, Object> deviceMetrics = new HashMap<String, Object>();
                    ChromeOptions chromeOptions = new ChromeOptions();
                    chromeOptions.setAcceptInsecureCerts(true);
                    chromeOptions.addArguments("start-maximized");
                    chromeOptions.addArguments("--auto-open-devtools-for-tabs");
                    chromeOptions.addArguments("--user-data-dir=C:\\Users\\350703\\AppData\\Local\\Google\\Chrome\\User Data");


                    WebDriver driver = new ChromeDriver(chromeOptions);
                    instance.driverMap.put(tId, driver);

                    Thread.sleep(2000);

                }


                logger.info("Inside getDriver >> Driver instance created for Thread id: " + tId);
            } else {
                logger.info("Inside getDriver >> Existing Driver instance is returned for Thread: " + tId);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return instance.driverMap.get(tId);
        }


    }


    /**
     * This method removes the existing WebDriver instance from a Thread. This method should be called in @after hook to eliminate driver instance of already executed scenario.
     *
     * @return <b>Boolean</b> value according to success or failure of WebDriver instance removal.
     */

    public static synchronized Boolean removeDriver() {

        String tId = String.valueOf(Thread.currentThread().getId());
        Boolean flag = false;
        if (instance.driverMap.containsKey(tId)) {
            flag = true;
            instance.driverMap.remove(tId);
            logger.info("Driver instance removed for Thread id: " + tId);
        }
        return flag;
    }
    public static String getChromeVersion() throws IOException {
        String query = "C:\\Windows\\SysWOW64\\wbem\\wmic datafile where name='C:\\\\Program Files\\\\Google\\\\Chrome\\\\Application\\\\chrome.exe' get Version /value";    Process process = Runtime.getRuntime().exec(query);
        String browserVersion = new BufferedReader(new InputStreamReader(process.getInputStream())).lines().collect(Collectors.joining("\n")).replace("Version=","").trim();
        return browserVersion;}
}
