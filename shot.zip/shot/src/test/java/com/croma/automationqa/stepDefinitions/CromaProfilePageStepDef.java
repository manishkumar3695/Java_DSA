package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.actionMoveToElementClick;
import static com.croma.automationqa.util.CommonUtil.clearTextBox;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.windowScrollIntoTopToBottom;
import static org.assertj.core.api.Assertions.assertThat;

//import sun.reflect.annotation.ExceptionProxy;


/*
     All the profile page related function defined in CromaProfilePageStepDef class
*/
public class CromaProfilePageStepDef {
    public static String defaultOTP = getConfig("defaultOTP");


    /*
        User provide the profile details and check box for receive promotional mailers and update and validate updation text
    */
    @When("^user provides the profile details \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and check box for receive promotional mailers and update and validate updation text \"([^\"]*)\"$")
    public void userProvidesTheProfileDetailsAndCheckBoxForReceivePromotionalMailersAndUpdateAndValidateUpdationText(String profileTitle1, String profileFirstName1, String profileMiddleName1, String profileLastName1, String profileGender1, String profileMobileNumber1, String profileEmailId1, String profileDob1, String profileAnniversary1, String updationText1) throws InterruptedException {
        logger.info(profileTitle1 + " " + profileFirstName1 + " " + profileMiddleName1 + " " + profileLastName1 + " " + profileDob1 + " " + profileAnniversary1 + " " + profileEmailId1 + " " + " " + profileMobileNumber1 + " " + profileGender1);
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        processScreenshot();
        //email verify
        processScreenshot();
        getElement("emailEditbutton").click();
        clearTextBox(getElement("emailID1"));
        getElement("emailID1").sendKeys(profileEmailId1);
        getElement("emailSendOtpbutton").click();
        if (!defaultOTP.equals("NA")) {
            logger.info("Entering Default OTP : " + defaultOTP);
            Thread.sleep(25000);
            getDriver().findElement(By.xpath("//input[@name='otp']")).sendKeys(defaultOTP);
            String jsString = "document.getElementById(\"partitioned\").value = \"" + defaultOTP + "\"";
            logger.info(jsString);
            ((JavascriptExecutor) getDriver()).executeScript(jsString);
        }
        getElement("validateOtpButton").click();
        Thread.sleep(5000);

        setContext("my_profile_first_name", getElement("firstName").getAttribute("value"));
        setContext("my_profile_middle_name", getElement("middleName").getAttribute("value"));
        setContext("my_profile_last_name", getElement("lastName").getAttribute("value"));
        setContext("my_profile_email_id", getElement("emailID").getAttribute("value"));
        getElement("profileTitle").click();
        getElement("selectProfileTitle", profileTitle1).click();
        clearTextBox(getElement("firstName"));
        getElement("firstName").sendKeys(profileFirstName1);
        clearTextBox(getElement("middleName"));
        getElement("middleName").sendKeys(profileMiddleName1);
        clearTextBox(getElement("lastName"));
        getElement("lastName").sendKeys(profileLastName1);
        getElement("SelectProfileGender", profileGender1).click();




        processScreenshot();
        clearTextBox(getElement("dateOfBirthDatePicker"));
        getElement("dateOfBirthDatePicker").sendKeys(profileDob1);
        clearTextBox(getElement("anniversaryDatePicker"));
        getElement("anniversaryDatePicker").sendKeys(profileAnniversary1);
        if (updationText1.equals("discardChanges")) {
            getElement("discardButton").click();
            assertThat(getElement("firstName").getAttribute("value")).describedAs("Profile first name").
                    isEqualTo(getContext("my_profile_first_name"));
            assertThat(getElement("lastName").getAttribute("value")).describedAs("Profile last name").
                    isEqualTo(getContext("my_profile_last_name"));
            assertThat(getElement("emailID").getAttribute("value")).describedAs("Profile email id").
                    isEqualTo(getContext("my_profile_email_id"));
            logger.info("changes discarded successfully");
        } else {
            getElement("saveButton").click();
            processScreenshot();
            /*profile update validation*/
            String ProfileUpdateText = getElement("ProfileUpdateMsgValidation").getText();
            logger.info("The get texted value is=" + ProfileUpdateText + " The message from data base is:" + updationText1);
            assertThat(ProfileUpdateText).describedAs("Update text is not matching").isEqualTo(updationText1);
        }
        passStepExecution("User provide the profile details and check box for receive promotional mailers and update and validate updation text");
    }


    @And("^user changes password on my profile page with old password \"([^\"]*)\" to new password \"([^\"]*)\"$")
    public void userChangesPasswordOnMyProfilePageWithOldPasswordToNewPassword(String oldPwd, String newPwd) {
        getElement("editPassword").click();
        processScreenshot();
        actionMoveToElementClick(getElement("updatePwdModal"));
        getElement("oldPasswordTextbox").sendKeys(oldPwd);
        getElement("newPasswordTextbox").sendKeys(newPwd);
        getElement("reEnterPasswordTextbox").sendKeys(newPwd);
        windowScrollIntoTopToBottom();
        //   conditionalWait(ExpectedConditions.elementToBeClickable(getElement("saveUpdatePwd")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("saveUpdatePwd").click();
        processScreenshot();
        assertStepExecution("Password updated", getElement("passwordChangeConfirmation").getText(), "Password change unsuccessful");
    }
}