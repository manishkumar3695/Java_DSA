package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.userWaitsForPageLoaderToBeInvisible;
import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.validateCategoryPageTitle;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.getElement;
import static com.croma.automationqa.util.ElementUtil.getOptionalElement;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static org.assertj.core.api.Assertions.assertThat;
import static com.croma.automationqa.util.JavaScriptUtil.*;


/*
     All the username related function defined in CromaSignInUserNameStepDef class
*/
public class CromaSignInStepDef {
    public static String defaultOTP = getConfig("defaultOTP");

    @And("^user provides \"([^\"]*)\" as mobile number and default OTP for log in$")
    public void userProvidesAsMobileNumberAndDefaultOTPForLogIn(String mobileNo) throws Throwable {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("userPhnNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        logger.info("Croma UserPhoneNo is:" + mobileNo + "The Default OTP is: " + defaultOTP);
        setContext("saved_user_mobile_number", mobileNo);
        if (!mobileNo.equals("NA")) {
            getElement("userPhnNumberTextBox").sendKeys(mobileNo);
            processScreenshot();
        }
        Thread.sleep(2000);

        jsClick(getElement("continueSignInButton"));
        if (!defaultOTP.equals("NA")) {
            logger.info("Entering Default OTP : " + defaultOTP);
            Thread.sleep(3000);
            getDriver().findElement(By.xpath("//input[@name='otp']")).sendKeys(defaultOTP);
            String jsString = "document.getElementById(\"partitioned\").value = \"" + defaultOTP + "\"";
            logger.info(jsString);
            ((JavascriptExecutor) getDriver()).executeScript(jsString);
        }
        getElement("submitOtpButton").click();
        userWaitsForPageLoaderToBeInvisible();
        Thread.sleep(5000);
    }

    /*
        User provide login credentials
    */


    @When("^user provides \"([^\"]*)\" as username \"([^\"]*)\" as password$")
    public void userProvidesAsUsernameAsPassword(String userName, String password) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("userPhoneNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        processScreenshot();
        logger.info("Croma UserPhoneNo is:" + userName + "The password is: " + password);
        setContext("saved_user_mobile_number", userName);
        if (!userName.equals("NA")) {
            getElement("userPhoneNumberTextBox").sendKeys(userName);
            processScreenshot();
        }
        getElement("continueSignInButton").click();
/*
        if (!password.equals("NA")) {
            logger.info("inside pwd not null if");
            waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));

            JavascriptExecutor JS = (JavascriptExecutor) getDriver();
            JS.executeScript("callbacks.otpEntered(\"" + password + "\")");

            JS.executeScript("(document.getElementsByClassName(\"confirmButton disabled\"))[0].disabled = false;", getElement("continueOTPButton"));

            JS.executeScript(" (document.getElementsByClassName(\"confirmButton disabled\"))[0].className = \"confirmButton\";", getElement("continueOTPButton"));
        }

        //      processScreenshot();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("continueOTPButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("continueOTPButton").click();*/
        JavascriptExecutor JS = (JavascriptExecutor) getDriver();
        if (!password.equals("NA")) {
            logger.info("inside pwd not null if");
            // waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
            Thread.sleep(25000);
            // getElement("userOtp").sendKeys(password);
//            JS.executeScript("document.getElementsByName(\"otp\").value=9182");
//            JS.executeScript("callbacks.otpEntered(document.getElementsByName(\"otp\").value)");
            getDriver().findElement(By.xpath("//input[@name='otp']")).sendKeys(password);
            String jsString = "document.getElementById(\"partitioned\").value = \"" + defaultOTP + "\"";
            logger.info(jsString);
            ((JavascriptExecutor) getDriver()).executeScript(jsString);

        }

        //     JS.executeScript("document.getElementsByClassName(\"card-button \")[0].click()");
        getElement("validateOtpButton").click();
        Thread.sleep(10000);
    }


    @When("^user provides login credentials \"([^\"]*)\" as login mechanism \"([^\"]*)\" as username \"([^\"]*)\" as password$")
    public void userProvidesLoginCredentialsAsLoginMechanismAsUsernameAsPassword(String loginOption, String userName, String password) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        switch (loginOption) {
            // Login with Email id and password
            case "1":
                getElement("useEmailLoginOption").click();
                logger.info("Croma EmailId is:" + userName + "Croma password is:" + password);
                if (!userName.equals("NA")) {
                    getElement("emailIdTextbox").sendKeys(userName);
                    processScreenshot();
                }
                getElement("continueSignInButton").click();

                if (!password.equals("NA")) {
                    getElement("cromaLoginInPassword").sendKeys(password);
                    processScreenshot();
                    getElement("newPwdShowImage").click();
                }
                processScreenshot();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaSignInButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                getElement("cromaSignInButton").click();

                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("otherLoginOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                processScreenshot();
                getElement("otherLoginOption").click();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaLoginInEmailId")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                processScreenshot();
                logger.info("Croma EmailId is:" + userName + "Croma password is:" + password);
                if (!userName.equals("NA"))
                    getElement("cromaLoginInEmailId").sendKeys(userName);
                if (!password.equals("NA")) {
                    getElement("cromaLoginInPassword").sendKeys(password);
                    processScreenshot();
                    getElement("newPwdShowImage").click();
                }
                processScreenshot();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaSignInButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                getElement("cromaSignInButton").click();
                break;


            // Login with mobile number id and password
            case "2":
                waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                logger.info("Croma UserPhoneNo is:" + userName + "The password is: " + password);
                setContext("saved_user_mobile_number", userName);
                if (!userName.equals("NA")) {
                    getElement("userPhoneNumberTextBox").sendKeys(userName);
                }
                getElement("continueSignInButton").click();
                getElement("usePwdInsteadLink").click();

                if (!password.equals("NA")) {
                    logger.info("inside pwd not null if");
                    waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                    getElement("passwordCromaTextBox").sendKeys(password);
                    getElement("newPwdShowImage").click();
                }
                assertStepExecution(true, getElement("goSignInButton") != null, "Login using mobile number and password");
                getElement("goSignInButton").click();
                break;

            // Login with mobile number id and otp
            case "3":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("userPhoneNumberTextBox")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                processScreenshot();
                logger.info("Croma UserPhoneNo is:- " + userName + " The password is: " + password);
                setContext("saved_user_mobile_number", userName);
                if (!userName.equals("NA")) {
                    getElement("userPhoneNumberTextBox").sendKeys(userName);
                    processScreenshot();
                }
                getElement("continueSignInButton").click();

                if (!password.equals("NA")) {
                    logger.info("inside pwd not null if");
                    waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
                    JavascriptExecutor JS = (JavascriptExecutor) getDriver();
                    JS.executeScript("callbacks.otpEntered(\"" + password + "\")");
                    getElement("enterOTPValue").sendKeys(password);

                }
                //      processScreenshot();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("continueOTPButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                getElement("continueOTPButton").click();
                break;
        }
    }




    /*
         Old login functionality
    */
/*
    @When("^user provides login credentials \"([^\"]*)\" as login mechanism \"([^\"]*)\" as username \"([^\"]*)\" as password$")
    public void userProvidesLoginCredentialsAsLoginMechanismAsUsernameAsPassword(String loginOption, String userName, String password) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        switch (loginOption) {
            // Login with Email id and password
            case "1":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("otherLoginOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                processScreenshot();
                getElement("otherLoginOption").click();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaLoginInEmailId")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                processScreenshot();
                logger.info("Croma EmailId is:" + userName + "Croma password is:" + password);
                if (!userName.equals("NA"))
                    getElement("cromaLoginInEmailId").sendKeys(userName);
                if (!password.equals("NA")) {
                    getElement("cromaLoginInPassword").sendKeys(password);
                    processScreenshot();
                    getElement("newPwdShowImage").click();
                }
                processScreenshot();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaSignInButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                getElement("cromaSignInButton").click();
                break;

            // Login with mobile number id and password
            case "2":
                logger.info("Croma UserPhoneNo is:" + userName + "The password is: " + password);
                if (!userName.equals("NA")) {
                    getElement("userPhoneNumberTextBox").sendKeys(userName);

                }
                getElement("continueSignInButton").click();
                //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("usePwdInsteadLink")), Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")));
                Thread.sleep(5000);
                getElement("usePwdInsteadLink").click();
                if (!password.equals("NA")) {
                    logger.info("inside pwd not null if");
                    waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
                    getElement("passwordCromaTextBox").sendKeys(password);
                    getElement("newPwdShowImage").click();
                }
                assertStepExecution(true, getOptionalElement("goSignInButton")!=null,"Login using mobile number and password");
                //conditionalWait(ExpectedConditions.elementToBeClickable(getElement("goSignInButton")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                getElement("goSignInButton").click();
                break;

            // Login with mobile number id and otp
            case "3":
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("otherLoginOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                processScreenshot();
                getElement("otherLoginOption").click();
                conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnSignUpUsingNumberAndOtp")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
                processScreenshot();
                getElement("clickOnSignUpUsingNumberAndOtp").click();
                processScreenshot();

                logger.info("Croma UserPhoneNo is:" + userName + " The OTP is: " + password);
                setContext("saved_user_mobile_number", userName);
      /*          if (!userName.equals("NA"))
                    getElement("userPhoneNumberTextBox").sendKeys(userName);
                processScreenshot();
                getElement("continueSignInButton").click();
                processScreenshot();
                if (!password.equals("NA")) {
                   logger.info("inside pwd not null if");
                    JavascriptExecutor JS = (JavascriptExecutor) getDriver();
                    JS.executeScript("callbacks.otpEntered(\"" + password + "\")");
                }*/
    //     userProvidesUserNameOtp(userName, password);
    //     processScreenshot();

    //    break;
    // }
    // }


    /*
        user clicks on left back arrow of login password page
    */
    @And("^user clicks on left back arrow of login password page$")
    public void userClicksOnLeftBackArrowOfLoginPasswordPage() {
        getElement("pwdPageLeftBackArrow").click();
        //    waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        processScreenshot();
    }


    /*
        user validates as error message
    */
    @And("^user validates \"([^\"]*)\" as error message for \"([^\"]*)\"$")
    public void userValidatesAsErrorMessageFor(String displayedErrorMessage, String errorMessageOption) {
        if (errorMessageOption.equals("toast-message")) {
            processScreenshot();
            logger.info("Displayed toast message is : " + getElement("validationToastMessage").getText());
            logger.info("Argument message is : " + displayedErrorMessage);
            assertThat(displayedErrorMessage).describedAs("Mobile no OTP field validation").isEqualTo(getElement("validationToastMessage").getText());
            //     waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        } else {
            //   waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
            processScreenshot();
            logger.info("Displayed message is :" + getElement("errorMessageForLoginTextbox", errorMessageOption).getText());
            logger.info("Argument message is :" + displayedErrorMessage);
            assertThat(displayedErrorMessage).describedAs("Email field validation").isEqualTo(getElement("errorMessageForLoginTextbox", errorMessageOption).getText());
        }
        passStepExecution("user validates as error message");
    }


    /*
        user provides new password and confirm password and confirms
    */
    @And("^user provides \"([^\"]*)\" as new password and \"([^\"]*)\" as confirm password and confirms$")
    public void userProvidesAsNewPasswordAndAsConfirmPasswordAndConfirms(String newPwd, String cnfrmPwd) {
        if (!newPwd.equals("NA")) {
            getElement("newPwdFieldForgotPwd").clear();
            getElement("newPwdFieldForgotPwd").sendKeys(newPwd);
            getElement("newPwdShowImage").click();
        }
        if (!cnfrmPwd.equals("NA")) {
            getElement("confirmPwdFieldForgotPwd").clear();
            getElement("confirmPwdFieldForgotPwd").sendKeys(cnfrmPwd);
            getElement("confirmPwdShowImage").click();
        }
        processScreenshot();
        getElement("forgotPwdConfirmButton").click();
    }


    /*
        user clicks on Forgot Password link and provides mobile no and OTP to change password
    */
    @And("^user clicks on forgot password link and provides \"([^\"]*)\" and OTP \"([^\"]*)\" to change password$")
    public void userClicksOnForgotPasswordLinkAndProvidesAndOTPToChangePassword(String mobileno, String otp) {
        processScreenshot();
        getElement("forgotPasswordLink").click();
        //   waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        userProvidesUserNameOtp(mobileno, otp);
        processScreenshot();
    }


    public void userProvidesUserNameOtp(String mobileno, String otp) {
        if (!mobileno.equals("NA"))
            getElement("userPhoneNumberTextBox").sendKeys(mobileno);
        //    waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        processScreenshot();
        getElement("continueSignInButton").click();
        processScreenshot();
        if (!otp.equals("NA")) {
            logger.info("inside pwd not null if");
            JavascriptExecutor JS = (JavascriptExecutor) getDriver();
            JS.executeScript("callbacks.otpEntered(\"" + otp + "\")");
        }
    }

    @And("^user signs up using new mobile number \"([^\"]*)\" as username \"([^\"]*)\" as password$")
    public void userSignUp(String mobileNo, String OTP) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("otherLoginOption")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("otherLoginOption").click();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("clickOnSignUpUsingNumberAndOtp")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("signup").click();
        userProvidesUserNameOtp(mobileNo, OTP);
        logger.info("New user - Croma UserPhoneNo is:" + mobileNo + " The OTP is: " + OTP);
    }

    @And("^user provides \"([^\"]*)\" and \"([^\"]*)\"$")
    public void userSignsUpDetails(String firstName, String lastName) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        getElement("privacyCheckbox").click();
        getElement("firstName").sendKeys(firstName);
        getElement("lastName").sendKeys(lastName);
        getElement("signIn").click();
    }


    @And("^user opens the same URL in a parallel window$")
    public void userOpensSiteInParallelWindow() {
        ((JavascriptExecutor) getDriver()).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(getDriver().getWindowHandles());
        getDriver().switchTo().window(tabs.get(1));
        getDriver().get(getConfig(("URL")));
        assertStepExecution(true, getElement("homePageCroma").isDisplayed(),
                "Navigated to home page");
    }

    /*
       User clicks on login option link
   */
    @When("^user clicks on \"([^\"]*)\" link in login page$")
    public void userClicksOnLinkInLoginPage(String loginOptionLink) {
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("loginOptionLink", loginOptionLink)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getOptionalElement("loginOptionLink", loginOptionLink) != null, "User clicks on login option link");
        getElement("loginOptionLink", loginOptionLink).click();
    }

    /*
            user is navigated to corresponding login option link page
        */
    @Then("^user is navigated to \"([^\"]*)\" corresponding page$")
    public void userIsNavigatedToCorrespondingPage(String loginOptionLinkPageName) {
        userMovesToNewWindow();
        logger.info("Terms & Use Text: " + getElement("categoryPageTitle").getText());
        assertStepExecution(true, getOptionalElement("categoryPageTitle") != null, "user is navigated to corresponding login option link page");
        validateCategoryPageTitle(getElement("categoryPageTitle").getText(), loginOptionLinkPageName);
    }

    @And("^user validates \"([^\"]*)\" on my profile page$")
    public void userValidatesOnMyProfilePage(String userName) throws Throwable {
        actionMoveToElementBuild(getElement("signInUserDetails"));
        actionMoveToElementClick(getElement("userAccountLinkMenu", "My Profile"));
        logger.info("FN value attri: " + getElement("firstNameProfPage").
                getAttribute("value"));
        assertStepExecution(true, getElement("firstNameProfPage").
                getAttribute("value").equalsIgnoreCase(userName), "first name of user in profile page");

    }

    @And("user validates {string} as error message")
    public void userValidatesAsErrorMessage(String displayedErrorMessage) throws InterruptedException {
        logger.info("Displayed toast message is : " + getElement("errorMessage").getText());
        logger.info("Argument message is : " + displayedErrorMessage);
        assertThat(displayedErrorMessage).describedAs("Mobile no field validation").isEqualTo(getElement("errorMessage").getText());
        Thread.sleep(10000);
    }

    @And("user clicks on cross icon on the sign in page")
    public void userClicksOnCrossIconOnTheSignInPage() throws InterruptedException {
        getElement("crossIcon").click();
        Thread.sleep(10000);
    }

    @And("user clicks on validate otp button")
    public void userClicksOnValidateOtpButton() throws InterruptedException {
        processScreenshot();
        getElement("validateOtp").click();
        Thread.sleep(10000);
    }

    @When("user checks my orders section under my profiles should not present without login")
    public void userChecksMyOrdersSectionUnderMyProfilesShouldNotPresentWithoutLogin() {
        assertStepExecution(true,getOptionalElement("myOrderSectionNotPresentWithoutLogin")==null,"user checks my orders section under my profiles should not present without login");
    }
}