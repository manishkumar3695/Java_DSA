package com.croma.automationqa.util;

import com.jayway.jsonpath.JsonPath;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.ScenarioUtil.getScenario;

/**
 * <h3> Purpose:  <p> <h4> &#10687; This class includes all the methods to communicate with QMetry using Open API interface provided by QMetry.
 * <br> &#10687; Main objective of this class is to automate the test execution reporting to QMetry.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @version 1.0 27/06/2020
 */
public class QMetryUtil {

    private static String apiKey = getConfig("API_Key");
    private static String baseURI = getConfig("Base_URL").trim();
    private static long projectId = Long.parseLong(getConfig("Project_Id"));
    private static String testCycleKey = getConfig("Test_Cycle_Key").trim();
    private static String testCycleId;
    private static int executionResultId_Pass = 0;  // executionResultId for Pass
    private static int executionResultId_Fail = 0;  // executionResultId for Fail
    private static int executionResultId_NE = 0;   // executionResultId for Not Executed
    private static HashMap<Long, ArrayList<Long>> testStepExecutionMap = new HashMap<>();
    private static HashMap<String, Long> testCaseExecutionMap = new HashMap<>();
    private static HashMap<String, String> attchParamsMap = new HashMap<>();

    private static Boolean initiationFlag = false;
    private static String environmentId = getConfig("EnvironmentId");
    private static String JSONRespTestCycleTestCaseMap = "";
    private static String QMetryFlag = getConfig("QMetryConn").trim().toLowerCase();
    private static JSONParser parser = new JSONParser(JSONParser.MODE_PERMISSIVE);

    /**
     * This constructor is kept <b>private</b> to prevent users from creating instance of this class by invoking '<b>new</b>' keyword from outside of this class.
     */
    private QMetryUtil() {
    }


    public static synchronized void initiateQMetry() {
        try {
            if (QMetryFlag.equalsIgnoreCase("true")) {


                // Before-Suite activity
                if (initiationFlag == false) {

                    RestAssured.baseURI = baseURI;
                    RestAssured.useRelaxedHTTPSValidation();
                    getExecutionResultId();
                    searchTestCycles();
                    searchLinkedTestCasesWithTestCycle();
                    initiationFlag = true;

                }


                // Before-Scenario activity
                searchTestCaseExecutionId();
                startNewExecution();
                getTestStepExecution();
            }
        } catch (IndexOutOfBoundsException ex) {
            logger.error("Undesired response from QMetry Open API");
            ex.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method searches testCaseExecutionId for current Test Scenario in QMetry.
     *
     * @return <b> int </b> - Test Case Execution Id
     */
    public static int searchTestCaseExecutionId() {

        String scn = "";
        String testCaseExecutionId = "0";
        ArrayList<Integer> arr;
        try {
            scn = getScenario().getName().trim();

            arr = JsonPath.read(JSONRespTestCycleTestCaseMap, "$..[?(@.summary == \"" + scn + "\")].testCaseExecutionId");
            testCaseExecutionId = String.valueOf(arr.get(0));
            setContext("testCaseExecutionId", testCaseExecutionId);
        } catch (IndexOutOfBoundsException ex) {
            ex.printStackTrace();
            logger.error("\n Scenario: " + scn + " is missing in QMetry for current Test Cycle & Project \n");
        } finally {
            return Integer.parseInt(testCaseExecutionId);
        }

    }

    /**
     * This method is automating a PUT request to update status of a testcase in QMetry.
     */
    public static void updateTestCaseExecution() throws ParseException {

        // Creating Request JSON Object
//        JSONObject obj = (JSONObject) p.parse("{ \"executionResultId\": " + executionResultId_Pass + " }");

        String reqJSON = getConfig("Update_Test_Case_Exec_Req_JSON");
        reqJSON = reqJSON.replaceAll("EXECUTION_RESULT_ID_PASS", String.valueOf(executionResultId_Pass));

        JSONObject obj = (JSONObject) parser.parse(reqJSON);

        RestAssured.given()
                .pathParam("id", testCycleId)
                .pathParam("testCaseExecutionId", getContext("testCaseExecutionId"))
                .header("Content-Type", "application/json")
                .header("apiKey", apiKey)
                .body(obj.toJSONString())
                .when()
                .put("testcycles/{id}/testcase-executions/{testCaseExecutionId}");

    }


    /**
     * This method is automating a POST request to fetch Linked Test Cases with TestCycle.
     *
     * @return <b> String </b> - Test Cycle Id
     */
    public static void searchLinkedTestCasesWithTestCycle() throws ParseException {

        // Creating Request JSON Object
        String reqJSON = getConfig("Search_Linked_Test_Case_Req_JSON");

        JSONObject obj = (JSONObject) parser.parse(reqJSON);

        Response response = RestAssured.given()
                .queryParam("fields", "key,summary,status")
                .pathParam("id", testCycleId)
                .header("Content-Type", "application/json")
                .header("apiKey", apiKey)
                .body(obj.toJSONString())
                .when()
                .post("testcycles/{id}/testcases/search/")
                .then()
                .extract()
                .response();

        logger.info("QMetryUtil => Search Linked Test Case with Test Cycle => HTTP STATUS : " + response.getStatusCode());

        JSONRespTestCycleTestCaseMap = response.getBody().asString();
        searchTestCaseExecutionId();


    }


    /**
     * This method is automating a POST request to fetch Test Cycle Ids for Test Cycles present inside a Project
     *
     * @param
     * @return <b> String </b> - Test Cycle Id
     */
    public static void searchTestCycles() throws ParseException {

        // Creating Request JSON Object
        String reqJSON = getConfig("Search_Test_Cycle_Req_JSON");
        reqJSON = reqJSON.replaceAll("PROJECTID", String.valueOf(projectId));

        JSONObject obj = (JSONObject) parser.parse(reqJSON);

        Response response = RestAssured.given()
                .header("Content-Type", "application/json")
                .header("apiKey", apiKey)
                .body(obj.toJSONString())
                .when()
                .post("/testcycles/search/")
                .then()
                .extract()
                .response();


        logger.info(response.getBody().asString());
        ArrayList<String> arr = JsonPath.read(response.getBody().asString(), "$..[?(@.key == '" + testCycleKey + "')].id");
        testCycleId = arr.get(0);

        logger.info("QMetryUtil => Search Test Cycle => HTTP STATUS : " + response.getStatusCode());
        logger.info("QMetryUtil => Search Test Cycle => Response Body : \n\n" + response.getBody().asString() + "\n");
        logger.info("QMetryUtil => Search Test Cycle => TestCycleId : " + testCycleId);

    }


    /**
     * This method is automating a GET request to fetch Execution Result ids corresponding to a projectId (e.g. Id 23994 means Fail and so on)
     *
     * @return <b> List&lt;String&gt; </b> - List of Execution Result Ids
     */
    public static void getExecutionResultId() {


        Response response = RestAssured.given()
                .pathParam("projectId", projectId)
                .header("Content-Type", "application/json")
                .header("apiKey", apiKey)
                .when()
                .get("/projects/{projectId}/execution-results")
                .then()
                .extract()
                .response();

        String body = response.getBody().asString();
        logger.info("QMetryUtil => Get Execution Result Id => HTTP STATUS : " + response.getStatusCode());
        logger.info("QMetryUtil => Get Execution Result Id => Response Body : \n\n" + body + "\n");

        ArrayList<Integer> arr = JsonPath.read(body, "$..[?(@.name =='Fail')].id");
        executionResultId_Fail = arr.get(0);


        arr = JsonPath.read(body, "$..[?(@.name =='Pass')].id");
        executionResultId_Pass = arr.get(0);

        arr = JsonPath.read(body, "$..[?(@.name =='Not Executed')].id");
        executionResultId_NE = arr.get(0);

    }

    /**
     * This method is automating a GET request to fetch a List of testStepExecutionIds corresponding to a TestCase's each Step
     *
     * @param projectId
     * @return <b> List&lt;String&gt; </b> - List of testStepExecutionIds
     */
    public static void getTestStepExecution() {

        Response response = RestAssured.given()
                .pathParam("id", testCycleId)
                .pathParam("testCaseExecutionId", getContext("testCaseExecutionId"))
                .header("Content-Type", "application/json")
                .header("apiKey", apiKey)
                .when()
                .get("testcycles/{id}/testcase-executions/{testCaseExecutionId}/teststeps/")
                .then()
                .extract()
                .response();


        logger.info("QMetryUtil => Get Test Step Execution => HTTP STATUS : " + response.getStatusCode());
        logger.info("QMetryUtil => Get Test Step Execution => Response Body : \n\n" + response.getBody().asString() + "\n");

        ArrayList<Long> arr = JsonPath.read(response.getBody().asString(), "$..testStepExecutionId");

        testStepExecutionMap.put(Thread.currentThread().getId(), arr);
    }


    /**
     * This method is automating a PUT request to update execution result of a test step
     *
     * @param <b>actualResult</b> - Actual result found during execution
     * @param <b>comment</b>      - Comment to be added for the step execution
     * @param <b>status</b>       - Status of execution e.g. Pass, Fail, Not Executed/NE
     */
    public static boolean updateTestStepExecution(String actualResult, String comment, String status) {


        Boolean successFlag = false;
        try {
            if (QMetryFlag.equalsIgnoreCase("true")) {
                status = status.toUpperCase().trim();

                if (status.contains("PASS")) {
                    status = String.valueOf(executionResultId_Pass);
                } else if (status.contains("FAIL")) {
                    status = String.valueOf(executionResultId_Fail);
                    setContext("ExecutionStatus", "Fail");
                } else if ((status.contains("NE")) || (status.contains("NOT EXECUTED"))) {
                    status = String.valueOf(executionResultId_NE);
                }
                // Creating Request JSON Object
//                JSONObject obj = (JSONObject) p.parse("{ \"actualResult\": \"" + actualResult + "\", \"comment\": \"" + comment + "\", \"executionResultId\":\"" + status + "\" }");

                String reqJSON = getConfig("Update_Test_Step_Req_JSON");
                reqJSON = reqJSON.replace("ACTUAL_RESULT", actualResult);
                reqJSON = reqJSON.replace("COMMENT", comment);
                reqJSON = reqJSON.replace("STATUS", status);

                logger.info("############################ ************************ " + reqJSON);

                JSONObject obj = (JSONObject) parser.parse(reqJSON);

                long tId = Thread.currentThread().getId();

                RestAssured.given()
                        .pathParam("id", testCycleId)
                        .pathParam("testStepExecutionId", testStepExecutionMap.get(tId).get(0))
                        .header("Content-Type", "application/json")
                        .header("apiKey", apiKey)
                        .body(obj.toJSONString())
                        .when()
                        .put("testcycles/{id}/teststep-executions/{testStepExecutionId}")
                        .then()
                        .extract()
                        .response();

                uploadTestStepAttachment();

                testStepExecutionMap.get(tId).remove(0);

                successFlag = true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            return successFlag;
        }

    }


    /**
     * This method is automating a PUT request to fetch Execution Result ids corresponding to a projectId (e.g. Id 23994 means Fail and so on)
     *
     * @param projectId
     * @return <b> List&lt;String&gt; </b> - List of Execution Result Ids
     */
    public static void startNewExecution() throws ParseException {

        // Creating Request JSON Object
        String reqJSON = getConfig("Start_New_Exec_Req_JSON");
        reqJSON = reqJSON.replaceAll("ENVIRONMENT_ID", environmentId);
        JSONObject obj = (JSONObject) parser.parse(reqJSON);

        ArrayList<Long> arr = JsonPath.read(JSONRespTestCycleTestCaseMap, "$..[?(@.testCaseExecutionId =='" + getContext("testCaseExecutionId") + "')].testCycleTestCaseMapId");

        Response response = RestAssured.given()
                .pathParam("id", testCycleId)
                .pathParam("testCycleTestCaseMapId", arr.get(0))
                .header("Content-Type", "application/json")
                .header("apiKey", apiKey)
                .body(obj.toJSONString())
                .when()
                .post("/testcycles/{id}/testcases/{testCycleTestCaseMapId}/executions")
                .then()
                .extract()
                .response();

        logger.info("QMetryUtil => Start New Execution => HTTP STATUS : " + response.getStatusCode());
        logger.info("QMetryUtil => Start New Execution => Response Body : \n\n" + response.getBody().asString() + "\n");
        searchLinkedTestCasesWithTestCycle();
    }


    /**
     * This method is automating a GET request to fetch upload credentials corresponding to a testcaseExecutionId
     *
     * @param fileName
     * @param testCaseExecutionId
     */
    public static void getTCExecutionAttachmentCred(String fileName, String testCaseExecutionId) {

        if (QMetryFlag.equalsIgnoreCase("true")) {

            RestAssured.baseURI = baseURI;

            Response response = RestAssured.given()
                    .pathParam("id", testCycleId)
                    .queryParam("fileName", fileName)
                    .queryParam("projectId", projectId)
                    .queryParam("testcaseExecutionId", testCaseExecutionId)
                    .header("apiKey", apiKey)
                    .when()
                    .get("/testcycles/{id}/testcase-executions/attachments/url")
                    .then()
                    .extract()
                    .response();

            String body = response.getBody().asString();
            logger.info("QMetryUtil => Get TestCase Execution Attachment Credentials => HTTP STATUS : " + response.getStatusCode());
            logger.info("QMetryUtil => Get TestCase Execution Attachment Credentials => Response Body : \n\n" + body + "\n");

            ArrayList<String> arr = JsonPath.read(body, "$..endpoint_url");
            attchParamsMap.put("endpoint_URL", arr.get(0));

            arr = JsonPath.read(body, "$..acl");
            attchParamsMap.put("acl", arr.get(0));

            arr = JsonPath.read(body, "$..key");
            attchParamsMap.put("key", arr.get(0));

            arr = JsonPath.read(body, "$..policy");
            attchParamsMap.put("policy", arr.get(0));

            arr = JsonPath.read(body, "$..success_action_status");
            attchParamsMap.put("success_action_status", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-algorithm");
            attchParamsMap.put("x-amz-algorithm", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-credential");
            attchParamsMap.put("x-amz-credential", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-date");
            attchParamsMap.put("x-amz-date", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-signature");
            attchParamsMap.put("x-amz-signature", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-Meta-file-name");
            attchParamsMap.put("x-amz-Meta-file-name", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-Meta-b");
            attchParamsMap.put("x-amz-Meta-b", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-Meta-a");
            attchParamsMap.put("x-amz-Meta-a", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-Meta-c");
            attchParamsMap.put("x-amz-Meta-c", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-Meta-test-case-exe-id");
            attchParamsMap.put("x-amz-Meta-test-case-exe-id", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-Meta-test-case-key");
            attchParamsMap.put("x-amz-Meta-test-case-key", arr.get(0));

            arr = JsonPath.read(body, "$..x-amz-Meta-tc-version-no");
            attchParamsMap.put("x-amz-Meta-tc-version-no", arr.get(0));

        }

    }


    /**
     * This method is automating a POST request to upload result file in Amazon AWS cloud
     *
     * @return <b> List&lt;String&gt; </b> - List of Execution Result Ids
     */
    public static void uploadTCExecutionAttachment(String filePath) {

        if (QMetryFlag.equalsIgnoreCase("true")) {
            RestAssured.baseURI = attchParamsMap.get("endpoint_URL");

            Response response = RestAssured.given()
                    .contentType("multipart/form-data")

                    .multiPart("acl", attchParamsMap.get("acl"))
                    .multiPart("key", attchParamsMap.get("key"))
                    .multiPart("policy", attchParamsMap.get("policy"))
                    .multiPart("success_action_status", attchParamsMap.get("success_action_status"))
                    .multiPart("x-amz-algorithm", attchParamsMap.get("x-amz-algorithm"))
                    .multiPart("x-amz-credential", attchParamsMap.get("x-amz-credential"))
                    .multiPart("x-amz-date", attchParamsMap.get("x-amz-date"))
                    .multiPart("x-amz-signature", attchParamsMap.get("x-amz-signature"))
                    .multiPart("x-amz-Meta-file-name", attchParamsMap.get("x-amz-Meta-file-name"))
                    .multiPart("x-amz-Meta-b", attchParamsMap.get("x-amz-Meta-b"))
                    .multiPart("x-amz-Meta-a", attchParamsMap.get("x-amz-Meta-a"))
                    .multiPart("x-amz-Meta-c", attchParamsMap.get("x-amz-Meta-c"))
                    .multiPart("x-amz-Meta-test-case-exe-id", attchParamsMap.get("x-amz-Meta-test-case-exe-id"))
                    .multiPart("x-amz-Meta-test-case-key", attchParamsMap.get("x-amz-Meta-test-case-key"))
                    .multiPart("x-amz-Meta-tc-version-no", attchParamsMap.get("x-amz-Meta-tc-version-no"))
                    .multiPart("file", new File(filePath))

                    .header("Content-Type", "multipart/form-data")
                    .when()
                    .post()
                    .then()
                    .extract()
                    .response();

            logger.info("QMetryUtil => Upload TestCase Execution Attachment => HTTP STATUS : " + response.getStatusCode());
            logger.info("QMetryUtil => Upload TestCase Execution Attachment => Response Body : \n\n" + response.getBody().asString() + "\n");

            RestAssured.baseURI = baseURI;
        }

    }


    /**
     * This method is automating a GET request & a POST to fetch upload credentials corresponding to a testcaseExecutionId and then upload the attachment with the received credentials
     *
     * @param fileName
     * @param testCaseExecutionId
     */
    public static void uploadTestStepAttachment() {

        try {
            if (QMetryFlag.equalsIgnoreCase("true") &&
                    (getConfig("QMetryStepScreenshotFlag").equalsIgnoreCase("true") ||
                            getContext("testStatus").equalsIgnoreCase("Failed"))) {

                String fileName = processScreenshot();

                RestAssured.baseURI = baseURI;

                Response response = RestAssured.given()
                        .pathParam("id", testCycleId)
                        .queryParam("fileName", fileName)
                        .queryParam("projectId", projectId)
                        .queryParam("testStepExecutionId", testStepExecutionMap.get(Thread.currentThread().getId()).get(0))
                        .header("apiKey", apiKey)
                        .when()
                        .get("/testcycles/{id}/teststep-executions/attachments/url")
                        .then()
                        .extract()
                        .response();

                String body = response.getBody().asString();
                logger.info("QMetryUtil => Get TestStep Execution Attachment Credentials => HTTP STATUS : " + response.getStatusCode());
                logger.info("QMetryUtil => Get TestStep Execution Attachment Credentials => Response Body : \n\n" + body + "\n");

                Map<String, String> uploadCreds = new HashMap<>();

                ArrayList<String> arr = JsonPath.read(body, "$..endpoint_url");
                uploadCreds.put("endpoint_URL", arr.get(0));

                body = body.substring((body.indexOf("params") + 10), body.length() - 2);

                body = body.replace("\"", "");

                String[] fields = body.split(",");

                for (String field : fields) {
                    String[] tupple = field.split(":");
                    uploadCreds.put(tupple[0], tupple[1]);
                }

                response = RestAssured.given()

                        .baseUri(uploadCreds.get("endpoint_URL"))
                        .contentType("multipart/form-data")

                        .multiPart("acl", uploadCreds.get("acl"))
                        .multiPart("key", uploadCreds.get("key"))
                        .multiPart("policy", uploadCreds.get("policy"))
                        .multiPart("success_action_status", uploadCreds.get("success_action_status"))
                        .multiPart("x-amz-algorithm", uploadCreds.get("x-amz-algorithm"))
                        .multiPart("x-amz-credential", uploadCreds.get("x-amz-credential"))
                        .multiPart("x-amz-date", uploadCreds.get("x-amz-date"))
                        .multiPart("x-amz-signature", uploadCreds.get("x-amz-signature"))
                        .multiPart("x-amz-Meta-file-name", uploadCreds.get("x-amz-Meta-file-name"))
                        .multiPart("x-amz-Meta-b", uploadCreds.get("x-amz-Meta-b"))
                        .multiPart("x-amz-Meta-a", uploadCreds.get("x-amz-Meta-a"))
                        .multiPart("x-amz-Meta-c", uploadCreds.get("x-amz-Meta-c"))
                        .multiPart("x-amz-Meta-test-case-exe-id", uploadCreds.get("x-amz-Meta-test-case-exe-id"))
                        .multiPart("x-amz-Meta-test-step-exe-id", uploadCreds.get("x-amz-Meta-test-step-exe-id"))
                        .multiPart("x-amz-Meta-test-step-exe-seq-no", uploadCreds.get("x-amz-Meta-test-step-exe-seq-no"))
                        .multiPart("x-amz-Meta-test-case-key", uploadCreds.get("x-amz-Meta-test-case-key"))
                        .multiPart("x-amz-Meta-tc-version-no", uploadCreds.get("x-amz-Meta-tc-version-no"))
                        .multiPart("file", new File("./target/Screenshots/" + fileName))

                        .header("Content-Type", "multipart/form-data")
                        .when()
                        .post()
                        .then()
                        .extract()
                        .response();

                logger.info("QMetryUtil => Upload TestStep Execution Attachment => HTTP STATUS : " + response.getStatusCode());
                logger.info("QMetryUtil => Upload TestStep Execution Attachment => Response Body : \n\n" + response.getBody().asString() + "\n");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}

