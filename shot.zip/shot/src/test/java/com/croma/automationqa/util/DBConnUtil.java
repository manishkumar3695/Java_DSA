package com.croma.automationqa.util;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

import static com.croma.automationqa.util.FrameworkUtil.getConfig;
import static com.croma.automationqa.util.FrameworkUtil.logger;

/**
 * <h3> Purpose:  <p> <h4> &#10687; This Class contains  Database related Utilities like Methods and Variables.
 * <br> &#10687; It uses Database connection and Database interaction to fetch the data from the Database and make the final feature files.
 *
 * @author Achintya Sett (achintya.sett@tcs.com)
 * @author Abhishek Samanta (samanta.abhishek1@tcs.com)
 * @version 1.0 08/06/2020
 */
public class DBConnUtil {

    /**
     * An Instance of {@link Connection} Class to represent database Connection
     */
    public static Connection con;


    /**
     * An Instance of {@link Statement} Class to represent SQL statement
     */
    public static Statement stmt;


    /**
     * ResultSet returning by executing th SQL Statement
     */
    public static ResultSet rs;


    /**
     * A String variable to store name of the Database
     */
    public static String dbName = getConfig("DBName");


    /**
     * A String variable to store PostgreSQL Connection URL
     */
    public static String connURL = getConfig("ConnURL") + dbName;


    /**
     * A String variable to store Username of PostgreSQL Database
     */
    public static String connUser = getConfig("ConnUser");


    /**
     * A String variable to store Password of PostgreSQL Database
     */
    public static String connPwd = getConfig("ConnPwd");


    /**
     * A String variable to store Driver Name of PostgreSQL Database
     */
    public static String postgresDriver = getConfig("PostgreSQLDriver");

    /**
     * <p>
     * This Method will take select Query as a parameter and get the Database Connection
     * with PostgreSQL Driver to fetch data from the database. It will make an ArrayList
     * of HashMap with String key-value  to consolidate the fetched data rows and return it.
     *
     * @param query A String type variable to contain select Query to fetch data from DB
     * @return arrayListOfHashMap
     * An ArrayList of HashMap witrh String key-value to return consolidate the fetched data rows
     * <p>
     * <p>
     * {@code numberOfColumns} An Integer variable to contain number of columns
     * <p>
     * {@code metadata} An Instance of {@link ResultSetMetaData} Class to contain Meta Information of {@link ResultSet}
     * @see java.sql.Connection
     * @see Class#forName(String)
     * @see DriverManager#getConnection(String, String, String)
     * @see Connection#createStatement()
     * @see Connection#setAutoCommit(boolean)
     * @see Statement#executeQuery(String)
     * @see ResultSet#getMetaData()
     * @see ResultSetMetaData#getColumnCount()
     */
    public static ArrayList<HashMap<String, String>> dbConnect(String query) {

        ArrayList<HashMap<String, String>> arrayListOfHashMap = new ArrayList<>();

        logger.info("query : " + query);

        int numberOfColumns = 0;
        /**
         * <p>
         * {@code try} Block is to ensure if any kind of {@link Exception} occurs
         */
        try {

            logger.info("Database connection started...");
            /**
             *  Get the PostgreSQL Driver and {@link Connection} to execute SQL {@link Statement}
             *  an return the {@link ResultSet}
             */
            Class.forName(postgresDriver);
            con = DriverManager.getConnection(connURL, connUser, connPwd);
            con.setAutoCommit(false);
            logger.info("Opened database successfully");
            stmt = con.createStatement();
            rs = stmt.executeQuery(query);
            ResultSetMetaData metadata = rs.getMetaData();
            numberOfColumns = metadata.getColumnCount();

            /**
             * <p>
             *  While {@link ResultSet}  is having data row iterate the loop
             *  {@code selectedValues} A HashMap of String key-value to store single row of data
             *
             * @see ResultSetMetaData#getColumnName(int)
             * @see ResultSet#getString(int)
             * @see ArrayList#add(Object)
             */
            while (rs.next()) {
                HashMap<String, String> selectedValues = new HashMap();
                for (int j = 1; j <= numberOfColumns; j++) {
                    selectedValues.put(metadata.getColumnName(j), rs.getString(j));
                }
                arrayListOfHashMap.add(selectedValues);
            }

            /**
             * <p>
             * Closing Database Connection, Statement and ResultSet after operation
             * @see Connection#close()
             * @see ResultSet#close()
             * @see Statement#close()
             */
            rs.close();
            stmt.close();
            con.close();

            /**
             * <p>
             * {@code catch} Block is to ctach {@link Exception} to handle it
             *
             * {@code e} An Instnace of {@link Exception}
             * @see Exception#getClass()
             * @see Exception#getMessage()
             * @see Exception#printStackTrace()
             * @see System#exit(int)
             */
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            e.printStackTrace();
            System.exit(0);

            /**
             * <p>
             * {@code finally} Block is to execute irrespective of the fact that
             * any {@link Exception} occurs or not
             */
        } finally {
            logger.info("Operation done successfully");
            return arrayListOfHashMap;
        }
    }


    /**
     * <p>
     * This Method is to insert any Step into {@code Step_Map} Table
     * It will take the step,Table Name and Insert Query as a Parameter
     * and insert the step with Table Name into {@code Step_Map} Table
     *
     * @param queryName A String variable to store Insert Query to insert step and Table name into {@code Step_Map} Table
     * @param table     A String variable to store Table Name to insert into {@code Step_Map} Table
     * @param step      A String variable to store Step Name to insert into {@code Step_Map} Table
     *                  <p>
     *                  {@code smt} An Instance of {@link PreparedStatement} Class
     * @see DriverManager#getConnection(String, String, String)
     * @see Connection#prepareStatement(String)
     * @see PreparedStatement#setString(int, String)
     * @see PreparedStatement#executeUpdate()
     * @see Connection#setAutoCommit(boolean)
     */
    public static void insertStep(String queryName, String table, String step) {
        try {
            logger.info("Database connection started...");
            Class.forName(postgresDriver);
            logger.info("query : " + queryName);
            con = DriverManager.getConnection(connURL, connUser, connPwd);
            PreparedStatement smt = con.prepareStatement(queryName);
            smt.setString(1, step);
            smt.setString(2, table);
            smt.executeUpdate();
            con.setAutoCommit(true);
            logger.info("Data Inserted");
            /**
             * <p>
             * Closing Database Connection, Statement and ResultSet after operation
             * @see Connection#close()
             * @see ResultSet#close()
             * @see Statement#close()
             */
            smt.close();
            con.close();


            /**
             * <p>
             * {@code catch} Block is to ctach {@link Exception} to handle it
             *
             * {@code e} An Instnace of {@link Exception}
             * @see Exception#getClass()
             * @see Exception#getMessage()
             * @see Exception#printStackTrace()
             * @see System#exit(int)
             */
        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println(ex.getClass().getName() + ": " + ex.getMessage());
            System.exit(0);
        }
    }

}
