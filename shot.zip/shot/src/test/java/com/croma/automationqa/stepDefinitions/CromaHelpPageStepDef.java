package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.util.Arrays;

import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.splitTextWithIndexing;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.CommonUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.windowScrollIntoViewAdjustment_scroll;
import static org.assertj.core.api.Assertions.assertThat;

public class CromaHelpPageStepDef {
    JavascriptExecutor js = (JavascriptExecutor) getDriver();
    @And("^user lands on Help and Support Page validate \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\"$")
    public void userLandsOnHelpAndSupportPageValidate(String helpPageHeader, String helpEmail, String helpNumber, String faxNumber) {

        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));

        String stepDescription = "user lands on Help and Support Page validate " + helpPageHeader + "," + helpEmail + "and " + helpNumber;

        String helpPageHeaderTitle = getElement("helpPageHeader").getText();

        logger.info("Help Page Header Title:" + helpPageHeaderTitle);
        assertThat(helpPageHeaderTitle).isEqualTo(helpPageHeader)
                .describedAs(helpPageHeader + " should display in Help Page Connect with Us Section");

//        getDriver().switchTo().frame(getElement("helpPageFrameSection"));

        String helpEmailId = getElement("helpPageEmailId").getText();
        logger.info("Help Page Email:" + helpEmailId);

        assertThat(helpEmailId).isEqualTo(helpEmail)
                .describedAs(helpEmail + " should display in Help Page Connect with Us Section");

        String helpPhoneNumber = getElement("helpPagePhoneNumber").getText();
        logger.info("Help Page Mobile :" + helpPhoneNumber);

        assertThat(helpPhoneNumber).isEqualTo(helpNumber)
                .describedAs(helpNumber + " should display in Help Page Connect with Us Section");

        String helpFaxNumber = getElement("helpFaxNumber").getText();
        logger.info("Help Page Fax :" + helpFaxNumber);

        assertThat(helpFaxNumber).isEqualTo(faxNumber)
                .describedAs(faxNumber + " should display in Help Page Connect with Us Section");

        passStepExecution(stepDescription + " :: Passed \n");

    }

    @When("^user provides \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" details$")
    public void userProvideDetails(String name, String emailId, String mobileNumber, String message) {

        String stepDescription = "user provides " + name + "  , " + name + " , " + emailId + " , " + mobileNumber + " , " + message + " details";

        assertThat(getOptionalElement("helpPageLogInputBoxes", "name")).isNotNull()
                .describedAs("Name input box should be present");
        getElement("helpPageLogInputBoxes", "name").sendKeys(name);

        assertThat(getOptionalElement("helpPageLogInputBoxes", "email")).isNotNull()
                .describedAs("Email input box should be present");
        getElement("helpPageLogInputBoxes", "email").sendKeys(emailId);

        assertThat(getOptionalElement("helpPageLogInputBoxes", "mobile")).isNotNull()
                .describedAs("Mobile input box should be present");
        getElement("helpPageLogInputBoxes", "mobile").sendKeys(mobileNumber);

        assertThat(getOptionalElement("helpPageLogMessageInputBox")).isNotNull()
                .describedAs("Message input box should be present");
        getElement("helpPageLogMessageInputBox").sendKeys(message);

        passStepExecution(stepDescription + " :: Passed \n");
    }

    @And("^user clicks on submit button$")
    public void userClicksOnSubmitButton() {

        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("helpPageSubmitBtn")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        assertStepExecution(true, getOptionalElement("helpPageSubmitBtn") != null,
                "user clicks on submit button");
        // Commenting as getting live call from
        //getElement("helpPageSubmitBtn").click();
    }

    @Then("^service request should be sent and successful message \"([^\"]*)\" should display$")
    public void serviceRequestShouldBeSentAndSuccessfulMessageShouldDisplay(String successMsg) throws InterruptedException {

        String stepDescription = "service request should be sent and successful message " + successMsg + " should display";
       /* String message = getElement("serviceRequestSuccessMsg").getText();
        logger.info("Message After Clicking Submit:" + message);
        assertStepExecution(message, successMsg, stepDescription);*/
        assertStepExecution(true, true, stepDescription);

    }

    @And("^user scroll down to footer$")
    public static void userScrollDownToFooter(WebElement webElement) {
        ((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(false);", webElement);
    }


    @And("user lands on Help and Support Page validate {string} ,{string}, {string} ,{string} , {string}")
    public void userLandsOnHelpAndSupportPageValidate(String moreHelpPageHeader, String officer, String officerName, String helpEmail, String helpNumber) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));

        String stepDescription = "user lands on Help and Support Page validate " + moreHelpPageHeader + "," + officer + "," + officerName + "," + helpEmail + "and " + helpNumber;

        String moreHelpPageHeaderTitle = getElement("moreHelpPageHeader").getText();

        logger.info("Help Page Header Title:" + moreHelpPageHeaderTitle);
        assertThat(moreHelpPageHeaderTitle).isEqualTo(moreHelpPageHeader)
                .describedAs(moreHelpPageHeader + " should display in Need more help Section");

        String officerTitle = getElement("officer", officer).getText();

        logger.info("Officer Title:" + officerTitle);
        assertThat(officerTitle).isEqualTo(officer)
                .describedAs(officer + " should display in Need more help Section");

        String officerNameHelp = getElement("officerName", officer).getText();

        logger.info("Officer Name:" + officerNameHelp);
        assertThat(officerNameHelp).isEqualTo(officerName)
                .describedAs(officerName + " should display in Need more help Section");

        String moreHelpPageEmailId = getElement("moreHelpPageEmailId", officer).getText();
        logger.info("Help Page Email:" + moreHelpPageEmailId);

        assertThat(moreHelpPageEmailId).isEqualTo(helpEmail)
                .describedAs(helpEmail + " should display in Need more help Section");

        String moreHelpPhoneNumber = getElement("moreHelpPagePhoneNumber", officer).getText();
        logger.info("Help Page Mobile :" + moreHelpPhoneNumber);

        assertThat(moreHelpPhoneNumber).isEqualTo(helpNumber)
                .describedAs(helpNumber + " should display in Need more help Section");

        passStepExecution(stepDescription + " :: Passed \n");

    }


    @And("user validates tab name {string} on help and support page")
    public void userValidatesTabNameOnHelpAndSupportPage(String tabName) {
        String helpAndSupportTabName = getElement("helpAndSupportTabName",tabName).getText();

        logger.info("Help Page tab name:" + helpAndSupportTabName);
        assertThat(helpAndSupportTabName).isEqualTo(tabName)
                .describedAs(tabName + " should display in Help and Support Page");
    }


    @And("user clicks on tab name {string} on help and support page")
    public void userClicksOnTabNameOnHelpAndSupportPage(String tabName) throws InterruptedException {
    Thread.sleep(3000);
        assertStepExecution(true, getOptionalElement("helpAndSupportTabName",tabName) != null,
                "user click on "+tabName+" tab");
        getElement("helpAndSupportTabName",tabName).click();
    }

    @And("user lands on my order page having title as {string}")
    public void userLandsOnMyOrderPageHavingTitleAs(String myOrders) {

        String myOrdersTitle = getElement("myOrders").getText();

        logger.info("Help Page tab name:" + myOrdersTitle);
        assertThat(myOrdersTitle).isEqualTo(myOrders)
                .describedAs(myOrders + " should display in My Orders Page");
    }

    @And("user lands on corresponding navigated page {string}")
    public void userLandsOnCorrespondingNavigatedPage(String pageName) {
        String pageTitle = getElement("pageName",pageName).getText();

        logger.info("Page tab name:" + pageTitle);
        assertThat(pageTitle).isEqualTo(pageName)
                .describedAs(pageName + " should display in respective Page");

    }

    @And("user validate the {string} in raise a request page")
    public void userValidateTheInRaiseARequestPage(String raiseARequestHeaderMsg) {
        String raiseARequestHeaderMessage = getElement("raiseARequestHeaderMsg").getText();

        logger.info("Raise a request header message:" + raiseARequestHeaderMessage);
        assertThat(raiseARequestHeaderMessage).isEqualTo(raiseARequestHeaderMsg)
                .describedAs(raiseARequestHeaderMessage + " should display in raise a request page");
    }

    @And("user select complain type {string} in raise a request page")
    public void userSelectComplainTypeInRaiseARequestPage(String complainType) throws InterruptedException {
        getElement("clickOnComplainReasonOneInputBox").click();
        Thread.sleep(2000);
        getElement("clickOnComplainReasonNameInputBox",complainType).click();
        logger.info("First reason selected is "+getElement("clickOnComplainReasonOneInputBox").getText());
        assertThat(getElement("clickOnComplainReasonOneInputBox").getText()).isEqualTo(complainType)
                .describedAs(complainType + " should display in raise a request page");
    }

    @And("user select complain sub type {string} in raise a request page")
    public void userSelectComplainSubTypeInRaiseARequestPage(String complainSubType) throws InterruptedException {
        getElement("clickOnComplainReasonTwoInputBox").click();
        Thread.sleep(2000);
        getElement("clickOnComplainReasonNameInputBox",complainSubType).click();
        logger.info("Second reason selected is "+getElement("clickOnComplainReasonTwoInputBox").getText());
        assertThat(getElement("clickOnComplainReasonTwoInputBox").getText()).isEqualTo(complainSubType)
                .describedAs(complainSubType + " should display in raise a request page");
    }

    @And("user provide order id {string} in raise a request page")
    public void userProvideOrderIdInRaiseARequestPage(String orderId) {
        assertStepExecution(true, getOptionalElement("provideOrderIdInRaiseRequestPage")!=null,
                "user verify order id section is present in raise a request page");
        getElement("provideOrderIdInRaiseRequestPage").sendKeys(orderId);
        logger.info("Order Id is"+getElement("provideOrderIdInRaiseRequestPage").getText());
    }

    @And("user provide detailed description {string} in free text field in raise a request page")
    public void userProvideDetailedDescriptionInFreeTextFieldInRaiseARequestPage(String description) throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("provideDescription")!=null,
                "user verify description section is present in raise a request page");
        getElement("provideDescription").sendKeys(description);
        logger.info("Description is"+getElement("provideDescription").getText());
    }

    @And("user validates select a reason first section is present in raise a request page")
    public void userValidatesSelectAReasonFirstSectionIsPresentInRaiseARequestPage() {
        assertStepExecution(true, getOptionalElement("clickOnComplainReasonOneInputBox").isDisplayed(),
                "user click on reason 1 tab");
    }

    @And("user validates select a reason second section is present in raise a request page")
    public void userValidatesSelectAReasonSecondSectionIsPresentInRaiseARequestPage() {
        assertStepExecution(true, getOptionalElement("clickOnComplainReasonTwoInputBox").isDisplayed(),
                "user click on reason 2 tab");
    }

    @And("user validates enter order id section is present in raise a request page")
    public void userValidatesEnterOrderIdSectionIsPresentInRaiseARequestPage() {
        assertStepExecution(true, getOptionalElement("provideOrderId").isDisplayed(),
                "user validates enter order id section is present in raise a request page");

    }

    @And("user validates detailed description text field is present in raise a request page")
    public void userValidatesDetailedDescriptionTextFieldIsPresentInRaiseARequestPage() {
        assertStepExecution(true, getOptionalElement("provideDescription").isDisplayed(),
                "user validates detailed description text field is present in raise a request page");
    }

    @Then("user validates full name section is present in raise a request page")
    public void userValidatesFullNameSectionIsPresentInRaiseARequestPage() {
        assertStepExecution(true, getOptionalElement("provideFullNameInRaiseRequestPage").isDisplayed(),
                "user validates full name section is present in raise a request page");
    }

    @And("user validates email id section is present in raise a request page")
    public void userValidatesEmailIdSectionIsPresentInRaiseARequestPage() {
        assertStepExecution(true, getOptionalElement("provideEmailInRaiseRequestPage").isDisplayed(),
                "user validates email id section is present in raise a request page");
    }

    @And("user validates mobile no section is present in raise a request page")
    public void userValidatesMobileNoSectionIsPresentInRaiseARequestPage() {
        assertStepExecution(true, getOptionalElement("provideMobileNumberInRaiseRequestPage").isDisplayed(),
                "user validates mobile number section is present in raise a request page");
    }

    @And("user provide full name {string} in raise a request page")
    public void userProvideFullNameInRaiseARequestPage(String fullName) {
        assertStepExecution(true, getOptionalElement("provideFullNameInRaiseRequestPage")!=null,
                "user verify full name section is present in raise a request page");
        getElement("provideFullNameInRaiseRequestPage").sendKeys(fullName);
        logger.info("Full name is"+getElement("provideFullNameInRaiseRequestPage").getText());
    }

    @And("user provide email {string} in raise a request page")
    public void userProvideEmailInRaiseARequestPage(String emailId) {
        assertStepExecution(true, getOptionalElement("provideEmailInRaiseRequestPage")!=null,
                "user verify email section is present in raise a request page");
        getElement("provideEmailInRaiseRequestPage").sendKeys(emailId);
        logger.info("Email is"+getElement("provideEmailInRaiseRequestPage").getText());
    }

    @And("user provide mobile number {string} in raise a request page")
    public void userProvideMobileNumberInRaiseARequestPage(String mobileNumber) {
        assertStepExecution(true, getOptionalElement("provideMobileNumberInRaiseRequestPage")!=null,
                "user verify mobile number section is present in raise a request page");
        getElement("provideMobileNumberInRaiseRequestPage").sendKeys(mobileNumber);
        logger.info("Mobile no is"+getElement("provideMobileNumberInRaiseRequestPage").getText());
    }

    @Then("user clicks on submit request button in raise a request page")
    public void userClicksOnSubmitRequestButtonInRaiseARequestPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("clickOnSubmitInRaiseRequestPage")!=null,
                "user verify submit request button is present in raise a request page");
        getElement("clickOnSubmitInRaiseRequestPage").click();
    }

    @And("user checks order id section is not present in raise a request page")
    public void userChecksOrderIdSectionIsNotPresentInRaiseARequestPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("provideOrderId")==null,
                "user verify sorder id section is not present in raise a request page");
    }

    @Then("user validates service request successful message {string}")
    public void userValidatesServiceRequestSuccessfulMessage(String serviceRequestMsg) throws InterruptedException {
        Thread.sleep(2000);
        conditionalWait(ExpectedConditions.visibilityOf(getElement("replacementMessage", serviceRequestMsg)), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        logger.info("service request message is: " + getElement("replacementMessage", serviceRequestMsg).getText());
        assertStepExecution(serviceRequestMsg, getElement("replacementMessage", serviceRequestMsg).getText(), "user validates service request message");
        String getSRIDNo=getElement("getSRIDNo").getText();
        logger.info("SR Id number is: "+getSRIDNo);
        setContext("getSRIDNo",getSRIDNo);
        logger.info("Service request message is: "+getElement("returnRequestMsg").getText());
    }

    @And("user closes the login popup")
    public void userClosesTheLoginPopup() {
        assertStepExecution(true, getOptionalElement("closePopUp")!=null,
                "user clicks on close button");
        getElement("closePopUp").click();
    }

    @And("user validates full name section is blank in raise a request page")
    public void userValidatesFullNameSectionIsBlankInRaiseARequestPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("provideFullNameInRaiseRequestPage").getText().isEmpty(),
                "user verify full name section is not blank in raise a request page");
    }

    @And("user validates email id section is blank in raise a request page")
    public void userValidatesEmailIdSectionIsBlankInRaiseARequestPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("provideEmailInRaiseRequestPage").getText().isEmpty(),
                "user verify email section is not blank in raise a request page");
    }

    @And("user validates mobile no section is blank in raise a request page")
    public void userValidatesMobileNoSectionIsBlankInRaiseARequestPage() throws InterruptedException {
        Thread.sleep(2000);
        assertStepExecution(true, getOptionalElement("provideMobileNumberInRaiseRequestPage").getText().isEmpty(),
                "user verify mobile no section is not blank in raise a request page");
    }

    @And("user clicks on My Service Request link from the pop-up")
    public void userClicksOnMyServiceRequestLinkFromThePopUp() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(4000);
        assertStepExecution(true, getOptionalElement("myServiceRequestLink")!=null, "user not able to clicks on My Service Request link");
        getElement("myServiceRequestLink").click();
    }

    @And("user lands on My Service Request page")
    public void userLandsOnMyServiceRequestPage() {
        String CurrentUrl = getDriver().getCurrentUrl();
        logger.info("CurrentUrl is :"+CurrentUrl);
        assertThat(CurrentUrl.contains("service-requests")).describedAs("user lands on My Service Requests page");
        String serviceRequestsPageName = "My Service Requests";
        logger.info("Service Requests Page Name is :" +getElement("serviceRequestsPageName").getText());
        assertThat(getElement("serviceRequestsPageName").getText()).isEqualTo(serviceRequestsPageName).describedAs(serviceRequestsPageName + " should display in respective Page");
    }

    @And("user validates the service request displayed in my service request page")
    public void userValidatesTheServiceRequestDisplayedInMyServiceRequestPage() throws InterruptedException {
         String SRId=getContext("getSRIDNo");
         SRId=splitTextWithIndexing(SRId,"- ",1);
        String SRID=getElement("SRIDFromSRPage",SRId).getText();
        logger.info("SR Id number is: "+SRID+" and saved id: "+SRId);
        assertThat(SRID).isEqualTo(SRId).describedAs("user validates the service request displayed in my service request page");
        Thread.sleep(5000);
    }

    @And("user validate upload image or video component {string} should appear for the category")
    public void userValidateUploadImageOrVideoComponentShouldAppearForTheCategory(String uploadImageMsg) {
        assertStepExecution(true, getElement("uploadPhotoVideoMsg").getText().equals(uploadImageMsg), "user validates Image/Video upload message is not present");
        assertStepExecution(true, getElement("uploadPhotoVideoComponent").isDisplayed(),"user validates Image/Video upload component is not present");
        getElement("uploadPhotoVideoComponent");

    }

    @And("user validates full name, email id, mobile section are autofilled after logged in user")
    public void userValidatesFullNameEmailIdMobileSectionAreAutofilledAfterLoggedInUser() throws InterruptedException {
        Thread.sleep(5000);
        assertThat(getElement("provideFullNameInRaiseRequestPage").getText()).describedAs("user verify full name section is blank in raise a request page").isNotNull();
        assertThat(getElement("provideEmailInRaiseRequestPage").getText()).describedAs("user verify Email id section is blank in raise a request page").isNotNull();
        assertThat(getElement("provideMobileNumberInRaiseRequestPage").getText()).describedAs("user verify mobile number section is blank in raise a request page").isNotNull();

        passStepExecution("User validates full name, email id, mobile section are autofilled after logged in user");
    }

    @And("user validate upload image or video component {string} should not appear for the category")
    public void userValidateUploadImageOrVideoComponentShouldNotAppearForTheCategory(String arg0) {
        //js.executeScript("window.scrollBy(0,400)");
        assertStepExecution(true, getOptionalElement("uploadPhotoVideoComponent") == null, "user validates Image/Video upload component is present");
    }

    @And("user clicks on the signin link on help and support page")
    public void userClicksOnTheSigninLinkOnHelpAndSupportPage() {
        getElement("signInLink").click();
    }
}
