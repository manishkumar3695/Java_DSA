package com.croma.automationqa.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.croma.automationqa.stepDefinitions.CromaCommonStepDef.*;
import static com.croma.automationqa.util.AssertUtil.assertStepExecution;
import static com.croma.automationqa.util.AssertUtil.passStepExecution;
import static com.croma.automationqa.util.CommonUtil.numericValuesExtractionMethod;
import static com.croma.automationqa.util.CommonUtil.splitTextWithIndexing;
import static com.croma.automationqa.util.ContextUtil.getContext;
import static com.croma.automationqa.util.ContextUtil.setContext;
import static com.croma.automationqa.util.DriverUtil.getDriver;
import static com.croma.automationqa.util.ElementUtil.*;
import static com.croma.automationqa.util.FrameworkUtil.*;
import static com.croma.automationqa.util.JavaScriptUtil.windowScrollIntoViewAdjustment;
import static com.croma.automationqa.util.JavaScriptUtil.windowScrollIntoViewByWebElement;
import static org.assertj.core.api.Assertions.assertThat;
import static com.croma.automationqa.util.CommonUtil.*;

/*
   All the order confirmation page related function defined in CromaOrderConfirmationPageStepDef class
*/
public class CromaOrderConfirmationPageStepDef {
    JavascriptExecutor js = (JavascriptExecutor) getDriver();


    /*
           User validate the order confirmation message,order delivery address,order billing address,order delivery mode,oder payment mode,order amount and product details

    @Then("^user validates the order confirmation message \"([^\"]*)\", \"([^\"]*)\", order delivery address \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", order billing address \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", order delivery mode \"([^\"]*)\", order Payment mode \"([^\"]*)\", order amount and product details$")
    public void userValidatesTheOrderConfirmationMessageOrderDeliveryAddressOrderBillingAddressOrderDeliveryModeOrderPaymentModeOrderAmountAndProductDetails(String orderConfirmationMessage, String orderConfirmationEmailId1, String orderDeliveryContactName, String orderDeliveryContactNumber, String orderDeliveryAddress1, String orderBillingContactName, String orderBillingContactNumber, String orderBillingAddress1, String orderDeliveryMode1, String orderPaymentMode1) {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        int confirmationEmailSubStringValue = 37, confirmationTotalProductCountSubStringFirstIndexValue = 1, confirmationTotalProductCountSubStringLastIndexValue = 2, confirmationDeliveryModeSubStringValue = 16, orderConfirmationPageScrollDownFirstIndex = 0, orderConfirmationPageScrollDownLastIndex = 200;
        String splitOption = "\\|", splitOption1 = "\\.", comparisonOrder = "ReverseOrder", replaceOption = "\n", replaceOptionOne = "  ";
        logger.info("Order Confirmation page Executed");
        getDriver().switchTo().defaultContent();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaOrderReceivedMsgXpath")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        processScreenshot();
        // getting all the getContext from cart page
        String orderedCromaProductDetailsCountFromContext = getContext("finalProductDetailsCount");
        String orderedCromaProductDetailsNameFromContext = getContext("finalProductDetailsProductNamesDetails");
        String orderedCromaProductDetailsQuantityFromContext = getContext("finalProductDetailsProductQuantityDetails");
        String orderedCromaProductDetailsPriceFromContext = getContext("finalProductDetailsProductPriceDetails");
        String orderCromaConfirmationTotalPriceFromContext = getContext("finalCartOrderedTotalPrice");
        logger.info("Final ordereded product name fetch in Confirmation Page from setContext: " + orderedCromaProductDetailsCountFromContext + " and Names " + orderedCromaProductDetailsNameFromContext + " and quantity " + orderedCromaProductDetailsQuantityFromContext + " total price in confirmation page: " + orderCromaConfirmationTotalPriceFromContext);
        // Confirmation message verification
        String orderConfirmationMsg = getElement("cromaOrderReceivedMsgXpath").getText();
        logger.info("Delivery orderConfirmation msg is " + orderConfirmationMsg + " " + orderConfirmationMessage);
        assertThat(orderConfirmationMsg).describedAs("Order confirmation message is not matching").isEqualTo(orderConfirmationMessage);
        // Confirmation email verification
        String orderConfirmationMsgEmail = getElement("cromaOrderReceivedMsgWithEmailXpath").getText();
        orderConfirmationMsgEmail = orderConfirmationMsgEmail.substring(confirmationEmailSubStringValue);
        logger.info("Delivery orderConfirmationMsgEmail is " + orderConfirmationMsgEmail + " " + orderConfirmationEmailId1);
        assertThat(orderConfirmationMsgEmail).describedAs("Email Id not matching in order confirmation page").isEqualTo(orderConfirmationEmailId1);
        // Confirmation order no verification
        String orderConfirmationOrderNumber = getElement("cromaOrderReceivedMsgWithOrderNoXpath").getText();
        logger.info("Delivery orderConfirmationMsgOrder is " + orderConfirmationOrderNumber);
        assertThat(orderConfirmationOrderNumber).describedAs("Order number message not present in order confirmation page").isNotEmpty();
        // Confirmation ordered product count number verification
        String orderConfirmationTotalProductCount = getElement("cromaOrderTotalProductCountXpath").getText();
        orderConfirmationTotalProductCount = orderConfirmationTotalProductCount.substring(confirmationTotalProductCountSubStringFirstIndexValue, confirmationTotalProductCountSubStringLastIndexValue);
        logger.info("Delivery orderConfirmationTotalProductCount is " + orderConfirmationTotalProductCount + " From SetContext " + orderedCromaProductDetailsCountFromContext);
        assertThat(orderConfirmationTotalProductCount).describedAs("Ordered product count is not matching in order confirmation page").isEqualTo(String.valueOf(orderedCromaProductDetailsCountFromContext));


        // Decoding all the product names and quantity from setContext in cart and checkout page
        List<String> itemListOrderedProductName = generatingProductDetailsListThroughCount(orderedCromaProductDetailsCountFromContext, orderedCromaProductDetailsNameFromContext, splitOption);
        List<String> itemListOrderedProductQuantity = generatingProductDetailsListThroughCount(orderedCromaProductDetailsCountFromContext, orderedCromaProductDetailsQuantityFromContext, splitOption);
        List<String> itemListOrderedProductPrice = generatingProductDetailsListThroughCount(orderedCromaProductDetailsCountFromContext, orderedCromaProductDetailsPriceFromContext, splitOption);
        logger.info("itemListOrderedProductName is: " + itemListOrderedProductName + " itemListOrderedProductQuantity is: " + itemListOrderedProductQuantity + " itemListOrderedProductPrice is: " + itemListOrderedProductPrice);
        // Getting and verifying all the product names and quantity from confirmation page
        productComparisonValidation(getElements("cromaOrderConfirmationNameListXpath"), itemListOrderedProductName, comparisonOrder);
        productComparisonValidation(getElements("cromaOrderConfirmationQuantityListXpath"), itemListOrderedProductQuantity, comparisonOrder);
        productComparisonValidation(getElements("cromaOrderConfirmationPriceListXpath"), itemListOrderedProductPrice, comparisonOrder);
        logger.info(getContext("storeDeliveryEnableFlag"));
        if (getContext("storeDeliveryEnableFlag").equals("false")) {
            // Confirmation delivery address verification
            windowScrollIntoViewByWebElement(getElement("cromaOrderReceivedDeliveryContactXpath"));
            windowScrollIntoViewAdjustment(orderConfirmationPageScrollDownFirstIndex, orderConfirmationPageScrollDownLastIndex);
            String orderConfirmationDeliveryContactName = getElement("cromaOrderReceivedDeliveryContactXpath").getText();
            String orderConfirmationDeliveryContactNumber = getElement("cromaOrderReceivedDeliveryContactNumberXpath").getText();
            String orderConfirmationDeliveryAddress = getElement("cromaOrderReceivedDeliveryAddressXpath").getText();
            logger.info("Delivery address is in confirmation page " + orderConfirmationDeliveryContactName + " " + orderConfirmationDeliveryContactNumber + " " + orderConfirmationDeliveryAddress + "Delivery address is in confirmation page arg " + orderDeliveryContactName + " " + orderDeliveryContactNumber + " " + orderDeliveryAddress1);
            assertThat(orderConfirmationDeliveryContactName).describedAs("Delivery contact name is not matching in order confirmation page").isEqualTo(orderDeliveryContactName);
            assertThat(orderConfirmationDeliveryContactNumber).describedAs("Delivery contact number is not matching in order confirmation page").isEqualTo(orderDeliveryContactNumber);
            assertThat(orderConfirmationDeliveryAddress).describedAs("Delivery address is not matching in order confirmation page").isEqualTo(orderDeliveryAddress1);
        } else if (getContext("storeDeliveryEnableFlag").equals("true")) {
            // Confirmation pickup address verification
            windowScrollIntoViewByWebElement(getElement("cromaOrderReceivedPickUpContactXpath"));
            windowScrollIntoViewAdjustment(orderConfirmationPageScrollDownFirstIndex, orderConfirmationPageScrollDownLastIndex);
            String orderConfirmationPickUpTitle = "PICKUP ADDRESS";
            String orderConfirmationPickUpContactName = getElement("cromaOrderReceivedPickUpContactXpath").getText();
            String orderConfirmationPickUpAddress = getElement("cromaOrderReceivedPickUpAddressXpath").getText();
            logger.info("PickUp address is in confirmation page " + getElement("cromaOrderReceivedPickUpXpath").getText() + " " + orderConfirmationPickUpContactName + " " + orderConfirmationPickUpAddress + "PickUp address is in confirmation page arg " + getContext("finalStoreDeliveryName") + " " + getContext("finalStoreDeliveryAddress"));
            assertThat(orderConfirmationPickUpTitle).describedAs("Pickup title is not matching in order confirmation page").isEqualToIgnoringCase(getElement("cromaOrderReceivedPickUpXpath").getText());
            assertThat(orderConfirmationPickUpContactName).describedAs("Pickup contact name is not matching in order confirmation page").isEqualToIgnoringCase(getContext("finalStoreDeliveryName"));
            assertThat(orderConfirmationPickUpAddress).describedAs("Pickup address is not matching in order confirmation page").isEqualToIgnoringCase(getContext("finalStoreDeliveryAddress"));
        }
        processScreenshot();

        // Confirmation billing address verification
        String orderConfirmationBillingContactName = getElement("cromaOrderReceivedBillingContactXpath").getText();
        String orderConfirmationBillingContactNumber = getElement("cromaOrderReceivedBillingContactNumberXpath").getText();
        String orderConfirmationBillingAddress = getElement("cromaOrderReceivedBillingAddressXpath").getText();
        logger.info("Delivery orderConfirmationBillingAddress is " + orderConfirmationBillingContactName + " " + orderConfirmationBillingContactNumber + " " + orderConfirmationBillingAddress);
        logger.info("Delivery orderConfirmationBillingAddress is from arg " + orderBillingContactName + " " + orderBillingContactNumber + " " + orderBillingAddress1);
        assertThat(orderConfirmationBillingContactName).describedAs("Billing contact name is not matching in order confirmation page").isEqualTo(orderBillingContactName);
        assertThat(orderConfirmationBillingContactNumber).describedAs("Billing contact number is not matching in order confirmation page").isEqualTo(orderBillingContactNumber);
        assertThat(orderConfirmationBillingAddress).describedAs("Billing address is not matching in order confirmation page").isEqualTo(orderBillingAddress1);

        // Confirmation delivery mode verification
        String orderConfirmationDeliveryMode = getElement("cromaOrderReceivedDeliveryModeXpath").getText();

        // orderConfirmationDeliveryMode = orderConfirmationDeliveryMode.replace("\n", " ").replace("  ", " ").substring(confirmationDeliveryModeSubStringValue);
        orderConfirmationDeliveryMode = removeLinesBreaksMethod(removeLinesBreaksMethod(orderConfirmationDeliveryMode, replaceOption), replaceOptionOne).substring(confirmationDeliveryModeSubStringValue);
        logger.info("Delivery orderConfirmationDeliveryMode is in confirmation page " + orderConfirmationDeliveryMode + " " + orderDeliveryMode1);
        assertThat(orderConfirmationDeliveryMode).describedAs("Delivery mode is not matching in order confirmation page").isEqualTo(orderDeliveryMode1);

        // Confirmation payment mode verification
        String orderConfirmationPaymentMethod = getElement("cromaOrderReceivedPaymentModeXpath").getText();
        logger.info("Payment mode is in confirmation page " + orderConfirmationPaymentMethod);
        assertThat(orderConfirmationPaymentMethod).isEqualToIgnoringCase(orderPaymentMode1);

        // Confirmation total price verification
        String orderConfirmationTotalPrice = getElement("cromaOrderTotalPriceXpath").getText();
        assertThat(orderConfirmationTotalPrice).describedAs("Total Price amount is not matching in order confirmation page").isEqualTo(orderCromaConfirmationTotalPriceFromContext);
        logger.info("Delivery orderConfirmationTotalPrice is " + orderConfirmationTotalPrice + " " + orderCromaConfirmationTotalPriceFromContext);

        //confirmation coupon amount verification
        logger.info(getContext("coupon_applied_flag_cart"));
        if (getContext("coupon_applied_flag_cart").equals("true")) {
            logger.info("Coupon title is in order confirmation page is: " + getElement("cromaOrderCouponTitle").getText() + " " + "Coupon amount is in confirmation page: " + (numericValuesExtractionMethod(splitTextWithIndexing(getElement("cromaOrderCouponAmountXpath").getText(), splitOption1, orderConfirmationPageScrollDownFirstIndex))) + " " + "Saved gift item amount from cart page: " + getContext("finalCouponCodeAmount"));

            assertThat(String.valueOf(numericValuesExtractionMethod(splitTextWithIndexing(getElement("cromaOrderCouponAmountXpath").getText(), splitOption1, orderConfirmationPageScrollDownFirstIndex)))).isEqualTo(getContext("finalCouponCodeAmount"));
        }
        //confirmation gift item amount verification
        logger.info(getContext("gift_item_applied_flag_cart"));
        if (getContext("gift_item_applied_flag_cart").equals("true")) {
            logger.info("Gift item title is in order confirmation page is: " + getElement("cromaOrderGiftItemTitle").getText() + " " + "Gift item amount is in confirmation page " + getElement("cromaOrderGiftItemAmountXpath").getText() + " " + "Saved gift item amount from cart page" + getContext("finalGiftItemAmount"));
            assertThat(getElement("cromaOrderGiftItemAmountXpath").getText()).isEqualTo(getContext("finalGiftItemAmount"));
        }
        //confirmation donation amount verification
        logger.info(getContext("donation_applied_flag_cart"));
        if (getContext("donation_applied_flag_cart").equals("true")) {
            logger.info("Donation title is in order confirmation page is: " + getElement("cromaOrderDonationTitle").getText() + " " + "Donation amount is in confirmation page " + getElement("cromaOrderDonationAmountXpath").getText() + " " + "Saved gift item amount from cart page" + getContext("finalDonationAmount"));
            assertThat(getElement("cromaOrderDonationAmountXpath").getText()).isEqualTo(getContext("finalDonationAmount"));
        }

        // Setting date and order confirmation number
        setContext("cromaOrderConfirmationNumber", orderConfirmationOrderNumber);
        String orderConfirmationDate = getElement("cromaOrderConfirmationDateXpath").getText();
        setContext("cromaOrderConfirmationDate", orderConfirmationDate);
        logger.info("Substring OrderNo : " + getContext("cromaOrderConfirmationNumber") + " date is: " + getContext("cromaOrderConfirmationDate"));
        windowScrollIntoViewByWebElement(getElement("cromaOrderConfirmationPageBelowContinueButtonXpath"));
        windowScrollIntoViewAdjustment(orderConfirmationPageScrollDownFirstIndex, orderConfirmationPageScrollDownLastIndex);
        processScreenshot();
        getElement("cromaOrderConfirmationPageBelowContinueButtonXpath").click();

        passStepExecution("Order confirmation page displays correct results");
    }

     */

    /*
       User validate the order confirmation message,order delivery address,order billing address,order delivery mode,oder payment mode,order amount and product details
    */
    @Then("^user validates the order confirmation message \"([^\"]*)\", \"([^\"]*)\", order delivery address \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", order billing address \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", order delivery mode \"([^\"]*)\", order Payment mode \"([^\"]*)\", order amount and product details$")
    public void userValidatesTheOrderConfirmationMessageOrderDeliveryAddressOrderBillingAddressOrderDeliveryModeOrderPaymentModeOrderAmountAndProductDetails(String orderConfirmationMessage, String orderConfirmationEmailId1, String orderDeliveryContactType, String orderDeliveryContactNumber, String orderDeliveryAddress1, String orderBillingContactName, String orderBillingContactNumber, String orderBillingAddress1, String orderDeliveryMode1, String orderPaymentMode1) {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("POLLING_WAIT")));
        int confirmationEmailSubStringValue = 37, confirmationTotalProductCountSubStringFirstIndexValue = 1, confirmationTotalProductCountSubStringLastIndexValue = 2, confirmationDeliveryModeSubStringValue = 16, orderConfirmationPageScrollDownFirstIndex = 0, orderConfirmationPageScrollDownLastIndex = 200;
        String splitOption = "\\|", splitOption1 = "\\.", comparisonOrder = "ReverseOrder", replaceOption = "\n", replaceOptionOne = "  ", splitOption2 = "to ";
        logger.info("Order Confirmation page Executed");
        getDriver().switchTo().defaultContent();
        conditionalWait(ExpectedConditions.elementToBeClickable(getElement("cromaOrderReceivedMsgXpath")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        // getting all the getContext from cart page
        String orderedCromaProductDetailsCountFromContext = getContext("finalProductDetailsCount");
        String orderCromaConfirmationTotalPriceFromContext = getContext("finalCartOrderedTotalPrice");
        logger.info("Final ordereded product name fetch in Confirmation Page from setContext: " + orderedCromaProductDetailsCountFromContext + " total price in confirmation page: " + orderCromaConfirmationTotalPriceFromContext);
        // Confirmation message verification
        String orderConfirmationMsg = getElement("cromaOrderReceivedMsgXpath").getText();
        logger.info("Delivery orderConfirmation msg is " + orderConfirmationMsg + " " + orderConfirmationMessage);
        assertThat(orderConfirmationMsg).describedAs("Order confirmation message is not matching").isEqualTo(orderConfirmationMessage);
        // Confirmation email verification
        String orderConfirmationMsgEmail = getElement("cromaOrderReceivedMsgWithEmailXpath").getText().substring(confirmationEmailSubStringValue);
        logger.info("Delivery orderConfirmationMsgEmail is " + orderConfirmationMsgEmail + " " + orderConfirmationEmailId1);
        assertThat(orderConfirmationMsgEmail).describedAs("Email Id not matching in order confirmation page").containsIgnoringCase(orderConfirmationEmailId1);
        // Confirmation order no verification
        String orderConfirmationOrderNumber = getElement("cromaOrderReceivedMsgWithOrderNoXpath").getText();
        logger.info("Delivery orderConfirmationMsgOrder is " + orderConfirmationOrderNumber);
        assertThat(orderConfirmationOrderNumber).describedAs("Order number message not present in order confirmation page").isNotEmpty();

        // validating all the product details in cart and checkout page
        int totalProduct = Integer.parseInt(orderedCromaProductDetailsCountFromContext);
        for (int product = totalProduct - confirmationTotalProductCountSubStringFirstIndexValue, index = orderConfirmationPageScrollDownFirstIndex; product >= orderConfirmationPageScrollDownFirstIndex && index < totalProduct; product--, index++) {
           /* if (getElements("cromaOrderConfirmationNameListXpath").get(index).getText() !=productMap.get(product).get("productName")){
                product++;
            }*/

            logger.info("Indices to check : index: " + index + " product : " + product);
            logger.info("Displayed name: " + getElements("cromaOrderConfirmationNameListXpath").get(index).getText() +
                    " saved name: " + productMap.get(product).get("productName"));
            logger.info("Displayed id: " + getElements("cromaOrderConfirmationIdListXpath").get(index).getText() +
                    " product id: " + productMap.get(product).get("productId"));
            logger.info("Displayed qty: " + getElements("cromaOrderConfirmationQuantityListXpath").get(index).getText() +
                    " product qty: " + productMap.get(product).get("productQty"));
            logger.info("Displayed price: " + getElements("cromaOrderConfirmationPriceListXpath").get(index).getText() +
                    " product price: " + productMap.get(product).get("productPrice"));


            assertThat(getElements("cromaOrderConfirmationNameListXpath").get(index).getText())
                    .isEqualToIgnoringCase(productMap.get(product).get("productName"));
            assertThat(getElements("cromaOrderConfirmationIdListXpath").get(index).getText())
                    .isEqualToIgnoringCase(productMap.get(product).get("productId"));
            assertThat(getElements("cromaOrderConfirmationQuantityListXpath").get(index).getText())
                    .isEqualToIgnoringCase(productMap.get(product).get("productQty"));
            assertThat(getElements("cromaOrderConfirmationPriceListXpath").get(index).getText().replace("₹", ""))
                    .isEqualToIgnoringCase(productMap.get(product).get("productPrice"));
            /*if (getElements("cromaOrderConfirmationNameListXpath").get(index).getText().equalsIgnoreCase(productMap.get(product).get("productName"))){
                product--;
            }*/
            // assertThat(getElements("cromaOrderCouponAmountXpath").get(index).getText())
            //  .isEqualToIgnoringCase(productMap.get(product).get("todaysSaving"));
        }
        productMap.clear();

        //Checking whether store delivery flag true or false
        logger.info(getContext("storeDeliveryEnableFlag"));
        if (getContext("storeDeliveryEnableFlag").equals("false")) {
            // Confirmation delivery address verification
            List<WebElement> deliveryAddress = getDriver().findElements(By.xpath(getLocator("cromaOrderConfirmationStoreDeliveryAddressListXpath")));
            logger.info("No of delivery address are: " + deliveryAddress.size());
            if (deliveryAddress.size() > orderConfirmationPageScrollDownFirstIndex) {
                for (int i = confirmationTotalProductCountSubStringFirstIndexValue; i <= deliveryAddress.size(); i++) {
                    logger.info(getElement("cromaOrderConfirmationStoreDeliveryTypeListXpath", String.valueOf(i)).getText());
                    logger.info(getElement("cromaOrderConfirmationStoreDeliveryExpectedDateListXpath", String.valueOf(i)).getText());
                    logger.info(getElement("cromaOrderConfirmationStoreDeliveryAddressListXpath", String.valueOf(i)).getText());
                    assertThat(getElement("cromaOrderConfirmationStoreDeliveryTypeListXpath", String.valueOf(i)).getText()).isEqualToIgnoringCase(orderDeliveryContactType);
                    assertThat(getElement("cromaOrderConfirmationStoreDeliveryAddressListXpath", String.valueOf(i)).getText()).isEqualToIgnoringCase(orderDeliveryAddress1);
                }
            }
        } else if (getContext("storeDeliveryEnableFlag").equals("true")) {
            // Confirmation pickup address verification
            String orderedCromaProductDetailsStoreDeliveryFromContext = getContext("finalProductDetailsProductStoreDeliveryAddress");
            String orderedCromaProductDetailsStoreDeliveryTypeFromContext = getContext("finalProductDetailsProductStoreDeliveryType");
            logger.info("Final ordereded product store delivery address fetch in Confirmation Page from setContext: " + orderedCromaProductDetailsCountFromContext);
            List<String> itemListOrderedProductStoreAddress = generatingProductDetailsListThroughCount(orderedCromaProductDetailsCountFromContext, orderedCromaProductDetailsStoreDeliveryFromContext, splitOption);
            List<String> itemListOrderedProductStoreAddressType = generatingProductDetailsListThroughCount(orderedCromaProductDetailsCountFromContext, orderedCromaProductDetailsStoreDeliveryTypeFromContext, splitOption);
            logger.info("itemListOrderedProductStoreAddress is: " + itemListOrderedProductStoreAddress + "itemListOrderedProductStoreAddressType is: " + itemListOrderedProductStoreAddressType);
            productComparisonValidation(getElements("cromaOrderConfirmationStoreDeliveryAddressListXpath"), itemListOrderedProductStoreAddress, comparisonOrder);
            productComparisonValidation(getElements("cromaOrderConfirmationStoreDeliveryTypeListXpath"), itemListOrderedProductStoreAddressType, comparisonOrder);
        }
        // Confirmation billing address verification
        String orderConfirmationBillingContactName = getElement("cromaOrderReceivedBillingContactXpath").getText();
        String orderConfirmationBillingAddress = getElement("cromaOrderReceivedBillingAddressXpath").getText();
        logger.info("Delivery order Confirmation Billing Address is " + orderConfirmationBillingContactName + " " + orderConfirmationBillingAddress);
        logger.info("Delivery order Confirmation Billing Address is from arg " + orderBillingContactName + " " + orderBillingContactNumber + " " + orderBillingAddress1);
        assertThat(orderConfirmationBillingContactName).describedAs("Billing contact name is not matching in order confirmation page").isEqualToIgnoringCase(orderBillingContactName);
        assertThat(orderConfirmationBillingAddress).describedAs("Billing address is not matching in order confirmation page").isEqualToIgnoringCase(orderBillingAddress1);
        // Confirmation contact information verification
        String orderConfirmationBillingContactEmailId = getElement("cromaOrderReceivedContactEmailIdXpath").getText();
        String orderConfirmationBillingContactPhoneNo = getElement("cromaOrderReceivedContactPhoneNoXpath").getText();
        assertThat(orderConfirmationBillingContactEmailId).describedAs("Contact email id is not matching in order confirmation page").isEqualToIgnoringCase(orderConfirmationEmailId1);
        assertThat(orderConfirmationBillingContactPhoneNo).describedAs("Contact phone number is not matching in order confirmation page").isEqualToIgnoringCase(orderDeliveryContactNumber);
        /*
        // Confirmation delivery mode verification
        String orderConfirmationDeliveryMode = getElement("cromaOrderReceivedDeliveryModeXpath").getText();
        // orderConfirmationDeliveryMode = orderConfirmationDeliveryMode.replace("\n", " ").replace("  ", " ").substring(confirmationDeliveryModeSubStringValue);
        orderConfirmationDeliveryMode = removeLinesBreaksMethod(removeLinesBreaksMethod(orderConfirmationDeliveryMode, replaceOption), replaceOptionOne).substring(confirmationDeliveryModeSubStringValue);
        logger.info("Delivery orderConfirmationDeliveryMode is in confirmation page " + orderConfirmationDeliveryMode + " " + orderDeliveryMode1);
        assertThat(orderConfirmationDeliveryMode).describedAs("Delivery mode is not matching in order confirmation page").isEqualTo(orderDeliveryMode1);
*/
        // Confirmation payment mode verification
        String orderConfirmationPaymentMethod = getElement("cromaOrderReceivedPaymentModeXpath").getText();
        logger.info("Payment mode is in confirmation page " + orderConfirmationPaymentMethod);
        assertThat(orderConfirmationPaymentMethod).isEqualToIgnoringCase(orderPaymentMode1);
        // Confirmation total price verification
        String orderConfirmationTotalPrice = getElement("cromaOrderTotalPriceXpath").getText();
        assertThat(orderConfirmationTotalPrice).describedAs("Total Price amount is not matching in order confirmation page").isEqualTo(orderCromaConfirmationTotalPriceFromContext);
        logger.info("Delivery orderConfirmationTotalPrice is " + orderConfirmationTotalPrice + " " + orderCromaConfirmationTotalPriceFromContext);
        //confirmation coupon amount verification
        logger.info(getContext("coupon_applied_flag_cart"));
        if (getContext("coupon_applied_flag_cart").equals("true")) {
            logger.info("Coupon title is in order confirmation page is: " + getElement("cromaOrderCouponTitle").getText() + " " + "Total Saving amount is in confirmation page: " + (numericValuesExtractionMethod(splitTextWithIndexing(getElement("totalSavingAmount").getText(), splitOption1, orderConfirmationPageScrollDownFirstIndex))) + " " + "Saved gift item amount from cart page: " + getContext("todaysFinalSaving"));
            assertThat(String.valueOf(numericValuesExtractionMethod(splitTextWithIndexing(getElement("totalSavingAmount").getText(), splitOption1, orderConfirmationPageScrollDownFirstIndex)))).isEqualTo(getContext("todaysFinalSaving"));
        }
        //confirmation gift item amount verification
        logger.info(getContext("gift_item_applied_flag_cart"));
        if (getContext("gift_item_applied_flag_cart").equals("true")) {
            logger.info("Gift item title is in order confirmation page is: " + getElement("cromaOrderGiftItemTitle").getText() + " " + "Gift item amount is in confirmation page " + getElement("cromaOrderGiftItemAmountXpath").getText() + " " + "Saved gift item amount from cart page" + getContext("finalGiftItemAmount"));
            assertThat(getElement("cromaOrderGiftItemAmountXpath").getText()).isEqualTo(getContext("finalGiftItemAmount"));
        }
        //confirmation donation amount verification
        logger.info(getContext("donation_applied_flag_cart"));
        if (getContext("donation_applied_flag_cart").equals("true")) {
            logger.info("Donation title is in order confirmation page is: " + getElement("cromaOrderDonationTitle").getText() + " " + "Donation amount is in confirmation page " + getElement("cromaOrderDonationAmountXpath").getText() + " " + "Saved gift item amount from cart page" + getContext("finalDonationAmount"));
            assertThat(getElement("cromaOrderDonationAmountXpath").getText()).isEqualTo(getContext("finalDonationAmount"));
        }
        // Setting date and order confirmation number
        setContext("cromaOrderConfirmationNumber", orderConfirmationOrderNumber);
        /*
        String orderConfirmationDate = getElement("cromaOrderConfirmationDateXpath").getText();
        setContext("cromaOrderConfirmationDate", orderConfirmationDate);
        logger.info("Substring OrderNo : " + getContext("cromaOrderConfirmationNumber") + " date is: " + getContext("cromaOrderConfirmationDate"));
        */
        windowScrollIntoViewByWebElement(getElement("cromaOrderConfirmationPageBelowContinueButtonXpath"));
        windowScrollIntoViewAdjustment(orderConfirmationPageScrollDownFirstIndex, orderConfirmationPageScrollDownLastIndex);
        processScreenshot();
        getElement("cromaOrderConfirmationPageBelowContinueButtonXpath").click();

        passStepExecution("Order confirmation page displays correct results");
    }

    @And("^user clicks on Go to cart button on order confirmation page$")
    public void userClicksOnGoToCartButtonOnOrderConfirmationPage() {
        //   conditionalWait(ExpectedConditions.elementToBeClickable(getElement("goToCartButton")), Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));
        getElement("goToCartButton").click();
    }

    @And("^user validates order placed successfully$")
    public void userValidatesOrderPlacedSuccessfully() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        logger.info("Order Confirmation page Executed");
        // Confirmation message verification
        String orderConfirmationMsg = getElement("cromaOrderReceivedMsgXpath").getText();
        logger.info("Delivery orderConfirmation msg is " + orderConfirmationMsg);
        assertThat(orderConfirmationMsg).describedAs("Order confirmation message is matching")
                .isEqualTo("Thank you for shopping with us");

        // Confirmation order no verification
        String orderConfirmationOrderNumber = getElement("cromaOrderReceivedMsgWithOrderNoXpath").getText();
        String orderProductName = getElement("cromaOrderConfirmationNameListXpath").getText();
        logger.info("Delivery orderConfirmationMsgOrder is " + orderConfirmationOrderNumber);
        String orderProductId=getElement("cromaOrderConfirmationIdListXpath").getText();
        String deliveryOption=getElement("cromaOrderConfirmationDeliveryOptionListXpath").getText();
        logger.info("Order Product Name : " + orderProductName);
        assertThat(orderConfirmationOrderNumber).describedAs("Order number message not present in order confirmation page").isNotEmpty();
        setContext("orderId", orderConfirmationOrderNumber);
        setContext("productName", orderProductName);
        setContext("productId",orderProductId);
        setContext("productDeliveryMode",deliveryOption);

    }

    @And("user validates {string} as number of products in order confirmation page")
    public void userValidatesAsNumberOfProductsInOrderConfirmationPage(String productCount) {
        ArrayList<WebElement> cartProductCountWeb = new ArrayList<>(getElements("productNames"));
        assertStepExecution(cartProductCountWeb.size(), Integer.parseInt(productCount),
                "user validates " + productCount + " as number of products in order confirmation page");

    }

    @And("user validates {string} as products names in order confirmation page")
    public void userValidatesAsProductsNamesInOrderConfirmationPage(String products) {
        ArrayList<WebElement> cartProductNameList = new ArrayList<>(getElements("productNames"));
        assertThat(cartProductNameList.size()).describedAs("Products are more than 1").isPositive();
        if (products.contains(";")) {
            String[] productNameFromExamples = products.split(";");
            for (int i = 0; i < productNameFromExamples.length; i++) {
                String productNameFromWeb = cartProductNameList.get(i).getText();
                logger.info("The product name from web is:" + productNameFromWeb);
                assertThat(productNameFromWeb).describedAs("Order Confirmation product name from web and examples are matched.").isEqualTo(productNameFromExamples[i]);
            }
        } else {
            assertThat(cartProductNameList.get(0).getText()).describedAs("Order Confirmation product name from web and examples are matched.").isEqualTo(products);
        }
        passStepExecution("Products names on Order Confirmation is verified");
    }

    @And("user validates {string} as products price in order confirmation page")
    public void userValidatesAsProductsPriceInOrderConfirmationPage(String productPrice) {
        List<WebElement> prices = getElements("productPrices");
        assertThat(prices.size()).describedAs("Prices are present there").isPositive();
        if (productPrice.contains(";")) {
            String[] priceFromExamples = productPrice.split(";");

            for (int price = 0; price < prices.size(); price++) {
                logger.info("displayed product name: " + prices.get(price).getText().substring(1));
                assertThat(priceFromExamples[price]).describedAs("Product Price is same").isEqualToIgnoringCase(prices.get(price).getText().substring(1));
            }
        } else {
            logger.info("displayed product name: " + prices.get(0).getText().substring(1));
            assertThat(productPrice).describedAs("Product price is same").isEqualToIgnoringCase(prices.get(0).getText().substring(1));

        }
    }

    @And("user validates {string} as products quantity in order confirmation page")
    public void userValidatesAsProductsQuantityInOrderConfirmationPage(String productQty) {

        List<WebElement> productQuantity = getElements("productQuantity");
        assertThat(productQuantity.size()).describedAs("product quantity are present there").isPositive();
        if (productQty.contains(";")) {
            String[] productQuantityFromExamples = productQty.split(";");

            for (int qty = 0; qty < productQuantity.size(); qty++) {

                assertThat(productQuantityFromExamples[qty]).describedAs("Product quantity is validated").isEqualToIgnoringCase(productQuantity.get(qty).getText());
            }
        } else {
            assertThat(productQty).describedAs("Product quantity is validated").isEqualToIgnoringCase(productQuantity.get(0).getText());

        }


    }

    @And("user validates {string} as products Ids in order confirmation page")
    public void userValidatesAsProductsIdsInOrderConfirmationPage(String productIds) {
        ArrayList<WebElement> productId = new ArrayList<>(getElements("productIDs"));
        assertThat(productId.size()).describedAs("No. of product should be greater than zero").isPositive();
        if (productIds.contains(";")) {
            String[] productIdFromExamples = productIds.split(";");

            for (int i = 0; i < productIdFromExamples.length; i++) {
                String productIdFromWeb = productId.get(i).getText().replaceAll("\\D", "");
                logger.info("The product in OrderSummary are" + productIdFromWeb);
                assertThat(productIdFromWeb).describedAs("Product id from web and from examples are matching").isEqualTo(productIdFromExamples[i]);

            }

        } else {
            String productIdFromWeb = productId.get(0).getText().replaceAll("\\D", "");
            logger.info("The product in OrderSummary are" + productIdFromWeb);
            assertThat(productIdFromWeb).describedAs("Product id from web and from examples are matching").isEqualTo(productIds);

        }
        passStepExecution("All productId from web and examples are matched on OrderSummary");


    }

    @And("user validates order id starts with TC on order confirmation page")
    public void userValidatesOrderIdStartsWithTCOnOrderConfirmationPage() {
        logger.info("TC Order id is : " + "Order id" + getElement("OrderIdConfirmationPage"));
        assertStepExecution(true, getElement("OrderIdConfirmationPage").getText().startsWith("TC"),
                "validates order id starts with TC on order confirmation page");
    }

    @And("user validates appropriate delivery mode is showing for all products in order confirmation page")
    public void userValidatesAppropriateDeliveryModeIsShowingForAllProductsInOrderConfirmationPage() {
        String selectedDeliveryOption = getContext("selectedDeliveryOption");
        //id = homeDelivery / storePickup / threeHourDelivery
        int totalProducts = getElements("productNames").size();
        String optionToCheck = "";
        if (selectedDeliveryOption.equals("homeDelivery")) {
            optionToCheck = "Home Delivery";
        } else if (selectedDeliveryOption.equals("storePickup")) {
            optionToCheck = "Pickup at";
        } else if (selectedDeliveryOption.equals("threeHourDelivery")) {
            optionToCheck = "Zip Delivery";
        }
        for (int product = 0; product < totalProducts; product++) {
            String deliveryOption = getElements("deliveryOptions").get(product).getText();
            logger.info("Delivery Option for Product " + (product + 1) + " : " + deliveryOption);
            assertThat(deliveryOption).describedAs(deliveryOption + " should starts with " + optionToCheck)
                    .startsWith(optionToCheck);
        }
        passStepExecution("user validates appropriate delivery mode is showing for all products in order confirmation page : Passed");
    }

    @And("user validates {string} as payment method in order confirmation page")
    public void userValidatesAsPaymentMethodInOrderConfirmationPage(String paymentMethodOrderConfirmation) throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("CONDITIONAL_LONG_WAIT")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        String value = getElement("paymentMethod").getText().trim();
        logger.info("Displayed payment tender type: " + value);
        assertStepExecution(paymentMethodOrderConfirmation, getElement("paymentMethod").getText().trim(), "user validates the payment method in order confirmation page");
        //assertThat(getContext("EMIText")).isEqualToIgnoringCase(getElement("paymentMethod").getText().trim()).describedAs("Product name on order page");
    }

    @And("user validates {string} as saving amount in order confirmation page")
    public void userValidatesAsSavingAmountInOrderConfirmationPage(String savingAmountOrderConfirmation) {
        assertStepExecution(savingAmountOrderConfirmation, getElement("savingAmount").getText(), "user validates saving amount in order confirmation page");
    }

    @And("user validates {string} as total amount in order confirmation page")
    public void userValidatesAsTotalAmountInOrderConfirmationPage(String totalAmountOrderConfirmation) {
        assertStepExecution(totalAmountOrderConfirmation, getElement("totalAmount").getText(), "user validates total amount in order confirmation page");
    }

    @And("user validates billing address in order confirmation page")
    public void userValidatesBillingAddressInOrderConfirmationPage() {
        String billingAddrDisplayed = getElement("billingAddrDisplayed").getText().substring(0, getElement("billingAddrDisplayed").getText().length() - 8).toLowerCase();
        String billingAddrFromContext = getContext("billingAddressDisplayedOnCheckoutPage").toLowerCase();
        logger.info("displayed addr on order confirmation page: " + getElement("billingAddrDisplayed").getText());
        logger.info("billingAddrDisplayed is: " + billingAddrDisplayed);
        logger.info("billingAddrFromContext is: " + billingAddrFromContext);
        assertStepExecution(true, billingAddrFromContext.contains(billingAddrDisplayed)
                , "Billing address validation in order confirmation page");


    }

    @And("user validates contact information in order confirmation page")
    public void userValidatesContactInformationInOrderConfirmationPage() {
        String displayedEmailId = getElement("emailIDDisplayed").getText();
        logger.info("displayedEmailId is: " + displayedEmailId);

        String displayedMobile = getElement("mobileNoDisplayed").getText().substring(4);
        logger.info("displayed mob no is " + displayedMobile);
        logger.info("displayedEmailId from context is: " + getContext("displayedContactEmailOnCheckoutPage"));
        logger.info("displayed mob from context is: " + getContext("displayedContactMobOnCheckoutPage"));

        assertThat(displayedEmailId).describedAs
                        ("Email id validation in order confirmation page")
                .isEqualTo(getContext
                        ("displayedContactEmailOnCheckoutPage"));
        assertThat(displayedMobile).describedAs
                        ("Mobile No validation in order confirmation page")
                .isEqualTo(getContext
                        ("displayedContactMobOnCheckoutPage"));

        passStepExecution("Contact information validation on order confirmation page");


    }

    /*
    User validates payment method with error messages
    */
    @Then("user validates payment failed for {string} with error messages {string}, {string}, {string} in order confirmation page")
    public void userValidatesPaymentFailedForWithErrorMessagesInOrderConfirmationPage(String paymentMethod, String errorMessage1, String errorMessage2, String errorMessage3) {
        logger.info("Inside Order Confirmation payment failure page");

        logger.info("displayed payment method on failure page: " + getElement("failurePagePaymentMethod",paymentMethod).getText());
        logger.info("displayed error message1 on failure page: " + getElement("failurePageErrorMessage1").getText());
        logger.info("displayed error message2 on failure page: " + getElement("failurePageErrorMessage2").getText());
        logger.info("displayed error message3 on failure page: " + getElement("failurePageErrorMessage3").getText());

        assertThat(getElement("failurePagePaymentMode", paymentMethod).getText()).describedAs("failure page price comparison not matched").isEqualToIgnoringCase(paymentMethod);
        assertThat(getElement("failurePageErrorMessage1").getText()).describedAs("failurePage error message comparison not matched").isEqualToIgnoringCase(errorMessage1);
        assertThat(getElement("failurePageErrorMessage2").getText()).describedAs("failurePage error message comparison not matched").contains(errorMessage2);
        assertThat(getElement("failurePageErrorMessage3").getText()).describedAs("failurePage error message comparison").isEqualToIgnoringCase(errorMessage3);

        //logger.info("displayed price on failure page : " + getElement("failurePageTotalAmount").getText() + "     " + getContext("finalCartOrderedTotalPrice"));
        //assertThat(getElement("failurePageTotalAmount").getText()).describedAs("failure page price comparison not matched").isEqualToIgnoringCase(getContext("finalCartOrderedTotalPrice"));

        passStepExecution("user validates payment failed for methods with error messages in order confirmation page: Passed");
    }

    /*
     User validates Retry button is present
     */
    @Then("user validates retry button is displayed")
    public void userValidatesRetryButtonIsDisplayed (){
        js.executeScript("window.scrollBy(0,200)");
        assertStepExecution(true, getElement("retryButtonOnOrderConfirmationPage").isDisplayed(), "user clicked on retry button in order confirmation page");
    }
    /*
     User clicks on Retry button
     */
    @And("user clicks on retry button in order confirmation page")
    public void userClicksOnRetryButtonInOrderConfirmationPage() throws InterruptedException {
        js.executeScript("window.scrollBy(0,400)");
        conditionalWait(ExpectedConditions.visibilityOf(getElement("retryButtonOnOrderConfirmationPage")), Integer.parseInt(getConfig("CONDITIONAL_LOW_WAIT")));
        getElement("retryButtonOnOrderConfirmationPage").click();
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("POLLING_WAIT")));
        Thread.sleep(5000);
        if (getOptionalElement("offerPopupSkipOnPayment") != null) {
            getElement("offerPopupSkipOnPayment").click();
        }
        assertStepExecution(true, getOptionalElement("paymentPageValidation") != null, "Navigated to Payment Page");


    }

    @And("user validates appropriate delivery option in order confirmation page")
    public void userValidatesAppropriateDeliveryOptionInOrderConfirmationPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        logger.info("StorePickupDeliveryOptionSelected");
        assertStepExecution(true, getElement("storePickUpImageXpath").isDisplayed(), "user has selected store pickup delivery");

    }

    /*
      User clicks on myOrders button
         */
    @And("User clicks on MyOrders button in Order Confirmation page")
    public void userClicksOnMyOrdersButtonInOrderConfirmationPage() throws InterruptedException {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LONG")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LONG")));
        Thread.sleep(3000);
        assertStepExecution(true, getElement("myOrdersButton").isDisplayed(), "My Orders button in present in order confirmation page");
        getElement("myOrdersButton").click();
    }

    @Then("user validates the order not processed page")
    public void userValidatesTheOrderNotProcessedPage() {
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertStepExecution(true, getElement("OrderNotProcessed").isDisplayed(),"User validates after 3 retry attempts landing on Order Not Processed page");

    }

    @And("user store the order id in order confirmation page")
    public void userStoreTheOrderIdInOrderConfirmationPage() throws IOException {
        Date objDate = new Date();
        BufferedWriter bW = fileWrite(getConfig("Text_File_Path"));
        logger.info(objDate.toString());
        logger.info("Product availability message: " + getContext("orderId") + "\n" + "Pincode: "+getContext("pinCode_applied")+ "\n" + "SKU ID: " +getContext("searchProduct")+ "\n" +"Product id in Order confirmation page"+getContext("productId")+"Product delivery mode"+getContext("productDeliveryMode")+"Product Name"+getContext("productName")+"time slot"+getContext("timeSlot")+ "Date and Time: " + objDate.toString() + " In " + getConfig("URL") + "\n\n");
        bW.write("Mobile Number: "+getContext("saved_user_mobile_number") + "\n" +"Order ID: "+ getContext("orderId") + "\n" +"Pincode: "+getContext("pinCode_applied")+ "\n" + "SKU ID: " +getContext("searchProduct")+ "\n" + "Product ID from order confirmation page: "+getContext("productId")+ "\n" + "Delivery mode from order confirmation page: "+getContext("productDeliveryMode") + "\n"+ "Product name from order confirmation page: " +getContext("productName")+"\n" + "Time slot from checkout page: "+"time slot"+getContext("timeSlot") +"\n" + "Date and Time: " + objDate.toString() + " In " + getConfig("URL") + "\n\n");
        bW.close();

    }

    @Then("user validates {string} is present on the payments details of order confirmation page")
    public void userValidatesIsPresentOnThePaymentsDetailsOfOrderConfirmationPage(String tendersPaymentMethods) {
        windowScrollIntoViewByWebElement(getElement("tendersPaymentMethod",tendersPaymentMethods));
        String value = getElement("tendersPaymentMethod",tendersPaymentMethods).getText().trim();
        logger.info("Displayed payment tenders in payment details : " + value);
        assertStepExecution(value, tendersPaymentMethods, "user validates the payment method in order confirmation page");
        //assertThat(getContext("emiText")).isEqualToIgnoringCase(getElement("tendersPaymentMethod",tendersPaymentMethods).getText().trim()).describedAs("User validates the EMI tender name in Payment page");
    }
    /*
      User validates "rupee" symbol against Discount in order confirmation page
     */
    @And("user should verify {string} symbol against Discount")
    public void userShouldVerifySymbolAgainstDiscount(String rupeeSymbol) throws InterruptedException {
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        if (getOptionalElement("MRPDiscount") != null) {
            assertThat(rupeeSymbol.contains("rupeeInMRPDiscount")).describedAs("User validates rupee symbol against MRP Discount in order confirmation page");
        }if(getOptionalElement("couponDiscount") != null) {
            assertThat(rupeeSymbol.contains("rupeeInCouponDiscount")).describedAs("User validates rupee symbol against Coupon Discount in order confirmation page");
        }
    }
    /*
     user validates No "rupee" symbol against NeuCoins in order confirmation page
    */
    @Then("user validate no rupee symbol against NeuCoins")
    public void userValidateNoRupeeSymbolAgainstNeuCoins() {
        js.executeScript("window.scrollBy(0,1800)");
        waitForJavascript(Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LIMIT_LOW")), Integer.parseInt(getConfig("PAGE_LOAD_WAIT_LOW")));
        assertThat(!getElement("neuCoinsValueInPaymentDetails").getText().contains("₹")).describedAs("User verified no rupee symbol against NeuCoins in order confirmation page").isEqualTo(true);
    }

    /*
      user validate today's saving line item should removed
     */
    @Then("user validate today's saving line item should removed")
    public void userValidateTodaySSavingLineItemShouldRemoved() {
     assertThat("SavingTextInPaymentDetails").doesNotContain("Today's Saving").doesNotContainAnyWhitespaces().describedAs("user validate today's saving line is not present");
    }

    /*
    user validates order details are present in order confirmation page
     */
    @Then("user validates order details are present in order confirmation page")
    public void userValidatesOrderDetailsArePresentInOrderConfirmationPage() {
        js.executeScript("window.scrollBy(0,400)");
        logger.info("productIDs : " + getElement("productIDs").getText() + "\n" + "deliveryOptions :" + getElement("deliveryOptions").getText() + "\n" + "billingAddrDisplayed :" + getElement("billingAddrDisplayed").getText() + "\n" + "paymentMethod :" + getElement("paymentMethod").getText() + "\n" + "itemTotal :" + getElement("itemTotal").getText() + "\n" + "deliveryCharges :" + getElement("deliveryCharges").getText() + "\n" + "savingAmount :" + getElement("savingAmount").getText() + "\n" + "rupeeInMRPDiscount :" + getElement("rupeeInMRPDiscount").getText()+ "\n" + "rupeeInCouponDiscount :" + getElement("rupeeInCouponDiscount").getText()+ "\n" + "totalAmount :" + getElement("totalAmount").getText());
        assertThat(getElement("productIDs").getText()).describedAs("Product id on order confirmation  page");
        assertThat(getElement("deliveryOptions").getText()).describedAs("Delivery option on order confirmation page").isNotEmpty();
        assertThat(getElement("billingAddrDisplayed").getText()).describedAs("Billing address on order confirmation page").isNotEmpty();
        assertThat(getElement("paymentMethod").getText()).describedAs("Payment method on order confirmation page").isNotEmpty();
        assertThat(getElement("itemTotal").getText()).describedAs("item total on order confirmation page").isNotEmpty();
        assertThat(getElement("deliveryCharges").getText()).describedAs("Delivery charges on order confirmation page").isNotEmpty();
        assertThat(getElement("savingAmount").getText()).describedAs("saving amount on order confirmation page").isNotEmpty();
        assertThat(getElement("rupeeInMRPDiscount").getText()).describedAs("MRP discount on order confirmation page").isNotEmpty();
        assertThat(getElement("rupeeInCouponDiscount").getText()).describedAs("coupon discount on order confirmation page").isNotEmpty();
        assertThat(getElement("totalAmount").getText()).describedAs("total ammount on order confirmation page").isNotEmpty();

        passStepExecution("User validates order history details in order confirmation page");
    }

    @Then("user validate the order confirmation page {string}")
    public void userValidateTheOrderConfirmationPage(String orderConfirmationPageValidation) {
        assertStepExecution(orderConfirmationPageValidation, getElement("orderConfirmationPageValidation", orderConfirmationPageValidation).getText(), "user is on Order confirmation page");
        String CurrentUrl = getDriver().getCurrentUrl();
        assertThat(CurrentUrl.contains("order-confirmation")).describedAs("user should lands on order-confirmation page");
    }

    @And("user validates {string} as billing address in order confirmation page")
    public void userValidatesAsBillingAddressInOrderConfirmationPage(String arg0) {
        conditionalWait(ExpectedConditions.visibilityOf(getElement("")),Integer.parseInt(getConfig("CONDITIONAL_MED_WAIT")));

    }
}
